import { useEffect, useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import MenuItem from "@mui/material/MenuItem";
import Stack from "@mui/material/Stack";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import CheckIcon from "@mui/icons-material/Check";

import { findAvailableStarts, fmtTime12, hasConflict } from "../../utils/scheduling.js";

export default function RescheduleForm({
  booking,
  bookings,
  customerById,
  onSubmit,
}) {
  const [date, setDate] = useState(booking.date);
  const [time, setTime] = useState(booking.startTime || "");
  const availableStarts = useMemo(
    () =>
      findAvailableStarts(date, booking.bathroomCount, bookings, booking.id),
    [date, booking, bookings],
  );
  const hasSelectedConflict = hasConflict(
    date,
    time,
    booking.bathroomCount,
    bookings,
    booking.id,
  );

  useEffect(() => {
    if (!availableStarts.includes(time)) setTime(availableStarts[0] || "");
  }, [availableStarts]); // eslint-disable-line

  return (
    <Box>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 2 }}>
        {customerById[booking.customerId]?.name} · {booking.bathroomCount}{" "}
        bathroom{booking.bathroomCount > 1 ? "s" : ""}
      </Typography>
      <Stack spacing={2} sx={{ mb: 2 }}>
        <TextField
          fullWidth
          size="small"
          type="date"
          label="New date"
          InputLabelProps={{ shrink: true }}
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
        <TextField
          select
          fullWidth
          size="small"
          label="New start time"
          value={time}
          onChange={(e) => setTime(e.target.value)}
        >
          {availableStarts.length === 0 && (
            <MenuItem value="">No slots free</MenuItem>
          )}
          {availableStarts.map((start) => (
            <MenuItem key={start} value={start}>
              {fmtTime12(start)}
            </MenuItem>
          ))}
        </TextField>
      </Stack>
      {hasSelectedConflict && (
        <Typography variant="caption" color="error" sx={{ display: "block", mb: 2 }}>
          This time overlaps another booking or falls outside working hours.
        </Typography>
      )}
      <Button
        fullWidth
        variant="contained"
        startIcon={<CheckIcon />}
        disabled={!time || hasSelectedConflict}
        onClick={() => {
          if (!hasConflict(date, time, booking.bathroomCount, bookings, booking.id)) {
            onSubmit(booking.id, date, time);
          }
        }}
      >
        Confirm reschedule
      </Button>
    </Box>
  );
}