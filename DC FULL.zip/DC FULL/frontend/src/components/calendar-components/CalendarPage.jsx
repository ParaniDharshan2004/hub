import { useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import Box from "@mui/material/Box";
import CalendarHeader from "./CalendarHeader.jsx";
import CalendarDatePicker from "./CalendarDatePicker.jsx";
import RouteByBlock from "./RouteByBlock.jsx";
import DayTimeline from "./DayTimeline.jsx";
import BookingDetailsDialog from "./BookingDetailsDialog.jsx";
import { toDateStr } from "../../utils/scheduling.js";
import CompleteJobForm from "./CompleteJobForm.jsx";

export default function CalendarPage({
  selectedDate,
  setSelectedDate,
  dayBookings,
  bookings,
  customerById,
  onComplete,
  onPrintServices,
  durationByBathrooms,
}) {
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [completeTarget, setCompleteTarget] = useState(null);
  const monthCursor = selectedDate.slice(0, 7);
  const activeBookings = dayBookings.filter((booking) => booking.status !== "cancelled");
  const completedCount = activeBookings.filter((booking) => booking.status === "completed").length;
  const conflictCount = activeBookings.filter((booking) => booking.status === "conflict").length;
  const today = toDateStr(new Date());

  return (
    <Box sx={{ width: "100%", pb: 3 }}>
      <CalendarHeader
        selectedDate={selectedDate}
        onToday={() => setSelectedDate(today)}
        totalCount={activeBookings.length}
        completedCount={completedCount}
        conflictCount={conflictCount}
      />

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "minmax(0, 1fr)",
            lg: "minmax(0, 3fr) minmax(0, 7fr)",
          },
          gridTemplateAreas: {
            xs: '"picker" "timeline" "route"',
            lg: '"picker timeline" "route timeline"',
          },
          gridTemplateRows: {
            lg: "auto 1fr",
          },
          gap: { xs: 2, lg: 2 },
          alignItems: "start",
        }}
      >
        <Box sx={{ gridArea: "timeline", minWidth: 0 }}>
          <DayTimeline
            selectedDate={selectedDate}
            setSelectedDate={setSelectedDate}
            dayBookings={dayBookings}
            customerById={customerById}
            onComplete={setCompleteTarget}
            durationByBathrooms={durationByBathrooms}
            onBookingClick={setSelectedBooking}
          />
        </Box>

        <Box sx={{ gridArea: "picker", minWidth: 0 }}>
          <CalendarDatePicker
            monthCursor={monthCursor}
            selectedDate={selectedDate}
            setSelectedDate={setSelectedDate}
            bookings={bookings}
          />
        </Box>

        <Box sx={{ gridArea: "route", minWidth: 0 }}>
          <RouteByBlock
            bookings={dayBookings}
            customerById={customerById}
            selectedDate={selectedDate}
            onPrintServices={onPrintServices}
          />
        </Box>
      </Box>

      <BookingDetailsDialog
        booking={selectedBooking}
        customerById={customerById}
        durationByBathrooms={durationByBathrooms}
        onClose={() => setSelectedBooking(null)}
      />

      <Dialog open={!!completeTarget} onClose={() => setCompleteTarget(null)} fullWidth maxWidth="xs">
        <DialogTitle>Mark job completed</DialogTitle>
        <DialogContent>
          {completeTarget && <CompleteJobForm booking={completeTarget} customerById={customerById} onSubmit={async (...args) => { await onComplete(...args); setCompleteTarget(null); }} />}
        </DialogContent>
      </Dialog>

    </Box>
  );
}