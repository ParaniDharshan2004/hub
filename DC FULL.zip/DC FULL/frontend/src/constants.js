export const BRAND = {
  black: '#111111',
  greenDark: '#0F5C57',
};

export const DAY_START_MIN = 8 * 60;
export const DAY_END_MIN = 19 * 60 + 30;
