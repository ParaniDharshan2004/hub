import { useMemo, useState } from 'react';
import dayjs from 'dayjs';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import CalendarPage from '../../components/calendar-components/CalendarPage.jsx';
import ServiceAreaPrintable from '../../components/calendar-components/ServiceAreaPrintable.jsx';
import { useSnackbar } from '../../components/common-components/SnackbarProvider';
import { listVisits } from '../../api/visits.js';

function timeFromSlotId(slotId) {
  const match = String(slotId || '').match(/-(\d+)$/);
  if (!match) return '';
  const minutes = Number(match[1]);
  if (minutes < 0 || minutes > 1439) return '';
  return `${String(Math.floor(minutes / 60)).padStart(2, '0')}:${String(minutes % 60).padStart(2, '0')}`;
}

function toCalendarBooking(visit) {
  const customer = visit.customerId && typeof visit.customerId === 'object' ? visit.customerId : {};
  const booking = visit.bookingId && typeof visit.bookingId === 'object' ? visit.bookingId : {};
  const scheduledDate = visit.scheduledDate || visit.date || booking.scheduledDate || booking.startDateTime;
  const bathroomCount = booking.bathroomCountId?.bathroomCount || 1;
  const date = scheduledDate
    ? String(scheduledDate).slice(0, 10)
    : '';
  const slotTime = timeFromSlotId(booking.slotId || visit.slotId);
  const duration = Number(
    booking.durationMinutes
    || booking.serviceDurationId?.durationMinutes
    || 60,
  );
  const startDateTime = booking.startDateTime || visit.startDateTime;
  const hasRealTime = startDateTime && dayjs(startDateTime).isValid() && !String(startDateTime).includes('T00:00');
  const hasScheduledTime = typeof scheduledDate === 'string'
    && scheduledDate.includes('T')
    && !scheduledDate.includes('T00:00');
  const startTime = slotTime
    || (hasScheduledTime ? dayjs(scheduledDate).format('HH:mm') : '')
    || (hasRealTime ? dayjs(startDateTime).format('HH:mm') : '')
    || '08:00';
  return {
    id: visit._id,
    visitNumber: visit.visitNumber || booking.bookingId || visit._id,
    bookingNumber: booking.bookingId || visit.visitNumber || visit._id,
    customerId: customer._id || visit.customerId,
    date,
    startTime,
    bathroomCount,
    duration,
    status: visit.isCancelled ? 'cancelled' : visit.isCompleted ? 'completed' : 'scheduled',
    blockNumber: customer.block || '',
    area: customer.area || '',
  };
}

async function updateVisit(id, changes) {
  const response = await fetch(`/api/visits/${id}`, {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(changes),
  });
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.message || 'Could not update the visit');
  }
  return response.json();
}

export default function ServiceCalendarPage() {
  const queryClient = useQueryClient();
  const snackbar = useSnackbar();
  const [selectedDate, setSelectedDate] = useState(dayjs().format('YYYY-MM-DD'));
  const [printData, setPrintData] = useState(null);
  const { data: visits = [], isLoading, isError, error, refetch } = useQuery({
    queryKey: ['visits', 'service-calendar'],
    queryFn: () => listVisits(),
  });
  const mutation = useMutation({
    mutationFn: ({ id, changes }) => updateVisit(id, changes),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['visits'] });
      queryClient.invalidateQueries({ queryKey: ['subscriptions'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard'] });
      queryClient.invalidateQueries({ queryKey: ['customers'] });
      snackbar.success('Service marked as completed.');
    },
  });

  const bookings = useMemo(() => visits.map(toCalendarBooking), [visits]);
  const durationByBathrooms = useMemo(() => bookings.reduce((durations, booking) => {
    if (!durations[booking.bathroomCount]) durations[booking.bathroomCount] = booking.duration;
    return durations;
  }, {}), [bookings]);
  const customerById = useMemo(() => {
    const customers = {};
    visits.forEach((visit) => {
      if (visit.customerId && typeof visit.customerId === 'object') {
        customers[visit.customerId._id] = {
          ...visit.customerId,
          phone: visit.customerId.phoneNumber,
          blockNumber: visit.customerId.block || '',
        };
      }
    });
    return customers;
  }, [visits]);
  const dayBookings = bookings.filter((booking) => booking.date === selectedDate);

  if (isLoading) return <div style={{ padding: 32 }}>Loading service calendar...</div>;
  if (isError) return <div style={{ padding: 32 }}>Could not load service calendar: {error.message} <button type="button" onClick={refetch}>Try again</button></div>;

  const printServices = (data) => {
    setPrintData(data);
    window.setTimeout(() => window.print(), 0);
  };

  return (
    <>
      <CalendarPage
        selectedDate={selectedDate}
        setSelectedDate={setSelectedDate}
        dayBookings={dayBookings}
        bookings={bookings}
        customerById={customerById}
        durationByBathrooms={durationByBathrooms}
        onComplete={(id) => mutation.mutateAsync({ id, changes: { isCompleted: true, isPending: false, actualEndDateTime: new Date().toISOString() } })}
        onPrintServices={printServices}
      />
      <div id="service-area-print-area">
        {printData && <ServiceAreaPrintable {...printData} />}
      </div>
    </>
  );
}
