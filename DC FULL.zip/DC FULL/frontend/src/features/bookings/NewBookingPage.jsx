/**
 * NewBookingPage.jsx
 * -----------------------------------------------------------------------
 * Multi-step wizard (Customer & Requirements, Schedule, Review & Confirm)
 * for creating confirmed bookings with real-time bill quoting.
 * -----------------------------------------------------------------------
 */

import { useEffect, useMemo, useState } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import dayjs from 'dayjs';

import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Stepper from '@mui/material/Stepper';
import Step from '@mui/material/Step';
import StepLabel from '@mui/material/StepLabel';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Autocomplete from '@mui/material/Autocomplete';
import Button from '@mui/material/Button';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Chip from '@mui/material/Chip';
import CircularProgress from '@mui/material/CircularProgress';
import Box from '@mui/material/Box';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';

import PageHeader from '../../components/common-components/PageHeader';
import BillSummary from '../../components/common-components/BillSummary';
import { useSnackbar } from '../../components/common-components/SnackbarProvider';
import { listCustomers, listAddressesForCustomer } from '../../api/customers';
import { createBooking, confirmBooking, quotePricing, listBookings } from '../../api/bookings';
import { getBookingMasters } from '../../api/bookingMasters';
import { serviceAreas } from '../../api/masters';
import { hasConflict, timeFromSlotId } from '../../utils/scheduling';

/**
 * Validation schema for the booking form across all wizard steps.
 */
const schema = z.object({
  customer: z.any().refine((v) => !!v, 'Select a customer'),
  address: z.any().refine((v) => !!v, 'Select a service address'),
  bathrooms: z.number({ invalid_type_error: 'Select number of bathrooms' }).min(1).max(4),
  frequencyId: z.string().min(1, 'Select a frequency'),
  planId: z.string().min(1, 'Select a plan'),
  discount: z.number().min(0).default(0),
  discountReason: z.string().optional().or(z.literal('')),
  startDate: z.any().refine((v) => !!v, 'Select a start date'),
  slotId: z.string().min(1, 'Select a service slot'),
  paymentModeId: z.string().min(1, 'Select a payment mode'),
  receiverAccountId: z.string().min(1, 'Select a receiver bank type'),
  paymentReference: z.string().optional().or(z.literal('')),
});

const DISCOUNT_APPROVAL_THRESHOLD = 300;
const steps = ['Customer & Requirements', 'Schedule', 'Review & Confirm'];

/**
 * Interactive step-by-step booking creation page component.
 */
export default function NewBookingPage() {
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [searchParams] = useSearchParams();
  const snackbar = useSnackbar();
  const [activeStep, setActiveStep] = useState(0);
  const [customerInput, setCustomerInput] = useState('');
  const { data: bookingMasters = { bathrooms: [], frequencies: [], plans: [], slots: [], slotsByBathroom: {}, durationByBathroom: {}, paymentAccounts: [], paymentMethods: [] }, isLoading: loadingBookingMasters } = useQuery({
    queryKey: ['booking-masters-v2'],
    queryFn: getBookingMasters,
    staleTime: 5 * 60 * 1000,
  });

  const {
    control,
    watch,
    trigger,
    handleSubmit,
    setValue,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      customer: null,
      address: null,
      bathrooms: '',
      frequencyId: '',
      planId: '',
      discount: 0,
      discountReason: '',
      startDate: dayjs().add(1, 'day'),
      slotId: '',
      paymentModeId: '',
      receiverAccountId: '',
      paymentReference: '',
    },
  });

  const values = watch();
  const selectedDuration = bookingMasters.durationByBathroom?.[String(values.bathrooms)];
  const durationByBathroom = bookingMasters.durationByBathroom || {};
  const { data: existingBookings = [] } = useQuery({
    queryKey: ['booking-availability'],
    queryFn: () => listBookings(),
    staleTime: 30 * 1000,
  });
  const bookedSlotsForDate = existingBookings
    .filter((booking) => String(booking.startDate || '').slice(0, 10) === values.startDate?.format('YYYY-MM-DD'))
    .map((booking) => ({
      id: booking.id,
      date: String(booking.startDate || '').slice(0, 10),
      startTime: timeFromSlotId(booking.slotId),
      bathroomCount: booking.bathrooms,
      status: booking.status,
    }));
  const availableSlots = values.bathrooms
    ? (bookingMasters.slotsByBathroom?.[String(values.bathrooms)] || []).filter((slot) => !hasConflict(
      values.startDate?.format('YYYY-MM-DD'),
      timeFromSlotId(slot.id),
      values.bathrooms,
      bookedSlotsForDate,
      undefined,
      durationByBathroom,
    ))
    : [];

  useEffect(() => {
    if (values.slotId && !availableSlots.some((slot) => slot.id === values.slotId)) {
      setValue('slotId', '', { shouldValidate: true });
    }
  }, [availableSlots, setValue, values.slotId]);

  /** Fetch matching customer options as user types */
  const { data: customerOptions = [], isFetching: loadingCustomers } = useQuery({
    queryKey: ['customer-options', customerInput],
    queryFn: () => listCustomers({ search: customerInput }),
  });

  /** Auto-prefill customer if customer query parameter exists */
  useEffect(() => {
    const prefillNumber = searchParams.get('customer');
    if (!prefillNumber) return;
    listCustomers({ search: prefillNumber }).then((rows) => {
      const match = rows.find((r) => r.customerNumber === prefillNumber);
      if (match) setValue('customer', match, { shouldValidate: true });
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  /** Fetch address options whenever customer selection changes */
  const { data: addressOptions = [] } = useQuery({
    queryKey: ['addresses-for-customer', values.customer?.id],
    queryFn: () => listAddressesForCustomer(values.customer.id),
    enabled: !!values.customer,
  });

  /** Auto-prefill address if address query parameter exists */
  useEffect(() => {
    const prefillAddress = searchParams.get('address');
    if (!prefillAddress || addressOptions.length === 0) return;
    const match = addressOptions.find((a) => a.addressNumber === prefillAddress);
    if (match) setValue('address', match, { shouldValidate: true });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [addressOptions]);

  /** Real-time financial price calculation breakdown */
  const quote = useMemo(
    () =>
      quotePricing({
        planId: values.planId,
        frequencyId: values.frequencyId,
        bathrooms: values.bathrooms,
        discount: Number(values.discount) || 0,
        planOptions: bookingMasters.plans,
        frequencyOptions: bookingMasters.frequencies,
      }),
    [bookingMasters.frequencies, bookingMasters.plans, values.planId, values.frequencyId, values.bathrooms, values.discount]
  );

  const requiresDiscountApproval = quote && quote.authorizedDiscount >= DISCOUNT_APPROVAL_THRESHOLD;

  const buildBookingPayload = () => ({
    customerId: values.customer.id,
    addressId: values.address.id,
    bathrooms: values.bathrooms,
    frequencyId: values.frequencyId,
    planId: values.planId,
    planOptions: bookingMasters.plans,
    frequencyOptions: bookingMasters.frequencies,
    discount: Number(values.discount) || 0,
    discountReason: values.discountReason,
    startDate: values.startDate.format('YYYY-MM-DD'),
    slotId: values.slotId,
  });

  /** Creates and confirms the booking in the final step. */
  const confirmMutation = useMutation({
    mutationFn: async () => {
      const booking = await createBooking(buildBookingPayload());
      return confirmBooking(booking.bookingNumber, {
        paymentModeId: values.paymentModeId,
        receiverAccountId: values.receiverAccountId,
        paymentReference: values.paymentReference,
      });
    },
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['bookings'] });
      queryClient.invalidateQueries({ queryKey: ['booking', result.booking.bookingNumber] });
      queryClient.invalidateQueries({ queryKey: ['visits'] });
      queryClient.invalidateQueries({ queryKey: ['dashboard'] });
      snackbar.success(`Payment ${result.payment.paymentNumber} recorded successfully.`);
      snackbar.success(`Booking confirmed. Invoice ${result.invoice.invoiceNumber} is ready.`);
      navigate(`/bookings/${result.booking.bookingNumber}`);
    },
    onError: (err) => snackbar.error(err.message),
  });

  /** Advances step after validating active step fields */
  const handleNext = async () => {
    const stepFields = [
      ['customer', 'address', 'bathrooms', 'frequencyId', 'planId'],
      ['startDate', 'slotId'],
    ][activeStep];
    const valid = await trigger(stepFields);
    if (!valid) return;

    setActiveStep((s) => s + 1);
  };

  /** Trigger final booking confirmation */
  const onConfirm = () => confirmMutation.mutate();
  const selectedAddress = [
    values.address?.doorNo,
    values.address?.block,
    values.address?.community,
    values.address?.addressLine,
    values.address?.area,
    values.address?.city,
    values.address?.pincode,
  ]
    .filter(Boolean)
    .join(', ');

  return (
    <Box sx={{ bgcolor: 'background.default', minHeight: '100vh', p: { xs: 2, sm: 3.5 } }}>
      <PageHeader
        title="New Booking"
        subtitle="Create a new service booking with auto-priced quotes and instant scheduling."
        breadcrumbs={[{ label: 'Bookings', path: '/bookings' }, { label: 'New' }]}
      />

      <Paper variant="outlined" sx={{ p: { xs: 2.5, sm: 3 }, mb: 3, borderRadius: 3 }}>
        <Stepper activeStep={activeStep} alternativeLabel>
          {steps.map((label) => (
            <Step key={label}>
              <StepLabel>{label}</StepLabel>
            </Step>
          ))}
        </Stepper>
      </Paper>

      <Grid container spacing={3}>
        <Grid item xs={12} md={7}>
          <Paper variant="outlined" sx={{ p: { xs: 2.5, sm: 3.5 }, borderRadius: 3 }}>
            {activeStep === 0 && (
              <Stack spacing={2.5}>
                <Typography variant="h6" sx={{ fontWeight: 700, color: 'text.primary' }}>
                  Customer & Requirements
                </Typography>

                <Controller
                  name="customer"
                  control={control}
                  render={({ field }) => (
                    <Autocomplete
                      options={customerOptions}
                      loading={loadingCustomers}
                      getOptionLabel={(o) => (o ? `${o.name} (${o.mobile})` : '')}
                      isOptionEqualToValue={(o, v) => o.id === v.id}
                      value={field.value}
                      onChange={(_, v) => {
                        field.onChange(v);
                        setValue('address', null);
                      }}
                      onInputChange={(_, v) => setCustomerInput(v)}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="Customer"
                          required
                          error={!!errors.customer}
                          helperText={errors.customer?.message || 'Search by name or phone number'}
                        />
                      )}
                    />
                  )}
                />

                <Controller
                  name="address"
                  control={control}
                  render={({ field }) => (
                    <Autocomplete
                      options={addressOptions}
                      disabled={!values.customer}
                      getOptionLabel={(o) =>
                        o
                          ? `${serviceAreas.find((a) => a.id === o.area)?.name || o.area || o.label}${o.addressLine ? ` — ${o.addressLine}` : ''}`
                          : ''
                      }
                      isOptionEqualToValue={(o, v) => o.id === v.id}
                      value={field.value}
                      onChange={(_, v) => field.onChange(v)}
                      renderInput={(params) => (
                        <TextField
                          {...params}
                          label="Service Address"
                          required
                          error={!!errors.address}
                          helperText={errors.address?.message || (!values.customer ? 'Select a customer first' : ' ')}
                        />
                      )}
                    />
                  )}
                />

                <Stack direction="row" spacing={2}>
                  <Controller
                    name="bathrooms"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        select
                        label="No. of Bathrooms"
                        required
                        fullWidth
                        disabled={loadingBookingMasters}
                        {...field}
                        onChange={(e) => field.onChange(Number(e.target.value))}
                        error={!!errors.bathrooms}
                        helperText={errors.bathrooms?.message}
                      >
                        {bookingMasters.bathrooms.map((bathroom) => (
                          <MenuItem key={bathroom.id} value={bathroom.value}>
                            {bathroom.label}
                          </MenuItem>
                        ))}
                      </TextField>
                    )}
                  />
                </Stack>

                <Stack direction="row" spacing={2}>
                  <Controller
                    name="frequencyId"
                    control={control}
                    render={({ field }) => (
                      <TextField select label="Cleaning Frequency" required fullWidth disabled={loadingBookingMasters} {...field} error={!!errors.frequencyId} helperText={errors.frequencyId?.message}>
                        {bookingMasters.frequencies.map((f) => (
                          <MenuItem key={f.id} value={f.id}>
                            {f.name}
                          </MenuItem>
                        ))}
                      </TextField>
                    )}
                  />
                  <Controller
                    name="planId"
                    control={control}
                    render={({ field }) => (
                      <TextField select label="Subscription Plan" required fullWidth disabled={loadingBookingMasters} {...field} error={!!errors.planId} helperText={errors.planId?.message}>
                        {bookingMasters.plans.map((p) => (
                          <MenuItem key={p.id} value={p.id}>
                            {p.name}
                          </MenuItem>
                        ))}
                      </TextField>
                    )}
                  />
                </Stack>

                <Divider />
                <Stack direction="row" spacing={2}>
                  <Controller
                    name="discount"
                    control={control}
                    render={({ field }) => (
                      <TextField
                        label="Optional Discount (₹)"
                        type="number"
                        fullWidth
                        disabled
                        {...field}
                        onChange={(e) => field.onChange(Number(e.target.value))}
                      />
                    )}
                  />
                  <Controller
                    name="discountReason"
                    control={control}
                    render={({ field }) => <TextField label="Discount Reason" fullWidth {...field} disabled />}
                  />
                </Stack>
                {requiresDiscountApproval && (
                  <Chip
                    size="small"
                    color="warning"
                    label="This discount exceeds the auto-approval threshold and requires a reason before confirmation."
                    sx={{ height: 'auto', py: 0.75, borderRadius: 2, '& .MuiChip-label': { whiteSpace: 'normal' } }}
                  />
                )}
              </Stack>
            )}

            {activeStep === 1 && (
              <Stack spacing={2.5}>
                <Typography variant="h6" sx={{ fontWeight: 700, color: 'text.primary' }}>
                  Schedule
                </Typography>
                <Controller
                  name="startDate"
                  control={control}
                  render={({ field }) => (
                    <DatePicker
                      label="Service Start Date"
                      value={field.value}
                      onChange={field.onChange}
                      minDate={dayjs()}
                      slotProps={{
                        textField: { fullWidth: true, error: !!errors.startDate, helperText: errors.startDate?.message },
                        popper: { placement: 'top-start' },
                        actionBar: {
                          actions: ['clear', 'today'],
                          sx: { justifyContent: 'space-between', px: 1 },
                        },
                      }}
                    />
                  )}
                />
                <Controller
                  name="slotId"
                  control={control}
                  render={({ field }) => (
                    <TextField select label={selectedDuration ? `Available Service Slot (${selectedDuration} minutes)` : 'Available Service Slot'} required fullWidth {...field} error={!!errors.slotId} helperText={errors.slotId?.message || (!values.bathrooms ? 'Select bathrooms first' : '')}>
                      {availableSlots.map((s) => (
                        <MenuItem key={s.id} value={s.id}>
                          {s.label}
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                />
              </Stack>
            )}

            {activeStep === 2 && (
              <Stack spacing={2.5}>
                <Typography variant="h6" sx={{ fontWeight: 700, color: 'text.primary' }}>
                  Review & Confirm
                </Typography>
                <Paper variant="outlined" sx={{ p: 2, bgcolor: '#F8FAF9', borderRadius: 2 }}>
                  <Stack spacing={0.75}>
                    <Typography variant="body2">
                      <strong>{values.customer?.name}</strong> · {values.customer?.mobile}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {selectedAddress}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      Start: {values.startDate?.format('DD MMM YYYY')} · Slot: {bookingMasters.slots.find((s) => s.id === values.slotId)?.label}
                    </Typography>
                  </Stack>
                </Paper>
                <Divider />
                <Controller
                  name="paymentModeId"
                  control={control}
                  render={({ field }) => (
                    <TextField select label="Payment Mode Received" required fullWidth {...field} error={!!errors.paymentModeId} helperText={errors.paymentModeId?.message}>
                      {bookingMasters.paymentMethods.map((m) => (
                        <MenuItem key={m.id} value={m.id}>
                          {m.name}
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                />
                <Controller
                  name="receiverAccountId"
                  control={control}
                  render={({ field }) => (
                    <TextField select label="Receiver Bank Type" required fullWidth disabled={loadingBookingMasters} {...field} error={!!errors.receiverAccountId} helperText={errors.receiverAccountId?.message}>
                      {bookingMasters.paymentAccounts.map((account) => (
                        <MenuItem key={account.id} value={account.id}>
                          {account.name}
                        </MenuItem>
                      ))}
                    </TextField>
                  )}
                />
                <Controller
                  name="paymentReference"
                  control={control}
                  render={({ field }) => <TextField label="Payment Reference (optional)" fullWidth {...field} />}
                />
                <Typography variant="caption" color="text.secondary">
                  Confirming will record the payment already collected, generate the invoice, activate the subscription, and
                  schedule all service visits in one step.
                </Typography>
              </Stack>
            )}

            <Stack direction="row" justifyContent="space-between" sx={{ mt: 4 }}>
              <Button disabled={activeStep === 0} onClick={() => setActiveStep((s) => s - 1)}>
                Back
              </Button>
              <Stack direction="row" spacing={1.5}>
                {activeStep < 2 ? (
                  <Button
                    variant="contained"
                    onClick={handleNext}
                    sx={{
                      color: '#FFFFFF',
                      '&.Mui-disabled': {
                        color: '#FFFFFF',
                      },
                    }}
                  >
                    Continue
                  </Button>
                ) : (
                  <Button
                    variant="contained"
                    onClick={handleSubmit(onConfirm)}
                    disabled={confirmMutation.isPending}
                    startIcon={confirmMutation.isPending ? <CircularProgress size={16} color="inherit" /> : null}
                  >
                    Confirm Booking
                  </Button>
                )}
              </Stack>
            </Stack>
          </Paper>
        </Grid>

        <Grid item xs={12} md={5}>
          <BillSummary quote={quote} />
        </Grid>
      </Grid>
    </Box>
  );
}

