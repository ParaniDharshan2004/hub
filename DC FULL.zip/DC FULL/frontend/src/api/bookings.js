import dayjs from 'dayjs';
import { getDb, saveDb, recordAudit, recordStatusChange } from './db';
import { generateId } from '../utils/idGenerator';
import { delay, plans, frequencies, taxComponents, visitsForPlan } from './masters';

// Server-side pricing calculation. The client never supplies a price; it
// only supplies selections, and this function is the single source of
// truth for the bill, exactly as required by "do not trust a client
// supplied price".
export function quotePricing({ planId, frequencyId, bathrooms, discount = 0, planOptions = plans, frequencyOptions = frequencies }) {
  const plan = planOptions.find((p) => p.id === planId);
  const frequency = frequencyOptions.find((f) => f.id === frequencyId);
  if (!plan || !frequency || !bathrooms) return null;

  const pricePerService = plan.pricePerServiceByBathroom[bathrooms];
  if (!pricePerService) return null;

  const numServices = visitsForPlan(plan, frequency);
  const serviceCharges = round2(pricePerService * numServices);
  const authorizedDiscount = round2(Math.min(discount || 0, serviceCharges));
  const taxableAmount = round2(serviceCharges - authorizedDiscount);

  const taxes = taxComponents.map((t) => ({
    ...t,
    amount: round2(taxableAmount * t.rate),
  }));
  const taxTotal = round2(taxes.reduce((s, t) => s + t.amount, 0));
  const total = round2(taxableAmount + taxTotal);

  return {
    plan,
    frequency,
    pricePerService,
    numServices,
    serviceCharges,
    authorizedDiscount,
    taxableAmount,
    taxes,
    taxTotal,
    total,
    effectiveDate: dayjs().format('YYYY-MM-DD'),
  };
}

function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

function toBookingRow(booking) {
  const db = getDb();
  const customer = db.customers.find((c) => c.id === booking.customerId);
  const address = db.addresses.find((a) => a.id === booking.addressId);
  return { ...booking, customer, address };
}

function formatTime(totalMinutes) {
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  const suffix = hours >= 12 ? 'PM' : 'AM';
  const displayHours = hours % 12 || 12;
  return `${String(displayHours).padStart(2, '0')}:${String(minutes).padStart(2, '0')} ${suffix}`;
}

function resolveSlotLabel(slotId, timeSlots, durationMinutes = 30) {
  const match = String(slotId || '').match(/-(\d+)$/);
  if (!match) return slotId || '';
  const startMinutes = Number(match[1]);
  return `${formatTime(startMinutes)} – ${formatTime(startMinutes + durationMinutes)}`;
}

function normalizeBooking(booking, masters = {}) {
  const customer = booking.customerId && typeof booking.customerId === 'object' ? booking.customerId : null;
  const frequency = masters.frequencies?.find((item) => item._id === booking.frequencyCode);
  const plan = masters.subscriptionTypes?.find((item) => item._id === booking.planId);
  return {
    ...booking,
    id: booking._id,
    bookingNumber: booking.bookingId,
    customer: customer
      ? {
          ...customer,
          id: customer._id,
          customerNumber: customer.customerNumber || customer._id,
          mobile: customer.phoneNumber,
        }
      : null,
    address: customer?.address
      ? { addressLine: customer.address, area: customer.area || '', label: 'Service address' }
      : null,
    bathrooms: booking.bathroomCountId?.bathroomCount,
    frequencyId: booking.frequencyCode,
    frequencyName: frequency?.frequencyName || booking.frequencyCode,
    planName: plan?.subscriptionName || booking.planId,
    startDate: booking.scheduledDate,
    slotLabel: resolveSlotLabel(
      booking.slotId,
      masters.timeSlots,
      booking.duration || booking.durationMinutes || booking.bathroomCountId?.serviceDurationReference?.durationMinutes,
    ),
    total: booking.totalAmount,
    status: booking.isCancelled ? 'Cancelled' : booking.isCompleted ? 'Confirmed' : 'Draft',
    createdOn: booking.createdAt,
  };
}

export async function listBookings({ search = '', status = 'All' } = {}) {
  const response = await fetch('/api/bookings');
  if (!response.ok) throw new Error('Could not fetch bookings from the database');
  const [frequencies, subscriptionTypes, timeSlots] = await Promise.all([
    fetch('/api/service-frequencies').then((res) => res.json()),
    fetch('/api/subscription-types').then((res) => res.json()),
    fetch('/api/time-slots').then((res) => res.json()),
  ]);
  let rows = (await response.json()).map((booking) => normalizeBooking(booking, { frequencies, subscriptionTypes, timeSlots }));

  if (status !== 'All') rows = rows.filter((b) => b.status === status);
  if (search.trim()) {
    const q = search.trim().toLowerCase();
    rows = rows.filter(
      (b) =>
        b.bookingNumber.toLowerCase().includes(q) ||
        b.customer?.name.toLowerCase().includes(q) ||
        b.customer?.customerNumber.toLowerCase().includes(q)
    );
  }
  return rows.sort((a, b) => new Date(b.createdOn) - new Date(a.createdOn));
}

export async function getBooking(bookingNumber) {
  const response = await fetch(`/api/bookings/${bookingNumber}`);
  if (response.status === 404) return null;
  if (!response.ok) throw new Error('Could not fetch booking details from the database');
  const [frequencies, subscriptionTypes, timeSlots] = await Promise.all([
    fetch('/api/service-frequencies').then((res) => res.json()),
    fetch('/api/subscription-types').then((res) => res.json()),
    fetch('/api/time-slots').then((res) => res.json()),
  ]);
  return normalizeBooking(await response.json(), { frequencies, subscriptionTypes, timeSlots });
}

// Creates the booking record used by the final confirmation transaction.
export async function createBooking(payload) {
  const quote = quotePricing({
    ...payload,
    planOptions: payload.planOptions || plans,
    frequencyOptions: payload.frequencyOptions || frequencies,
  });
  if (!quote) throw new Error('Unable to price this combination.');
  const response = await fetch('/api/bookings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      customerId: payload.customerId,
      addressId: payload.addressId,
      offeringId: payload.offeringId,
      bathroomCount: payload.bathrooms,
      frequencyId: payload.frequencyId,
      planId: payload.planId,
      discount: quote.authorizedDiscount,
      discountReason: payload.discountReason || '',
      startDate: payload.startDate,
      slotId: payload.slotId,
      serviceCharges: quote.serviceCharges,
      taxableAmount: quote.taxableAmount,
      totalAmount: quote.total,
      totalVisits: quote.numServices,
    }),
  });
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.message || 'Could not save booking to the database');
  }
  const result = await response.json();
  return {
    ...result.booking,
    id: result.booking._id,
    bookingNumber: result.booking.bookingId,
    status: 'Pending',
  };
}

// Atomic confirmation: in a real backend this is one DB transaction. Here
// we mutate the mock tables synchronously (no await between steps) so the
// "all or nothing" contract is honestly represented, then persist once at
// the end.
export async function confirmBooking(bookingNumber, { paymentModeId, receiverAccountId, paymentReference }) {
  if (!paymentModeId) throw new Error('Payment mode is required to confirm a booking.');
  if (!receiverAccountId) throw new Error('Receiver bank type is required to confirm a booking.');

  const response = await fetch(`/api/bookings/${encodeURIComponent(bookingNumber)}/confirm`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ paymentModeId, receiverAccountId, paymentReference }),
  });
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.error ? `${error.message || 'Could not confirm booking in the database'}: ${error.error}` : error.message || 'Could not confirm booking in the database');
  }
  const result = await response.json();
  return {
    ...result,
    booking: result.booking
      ? {
          ...result.booking,
          id: result.booking._id,
          bookingNumber: result.booking.bookingId,
        }
      : result.booking,
  };
}

export async function cancelBooking(bookingNumber, reason) {
  await delay(300);
  const db = getDb();
  const booking = db.bookings.find((b) => b.bookingNumber === bookingNumber);
  if (!booking) throw new Error('Booking not found');
  if (booking.status === 'Confirmed') {
    throw new Error('Confirmed bookings cannot be cancelled here; reverse the payment first.');
  }
  const fromStatus = booking.status;
  booking.status = 'Cancelled';
  recordStatusChange({
    entityType: 'Booking',
    entityNumber: booking.bookingNumber,
    fromStatus,
    toStatus: 'Cancelled',
    reason,
  });
  recordAudit({ module: 'Bookings', action: 'CANCEL', entityType: 'Booking', entityNumber: booking.bookingNumber });
  saveDb();
  return toBookingRow(booking);
}
