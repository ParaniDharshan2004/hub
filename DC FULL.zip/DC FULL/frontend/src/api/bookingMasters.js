async function fetchMaster(resource) {
  const response = await fetch(`/api/${resource}`);
  if (!response.ok) {
    throw new Error(`Could not load ${resource.replaceAll('-', ' ')}.`);
  }
  return response.json();
}

function toMinutes(time) {
  const match = String(time).trim().match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
  if (!match) return null;

  let hours = Number(match[1]) % 12;
  if (match[3].toUpperCase() === 'PM') hours += 12;
  return hours * 60 + Number(match[2]);
}

function formatTime(totalMinutes) {
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  const suffix = hours >= 12 ? 'PM' : 'AM';
  const displayHours = hours % 12 || 12;
  return `${String(displayHours).padStart(2, '0')}:${String(minutes).padStart(2, '0')} ${suffix}`;
}

function buildTimeSlots(timeSlots, durationMinutes = 30) {
  return timeSlots
    .filter((timeSlot) => timeSlot.isActive !== false)
    .flatMap((timeSlot) => {
      const startMinutes = toMinutes(timeSlot.startTime);
      const endMinutes = toMinutes(timeSlot.endTime);
      if (startMinutes == null || endMinutes == null || endMinutes <= startMinutes) return [];

      const slots = [];
      for (let current = startMinutes; current + durationMinutes <= endMinutes; current += durationMinutes) {
        slots.push({
          id: `${timeSlot._id}-${current}`,
          label: `${formatTime(current)} – ${formatTime(current + durationMinutes)}`,
        });
      }
      return slots;
    });
}

export async function getBookingMasters() {
  const [bathroomCounts, frequencies, subscriptionTypes, pricing, timeSlots, paymentAccounts, paymentMethods] = await Promise.all([
    fetchMaster('bathroom-counts'),
    fetchMaster('service-frequencies'),
    fetchMaster('subscription-types'),
    fetchMaster('pricing'),
    fetchMaster('time-slots'),
    fetchMaster('payment-accounts'),
    fetchMaster('payment-methods'),
  ]);

  const priceByBathroom = pricing.reduce((prices, item) => {
    const bathroomCount = item.bathroomCountReference?.bathroomCount;
    if (item.isActive !== false && bathroomCount && item.price != null) {
      prices[bathroomCount] = item.price;
    }
    return prices;
  }, {});

  const durationByBathroom = pricing.reduce((durations, item) => {
    const bathroomCount = item.bathroomCountReference?.bathroomCount;
    const durationMinutes = item.serviceDurationReference?.durationMinutes;
    if (item.isActive !== false && bathroomCount && durationMinutes) {
      durations[bathroomCount] = durationMinutes;
    }
    return durations;
  }, {});

  return {
    bathrooms: bathroomCounts
      .filter((item) => item.isActive !== false)
      .sort((a, b) => a.bathroomCount - b.bathroomCount)
      .map((item) => ({
        id: item._id,
        value: item.bathroomCount,
        label: String(item.bathroomCount),
      })),
    frequencies: frequencies
      .filter((item) => item.isActive !== false)
      .map((item) => ({
        id: item._id,
        name: item.frequencyName,
        visitsPerMonth: Math.max(1, Math.round(30 / item.intervalDays)),
      })),
    plans: subscriptionTypes
      .filter((item) => item.isActive !== false)
      .map((item) => ({
        id: item._id,
        name: item.subscriptionName,
        termMonths: Math.max(1, Math.round(item.timeGap / 30)),
        pricePerServiceByBathroom: priceByBathroom,
      })),
    durationByBathroom,
    slots: buildTimeSlots(timeSlots),
    slotsByBathroom: Object.fromEntries(
      Object.entries(durationByBathroom).map(([bathroomCount, durationMinutes]) => [
        bathroomCount,
        buildTimeSlots(timeSlots, durationMinutes),
      ]),
    ),
    paymentAccounts: paymentAccounts
      .filter((item) => item.isActive !== false)
      .map((item) => ({ id: item._id, name: item.accountName })),
    paymentMethods: paymentMethods
      .filter((item) => item.isActive !== false)
      .map((item) => ({ id: item._id, name: item.paymentMethodName })),
  };
}
