import dayjs from 'dayjs';
import { getDb } from './db';

function toSubscriptionRow(sub) {
  const db = getDb();
  const customer = db.customers.find((c) => c.id === sub.customerId);
  const address = db.addresses.find((a) => a.id === sub.addressId);
  const periods = db.periods
    .filter((p) => p.subscriptionId === sub.id)
    .sort((a, b) => new Date(b.startDate) - new Date(a.startDate));
  const currentPeriod = periods[0] || null;
  const visits = currentPeriod ? db.visits.filter((v) => v.periodId === currentPeriod.id) : [];
  const nextVisit = visits
    .filter((v) => v.status === 'Scheduled')
    .sort((a, b) => new Date(a.date) - new Date(b.date))[0];

  const renewalStatus = currentPeriod
    ? dayjs(currentPeriod.endDate).diff(dayjs(), 'day') <= 7
      ? 'Renewal Due Soon'
      : dayjs(currentPeriod.endDate).isBefore(dayjs())
      ? 'Renewal Overdue'
      : 'On Track'
    : 'No Period';

  return { ...sub, customer, address, periods, currentPeriod, nextVisit, renewalStatus };
}

export async function listSubscriptions({ search = '', status = 'All' } = {}) {
  const response = await fetch('/api/subscriptions');
  if (!response.ok) throw new Error('Could not fetch subscriptions from the database');
  let rows = await response.json();

  if (status !== 'All') rows = rows.filter((s) => s.status === status);
  if (search.trim()) {
    const q = search.trim().toLowerCase();
    rows = rows.filter(
      (s) =>
        s.subscriptionNumber.toLowerCase().includes(q) ||
        s.customer?.name.toLowerCase().includes(q) ||
        s.customer?.customerNumber.toLowerCase().includes(q)
    );
  }
  return rows.sort((a, b) => new Date(b.createdOn) - new Date(a.createdOn));
}

export async function getSubscription(subscriptionNumber) {
  const response = await fetch(`/api/subscriptions/${encodeURIComponent(subscriptionNumber)}`);
  if (response.status === 404) return null;
  if (!response.ok) throw new Error('Could not fetch subscription details from the database');
  return response.json();
}

// Renewal: purchases a new period on the *same* subscription account.
// Prior periods, their visits, and every historical booking/payment/invoice
// are left completely untouched.
