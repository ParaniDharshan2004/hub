import dayjs from 'dayjs';
import { getDb, saveDb, recordAudit } from './db';
import { generateId } from '../utils/idGenerator';
import { delay } from './masters';

function toCustomerRow(customer) {
  const db = getDb();
  const addresses = db.addresses.filter((a) => a.customerId === customer.id);
  const activeAddresses = addresses.filter((a) => a.status === 'Active');
  const bookings = db.bookings.filter((b) => b.customerId === customer.id);
  const subscriptions = db.subscriptions.filter((s) => s.customerId === customer.id);
  const activeSubscriptions = subscriptions.filter((s) => s.status === 'Active');
  const payments = db.payments.filter((p) => p.customerId === customer.id && p.status !== 'Reversed');
  const lifetimeCollected = payments.reduce((sum, p) => sum + p.amount, 0);

  const upcomingVisits = db.visits
    .filter((v) => subscriptions.some((s) => s.id === v.subscriptionId) && v.status === 'Scheduled')
    .sort((a, b) => new Date(a.date) - new Date(b.date));

  return {
    ...customer,
    defaultAddress: addresses.find((a) => a.isDefault) || addresses[0] || null,
    addressCount: activeAddresses.length,
    activeSubscriptionCount: activeSubscriptions.length,
    nextVisit: upcomingVisits[0] || null,
    lifetimeCollected,
  };
}

export async function listCustomers({ search = '', status = 'All' } = {}) {
  const response = await fetch('/api/customers');
  if (!response.ok) {
    throw new Error('Could not fetch customers from the database');
  }

  const customers = await response.json();
  let rows = customers.map((customer) => ({
    id: customer._id,
    customerNumber: customer.customerNumber || customer._id,
    name: customer.name,
    mobile: customer.phoneNumber,
    email: customer.email || '',
    status: customer.isActive ? 'Active' : 'Inactive',
    defaultAddress: customer.address
      ? { addressLine: customer.address, area: customer.area || null }
      : null,
    defaultArea: customer.defaultArea || customer.area || '',
    serviceFrequencyName: customer.serviceFrequencyName || '',
    subscriptionTypeName: customer.subscriptionTypeName || '',
    addressCount: customer.addressCount ?? (customer.address ? 1 : 0),
    activeSubscriptionCount: customer.activeSubscriptionCount ?? 0,
    nextVisit: customer.nextVisit
      ? { ...customer.nextVisit, date: customer.nextVisit.scheduledDate }
      : null,
    lifetimeCollected: 0,
    createdOn: customer.createdAt,
  }));

  if (status !== 'All') {
    rows = rows.filter((c) => c.status === status);
  }
  if (search.trim()) {
    const q = search.trim().toLowerCase();
    rows = rows.filter(
      (c) =>
        c.customerNumber.toLowerCase().includes(q) ||
        c.name.toLowerCase().includes(q) ||
        c.mobile.includes(q) ||
        (c.email || '').toLowerCase().includes(q)
    );
  }
  return rows.sort((a, b) => new Date(b.createdOn) - new Date(a.createdOn));
}

export async function getCustomerByNumber(customerNumber) {
  await delay(150);
  const db = getDb();
  const customer = db.customers.find((c) => c.customerNumber === customerNumber);
  return customer ? toCustomerRow(customer) : null;
}

export async function listAddressesForCustomer(customerId) {
  const response = await fetch(`/api/customers/${customerId}`);
  if (!response.ok) throw new Error('Could not fetch customer addresses');
  const customer = await response.json();
  if (!customer.address) return [];
  return [{
    id: customer._id,
    addressNumber: customer._id,
    customerId: customer._id,
    label: 'Primary address',
    addressLine: customer.address,
    doorNo: customer.doorNo || '',
    block: customer.block || '',
    community: customer.apartmentName || '',
    area: customer.area || '',
    city: customer.city || '',
    pincode: customer.pincode || '',
    landmark: customer.landmark || '',
    isDefault: true,
    status: customer.isActive ? 'Active' : 'Inactive',
  }];
}

export async function findByMobile(mobile) {
  const response = await fetch(`/api/customers?phoneNumber=${encodeURIComponent(mobile)}`);
  if (!response.ok) throw new Error('Could not check existing customers');
  const customers = await response.json();
  return customers.map((customer) => ({
    id: customer._id,
    customerNumber: customer.customerNumber || customer._id,
    name: customer.name,
    mobile: customer.phoneNumber,
  }));
}

export async function createCustomerWithAddress(payload) {
  const response = await fetch('/api/customers', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name: payload.name,
      phoneNumber: payload.mobile,
      address: payload.addressLine,
      doorNo: payload.doorNo || '',
      block: payload.block || '',
      apartmentName: payload.community || '',
      landmark: payload.landmark || '',
      city: payload.city || '',
      pincode: payload.pincode || '',
      area: payload.area || '',
      whatsapp: payload.sameAsMobile ? payload.mobile : payload.whatsapp || '',
      email: payload.email || '',
    }),
  });
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.message || 'Could not create customer in the database');
  }

  const customer = await response.json();
  return {
    customer: {
      ...customer,
      id: customer._id,
      customerNumber: customer.customerNumber || customer._id,
      mobile: customer.phoneNumber,
    },
    address: {
      addressNumber: customer._id,
      addressLine: customer.address,
    },
  };
}

export async function addAddress(customerNumber, payload) {
  await delay(350);
  const db = getDb();
  const customer = db.customers.find((c) => c.customerNumber === customerNumber);
  if (!customer) throw new Error('Customer not found');

  if (payload.isDefault) {
    db.addresses
      .filter((a) => a.customerId === customer.id)
      .forEach((a) => {
        a.isDefault = false;
      });
  }

  const address = {
    id: `int-addr-${db.addresses.length + 1}-${Date.now()}`,
    addressNumber: generateId.address(),
    customerId: customer.id,
    label: payload.addressLabel || 'Address',
    doorNo: payload.doorNo || '',
    block: payload.block || '',
    community: payload.community || '',
    addressLine: payload.addressLine || '',
    area: payload.area,
    city: payload.city || '',
    pincode: payload.pincode || '',
    landmark: payload.landmark || '',
    isDefault: !!payload.isDefault || db.addresses.filter((a) => a.customerId === customer.id).length === 0,
    status: 'Active',
    createdOn: new Date().toISOString(),
  };
  db.addresses.push(address);

  recordAudit({
    module: 'Customers',
    action: 'ADD_ADDRESS',
    entityType: 'Customer',
    entityNumber: customer.customerNumber,
    details: `Added address ${address.addressNumber}`,
  });

  saveDb();
  return address;
}

export async function getCustomer360(customerNumber) {
  const response = await fetch(`/api/customers/${customerNumber}`);
  if (response.status === 404) return null;
  if (!response.ok) throw new Error('Could not fetch customer details from the database');

  const record = await response.json();
  const customer = {
    ...record,
    id: record._id,
    customerNumber: record.customerNumber || record._id,
    mobile: record.phoneNumber,
    status: record.isActive ? 'Active' : 'Inactive',
  };
  const addresses = record.addresses || [];
  const bookings = (record.bookings || []).map((booking) => ({
    ...booking,
    id: booking.id || booking._id,
  }));
  const subscriptions = (record.subscriptions || []).map((subscription) => ({
    ...subscription,
    id: subscription.id || subscription._id,
  }));
  const payments = record.payments || [];
  const invoices = record.invoices || [];
  const visits = record.visits || [];
  const auditEvents = [];

  return {
    customer,
    addresses,
    bookings,
    subscriptions,
    payments,
    invoices,
    visits,
    auditEvents,
    summary: record.summary || {
      addressCount: addresses.filter((a) => a.status === 'Active').length,
      totalBookings: bookings.length,
      activeSubscriptions: subscriptions.filter((s) => s.status === 'Active').length,
      visitsCompleted: visits.filter((v) => v.status === 'Completed').length,
      lifetimeCollected: 0,
      nextVisits: [],
    },
  };
}

export async function deactivateCustomer(customerNumber) {
  await delay(300);
  const db = getDb();
  const customer = db.customers.find((c) => c.customerNumber === customerNumber);
  if (!customer) throw new Error('Customer not found');
  const hasActiveSub = db.subscriptions.some((s) => s.customerId === customer.id && s.status === 'Active');
  if (hasActiveSub) {
    throw new Error('Cannot deactivate: customer has active subscriptions.');
  }
  customer.status = 'Inactive';
  recordAudit({
    module: 'Customers',
    action: 'DEACTIVATE',
    entityType: 'Customer',
    entityNumber: customer.customerNumber,
  });
  saveDb();
  return customer;
}
