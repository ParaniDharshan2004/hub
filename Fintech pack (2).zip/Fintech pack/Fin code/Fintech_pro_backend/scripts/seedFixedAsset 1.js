import mongoose from 'mongoose';
import dotenv from 'dotenv';

import FixedAssetMaster from '../models/master-models/fixed-assets-master-model.js';

dotenv.config();

const userId = new mongoose.Types.ObjectId(
  '6aa0ddb3f070abe2bf992b11',
);

const assets = [
  // Computer & Equipment
  {
    assetName: 'Laptop',
    categoryId: '6ad9c2a290e999b08df700f4',
    description: 'Employee laptop',
  },
  {
    assetName: 'Desktop',
    categoryId: '6ad9c2a290e999b08df700f4',
    description: 'Desktop computer',
  },
  {
    assetName: 'Monitor',
    categoryId: '6ad9c2a290e999b08df700f4',
    description: 'Computer monitor',
  },
  {
    assetName: 'Mouse',
    categoryId: '6ad9c2a290e999b08df700f4',
    description: 'Computer mouse',
  },
  {
    assetName: 'Keyboard',
    categoryId: '6ad9c2a290e999b08df700f4',
    description: 'Computer keyboard',
  },
  {
    assetName: 'Printer',
    categoryId: '6ad9c2a290e999b08df700f4',
    description: 'Office printer',
  },
  {
    assetName: 'Scanner',
    categoryId: '6ad9c2a290e999b08df700f4',
    description: 'Document scanner',
  },
  {
    assetName: 'Web Camera',
    categoryId: '6ad9c2a290e999b08df700f4',
    description: 'USB camera',
  },
  {
    assetName: 'Headset',
    categoryId: '6ad9c2a290e999b08df700f4',
    description: 'Employee headset',
  },

  // Furniture
  {
    assetName: 'Office Chair',
    categoryId: '6ad9c2a290e999b08df700f5',
    description: 'Office chair',
  },
  {
    assetName: 'Office Table',
    categoryId: '6ad9c2a290e999b08df700f5',
    description: 'Office table',
  },
  {
    assetName: 'File Rack',
    categoryId: '6ad9c2a290e999b08df700f5',
    description: 'Document storage rack',
  },
  {
    assetName: 'Storage Cabinet',
    categoryId: '6ad9c2a290e999b08df700f5',
    description: 'Office storage cabinet',
  },

  // Networking Equipment
  {
    assetName: 'Router',
    categoryId: '6ad9c2a290e999b08df700f6',
    description: 'Network router',
  },
  {
    assetName: 'Switch',
    categoryId: '6ad9c2a290e999b08df700f6',
    description: 'Network switch',
  },
  {
    assetName: 'Firewall',
    categoryId: '6ad9c2a290e999b08df700f6',
    description: 'Network firewall',
  },
  {
    assetName: 'Access Point',
    categoryId: '6ad9c2a290e999b08df700f6',
    description: 'Wireless access point',
  },

  // Office Infrastructure
  {
    assetName: 'Air Conditioner',
    categoryId: '6ad9c2a290e999b08df700f7',
    description: 'Office air conditioner',
  },
  {
    assetName: 'UPS',
    categoryId: '6ad9c2a290e999b08df700f7',
    description: 'Power backup UPS',
  },
  {
    assetName: 'Projector',
    categoryId: '6ad9c2a290e999b08df700f7',
    description: 'Office projector',
  },
  {
    assetName: 'Generator',
    categoryId: '6ad9c2a290e999b08df700f7',
    description: 'Power generator',
  },

  // Mobile Devices
  {
    assetName: 'Mobile Phone',
    categoryId: '6ad9c2a290e999b08df700f8',
    description: 'Corporate mobile phone',
  },
  {
    assetName: 'Tablet',
    categoryId: '6ad9c2a290e999b08df700f8',
    description: 'Corporate tablet',
  },
];

const seed = async () => {
  try {
    await mongoose.connect(process.env.MONGO_URI);

    for (const asset of assets) {
      await FixedAssetMaster.updateOne(
        {
          assetName: asset.assetName,
        },
        {
          $set: {
            ...asset,
            updatedBy: userId,
          },
          $setOnInsert: {
            createdBy: userId,
          },
        },
        {
          upsert: true,
        },
      );
    }

    console.log('Fixed Assets Seeded Successfully');

    process.exit(0);
  } catch (error) {
    console.error(error);
    process.exit(1);
  }
};

seed();