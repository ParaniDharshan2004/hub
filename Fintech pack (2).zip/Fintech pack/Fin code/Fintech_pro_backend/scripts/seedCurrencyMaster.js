import dotenv from 'dotenv';
import mongoose from 'mongoose';

import CurrencyMaster from '../models/master-models/currency-master-model.js';

dotenv.config();

const currencies = [
  {
    currencyCode: 'INR',
    currencyName: 'Indian Rupee',
    currencySymbol: '₹',
    exchangeRate: 1,
    displayOrder: 1,
    isActive: true,
  },
  {
    currencyCode: 'USD',
    currencyName: 'US Dollar',
    currencySymbol: '$',
    exchangeRate: 84.50,
    displayOrder: 2,
    isActive: true,
  },
];

const seedCurrencyMaster = async () => {
  if (!process.env.MONGO_URI) {
    throw new Error('MONGO_URI is not configured');
  }

  await mongoose.connect(process.env.MONGO_URI);

  for (const currency of currencies) {
    await CurrencyMaster.updateOne(
      { currencyCode: currency.currencyCode },
      {
        $set: currency,
      },
      { upsert: true },
    );
  }

  console.log(
    `Currency master seeded successfully (${currencies.length} currencies).`,
  );
};

seedCurrencyMaster()
  .catch((error) => {
    console.error('Currency master seeding failed:', error);
    process.exitCode = 1;
  })
  .finally(async () => {
    await mongoose.disconnect();
  });
