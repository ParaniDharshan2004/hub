const names = {
  dashboard: "Dashboard",
  upload: "Excel Upload",
  excel: "Uploaded Excel Data",
    reports: "Reports",
  master: "Master",
  assets: "Asset Tracking",
  insurance: "Insurance",
    };
function go(page) {
  const target = document.getElementById(page);
  if (target && target.classList.contains("page")) {
    document
      .querySelectorAll(".page")
      .forEach((p) => p.classList.toggle("active", p.id === page));
    document
      .querySelectorAll(".nav-item")
      .forEach((n) => n.classList.toggle("active", n.dataset.page === page));
    const crumb = document.getElementById("crumb");
    if (crumb) crumb.textContent = names[page] || "Dashboard";
    window.scrollTo({ top: 0, behavior: "smooth" });
  } else {
    window.location.href = page + ".html";
  }
}
document.querySelectorAll("[data-page]").forEach((n) => {
  n.addEventListener("click", (e) => {
    const page = n.dataset.page;
    const target = document.getElementById(page);
    if (target && target.classList.contains("page")) {
      e.preventDefault();
      go(page);
    }
  });
});
document.querySelectorAll("[data-go]").forEach((n) => {
  n.addEventListener("click", (e) => {
    const page = n.dataset.go;
    const target = document.getElementById(page);
    if (target && target.classList.contains("page")) {
      e.preventDefault();
      go(page);
    } else {
      window.location.href = page + ".html";
    }
  });
});
const masterLink = document.querySelector('a[href="master.html"][data-page="master"]');
if (masterLink && !document.querySelector(".master-sidebar")) {
  masterLink.classList.add("master-toggle");
  masterLink.removeAttribute("data-page");
  masterLink.setAttribute("aria-expanded", "false");
  masterLink.insertAdjacentHTML(
    "beforeend",
    `<span class="master-chevron" aria-hidden="true">›</span>`,
  );
  masterLink.insertAdjacentHTML(
    "afterend",
    `<nav class="master-sidebar" aria-label="Master subpages">
      <a class="master-sidebar-item" href="master.html#master-departments" data-master-tab="master-departments">Departments</a>
      <a class="master-sidebar-item" href="master.html#master-teams" data-master-tab="master-teams">Teams</a>
      <a class="master-sidebar-item" href="master.html#master-employees" data-master-tab="master-employees">Employees</a>
    </nav>`,
  );
}

if (masterLink) {
  const masterSidebar = masterLink.nextElementSibling;
  const isMasterPage = window.location.pathname.toLowerCase().endsWith("master.html");
  if (masterSidebar?.classList.contains("master-sidebar") && isMasterPage) {
    masterSidebar.classList.add("open");
    masterLink.setAttribute("aria-expanded", "true");
  }
  masterLink.addEventListener("click", (event) => {
    const sidebar = masterLink.nextElementSibling;
    if (!sidebar?.classList.contains("master-sidebar")) return;
    event.preventDefault();
    const isOpen = sidebar.classList.toggle("open");
    masterLink.setAttribute("aria-expanded", String(isOpen));
  });
}

const setMasterSubpage = (target) => {
  if (!target) target = "master-departments";
  document
    .querySelectorAll("[data-master-tab]")
    .forEach((item) =>
      item.classList.toggle("active", item.dataset.masterTab === target),
    );
  document
    .querySelectorAll(".master-subpage")
    .forEach((page) => page.classList.toggle("active", page.id === target));
  document
    .querySelectorAll("[data-master-tab]")
    .forEach((item) =>
      item.setAttribute(
        "aria-selected",
        String(item.dataset.masterTab === target),
      ),
    );
};

document.querySelectorAll("[data-master-tab]").forEach((tab) => {
  tab.addEventListener("click", (event) => {
    const target = tab.dataset.masterTab;
    if (!document.querySelector(".master-subpage")) return;
    event.preventDefault();
    if (window.location.pathname.toLowerCase().endsWith("master.html")) {
      window.history.replaceState(null, "", `#${target}`);
      setMasterSubpage(target);
    } else {
      window.location.href = `master.html#${target}`;
    }
  });
});

if (document.querySelector(".master-subpage")) {
  const hashTarget = window.location.hash.replace("#", "");
  setMasterSubpage(document.getElementById(hashTarget) ? hashTarget : "master-departments");
}

window.addEventListener("hashchange", () => {
  if (!document.querySelector(".master-subpage")) return;
  const hashTarget = window.location.hash.replace("#", "");
  setMasterSubpage(document.getElementById(hashTarget) ? hashTarget : "master-departments");
});

const assetModal = document.getElementById("assetModal");
const assetForm = document.getElementById("assetForm");
const assetTableBody = document.getElementById("assetTableBody");
const assetModalTitle = document.getElementById("assetModalTitle");
const assetSubmitButton = assetForm?.querySelector('button[type="submit"]');
let editingAssetRow = null;

const formatCurrency = (value) =>
  value ? `₹${Number(value).toLocaleString("en-IN")}` : "—";
const formatDate = (value) =>
  value
    ? new Date(`${value}T00:00:00`).toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      })
    : "—";

const defaultAssetCatalog = [
  {
    code: "LAP-001",
    type: "Laptop",
    name: "Laptop",
    brand: "Dell",
    serial: "DL-LAP-001",
    cost: "₹75,000",
    assignedDate: "—",
    warranty: "31 Dec 2027",
    status: "In Stock",
    empCode: "",
    employee: "",
  },
  {
    code: "LAP-002",
    type: "Laptop",
    name: "Laptop",
    brand: "HP",
    serial: "HP-LAP-002",
    cost: "₹82,000",
    assignedDate: "—",
    warranty: "31 Mar 2028",
    status: "In Stock",
    empCode: "",
    employee: "",
  },
  {
    code: "DES-001",
    type: "Desktop",
    name: "Desktop",
    brand: "Lenovo",
    serial: "LV-DES-001",
    cost: "₹65,000",
    assignedDate: "—",
    warranty: "30 Jun 2027",
    status: "In Stock",
    empCode: "",
    employee: "",
  },
  {
    code: "MON-001",
    type: "Monitor",
    name: "Monitor",
    brand: "LG",
    serial: "LG-MON-001",
    cost: "₹18,000",
    assignedDate: "—",
    warranty: "31 May 2027",
    status: "In Stock",
    empCode: "",
    employee: "",
  },
  {
    code: "MOB-001",
    type: "Mobile Phone",
    name: "Mobile Phone",
    brand: "Samsung",
    serial: "SM-MOB-001",
    cost: "₹35,000",
    assignedDate: "15 Apr 2025",
    warranty: "15 Apr 2027",
    status: "Assigned",
    empCode: "EMP-001",
    employee: "RG Emp 1",
  },
  {
    code: "LAP-003",
    type: "Laptop",
    name: "Laptop",
    brand: "Apple",
    serial: "AP-LAP-003",
    cost: "₹45,000",
    assignedDate: "10 Mar 2025",
    warranty: "10 Mar 2027",
    status: "Assigned",
    empCode: "EMP-001",
    employee: "RG Emp 1",
  },
];

function getAssetInventory() {
  try {
    const stored = localStorage.getItem("flc_assets_inventory");
    if (stored) return JSON.parse(stored);
  } catch (e) {}
  return defaultAssetCatalog;
}

function saveAssetInventory(items) {
  try {
    localStorage.setItem("flc_assets_inventory", JSON.stringify(items));
  } catch (e) {}
}

function syncAssetTableWithInventory() {
  if (!assetTableBody) return;
  const inventory = getAssetInventory();
  const rows = Array.from(assetTableBody.querySelectorAll("tr"));
  rows.forEach((row) => {
    const code = row.cells[0]?.textContent.trim();
    const item = inventory.find((i) => i.code === code);
    if (item) {
      row.dataset.status = item.status;
      row.cells[6].textContent = item.assignedDate || "—";
      const statusClass =
        item.status === "In Stock"
          ? "success"
          : item.status === "Assigned"
            ? "neutral"
            : "warning";
      row.cells[8].innerHTML = `<span class="status ${statusClass}">${item.status}</span>`;
      if (item.employee) {
        row.dataset.assignedEmployee = item.employee;
      } else {
        delete row.dataset.assignedEmployee;
      }
    }
  });
  updateAssetCounts();
}

function updateAssetCounts() {
  if (!assetTableBody) return;
  const rows = Array.from(assetTableBody.querySelectorAll("tr"));
  const assigned = rows.filter(
    (row) => row.dataset.status === "Assigned",
  ).length;
  const purchaseValue = rows.reduce((total, row) => {
    const value = row.cells[5].textContent.replace(/[₹,]/g, "");
    return total + (value === "—" ? 0 : Number(value) || 0);
  }, 0);
  const totalAssetCountEl = document.getElementById("totalAssetCount");
  if (totalAssetCountEl) totalAssetCountEl.textContent = rows.length;
  const availableAssetCountEl = document.getElementById("availableAssetCount");
  if (availableAssetCountEl)
    availableAssetCountEl.textContent = rows.filter(
      (row) => row.dataset.status !== "Assigned",
    ).length;
  const assignedAssetCountEl = document.getElementById("assignedAssetCount");
  if (assignedAssetCountEl) assignedAssetCountEl.textContent = assigned;
  const assetPurchaseValueEl = document.getElementById("assetPurchaseValue");
  if (assetPurchaseValueEl) {
    assetPurchaseValueEl.textContent =
      purchaseValue >= 100000
        ? `₹${(purchaseValue / 100000).toFixed(1)}L`
        : `₹${purchaseValue.toLocaleString("en-IN")}`;
  }
}
function deleteAsset(button) {
  const row = button.closest("tr");
  const code = row.cells[0].textContent.trim();
  if (window.confirm(`Delete asset ${code}?`)) {
    row.remove();
    updateAssetCounts();
    refreshAvailableAssetLists();
  }
}
function openAssetEditor(button) {
  const row = button.closest("tr");
  const cells = row.querySelectorAll("td");
  assetForm.reset();
  assetForm.elements.resourceCategoryId.value = "1";
  assetForm.elements.assetCode.value = cells[0].textContent.trim();
  assetForm.elements.assetName.value = cells[2].textContent.trim();
  assetForm.elements.asset.value = cells[2].textContent.trim();
  assetForm.elements.brand.value = cells[3].textContent.trim();
  assetForm.elements.serialNumber.value = cells[4].textContent.trim();
  assetForm.elements.purchaseCost.value =
    cells[5].textContent.replace(/[₹,]/g, "") === "—"
      ? ""
      : cells[5].textContent.replace(/[₹,]/g, "");
  assetForm.elements.assignedDate.value = "";
  assetForm.elements.warrantyDate.value = "";
  assetForm.elements.status.value = row.dataset.status || "In Stock";
  assetForm.elements.createdBy.value = "Administrator";
  editingAssetRow = row;
  assetModalTitle.textContent = "Edit asset";
  assetSubmitButton.textContent = "Update asset";
  assetModal.hidden = false;
  assetForm.elements.assetCode.focus();
}
document.getElementById("addAssetBtn")?.addEventListener("click", () => {
  assetForm.reset();
  editingAssetRow = null;
  assetModalTitle.textContent = "Add asset";
  assetSubmitButton.textContent = "Save asset";
  assetModal.hidden = false;
  assetForm.elements.assetCode.focus();
});
document.querySelectorAll("[data-close-asset-modal]").forEach((button) =>
  button.addEventListener("click", () => {
    assetModal.hidden = true;
    editingAssetRow = null;
  }),
);
assetModal.addEventListener("click", (event) => {
  if (event.target === assetModal) {
    assetModal.hidden = true;
    editingAssetRow = null;
  }
});
assetTableBody
  ?.querySelectorAll("[data-edit-asset]")
  .forEach((button) =>
    button.addEventListener("click", () => openAssetEditor(button)),
  );
assetTableBody
  ?.querySelectorAll("[data-delete-asset]")
  .forEach((button) =>
    button.addEventListener("click", () => deleteAsset(button)),
  );
assetForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(assetForm).entries());
  const statusClass =
    data.status === "Assigned"
      ? "neutral"
      : data.status === "Returned"
        ? "warning"
        : "success";
  const row = editingAssetRow || document.createElement("tr");
  row.dataset.assetType = data.assetName;
  row.dataset.status = data.status;
  row.innerHTML = `
          <td><b>${escapeHtml(data.assetCode)}</b></td>
          <td>Hardware</td>
          <td>${escapeHtml(data.assetName)}</td>
          <td>${escapeHtml(data.brand)}</td>
          <td>${escapeHtml(data.serialNumber)}</td>
          <td>${formatCurrency(data.purchaseCost)}</td>
          <td>${formatDate(data.assignedDate)}</td>
          <td>${formatDate(data.warrantyDate)}</td>
          <td><span class="status ${statusClass}">${escapeHtml(data.status)}</span></td>
          <td><button class="btn small" type="button" data-edit-asset>Edit</button> <button class="btn small danger" type="button" data-delete-asset>Delete</button></td>
        `;
  if (!editingAssetRow) assetTableBody.appendChild(row);
  row
    .querySelector("[data-edit-asset]")
    .addEventListener("click", () =>
      openAssetEditor(row.querySelector("[data-edit-asset]")),
    );
  row
    .querySelector("[data-delete-asset]")
    .addEventListener("click", () =>
      deleteAsset(row.querySelector("[data-delete-asset]")),
    );
  assetModal.hidden = true;
  editingAssetRow = null;
  updateAssetCounts();
  refreshAvailableAssetLists();
});
function filterAssets() {
  if (!assetTableBody) return;
  const search =
    document.getElementById("assetSearch")?.value?.toLowerCase() || "";
  const type = document.getElementById("assetTypeFilter")?.value || "";
  const status = document.getElementById("assetStatusFilter")?.value || "";
  assetTableBody.querySelectorAll("tr").forEach((row) => {
    const matchesSearch = row.textContent.toLowerCase().includes(search);
    const matchesType = !type || row.dataset.assetType === type;
    const matchesStatus = !status || row.dataset.status === status;
    row.hidden = !(matchesSearch && matchesType && matchesStatus);
  });
}
["assetSearch", "assetTypeFilter", "assetStatusFilter"].forEach((id) => {
  document
    .getElementById(id)
    ?.addEventListener(id === "assetSearch" ? "input" : "change", filterAssets);
});
function refreshAvailableAssetLists() {
  const inventory = getAssetInventory();
  document.querySelectorAll(".available-asset-select").forEach((select) => {
    const assetType = select.dataset.assetType;
    const currentValue = select.value;
    select.innerHTML = `<option value="">Select an available ${assetType.toLowerCase()}</option>`;
    inventory.forEach((asset) => {
      if (asset.type === assetType && asset.status !== "Assigned") {
        const option = document.createElement("option");
        option.value = asset.code;
        option.textContent = `${asset.code} · ${asset.brand} · ${asset.serial}`;
        select.appendChild(option);
      }
    });
    if (
      Array.from(select.options).some((option) => option.value === currentValue)
    ) {
      select.value = currentValue;
    }
  });
}
if (assetTableBody) {
  syncAssetTableWithInventory();
}
refreshAvailableAssetLists();
const departmentModal = document.getElementById("departmentModal");
const departmentForm = document.getElementById("departmentForm");
const departmentTableBody = document.getElementById("departmentTableBody");
const departmentCardGrid = document.getElementById("departmentCardGrid");
const addDepartmentButton = document.getElementById("addDepartmentBtn");
const departmentModalTitle = document.getElementById("departmentModalTitle");
const departmentSubmitButton = departmentForm?.querySelector(
  'button[type="submit"]',
);
let editingDepartmentRow = null;

const closeDepartmentModal = () => {
  departmentModal.hidden = true;
  editingDepartmentRow = null;
};
addDepartmentButton?.addEventListener("click", () => {
  departmentForm.reset();
  editingDepartmentRow = null;
  departmentModalTitle.textContent = "Add department";
  departmentSubmitButton.textContent = "Save department";
  departmentModal.hidden = false;
  departmentForm.elements.deptId.focus();
});
document
  .querySelectorAll("[data-close-department-modal]")
  .forEach((button) => button.addEventListener("click", closeDepartmentModal));
departmentModal.addEventListener("click", (event) => {
  if (event.target === departmentModal) closeDepartmentModal();
});

function deleteDepartment(button) {
  const row = button.closest("tr");
  const departmentName =
    row.querySelector("td:nth-child(3)")?.textContent.trim() ||
    "this department";
  if (window.confirm(`Delete ${departmentName}?`)) {
    row.remove();
    refreshDepartmentCards();
  }
}
function openDepartmentEditor(button) {
  const row = button.closest("tr");
  const cells = row.querySelectorAll("td");
  departmentForm.reset();
  departmentForm.elements.deptId.value = cells[0].textContent.trim();
  departmentForm.elements.compId.value = "1";
  departmentForm.elements.deptCode.value = cells[1].textContent.trim();
  departmentForm.elements.deptName.value = cells[2].textContent.trim();
  departmentForm.elements.isActive.value = cells[3].textContent.includes(
    "Active",
  )
    ? "true"
    : "false";
  editingDepartmentRow = row;
  departmentModalTitle.textContent = "Edit department";
  departmentSubmitButton.textContent = "Update department";
  departmentModal.hidden = false;
  departmentForm.elements.deptCode.focus();
}
function refreshDepartmentCards() {
  if (!departmentCardGrid || !departmentTableBody) return;
  const cards = Array.from(departmentCardGrid.querySelectorAll(".master-card"));
  ["1", "2", "3"].forEach((departmentId, index) => {
    const row = Array.from(departmentTableBody.querySelectorAll("tr")).find(
      (departmentRow) =>
        departmentRow.cells[0]?.textContent.trim() === departmentId,
    );
    if (!row || !cards[index]) return;
    const code = row.cells[1].textContent.trim();
    const name = row.cells[2].textContent.trim();
    const status = row.cells[3].textContent.trim().replace("●", "").trim();
    cards[index].querySelector("h3").textContent = name;
    cards[index].querySelector(".code").textContent = `${code} · ${status}`;
  });
}
departmentTableBody
  ?.querySelectorAll("[data-edit-department]")
  .forEach((button) =>
    button.addEventListener("click", () => openDepartmentEditor(button)),
  );
departmentTableBody
  ?.querySelectorAll("[data-delete-department]")
  .forEach((button) =>
    button.addEventListener("click", () => deleteDepartment(button)),
  );
departmentForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const formData = new FormData(departmentForm);
  const department = Object.fromEntries(formData.entries());
  const isActive = department.isActive === "true";
  const statusClass = isActive ? "success" : "neutral";
  const statusText = isActive ? "Active" : "Inactive";
  const created = editingDepartmentRow
    ? editingDepartmentRow.cells[4].textContent.trim()
    : new Date().toLocaleDateString("en-GB", {
        day: "2-digit",
        month: "short",
        year: "numeric",
      });
  const row = editingDepartmentRow || document.createElement("tr");
  row.innerHTML = `
          <td>${escapeHtml(department.deptId)}</td>
          <td><span class="tag">${escapeHtml(department.deptCode)}</span></td>
          <td>${escapeHtml(department.deptName)}</td>
          <td><span class="status ${statusClass}">${statusText}</span></td>
          <td>${created}</td>
          <td>
            <button class="btn small" type="button" data-edit-department>Edit</button>
            <button class="btn small danger" type="button" data-delete-department>Delete</button>
          </td>
        `;
  if (!editingDepartmentRow && departmentTableBody)
    departmentTableBody.appendChild(row);
  row
    .querySelector("[data-edit-department]")
    .addEventListener("click", () =>
      openDepartmentEditor(row.querySelector("[data-edit-department]")),
    );
  row
    .querySelector("[data-delete-department]")
    .addEventListener("click", () =>
      deleteDepartment(row.querySelector("[data-delete-department]")),
    );
  refreshDepartmentCards();
  closeDepartmentModal();
});
const teamModal = document.getElementById("teamModal");
const teamForm = document.getElementById("teamForm");
const teamTableBody = document.getElementById("teamTableBody");
const addTeamButton = document.getElementById("addTeamBtn");
const teamModalTitle = document.getElementById("teamModalTitle");
const teamSubmitButton = teamForm?.querySelector('button[type="submit"]');
let editingTeamRow = null;
const syncEmployeeTeamOptions = () => {
  document.querySelectorAll('select[name="teamId"]').forEach((select) => {
    if (select.id === "employeeTeamSelect" || select.classList.contains("team-select")) {
      const selected = select.value;
      const activeTeams = Array.from(teamTableBody?.querySelectorAll("tr") || [])
        .filter((row) => row.cells[4]?.textContent.includes("Active"))
        .map((row) => row.cells[2]?.textContent.trim())
        .filter(Boolean);
      select.innerHTML =
        '<option value="">Select team</option>' +
        activeTeams
          .map((team) => `<option value="${escapeHtml(team)}">${escapeHtml(team)}</option>`)
          .join("");
      if (activeTeams.includes(selected) || activeTeams.includes(employeeForm?.elements?.teamId?.dataset.currentValue)) {
        select.value = selected || employeeForm?.elements?.teamId?.dataset.currentValue || "";
      }
    }
  });
};

const closeTeamModal = () => {
  if (teamModal) teamModal.hidden = true;
  editingTeamRow = null;
};
addTeamButton?.addEventListener("click", () => {
  teamForm?.reset();
  editingTeamRow = null;
  if (teamModalTitle) teamModalTitle.textContent = "Add team";
  if (teamSubmitButton) teamSubmitButton.textContent = "Save team";
  if (teamModal) {
    teamModal.hidden = false;
    teamForm.elements.teamId.focus();
  }
});
document
  .querySelectorAll("[data-close-team-modal]")
  .forEach((button) => button.addEventListener("click", closeTeamModal));
teamModal?.addEventListener("click", (event) => {
  if (event.target === teamModal) closeTeamModal();
});
function openTeamEditor(button) {
  const row = button.closest("tr");
  const cells = row.querySelectorAll("td");
  teamForm.reset();
  teamForm.elements.teamId.value = cells[0].textContent.trim();
  teamForm.elements.compId.value = "1";
  teamForm.elements.teamCode.value = cells[1].textContent.trim();
  teamForm.elements.teamName.value = cells[2].textContent.trim();
  teamForm.elements.teamDescription.value = cells[3].textContent.trim();
  teamForm.elements.teamIsActive.value = cells[4].textContent.includes("Active") ? "true" : "false";
  editingTeamRow = row;
  teamModalTitle.textContent = "Edit team";
  teamSubmitButton.textContent = "Update team";
  teamModal.hidden = false;
  teamForm.elements.teamCode.focus();
}
function deleteTeam(button) {
  const row = button.closest("tr");
  const teamName = row.cells[2]?.textContent.trim() || "this team";
  if (window.confirm(`Delete ${teamName}?`)) {
    row.remove();
    syncEmployeeTeamOptions();
  }
}
teamTableBody?.querySelectorAll("[data-edit-team]").forEach((button) => {
  button.addEventListener("click", () => openTeamEditor(button));
});
teamTableBody?.querySelectorAll("[data-delete-team]").forEach((button) => {
  button.addEventListener("click", () => deleteTeam(button));
});
teamForm?.addEventListener("submit", (event) => {
  event.preventDefault();
  const data = Object.fromEntries(new FormData(teamForm).entries());
  const isActive = data.teamIsActive === "true";
  const row = editingTeamRow || document.createElement("tr");
  row.innerHTML = `
    <td>${escapeHtml(data.teamId)}</td>
    <td><span class="tag">${escapeHtml(data.teamCode)}</span></td>
    <td>${escapeHtml(data.teamName)}</td>
    <td>${escapeHtml(data.teamDescription || "")}</td>
    <td><span class="status ${isActive ? "success" : "neutral"}">${isActive ? "Active" : "Inactive"}</span></td>
    <td>
      <button class="btn small" type="button" data-edit-team>Edit</button>
      <button class="btn small danger" type="button" data-delete-team>Delete</button>
    </td>
  `;
  if (!editingTeamRow) teamTableBody.appendChild(row);
  row.querySelector("[data-edit-team]").addEventListener("click", () => openTeamEditor(row.querySelector("[data-edit-team]")));
  row.querySelector("[data-delete-team]").addEventListener("click", () => deleteTeam(row.querySelector("[data-delete-team]")));
  syncEmployeeTeamOptions();
  closeTeamModal();
});
const teamSearch = document.getElementById("teamSearch");
const teamStatusFilter = document.getElementById("teamStatusFilter");
const filterTeams = () => {
  const search = (teamSearch?.value || "").toLowerCase();
  const status = teamStatusFilter?.value || "";
  teamTableBody?.querySelectorAll("tr").forEach((row) => {
    const matchesSearch = row.textContent.toLowerCase().includes(search);
    const matchesStatus = !status || row.cells[4]?.textContent.includes(status);
    row.hidden = !(matchesSearch && matchesStatus);
  });
};
teamSearch?.addEventListener("input", filterTeams);
teamStatusFilter?.addEventListener("change", filterTeams);
syncEmployeeTeamOptions();
const employeeModal = document.getElementById("employeeModal");
const employeeForm = document.getElementById("employeeForm");
const employeeTableBody = document.getElementById("employeeTableBody");
const addEmployeeButton = document.getElementById("addEmployeeBtn");
const employeeModalTitle = document.getElementById("employeeModalTitle");
const employeeSubmitButton = employeeForm?.querySelector(
  'button[type="submit"]',
);
let editingEmployeeRow = null;
const employeeRowData = new WeakMap();
const departmentNames = {
  1: "Revenue Generating Department",
  2: "Reservation Department",
  3: "Administrative Department",
};
if (employeeForm && !employeeForm.querySelector(".direct-cost-launcher")) {
  const insuranceSelection = employeeForm.querySelector("#employeeInsuranceSection");
  if (insuranceSelection) {
    insuranceSelection.insertAdjacentHTML(
      "afterend",
      `<div class="direct-cost-launcher form-field-wide">
        <div class="direct-cost-launcher-copy">
          <span class="direct-cost-launcher-icon">₹</span>
          <div>
            <strong>Direct cost details</strong>
            <small>Add salary, certification reimbursement and holiday bonus</small>
          </div>
        </div>
        <button class="direct-cost-action" type="button" id="openDirectCostModal">
          <span>Open details</span>
          <span aria-hidden="true">→</span>
        </button>
      </div>`,
    );
  }
}
employeeForm
  .querySelectorAll('input[type="checkbox"][data-detail]')
  .forEach((checkbox) => {
    checkbox.addEventListener("change", () => {
      const detail = document.getElementById(checkbox.dataset.detail);
      if (detail) detail.hidden = !checkbox.checked;
    });
  });
const directCostModalMarkup = `
  <div class="modal-backdrop" id="directCostModal" hidden>
    <div class="modal" role="dialog" aria-modal="true" aria-labelledby="directCostModalTitle">
      <div class="modal-head">
        <div>
          <h2 id="directCostModalTitle">Direct cost details</h2>
          <p>Employee-linked costs used in the direct-cost calculation.</p>
        </div>
        <button class="modal-close" type="button" data-close-direct-cost-modal>×</button>
      </div>
      <form id="directCostForm">
        <div class="assignment-section form-field-wide">
          <h3>Salary</h3>
          <div class="detail-grid">
            <label>Annual salary (₹)<input name="annualSalary" type="number" min="0" step="0.01" placeholder="300000" /></label>
            <label>Monthly salary (₹)<input name="monthlySalary" type="number" min="0" step="0.01" placeholder="25000" /></label>
            <label>Salary effective from<input name="salaryEffectiveFrom" type="date" /></label>
            <label>Salary effective to<input name="salaryEffectiveTo" type="date" /></label>
            <label>Salary status<select name="salaryIsActive"><option value="true">Active</option><option value="false">Inactive</option></select></label>
            <label class="form-field-wide">Salary remarks<textarea name="salaryRemarks" rows="2" placeholder="Optional salary history note"></textarea></label>
          </div>
        </div>
        <div class="assignment-section form-field-wide" style="margin-top:12px;">
          <h3>Professional certification reimbursement</h3>
          <div class="detail-grid">
            <label>Certification name<input name="certificationName" placeholder="Professional certification" /></label>
            <label>Provider<input name="certificationProvider" placeholder="Provider" /></label>
            <label>Amount (₹)<input name="certificationAmount" type="number" min="0" step="0.01" placeholder="4500" /></label>
            <label>Reimbursement date<input name="reimbursementDate" type="date" /></label>
            <label>Effective year<input name="reimbursementEffectiveYear" type="number" min="2000" max="2100" placeholder="2026" /></label>
          </div>
        </div>
        <div class="assignment-section form-field-wide" style="margin-top:12px;">
          <h3>Holiday bonus</h3>
          <div class="detail-grid">
            <label>Bonus amount (₹)<input name="holidayBonusAmount" type="number" min="0" step="0.01" placeholder="6000" /></label>
            <label>Effective year<input name="holidayBonusEffectiveYear" type="number" min="2000" max="2100" placeholder="2026" /></label>
          </div>
        </div>
        <div class="modal-actions">
          <button class="btn" type="button" data-close-direct-cost-modal>Cancel</button>
          <button class="btn primary" type="submit">Save direct cost details</button>
        </div>
      </form>
    </div>
  </div>
`;
document.body.insertAdjacentHTML("beforeend", directCostModalMarkup);
const directCostModal = document.getElementById("directCostModal");
const directCostForm = document.getElementById("directCostForm");
const openDirectCostModalButton = document.getElementById("openDirectCostModal");
const closeDirectCostModal = () => {
  if (directCostModal) directCostModal.hidden = true;
};
openDirectCostModalButton?.addEventListener("click", () => {
  if (directCostModal) directCostModal.hidden = false;
  directCostForm?.elements?.annualSalary?.focus();
});
document
  .querySelectorAll("[data-close-direct-cost-modal]")
  .forEach((button) => button.addEventListener("click", closeDirectCostModal));
directCostModal?.addEventListener("click", (event) => {
  if (event.target === directCostModal) closeDirectCostModal();
});
directCostForm?.addEventListener("submit", (event) => {
  event.preventDefault();
  const directCostButton = document.getElementById("openDirectCostModal");
  if (directCostButton) {
    directCostButton.innerHTML = "<span>Details saved</span><span aria-hidden=\"true\">✓</span>";
  }
  closeDirectCostModal();
});
const escapeHtml = (value) =>
  value.replace(
    /[&<>"']/g,
    (character) =>
      ({
        "&": "&amp;",
        "<": "&lt;",
        ">": "&gt;",
        '"': "&quot;",
        "'": "&#039;",
      })[character],
  );
const insuranceSection = document.getElementById("employeeInsuranceSection");
const clearEmployeeInsurance = () => {
  if (!insuranceSection) return;
  insuranceSection
    .querySelectorAll('input[name="insurance"]')
    .forEach((checkbox) => {
      checkbox.checked = false;
    });
  insuranceSection.querySelectorAll(".item-detail").forEach((detail) => {
    detail.hidden = true;
    detail.querySelectorAll("input, select").forEach((field) => {
      if (field instanceof HTMLInputElement) field.value = "";
      if (field instanceof HTMLSelectElement) {
        field.selectedIndex = 0;
      }
    });
  });
};
const syncEmployeeInsuranceDepartment = (clearOnReservation = false) => {
  if (
    !insuranceSection ||
    !employeeForm ||
    !employeeForm.elements ||
    !employeeForm.elements.deptId
  )
    return;
  const departmentId = String(employeeForm.elements.deptId.value);
  const isReservation = departmentId === "2";

  // Keep section visible
  insuranceSection.hidden = false;

  let notice = insuranceSection.querySelector(".insurance-disabled-notice");
  if (!notice) {
    notice = document.createElement("div");
    notice.className = "insurance-disabled-notice";
    notice.style.cssText =
      "background:#fef2f2; border:1px solid #fecaca; color:#991b1b; padding:8px 12px; border-radius:6px; font-size:12px; font-weight:600; margin-bottom:12px; display:flex; align-items:center; gap:8px;";
    notice.innerHTML = "<span>🚫</span><span>Insurance is disabled for Reservation Department (RE) employees.</span>";
    const h3 = insuranceSection.querySelector("h3");
    if (h3) {
      h3.insertAdjacentElement("afterend", notice);
    } else {
      insuranceSection.insertBefore(notice, insuranceSection.firstChild);
    }
  }

  const checkboxGrid = insuranceSection.querySelector(".checkbox-grid");
  const checkboxes = insuranceSection.querySelectorAll('input[name="insurance"]');
  const details = insuranceSection.querySelectorAll(".item-detail");

  if (isReservation) {
    notice.style.display = "flex";
    if (checkboxGrid) {
      checkboxGrid.style.opacity = "0.45";
      checkboxGrid.style.pointerEvents = "none";
      checkboxGrid.style.filter = "grayscale(1)";
    }
    checkboxes.forEach((cb) => {
      cb.disabled = true;
      cb.checked = false;
    });
    details.forEach((detail) => {
      detail.hidden = true;
      detail.querySelectorAll("input, select").forEach((field) => {
        field.disabled = true;
        if (field instanceof HTMLInputElement) field.value = "";
        if (field instanceof HTMLSelectElement) field.selectedIndex = 0;
      });
    });
    if (clearOnReservation) clearEmployeeInsurance();
  } else {
    notice.style.display = "none";
    if (checkboxGrid) {
      checkboxGrid.style.opacity = "1";
      checkboxGrid.style.pointerEvents = "auto";
      checkboxGrid.style.filter = "none";
    }
    checkboxes.forEach((cb) => {
      cb.disabled = false;
    });
    details.forEach((detail) => {
      detail.querySelectorAll("input, select").forEach((field) => {
        field.disabled = false;
      });
    });
  }
};
employeeForm?.elements?.deptId?.addEventListener("change", () => {
  syncEmployeeInsuranceDepartment(true);
});
const closeEmployeeModal = () => {
  employeeModal.hidden = true;
  editingEmployeeRow = null;
};
addEmployeeButton?.addEventListener("click", () => {
  if (employeeForm) {
    employeeForm.reset();
    directCostForm?.reset();
    const directCostButton = document.getElementById("openDirectCostModal");
    if (directCostButton) {
      directCostButton.innerHTML = "<span>Open details</span><span aria-hidden=\"true\">→</span>";
    }
    employeeForm
      .querySelectorAll(".item-detail")
      .forEach((detail) => (detail.hidden = true));
    const today = new Date().toISOString().slice(0, 10);
    [
      "laptopAssignedDate",
      "desktopAssignedDate",
      "monitorAssignedDate",
      "mobileAssignedDate",
    ].forEach((fieldName) => {
      if (employeeForm.elements && employeeForm.elements[fieldName]) {
        employeeForm.elements[fieldName].value = today;
      }
    });
    syncEmployeeInsuranceDepartment(false);
    employeeForm.elements?.empCode?.focus();
  }
  if (employeeModalTitle) employeeModalTitle.textContent = "Add employee";
  if (employeeSubmitButton) employeeSubmitButton.textContent = "Save employee";
  editingEmployeeRow = null;
  if (employeeModal) employeeModal.hidden = false;
});
employeeTableBody
  ?.querySelectorAll("[data-edit-employee]")
  .forEach((button) => {
    button.addEventListener("click", () => openEmployeeEditor(button));
  });
employeeTableBody
  ?.querySelectorAll("[data-delete-employee]")
  .forEach((button) => {
    button.addEventListener("click", () => deleteEmployee(button));
  });
const deassignModal = document.getElementById("deassignEmployeeModal");
const deassignTitle = document.getElementById("deassignModalTitle");
const deassignDetails = document.getElementById("deassignEmployeeDetails");
const deassignContainer = document.getElementById("deassignAssetListContainer");
const confirmDeassignBtn = document.getElementById("confirmDeassignDeleteBtn");
let employeeRowPendingDeletion = null;

const closeDeassignModal = () => {
  if (deassignModal) deassignModal.hidden = true;
  employeeRowPendingDeletion = null;
};

document
  .querySelectorAll("[data-close-deassign-modal]")
  .forEach((btn) => btn.addEventListener("click", closeDeassignModal));

if (deassignModal) {
  deassignModal.addEventListener("click", (e) => {
    if (e.target === deassignModal) closeDeassignModal();
  });
}

function getAssignedAssetsForEmployee(empCode, empName, row) {
  const inventory = getAssetInventory();
  const assigned = [];

  inventory.forEach((asset) => {
    if (
      asset.status === "Assigned" &&
      ((asset.empCode && asset.empCode === empCode) ||
        (asset.employee &&
          asset.employee.toLowerCase() === empName.toLowerCase()))
    ) {
      assigned.push(asset);
    }
  });

  const data = employeeRowData.get(row);
  if (data && data.assignmentDetails) {
    const details = data.assignmentDetails;
    ["laptopAsset", "desktopAsset", "monitorAsset", "mobileAsset"].forEach(
      (k) => {
        const code = details[k];
        if (code && !assigned.some((a) => a.code === code)) {
          const matched = inventory.find((i) => i.code === code);
          if (matched) assigned.push(matched);
        }
      },
    );
  }

  if (empCode === "EMP-001" && assigned.length === 0) {
    inventory.forEach((asset) => {
      if (
        (asset.code === "LAP-003" || asset.code === "MOB-001") &&
        asset.status === "Assigned"
      ) {
        assigned.push(asset);
      }
    });
  }

  return assigned;
}

function deleteEmployee(button) {
  const row = button.closest("tr");
  if (!row) return;

  const empCode = row.cells[0]?.textContent.trim();
  const empName = row.cells[1]?.textContent.trim();
  const email = row.cells[2]?.textContent.trim();
  const designation = row.cells[3]?.textContent.trim();
  const dept = row.cells[4]?.textContent.trim();

  employeeRowPendingDeletion = row;

  const assignedAssets = getAssignedAssetsForEmployee(empCode, empName, row);

  const initials = empName
    .split(/\s+/)
    .map((p) => p[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();

  if (deassignDetails) {
    deassignDetails.innerHTML = `
            <div style="background: var(--bg); border: 1px solid var(--line); border-radius: 9px; padding: 13px 15px; margin-bottom: 15px; display: flex; align-items: center; justify-content: space-between; gap: 12px;">
              <div style="display: flex; align-items: center; gap: 12px;">
                <span class="emp-avatar" style="width: 38px; height: 38px; font-size: 13px;">${escapeHtml(initials)}</span>
                <div>
                  <div style="font-weight: 700; font-size: 14.5px;">${escapeHtml(empName)} <span class="tag" style="margin-left: 6px;">${escapeHtml(empCode)}</span></div>
                  <div style="color: var(--muted); font-size: 12px; margin-top: 2px;">${escapeHtml(designation)} · ${escapeHtml(dept)}</div>
                </div>
              </div>
              <div style="text-align: right; font-size: 12px; color: var(--muted);">${escapeHtml(email)}</div>
            </div>
          `;
  }

  if (deassignContainer) {
    if (assignedAssets.length > 0) {
      deassignContainer.innerHTML = `
              <div style="background: #fffbeb; border: 1px solid #fde68a; border-radius: 8px; padding: 11px 14px; margin-bottom: 14px; font-size: 12.5px; color: #92400e; line-height: 1.5;">
                <strong>⚠️ Active Asset Assignments Found:</strong><br />
                This employee currently has <b>${assignedAssets.length} active company asset(s)</b> registered. Please verify that all physical equipment has been resigned/returned and select assets to de-assign back to stock.
              </div>

              <div class="table-wrap" style="border: 1px solid var(--line); border-radius: 8px; overflow: hidden; margin-bottom: 14px;">
                <table style="width: 100%; border-collapse: collapse; font-size: 12px;">
                  <thead>
                    <tr style="background: var(--bg); border-bottom: 1px solid var(--line);">
                      <th style="padding: 8px 10px; width: 34px; text-align: center;">
                        <input type="checkbox" id="selectAllDeassign" checked title="Select/Deselect All" />
                      </th>
                      <th style="padding: 8px 10px; text-align: left;">Asset code</th>
                      <th style="padding: 8px 10px; text-align: left;">Type</th>
                      <th style="padding: 8px 10px; text-align: left;">Brand / Serial</th>
                      <th style="padding: 8px 10px; text-align: left;">Assigned date</th>
                      <th style="padding: 8px 10px; text-align: left;">Action</th>
                    </tr>
                  </thead>
                  <tbody>
                    ${assignedAssets
                      .map(
                        (asset) => `
                      <tr style="border-bottom: 1px solid var(--line);">
                        <td style="padding: 8px 10px; text-align: center;">
                          <input type="checkbox" class="deassign-item-check" value="${escapeHtml(asset.code)}" checked />
                        </td>
                        <td style="padding: 8px 10px;"><b>${escapeHtml(asset.code)}</b></td>
                        <td style="padding: 8px 10px;">${escapeHtml(asset.type)}</td>
                        <td style="padding: 8px 10px;">${escapeHtml(asset.brand)} · <small style="color:var(--muted)">${escapeHtml(asset.serial)}</small></td>
                        <td style="padding: 8px 10px; color: var(--muted);">${escapeHtml(asset.assignedDate || "—")}</td>
                        <td style="padding: 8px 10px;"><span class="status warning">De-assign to Stock</span></td>
                      </tr>
                    `,
                      )
                      .join("")}
                  </tbody>
                </table>
              </div>

              <label style="display: flex; align-items: flex-start; gap: 8px; cursor: pointer; font-size: 12px; color: var(--text);">
                <input type="checkbox" id="deassignAckCheck" checked style="margin-top: 2px;" />
                <span>I confirm that all company assets and equipment have been officially resigned / handed over by this employee.</span>
              </label>
            `;

      const selectAll = document.getElementById("selectAllDeassign");
      selectAll?.addEventListener("change", () => {
        document.querySelectorAll(".deassign-item-check").forEach((cb) => {
          cb.checked = selectAll.checked;
        });
      });
    } else {
      deassignContainer.innerHTML = `
              <div style="background: #f0fdf4; border: 1px solid #bbf7d0; border-radius: 8px; padding: 13px 15px; margin-bottom: 14px; font-size: 12.5px; color: #166534;">
                <b>✓ No Assets Assigned:</b> This employee does not have any active hardware equipment registered to them.
              </div>
              <p style="font-size: 13px; color: var(--text); margin: 10px 0 0;">
                Are you sure you want to permanently delete employee <b>${escapeHtml(empName)} (${escapeHtml(empCode)})</b>?
              </p>
            `;
    }
  }

  if (confirmDeassignBtn) {
    confirmDeassignBtn.textContent =
      assignedAssets.length > 0
        ? "De-assign Assets & Delete Employee"
        : "Delete Employee";
  }

  if (deassignModal) {
    deassignModal.hidden = false;
  } else {
    if (window.confirm(`Delete ${empName}?`)) {
      row.remove();
    }
  }
}

if (confirmDeassignBtn) {
  confirmDeassignBtn.addEventListener("click", () => {
    if (!employeeRowPendingDeletion) return;

    const row = employeeRowPendingDeletion;
    const empName = row.cells[1]?.textContent.trim();

    const checkedAssetCodes = Array.from(
      document.querySelectorAll(".deassign-item-check:checked"),
    ).map((cb) => cb.value);

    const inventory = getAssetInventory();
    checkedAssetCodes.forEach((code) => {
      const item = inventory.find((i) => i.code === code);
      if (item) {
        item.status = "In Stock";
        item.assignedDate = "—";
        item.empCode = "";
        item.employee = "";
      }
    });
    saveAssetInventory(inventory);

    syncAssetTableWithInventory();
    refreshAvailableAssetLists();

    row.remove();
    closeDeassignModal();

    const toast = document.createElement("div");
    toast.className = "toast-notification";
    toast.style.cssText =
      "position:fixed;bottom:24px;right:24px;background:#1e293b;color:#fff;padding:12px 18px;border-radius:8px;box-shadow:0 8px 24px rgba(0,0,0,0.2);z-index:9999;font-size:13px;display:flex;align-items:center;gap:8px;";
    toast.innerHTML = `<span>✓</span> Employee <b>${escapeHtml(empName)}</b> deleted.${checkedAssetCodes.length > 0 ? ` ${checkedAssetCodes.length} asset(s) de-assigned back to inventory.` : ""}`;
    document.body.appendChild(toast);
    setTimeout(() => toast.remove(), 4000);
  });
}
function openEmployeeEditor(button) {
  const row = button.closest("tr");
  const cells = row.querySelectorAll("td");
  employeeForm.reset();
  employeeForm
    .querySelectorAll(".item-detail")
    .forEach((detail) => (detail.hidden = true));
  const departmentCode =
    cells[4].querySelector(".tag")?.textContent.trim() || "";
  const departmentId =
    departmentCode === "Revenue Generating Department"
      ? "1"
      : departmentCode === "Reservation Department"
        ? "2"
        : departmentCode === "Administrative Department"
          ? "3"
          : departmentCode === "RG"
            ? "1"
            : departmentCode === "RE"
              ? "2"
              : "3";
  const savedData = employeeRowData.get(row) || {};
  employeeForm.elements.compId.value = savedData.compId || "1";
  employeeForm.elements.empCode.value =
    savedData.empCode || cells[0].textContent.trim();
  employeeForm.elements.empName.value =
    savedData.empName || cells[1].textContent.trim();
  employeeForm.elements.email.value =
    savedData.email || cells[2].textContent.trim();
  employeeForm.elements.designation.value =
    savedData.designation || cells[3].textContent.trim();
  employeeForm.elements.deptId.value = savedData.deptId || departmentId;
  employeeForm.elements.teamId.value =
    savedData.teamId || cells[5].textContent.trim();
  employeeForm.elements.status.value =
    savedData.status || cells[6].textContent.trim().replace("●", "").trim();
  if (directCostForm) {
    directCostForm.reset();
    const directCostDetails =
      savedData.directCostDetails ||
      savedData.assignmentDetails?.directCostDetails ||
      null;
    if (directCostDetails) {
      const salary = directCostDetails.salary || {};
      directCostForm.elements.annualSalary.value = salary.annualSalary || "";
      directCostForm.elements.monthlySalary.value = salary.monthlySalary || "";
      directCostForm.elements.salaryEffectiveFrom.value = salary.effectiveFrom || "";
      directCostForm.elements.salaryEffectiveTo.value = salary.effectiveTo || "";
      directCostForm.elements.salaryIsActive.value = String(salary.isActive ?? true);
      directCostForm.elements.salaryRemarks.value = salary.remarks || "";
      const certification = directCostDetails.certificationReimbursement || {};
      directCostForm.elements.certificationName.value = certification.certificationName || "";
      directCostForm.elements.certificationProvider.value = certification.provider || "";
      directCostForm.elements.certificationAmount.value = certification.amount || "";
      directCostForm.elements.reimbursementDate.value = certification.reimbursementDate || "";
      directCostForm.elements.reimbursementEffectiveYear.value = certification.effectiveYear || "";
      const holidayBonus = directCostDetails.holidayBonus || {};
      directCostForm.elements.holidayBonusAmount.value = holidayBonus.amount || "";
      directCostForm.elements.holidayBonusEffectiveYear.value = holidayBonus.effectiveYear || "";
    }
  }
  const directCostButton = document.getElementById("openDirectCostModal");
  const hasDirectCostDetails =
    savedData.directCostDetails ||
    savedData.assignmentDetails?.directCostDetails;
  if (directCostButton) {
    directCostButton.innerHTML = hasDirectCostDetails
      ? "<span>Details saved</span><span aria-hidden=\"true\">✓</span>"
      : "<span>Open details</span><span aria-hidden=\"true\">→</span>";
  }
  syncEmployeeInsuranceDepartment(false);
  if (savedData.assignmentDetails) {
    Object.entries(savedData.assignmentDetails).forEach(([name, value]) => {
      const field = employeeForm.elements[name];
      if (!field) return;
      if (field instanceof RadioNodeList) {
        Array.from(field).forEach((checkbox) => {
          checkbox.checked = Array.isArray(value)
            ? value.includes(checkbox.value)
            : value === checkbox.value;
          if (checkbox.checked) {
            const detail = document.getElementById(checkbox.dataset.detail);
            if (detail) detail.hidden = false;
          }
        });
        return;
      }
      if (field instanceof HTMLInputElement && field.type === "checkbox") {
        field.checked = Array.isArray(value)
          ? value.includes(field.value)
          : value === field.value;
        if (field.checked) {
          const detail = document.getElementById(field.dataset.detail);
          if (detail) detail.hidden = false;
        }
        return;
      }
      if (
        field instanceof HTMLInputElement ||
        field instanceof HTMLSelectElement ||
        field instanceof HTMLTextAreaElement
      ) {
        field.value = value;
      }
    });
  }
  editingEmployeeRow = row;
  employeeModalTitle.textContent = "Edit employee";
  employeeSubmitButton.textContent = "Update employee";
  employeeModal.hidden = false;
  employeeForm.elements.empCode.focus();
}
document
  .querySelectorAll("[data-close-employee-modal]")
  .forEach((button) => button.addEventListener("click", closeEmployeeModal));
employeeModal.addEventListener("click", (event) => {
  if (event.target === employeeModal) closeEmployeeModal();
});
employeeForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const formData = new FormData(employeeForm);
  const employee = Object.fromEntries(formData.entries());
  employee.resources = formData.getAll("resources");
  employee.software = formData.getAll("software");
  const isInsuranceEligible =
    employee.deptId === "1" || employee.deptId === "3";
  employee.insurance = isInsuranceEligible ? formData.getAll("insurance") : [];
  const directCostData = directCostForm
    ? new FormData(directCostForm)
    : new FormData();
  const generatedEmployeeLink = employee.empCode || "";
  employee.directCostDetails = {
    salary: {
      sal_id: null,
      emp_id: generatedEmployeeLink,
      annualSalary: directCostData.get("annualSalary"),
      monthlySalary: directCostData.get("monthlySalary"),
      effectiveFrom: directCostData.get("salaryEffectiveFrom"),
      effectiveTo: directCostData.get("salaryEffectiveTo"),
      isActive: directCostData.get("salaryIsActive") === "true",
      remarks: directCostData.get("salaryRemarks"),
    },
    certificationReimbursement: {
      pcr_id: null,
      emp_id: generatedEmployeeLink,
      certificationName: directCostData.get("certificationName"),
      provider: directCostData.get("certificationProvider"),
      amount: directCostData.get("certificationAmount"),
      reimbursementDate: directCostData.get("reimbursementDate"),
      effectiveYear: directCostData.get("reimbursementEffectiveYear"),
    },
    holidayBonus: {
      hb_id: null,
      emp_id: generatedEmployeeLink,
      amount: directCostData.get("holidayBonusAmount"),
      effectiveYear: directCostData.get("holidayBonusEffectiveYear"),
    },
  };
  employee.assignmentDetails = {
    ...Object.fromEntries(formData.entries()),
    resources: employee.resources,
    software: employee.software,
    insurance: employee.insurance,
    directCostDetails: employee.directCostDetails,
  };
  const today = new Date().toISOString().slice(0, 10);
  const inventory = getAssetInventory();
  [
    ["laptopAsset", "laptopAssignedDate"],
    ["desktopAsset", "desktopAssignedDate"],
    ["monitorAsset", "monitorAssignedDate"],
    ["mobileAsset", "mobileAssignedDate"],
  ].forEach(([fieldName, dateFieldName]) => {
    const assetCode = formData.get(fieldName);
    if (!assetCode) return;
    const assignedDate = formData.get(dateFieldName) || today;
    const item = inventory.find((i) => i.code === String(assetCode));
    if (item) {
      item.status = "Assigned";
      item.assignedDate = formatDate(assignedDate);
      item.empCode = employee.empCode;
      item.employee = employee.empName;
    }
  });
  saveAssetInventory(inventory);
  syncAssetTableWithInventory();
  refreshAvailableAssetLists();
  const initials = employee.empName
    .split(/\s+/)
    .map((part) => part[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
  const statusClass = employee.status === "Active" ? "success" : "neutral";
  const row = editingEmployeeRow || document.createElement("tr");
  row.innerHTML = `
          <td><b>${escapeHtml(employee.empCode)}</b></td>
          <td><div class="employee"><span class="emp-avatar">${escapeHtml(initials)}</span>${escapeHtml(employee.empName)}</div></td>
          <td>${escapeHtml(employee.email)}</td>
          <td>${escapeHtml(employee.designation)}</td>
          <td><span class="tag">${departmentNames[employee.deptId]}</span></td>
          <td>${escapeHtml(employee.teamId)}</td>
          <td><span class="status ${statusClass}">${escapeHtml(employee.status)}</span></td>
          <td>
            <button class="btn small" type="button" data-edit-employee>Edit</button>
            <button class="btn small danger" type="button" data-delete-employee>Delete</button>
          </td>
        `;
  employeeRowData.set(row, employee);
  if (!editingEmployeeRow && employeeTableBody)
    employeeTableBody.appendChild(row);
  row
    .querySelector("[data-edit-employee]")
    ?.addEventListener("click", () =>
      openEmployeeEditor(row.querySelector("[data-edit-employee]")),
    );
  row
    .querySelector("[data-delete-employee]")
    ?.addEventListener("click", () =>
      deleteEmployee(row.querySelector("[data-delete-employee]")),
    );
  refreshAvailableAssetLists();
  refreshInsuranceTable();
  closeEmployeeModal();
});
function refreshInsuranceTable() {
  const insuranceBody = document.getElementById("insuranceTableBody");
  if (!insuranceBody) return;
  insuranceBody
    .querySelectorAll(".insurance-dynamic")
    .forEach((row) => row.remove());

  const dynamicTypes = [
    ["Health Insurance", "health", "health_riderOpted"],
    ["Life Insurance", "life", null],
    ["Accidental Insurance", "accidental", null],
  ];

  if (employeeTableBody) {
    employeeTableBody.querySelectorAll("tr").forEach((employeeRow) => {
      const employee = employeeRowData.get(employeeRow);
      if (!employee || !Array.isArray(employee.insurance)) return;
      if (!["1", "3"].includes(String(employee.deptId))) return;

      employee.insurance.forEach((insuranceName) => {
        const config = dynamicTypes.find(([name]) => name === insuranceName);
        if (!config) return;
        const [, prefix, riderName] = config;
        const details = employee.assignmentDetails || {};
        const premium = details[`${prefix}_premiumAmount`];
        const status = details[`${prefix}_status`] || "Active";
        const statusClass =
          status === "Active"
            ? "success"
            : status === "Renewal Due"
              ? "warning"
              : "neutral";
        const formatValue = (value) => {
          if (!value) return "—";
          if (String(value).includes("-")) return value;
          return value;
        };
        const formatPremium = (value) =>
          value ? `₹${Number(value).toLocaleString("en-IN")}` : "—";
        const effectiveFrom = formatValue(
          details[`${prefix}_effectiveFrom`]
            ? formatDate(details[`${prefix}_effectiveFrom`])
            : "",
        );
        const renewalDate = formatValue(
          details[`${prefix}_renewalDate`]
            ? formatDate(details[`${prefix}_renewalDate`])
            : "",
        );
        const row = document.createElement("tr");
        row.className = "insurance-dynamic";
        row.dataset.insuranceType = insuranceName;
        row.dataset.status = status;
        row.innerHTML = `
              <td><b>${escapeHtml(employee.empName)}</b></td>
              <td>${escapeHtml(insuranceName)}</td>
              <td>${escapeHtml(formatValue(details[`${prefix}_policyNo`]))}</td>
              <td>${escapeHtml(formatValue(details[`${prefix}_policyName`]))}</td>
              <td>${escapeHtml(formatValue(details[`${prefix}_provider`]))}</td>
              <td>${escapeHtml(formatValue(details[`${prefix}_frequency`]))}</td>
              <td>${escapeHtml(effectiveFrom)}</td>
              <td>${escapeHtml(renewalDate)}</td>
              <td>${escapeHtml(formatPremium(premium))}</td>
              <td>${escapeHtml(riderName ? details[riderName] || "No" : "—")}</td>
              <td><span class="status ${statusClass}">${escapeHtml(status)}</span></td>
            `;
        insuranceBody.appendChild(row);
      });
    });
  }
  updateInsuranceMetrics();
}
function updateInsuranceMetrics() {
  const rows = Array.from(
    document.querySelectorAll("#insuranceTableBody tr"),
  ).filter((row) => !row.hidden);
  const visibleRows = rows.length ? rows : [];
  document.getElementById("totalPolicyCount").textContent = String(
    visibleRows.length,
  );
  document.getElementById("activePolicyCount").textContent = String(
    visibleRows.filter((row) => row.dataset.status === "Active").length,
  );
  document.getElementById("renewalDueCount").textContent = String(
    visibleRows.filter((row) => row.dataset.status === "Renewal Due").length,
  );
  let annualPremium = 0;
  visibleRows.forEach((row) => {
    const premiumCell = row.cells[8]?.textContent || "";
    const premium = Number(premiumCell.replace(/[₹,—,\s]/g, ""));
    if (!Number.isNaN(premium)) annualPremium += premium;
  });
  document.getElementById("annualPremiumValue").textContent =
    `₹${annualPremium.toLocaleString("en-IN")}`;
}
function filterInsuranceTable() {
  const search = document
    .getElementById("insuranceSearch")
    .value.trim()
    .toLowerCase();
  const type = document.getElementById("insuranceTypeFilter").value;
  const status = document.getElementById("insuranceStatusFilter").value;
  document.querySelectorAll("#insuranceTableBody tr").forEach((row) => {
    const matchesSearch =
      !search || row.textContent.toLowerCase().includes(search);
    const matchesType = !type || row.dataset.insuranceType === type;
    const matchesStatus = !status || row.dataset.status === status;
    row.hidden = !(matchesSearch && matchesType && matchesStatus);
  });
  updateInsuranceMetrics();
}
document
  .getElementById("insuranceSearch")
  ?.addEventListener("input", filterInsuranceTable);
document
  .getElementById("insuranceTypeFilter")
  ?.addEventListener("change", filterInsuranceTable);
document
  .getElementById("insuranceStatusFilter")
  ?.addEventListener("change", filterInsuranceTable);
document.addEventListener("keydown", (event) => {
  if (event.key === "Escape" && directCostModal && !directCostModal.hidden) {
    closeDirectCostModal();
  }
  if (event.key === "Escape" && teamModal && !teamModal.hidden) {
    closeTeamModal();
  }
  if (event.key === "Escape" && assetModal && !assetModal.hidden) {
    assetModal.hidden = true;
    editingAssetRow = null;
  }
  if (event.key === "Escape" && departmentModal && !departmentModal.hidden) {
    closeDepartmentModal();
  }
  if (event.key === "Escape" && employeeModal && !employeeModal.hidden) {
    closeEmployeeModal();
  }
  if (event.key === "Escape" && deassignModal && !deassignModal.hidden) {
    closeDeassignModal();
  }
});
const templateColumns = [
  "Cost item",
  "Total cost",
  "Ratio",
  "Cost Per Annum (RS)",
  "Cost Per Month (RS)",
  "Cost Per Annum (RS)",
  "Cost Per Month (RS)",
  "Cost Per Annum (RS)",
  "Cost Per Month (RS)",
  "Cost Per Annum (RS)",
  "Cost Per Month (RS)",
  "Cost Per Annum (RS)",
  "Cost Per Month (RS)",
  "Total Cost - RG Department",
  "Cost Per Annum (RS)",
  "Cost Per Month (RS)",
  "Cost Per Annum (RS)",
  "Cost Per Month (RS)",
  "Total Cost - RE Department",
  "Ratio",
  "Cost Per Annum (RS)",
  "Cost Per Month (RS)",
  "Cost Per Annum (RS)",
  "Cost Per Month (RS)",
  "Total Cost - AD Department",
  "Total Cost (RG+RE+AD)",
  "Total Cost Per Component",
];
const employeeGroups = [
  ["RG Emp 1", "rg"],
  ["RG Emp 2", "rg"],
  ["RG Emp 3", "rg"],
  ["RG Emp 4", "rg"],
  ["RG Emp 5", "rg"],
  ["Total Cost - RG Department", "rg-total"],
  ["RD Emp 1", "reserve"],
  ["RD Emp 2", "reserve"],
  ["Total Cost - RE Department", "reserve-total"],
  ["Ratio", "ratio"],
  ["AD Emp 1", "admin"],
  ["AD Emp 2", "admin"],
  ["Total Cost - AD Department", "admin-total"],
  ["Total Cost (RG+RE+AD)", "grand-total"],
  ["Total Cost Per Component", "grand-total"],
];
const directRows = [
  [
    "Salary",
    [
      300000, 25000, 318000, 26500, 336000, 28000, 354000, 29500, 372000, 31000,
      140000, 390000, 32500, 408000, 34000, 66500, 426000, 35500, 444000, 37000,
      72500, 279000, 2178000,
    ],
  ],
  [
    "Life insurance",
    [
      6453, 537.75, 6027, 502.25, 8570, 714.17, 7870, 655.83, 9000, 750, 3160,
      9450, 787.5, 9900, 825, 1612.5, 11183, 931.92, 10850, 904.17, 1836.08,
      6608.58, 50953,
    ],
  ],
  [
    "Health Insurance",
    [
      12000, 1000, 12700, 1058.33, 13400, 1116.67, 8683, 723.58, 14800, 1233.33,
      5131.92, 15500, 1291.67, 16200, 1350, 2641.67, 16900, 1408, 17600, 1467,
      2875, 10648.58, 81283,
    ],
  ],
  [
    "Holiday Bonus",
    [
      6000, 500, 6300, 525, 6600, 550, 6900, 575, 7200, 600, 2750, 7500, 625,
      7800, 650, 1275, 8100, 675, 8400, 700, 1375, 5400, 42300,
    ],
  ],
  [
    "Special Professional certification reimbursement",
    [
      4500,
      375,
      4750,
      396,
      5000,
      417,
      5250,
      438,
      5500,
      458,
      "",
      5750,
      479,
      6000,
      500,
      "",
      6250,
      521,
      6500,
      542,
      "",
      "",
      32250,
    ],
  ],
  [
    "Total Direct Labour",
    [
      328953, 27412.75, 347777, 28981.58, 369570, 30797.5, 377453, 31454.42,
      408500, 34041.33, 152687.58, 428200, 35683.17, 447900, 37325, 73008.17,
      468433, 38514.92, 487350, 40071.17, 78586.08, 304281.83, 2384786,
    ],
    "total",
  ],
  [
    "Dedicated Employee resource -(Depreciation)*",
    [
      18294.39, 1524.53, 9870.39, 822.53, 9945.99, 828.83, 11750.4, 979.2,
      55169.63, 4597.47, 8752.57, 17009.73, 1417.48, 17142.31, 1428.53, 2846,
      55169.63, 4597.47, 8517.15, 709.76, 5307.23, 16905.8, 113547.95,
    ],
  ],
  [
    "Dedicated Employee software access cost*",
    [
      72306, 6025.5, 72306, 6025.5, 72306, 6025.5, 13221, 1101.75, 57600, 4800,
      23978.25, 13221, 1101.75, 13221, 1101.75, 2203.5, 14521, 1210.08, 13221,
      1101.75, 2311.83, 28493.58, 257881,
    ],
  ],
  [
    "Total Direct Material",
    [
      90600.39,
      7550.03,
      82176.39,
      6848.03,
      82251.99,
      6854.33,
      24971.4,
      2080.95,
      "",
      "",
      23333.35,
      30230.73,
      2519.23,
      30363.31,
      2530.28,
      5049.5,
      69690.63,
      5807.55,
      21738.15,
      1811.51,
      7619.06,
      36001.92,
      371428.95,
    ],
    "total",
  ],
  [
    "Total Direct Cost",
    [
      419553.39,
      34962.78,
      429953.39,
      35829.62,
      451821.99,
      37651.83,
      402424.4,
      33535.37,
      408500,
      34041.33,
      176020.93,
      458430.73,
      38202.39,
      478263.31,
      39855.28,
      78057.67,
      538123.63,
      44322.47,
      509088.15,
      "",
      44322.47,
      298401.07,
      742857.89,
    ],
    "total",
  ],
];
const variableRows = [
  ["Office Rent", 654720],
  ["Electricity", 72763.64],
  ["Travel", 72000],
  ["Internet & Phone", 11760],
  ["Food & Water", 36240],
  ["Small tools & Equipment*", 17749],
  ["Software*", 25353.17],
  ["Bank Charges (Estimated)", 5000],
  ["Professional fees (Estimated)*", 96000],
  ["Registration & Legal Expenses (Estimated)", 15000],
  ["Marketing & Advertisement", 60000],
  ["Liability Insurance", 30000],
  ["Employee Recognition & Rewards (Estimated)*", 45000],
  ["Employee Related Events & trips (Estimated)*", 84000],
  ["Misc office Expenses (Estimated)*", 50000],
];
const fixedRows = [
  ["Air conditioner", 13941.99],
  ["Furniture*", 11045.97],
  ["Printer", 7101],
  ["Inverter (UPS)", 6075],
  ["Mobile Phone", 4214.16],
  ["Security Camera", 8901.9],
  ["Water dispenser", 2770.2],
];
function makeAllocatedValues(total, ratio = 0.111111) {
  const annual = total * ratio;
  const month = annual / 12;
  return [
    total,
    ratio,
    annual,
    month,
    annual,
    month,
    annual,
    month,
    annual,
    month,
    annual,
    month,
    month * 5,
    annual,
    month,
    annual,
    month,
    month * 2,
    ratio,
    annual,
    month,
    annual,
    month,
    month * 2,
    month * 9,
    total,
  ];
}
const sectionLabels = [
  [
    "Total Direct Cost + Total Variable cost + Total Fixed Cost depreciation",
    "total",
  ],
  [
    "Absolute cost per Employee Before Apportionment from Administrative Department :",
    "section",
  ],
  ["Cost per Hour (Direct)", "subsection"],
  ["Cost per Hour (Indirect)", "subsection"],
  ["Cost per Hour (Direct) + Cost per Hour (Indirect)", "total"],
  ["Cost per Month", "subsection"],
  ["Semi-Variable cost (Adminstrative)", "section"],
  ["Overheads apportioned from Administrative department", "subsection"],
  ["Total Semi-Variable cost", "total"],
  ["T.D.C + T.V.C + T.F.C (D) + Semi-Variable Cost", "total"],
];
function formatTemplateValue(value) {
  if (value === "" || value === null || value === undefined) return "—";
  if (typeof value === "number") {
    return value.toLocaleString("en-IN", {
      maximumFractionDigits: 2,
    });
  }
  return value;
}
function renderTemplateSheet() {
  const table = document.getElementById("templateSheet");
  const columnWidths = Array.from(
    { length: 27 },
    (_, index) =>
      `<col style="width: ${index === 0 ? 180 : index < 3 ? 75 : 96}px" />`,
  ).join("");
  const header = `
          <colgroup>${columnWidths}</colgroup>
          <thead>
            <tr class="sheet-title"><th colspan="27">Fully Loaded Cost Per Employee for 2026 (Cost per hour)</th></tr>
            <tr class="sheet-groups">
              <th colspan="3" rowspan="3">Direct Cost</th>
              <th colspan="11" class="group-rg">Revenue Generating Department</th>
              <th colspan="5" class="group-reserve">Reserve Department</th>
              <th colspan="6" class="group-admin">Administrative Department</th>
              <th colspan="2" class="group-total">Total Per year</th>
            </tr>
            <tr class="sheet-people">${employeeGroups.map(([name, group]) => `<th colspan="${group.includes("total") || group === "grand-total" ? 1 : 2}" class="${group}">${name}</th>`).join("")}</tr>
            <tr class="sheet-columns">${templateColumns
              .slice(3)
              .map((name) => `<th>${name.replace(" ", "<br />")}</th>`)
              .join("")}</tr>
          </thead>`;
  const rows = [];
  rows.push(
    `<tr class="section"><td class="text cost-label" colspan="3">Direct Cost</td><td colspan="24"></td></tr>`,
  );
  rows.push(
    `<tr class="section"><td class="text cost-label" colspan="3">Direct Labour</td><td colspan="24"></td></tr>`,
  );
  directRows.forEach(([label, values, kind]) => {
    const displayValues = [...values.slice(0, 16), "", ...values.slice(16)];
    const cells = displayValues
      .map((value) => `<td class="num">${formatTemplateValue(value)}</td>`)
      .join("");
    rows.push(
      `<tr class="${kind || ""}"><td class="text cost-label" colspan="3">${label}</td>${cells}</tr>`,
    );
  });
  rows.push(
    `<tr class="section"><td class="text cost-label" colspan="3">Indirect Overhead cost</td><td colspan="24"></td></tr>`,
  );
  rows.push(
    `<tr class="subsection"><td class="text cost-label" colspan="3">Variable cost</td><td colspan="24"></td></tr>`,
  );
  variableRows.forEach(([label, total]) => {
    const cells = makeAllocatedValues(total)
      .map((value) => `<td class="num">${formatTemplateValue(value)}</td>`)
      .join("");
    rows.push(`<tr><td class="text cost-label">${label}</td>${cells}</tr>`);
  });
  rows.push(
    `<tr class="total"><td class="text cost-label" colspan="3">Total Variable cost</td><td colspan="24">Formula cached</td></tr>`,
  );
  rows.push(
    `<tr class="total"><td class="text cost-label" colspan="3">Total Direct Cost + Total Variable cost</td><td colspan="24">Formula cached</td></tr>`,
  );
  rows.push(
    `<tr class="section"><td class="text cost-label" colspan="3">Fixed Cost (Depreciation)</td><td colspan="24"></td></tr>`,
  );
  fixedRows.forEach(([label, total]) => {
    const cells = makeAllocatedValues(total)
      .map((value) => `<td class="num">${formatTemplateValue(value)}</td>`)
      .join("");
    rows.push(`<tr><td class="text cost-label">${label}</td>${cells}</tr>`);
  });
  rows.push(
    `<tr class="total"><td class="text cost-label" colspan="3">Total Fixed cost depreciation</td><td colspan="24">Formula cached</td></tr>`,
  );
  sectionLabels.forEach(([label, kind]) => {
    rows.push(
      `<tr class="${kind}"><td class="text cost-label" colspan="3">${label}</td><td colspan="24">—</td></tr>`,
    );
  });
  table.innerHTML = `${header}<tbody>${rows.join("")}</tbody>`;
}
// The original workbook grid is embedded below using cached numeric values only.
const input = document.getElementById("fileInput"),
  state = document.getElementById("fileState"),
  process = document.getElementById("processBtn");
const uploadMonth = document.getElementById("uploadMonth");
const uploadYear = document.getElementById("uploadYear");
const uploadZone = document.getElementById("uploadZoneLabel");
const periodBadge = document.getElementById("selectedPeriodBadge");
const periodText = document.getElementById("selectedPeriodText");
const periodMsg = document.getElementById("periodValidationMsg");

const monthNames = [
  "",
  "January",
  "February",
  "March",
  "April",
  "May",
  "June",
  "July",
  "August",
  "September",
  "October",
  "November",
  "December",
];

function isPeriodSelected() {
  return uploadMonth && uploadYear && uploadMonth.value && uploadYear.value;
}

// === Dynamic Calculation Engine & Working Calendar ===
const DEFAULT_HOLIDAYS = {
  1: 2,  // Jan: New Year, Republic Day
  2: 1,  // Feb: Maha Shivaratri
  3: 1,  // Mar: Holi
  4: 2,  // Apr: Good Friday, Tamil New Year
  5: 1,  // May: May Day
  6: 0,  // Jun
  7: 0,  // Jul
  8: 2,  // Aug: Independence Day, Janmashtami
  9: 1,  // Sep: Milad-un-Nabi
  10: 3, // Oct: Gandhi Jayanti, Dussehra, Diwali
  11: 1, // Nov: Guru Nanak Jayanti
  12: 1  // Dec: Christmas
};

function getWeekdaysInMonth(year, month1Indexed) {
  const month0 = month1Indexed - 1;
  const daysInMonth = new Date(year, month1Indexed, 0).getDate();
  let weekdays = 0;
  for (let d = 1; d <= daysInMonth; d++) {
    const dayOfWeek = new Date(year, month0, d).getDay();
    if (dayOfWeek !== 0 && dayOfWeek !== 6) {
      weekdays++;
    }
  }
  return weekdays;
}

function getActiveHeadcount() {
  const empRows = document.querySelectorAll("#employeeTableBody tr");
  let count = 0;
  empRows.forEach((r) => {
    if (r.textContent.includes("Active")) count++;
  });
  return count > 0 ? count : 9;
}

function updateEngineParameters() {
  const mSelect = document.getElementById("uploadMonth");
  const ySelect = document.getElementById("uploadYear");
  const holidayInput = document.getElementById("calcHolidaysInput");
  if (!mSelect || !ySelect) return;

  const mVal = parseInt(mSelect.value, 10);
  const yVal = parseInt(ySelect.value, 10) || 2026;
  const monthName = (mVal && monthNames[mVal]) ? monthNames[mVal] : "Selected Month";

  const periodDisplay = document.getElementById("calcPeriodDisplay");
  if (periodDisplay) {
    periodDisplay.textContent = mVal ? `${monthName} ${yVal}` : "Select a month";
  }

  // Active headcount & ratio
  const headcount = getActiveHeadcount();
  const ratio = (1 / headcount).toFixed(4);
  const ratioVal = document.getElementById("calcRatioValue");
  const noteRatio = document.getElementById("noteRatio");
  if (ratioVal) ratioVal.textContent = ratio;
  if (noteRatio) noteRatio.textContent = ratio;

  if (!mVal) return;

  // Weekdays in month
  const weekdays = getWeekdaysInMonth(yVal, mVal);
  const weekdaysVal = document.getElementById("calcWeekdaysValue");
  if (weekdaysVal) weekdaysVal.textContent = `${weekdays} days`;

  // Holidays
  let holidays = 1;
  if (holidayInput) {
    if (holidayInput.dataset.lastMonth !== String(mVal)) {
      holidays = DEFAULT_HOLIDAYS[mVal] !== undefined ? DEFAULT_HOLIDAYS[mVal] : 1;
      holidayInput.value = holidays;
      holidayInput.dataset.lastMonth = String(mVal);
    } else {
      holidays = parseInt(holidayInput.value, 10) || 0;
    }
  }

  // Working hours
  const netDays = Math.max(0, weekdays - holidays);
  const hours = netDays * 8;
  const hoursVal = document.getElementById("calcWorkingHoursValue");
  const formulaVal = document.getElementById("calcWorkingHoursFormula");
  const noteHours = document.getElementById("noteHours");
  if (hoursVal) hoursVal.textContent = `${hours} hrs`;
  if (formulaVal) formulaVal.textContent = `${netDays} working days × 8.0 hrs/day`;
  if (noteHours) noteHours.textContent = `${hours} hrs`;
}

function updateUploadState() {
  if (uploadZone && uploadZone.classList) {
    if (isPeriodSelected()) {
      uploadZone.classList.remove("period-locked");
      if (periodMsg) periodMsg.hidden = true;
    } else {
      uploadZone.classList.add("period-locked");
    }
  }
  updateEngineParameters();
}

if (uploadMonth && uploadYear) {
  // Initialize state and engine parameters
  updateUploadState();
  uploadMonth.addEventListener("change", () => {
    const holidayInput = document.getElementById("calcHolidaysInput");
    if (holidayInput) delete holidayInput.dataset.lastMonth;
    updateUploadState();
  });
  uploadYear.addEventListener("change", updateUploadState);
}

const holidayInput = document.getElementById("calcHolidaysInput");
if (holidayInput) {
  holidayInput.addEventListener("input", () => {
    updateEngineParameters();
  });
}

if (input && state && process) {
  input.addEventListener("change", () => {
    if (!isPeriodSelected()) {
      if (periodMsg) periodMsg.hidden = false;
      input.value = "";
      return;
    }
    const f = input.files[0];
    if (!f) return;
    state.style.display = "block";
    const mon = monthNames[parseInt(uploadMonth.value, 10)];
    const yr = uploadYear.value;
    state.innerHTML =
      "<b>✓ " +
      f.name +
      "</b><br><span>Selected for secure validation · " +
      (f.size / 1024 / 1024).toFixed(2) +
      " MB · Period: " +
      mon +
      " " +
      yr +
      "</span>";
    // Show period badge
    if (periodBadge && periodText) {
      periodText.textContent = "📅 " + mon + " " + yr;
      periodBadge.hidden = false;
      periodBadge.style.display = "flex";
    }
    process.disabled = false;
  });
  process.addEventListener("click", () => {
    if (!isPeriodSelected()) {
      if (periodMsg) periodMsg.hidden = false;
      return;
    }

    // Save calculation parameters to localStorage
    const mVal = parseInt(uploadMonth.value, 10);
    const yVal = parseInt(uploadYear.value, 10);
    const weekdays = getWeekdaysInMonth(yVal, mVal);
    const holidays = holidayInput ? (parseInt(holidayInput.value, 10) || 0) : 1;
    const netDays = Math.max(0, weekdays - holidays);
    const hours = netDays * 8;
    const headcount = getActiveHeadcount();
    const ratio = (1 / headcount).toFixed(4);

    const calcParams = {
      year: yVal,
      month: monthNames[mVal],
      monthNum: uploadMonth.value,
      weekdays: weekdays,
      holidays: holidays,
      workingDays: netDays,
      workingHours: hours,
      activeHeadcount: headcount,
      ratio: ratio
    };
    try {
      localStorage.setItem("flc_calculation_params", JSON.stringify(calcParams));
    } catch(err) {}

    process.textContent = "Processing…";
    process.disabled = true;
    setTimeout(() => {
      process.textContent = "Process workbook →";
      go("excel");
    }, 650);
  });
}
document.getElementById("resultSearch")?.addEventListener("input", (e) => {
  const q = e.target.value.toLowerCase();
  document
    .querySelectorAll("#resultTable tbody tr, #hourResultTable tbody tr")
    .forEach(
      (r) =>
        (r.style.display = r.textContent.toLowerCase().includes(q)
          ? ""
          : "none"),
    );
});
