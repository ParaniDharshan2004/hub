# FLC Intelligence Prototype

## Overview

FLC Intelligence is a prototype application for understanding and managing the Fully Loaded Cost of employees. The application combines employee master data, direct-cost components, indirect costs, resource tracking, insurance records, workbook uploads, reports, and management dashboards.

The prototype is organized around two main ideas:

1. **Direct cost** represents employee and employee-linked expenses.
2. **Indirect cost** represents shared operating costs that must be allocated across employees or departments.

The dashboard presents the current cost view, while the Master, Asset Tracking, and Insurance pages maintain the supporting information used for the cost model.

---

## 1. Dashboard

**Available files:** `dashboard.html` and `index.html`

### Purpose

The Dashboard provides a high-level executive summary of the fully loaded cost model. It is the first page a finance manager or administrator would use to understand the current cost position without reviewing every workbook row.

### Information shown

- **Direct Cost:** the employee annual direct-cost total.
- **Indirect Cost:** variable, fixed depreciation, and semi-variable allocations.
- **Employees Listed:** the number of employees included in the source workbook.
- **Cost Outlook:** an annual cost-composition chart comparing direct, variable, fixed depreciation, and semi-variable costs.
- **Largest Component:** the cost category with the greatest contribution to the annual total.
- **Projected Annual FLC:** the total fully loaded cost shown as an annual projection.
- **Source Workbook Calculation Status:** a clear explanation of whether the workbook calculations can be completed, including any formula or source-data limitations.

### Purpose in the application

The Dashboard is intended to provide a quick financial overview and identify incomplete or inconsistent workbook calculations. It also provides shortcuts to workbook upload and report review.

The `dashboard.html` file shows the completed example view. The `index.html` file shows an alternate or recovery view where unavailable calculations are clearly marked instead of presented as confirmed values.

---

## 2. Excel Upload

**Page:** `upload.html`

### Purpose

The Excel Upload page is the controlled entry point for adding authoritative FLC workbook files to the application.

### Information shown

- A reporting period selector for month and year.
- System calculation parameters such as the overhead ratio and monthly working hours.
- A drag-and-drop or file-selection area for XLS and XLSX workbooks.
- The selected file status.
- A recent upload history showing previous workbook submissions.

### Purpose in the application

This page establishes the reporting period before a workbook is processed. It helps prevent a workbook from being uploaded without the correct month and year.

The page is also intended to show the key calculation inputs derived from the master headcount and working calendar, so users can verify those values before processing the workbook.

---

## 3. Uploaded Excel Data

**Page:** `excel.html`

### Purpose

The Uploaded Excel Data page preserves the visual layout of the uploaded workbook and displays it as a read-only spreadsheet view.

### Information shown

- The uploaded workbook name.
- The original worksheet structure and merged headings.
- Department and employee columns.
- Direct-cost rows.
- Variable-cost rows.
- Fixed and depreciation rows.
- Semi-variable and fully loaded cost sections.
- Department colour coding and workbook totals.

### Purpose in the application

This page allows users to review exactly how the workbook data has been represented in the application. It is useful for checking source values, workbook layout, and formula areas without modifying the original spreadsheet.

The page has a transition to the Reports page once the workbook data is ready for report generation.

---

## 4. Reports

**Page:** `reports.html`

### Purpose

The Reports page provides a historical and period-based view of completed FLC reports.

### Information shown

- Report period, such as month and year.
- Source workbook name.
- Number of employees included.
- Number of departments covered.
- Validated or report status.
- Annual total FLC.
- Average FLC per employee.
- FLC per hour.
- Full workbook report sections.
- Download information for the formatted report workbook.

### Information available through report controls

- Search by report name or keyword.
- Filter by month.
- Filter by year.
- Reset active filters.
- Open a report to view its complete details.
- Download or access the formatted report output.

### Purpose in the application

Reports are designed for end-of-period review, management presentation, and audit or finance traceability. They allow users to compare separate reporting periods and return to the workbook model behind a report.

Monthly FLC projections are not presented as a separate dashboard metric. The report view focuses on annual total FLC, employee average FLC, and hourly FLC.

---

## 5. Master

**Page:** `master.html`

### Purpose

The Master page maintains the administrative records that support FLC calculations and employee allocation.

The Master navigation is organized as expandable subpages:

- Departments
- Teams
- Employees

This structure keeps master maintenance separate while placing it under one administration area.

---

## 5.1 Departments Subpage

### Purpose

The Departments subpage maintains the department master used to categorize employees and allocate costs.

### Information shown

- Department ID.
- Department code.
- Department name.
- Active or inactive status.
- Creation date.
- Edit and delete actions.

### Current department categories

- Revenue Generating Department
- Reservation Department
- Administrative Department

### Purpose in the application

Departments define employee organization and determine whether employees belong to revenue-generating, reserve, or shared administrative cost groups.

---

## 5.2 Teams Subpage

### Purpose

The Teams subpage maintains the teams to which employees can belong.

### Information shown

- Team ID.
- Team code.
- Team name.
- Team description.
- Active or inactive status.
- Edit and delete actions.

### Purpose in the application

Teams provide a finer organizational structure beneath departments. Typical teams include IT, Accounting, Testing, or any new team added by the organization.

The Teams section intentionally does not require a department assignment. This allows teams to be maintained independently and assigned to employees through the employee master.

---

## 5.3 Employees Subpage

### Purpose

The Employees subpage maintains the employee records that form the basis of direct-cost calculations and FLC allocation.

### Information shown

- Employee code.
- Employee name.
- Email address.
- Designation.
- Department.
- Team.
- Employment status.
- Edit and delete actions.

### Additional employee information

Employee records can also include:

- Resources assigned to the employee.
- Software access assigned to the employee.
- Employee insurance selections.
- Salary and salary-effective period.
- Professional certification reimbursement.
- Holiday bonus.

### Direct Cost Details

Direct employee cost information is kept in a separate popup to avoid overcrowding the main employee form. It includes:

- Annual salary.
- Monthly salary.
- Salary effective dates.
- Salary status.
- Salary remarks.
- Certification name and provider.
- Certification reimbursement amount.
- Reimbursement date and effective year.
- Holiday bonus amount.
- Holiday bonus effective year.

System-generated IDs are used for database relationships and do not need to be entered manually.

### Purpose in the application

Employee records connect departments, teams, salary, benefits, resources, software, insurance, and direct-cost components. They are the central master data for employee-level FLC calculations.

---

## 6. Asset Tracking

**Page:** `assets.html`

### Purpose

The Asset Tracking page manages company hardware and resource inventory and links assets to employees.

### Summary information

- Total assets.
- Available assets.
- Assigned assets.
- Total recorded purchase value.

### Resource inventory information

- Asset code.
- Asset type.
- Asset name.
- Brand.
- Serial number.
- Purchase cost.
- Purchase or assigned date.
- Warranty date.
- Current status.
- Edit and delete actions.

### Supported asset states

- In Stock
- Assigned
- Returned
- Maintenance

### Purpose in the application

This page tracks who has received company equipment and how asset purchase cost contributes to the cost model. It also supports the de-assignment process when an employee leaves or changes asset ownership.

---

## 7. Insurance Management

**Page:** `insurance.html`

### Purpose

The Insurance page maintains employee insurance policies and their renewal status.

### Summary information

- Total policies.
- Active policies.
- Policies due for renewal.
- Annual premium amount.

### Insurance register information

- Employee name.
- Insurance type.
- Policy number.
- Policy name.
- Provider.
- Payment frequency.
- Effective date.
- Renewal date.
- Premium amount.
- Rider details.
- Policy status.

### Supported insurance types

- Health Insurance
- Life Insurance
- Accidental Insurance

### Purpose in the application

The page identifies insurance costs, coverage, active policies, and renewals. Insurance premiums associated with employees may also be included in direct-cost or benefit calculations.

---

## 8. Standalone Prototype Page

**Page:** `pro.html`

### Purpose

`pro.html` is a self-contained copy of the dashboard view. Its styles and JavaScript are embedded directly inside the HTML file.

### Purpose in the application

This file can be opened independently without maintaining separate references to `style.css` or `script.js`. It is useful for demonstrations, sharing, review, or early presentation.

The standalone view includes:

- Executive cost summary cards.
- Cost Outlook projection chart.
- Direct, variable, fixed, and semi-variable cost comparisons.
- Projected annual FLC summary.
- Source workbook calculation status.

---

## Page Relationships

The pages are connected as follows:

- **Excel Upload** receives the source workbook and reporting period.
- **Uploaded Excel Data** presents the workbook model for validation.
- **Master** maintains departments, teams, employees, salary, benefits, and employee assignments.
- **Asset Tracking** maintains resource inventory and employee asset assignments.
- **Insurance Management** maintains employee insurance details and premiums.
- **Dashboard** summarizes the overall financial position.
- **Reports** provides period-specific validated FLC output.
- **Standalone Dashboard** provides a single-file demonstration view.

---

## Application Workflow

### Step 1: Configure the Master Data

The workflow begins in the **Master** page.

1. Open Master from the Administration section of the sidebar.
2. Open the expandable Master menu to select Departments, Teams, or Employees.
3. Create or update departments so employees can be assigned to the correct organizational category.
4. Create teams such as IT, Accounting, or Testing.
5. Create or update employee records and assign each employee to a department and team.
6. Where applicable, enter salary, certification reimbursement, holiday bonus, resource, software, insurance, and direct-cost details for employees.

This master data becomes the organizational and employee reference information used throughout the application.

### Step 2: Track Physical Resources

Open **Asset Tracking** to maintain the company asset register.

1. Add available laptops, desktops, monitors, mobile phones, or other resources.
2. Record the asset code, serial number, brand, purchase cost, invoice date, warranty date, and status.
3. Assign an asset to an employee when it is issued.
4. Update or de-assign the asset if it is returned, replaced, or moved to maintenance.
5. Use the summary cards to review total, available, assigned, and purchase-value counts.

This ensures that dedicated employee resources are available and visible in the direct-cost structure.

### Step 3: Maintain Insurance Records

Open **Insurance Management** to maintain employee policy information.

1. Review existing health, life, or accidental insurance policies.
2. Add or update the policy number, provider, effective date, renewal date, premium, rider, and status.
3. Monitor policies that are active or approaching renewal.
4. Use the summary cards to understand total premium and policy coverage.

Insurance information supplements employee benefit and direct-cost records.

### Step 4: Select the Reporting Period

Open **Excel Upload** before processing a workbook.

1. Select the reporting month.
2. Select the reporting year.
3. Review the calculated overhead ratio.
4. Review the month weekday count.
5. Review the resulting monthly working hours.
6. Confirm that both period fields are selected before enabling the upload area.

The reporting period identifies the specific month and year represented by the workbook.

### Step 5: Upload the FLC Workbook

Continue from **Excel Upload**.

1. Use the upload area to browse for or drag an XLS or XLSX workbook.
2. Confirm the selected file name and file status.
3. Process the workbook after the reporting period is valid.
4. The system evaluates the workbook against the reporting period and master headcount.

The upload should contain the authoritative direct-cost, indirect-cost, employee, department, depreciation, and formula data required for FLC reporting.

### Step 6: Review the Uploaded Excel Data

After upload, open **Uploaded Excel Data**.

1. Review the workbook name and spreadsheet layout.
2. Verify employee names, departments, direct-cost rows, variable-cost rows, fixed-cost rows, and totals.
3. Compare workbook values with the Master records.
4. Check department colour coding and employee grouping.
5. Confirm whether the workbook formulas and source values are complete.

This page acts as a validation step before report generation. Formula errors or missing source components should be identified before relying on the output.

### Step 7: Review Calculation Status

The validation process determines whether the uploaded workbook can be used for final FLC reporting.

The result may be:

- **Complete:** the direct, variable, fixed, semi-variable, and final FLC values can be confirmed.
- **Incomplete:** a required source value or formula is missing.
- **Formula error:** a workbook formula, such as semi-variable apportionment, returns an error or cannot be reconciled.

If incomplete or invalid data is found, return to Excel Upload, Master, or the source workbook to correct the missing information.

### Step 8: Generate or Review Reports

Open **Reports** after the workbook data is ready.

1. Search for a report by period or keyword.
2. Filter reports by month and year.
3. Open the relevant report, such as March 2026.
4. Review annual FLC, average FLC per employee, and FLC per hour.
5. Review the full report workbook model if detailed component analysis is required.

Reports are period-specific summaries of the validated workbook. They are used for finance review and management reporting.

### Step 9: Use the Dashboard

Open **Dashboard** for the executive overview.

1. Review direct cost.
2. Review indirect cost.
3. Review the number of employees included.
4. Review the Cost Outlook bar chart.
5. Identify the largest cost component.
6. Review the source workbook calculation status.
7. Use the upload or report links to investigate incomplete or detailed information.

The Dashboard summarizes the result of master setup, asset and insurance maintenance, workbook upload, and report validation.

### Step 10: Use the Standalone Dashboard

Open **pro.html** when a single-file demonstration view is needed.

The standalone page presents the same dashboard concepts but combines the HTML, styling, and interaction script into one file. It can be used for review or presentation without separately opening the normal application navigation.

---

## End-to-End Navigation Summary

The standard workflow is:

**Master → Asset Tracking → Insurance Management → Excel Upload → Uploaded Excel Data → Report/Calculation Validation → Dashboard or Reports**

The user journey can also begin at:

- **Dashboard**, when reviewing an existing cost overview.
- **Reports**, when reviewing a previously validated period.
- **Excel Upload**, when a new workbook is ready to be introduced.

All paths return to the Dashboard or Reports for summarized financial review.

## Current Prototype Scope

This prototype currently demonstrates the intended user experience and business information structure. It includes static or browser-based sample data and interactive prototype controls.

The primary purpose is to validate:

- FLC page hierarchy.
- Department and team master structures.
- Employee direct-cost data.
- Resource and insurance tracking.
- Workbook upload workflow.
- Dashboard and report presentation.
- Source workbook calculation status.
- Usability of the Master sidebar and subpages.
