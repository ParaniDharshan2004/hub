# Overall System Flow & File Connection Guide

This document provides a comprehensive end-to-end explanation of how every file in the **Jolly Home Needs** application connects, from the **React + Vite Frontend** to the **Express + MongoDB Backend**, including API request flows, proxy forwarding, controller routing, model relations, and database operations.

---

## 🏗️ 1. High-Level Architecture Overview

```mermaid
flowchart TD
    subgraph Browser ["Client (Browser - Port 5173)"]
        UI["React UI Components\n(Pages & Dialogs)"] --> Hooks["TanStack Query & Form Hooks"]
        Hooks --> Services["Frontend API Services\n(src/services/*.js)"]
    end

    subgraph ViteProxy ["Vite Development Proxy"]
        Services -- "HTTP /api/*" --> Proxy["Vite Server Proxy\n(frontend/vite.config.js)"]
    end

    subgraph ExpressBackend ["Backend Server (Port 5000)"]
        Proxy -- "Forward /api/*" --> Server["Express App\n(backend/src/server.js)"]
        Server --> Routes["API Router\n(backend/src/routes/apiRoutes.js)"]
        
        Routes --> AuthCtrl["authController.js"]
        Routes --> MasterCtrl["masterController.js"]
        Routes --> OpsCtrl["operationsController.js"]

        AuthCtrl --> Models["Mongoose Models\n(backend/src/models/index.js)"]
        MasterCtrl --> Models
        OpsCtrl --> Models
    end

    subgraph Database ["MongoDB Database"]
        Models -- "Mongoose Queries" --> MongoDB[("MongoDB Database")]
    end
```

---

## 🔗 2. Detailed File Connection Map

Here is the exact mapping of frontend files, API endpoints, backend routes, controllers, and Mongoose database models:

| Feature / Business Unit | Frontend File(s) | API Method & Endpoint | Backend Route File | Backend Controller File | Mongoose Model(s) Used |
| :--- | :--- | :--- | :--- | :--- | :--- |
| **Authentication** | `src/features/auth/LoginPage.jsx` | `POST /api/login`<br>`GET /api/me` | `backend/src/routes/apiRoutes.js` | `backend/src/controllers/authController.js` | `User`, `Role` |
| **Dashboard** | `src/features/dashboard/DashboardPage.jsx` | `GET /api/bookings`<br>`GET /api/visits`<br>`GET /api/subscriptions` | `backend/src/routes/apiRoutes.js` | `backend/src/controllers/operationsController.js` | `Booking`, `Visit`, `Subscription`, `Customer` |
| **Bookings (List & Create)** | `src/features/bookings/BookingListPage.jsx`<br>`src/features/bookings/NewBookingPage.jsx` | `GET /api/bookings`<br>`POST /api/bookings` | `backend/src/routes/apiRoutes.js` | `backend/src/controllers/operationsController.js` | `Booking`, `Customer`, `Subscription`, `Visit`, `ServicePayment`, `Invoice` |
| **Booking Details** | `src/features/bookings/BookingDetailPage.jsx` | `GET /api/bookings/:id`<br>`PUT /api/bookings/:id` | `backend/src/routes/apiRoutes.js` | `backend/src/controllers/operationsController.js` | `Booking`, `Customer`, `Pricing`, `TimeSlot` |
| **Visits Management** | `src/features/visits/VisitListPage.jsx`<br>`src/features/visits/VisitCalendarPage.jsx`<br>`src/components/RescheduleVisitDialog.jsx` | `GET /api/visits`<br>`PUT /api/visits/:id` | `backend/src/routes/apiRoutes.js` | `backend/src/controllers/operationsController.js` | `Visit`, `Subscription`, `Booking`, `Customer` |
| **Subscriptions** | `src/features/subscriptions/SubscriptionListPage.jsx`<br>`src/features/subscriptions/SubscriptionDetailPage.jsx` | `GET /api/subscriptions`<br>`PUT /api/subscriptions/:id` | `backend/src/routes/apiRoutes.js` | `backend/src/controllers/operationsController.js` | `Subscription`, `Booking`, `Customer` |
| **Customers** | `src/features/customers/CustomerListPage.jsx`<br>`src/features/customers/CustomerProfilePage.jsx` | `GET /api/customers`<br>`POST /api/customers`<br>`PUT /api/customers/:id` | `backend/src/routes/apiRoutes.js` | `backend/src/controllers/operationsController.js` | `Customer` |
| **Payments & Invoices** | `src/features/payments/PaymentListPage.jsx`<br>`src/components/BillSummary.jsx` | `GET /api/service-payments`<br>`GET /api/invoices` | `backend/src/routes/apiRoutes.js` | `backend/src/controllers/operationsController.js` | `ServicePayment`, `Invoice`, `Customer` |
| **Master Data (Bathroom Counts, Slots, Pricing, etc.)** | `src/features/admin/RolesPage.jsx`<br>`src/features/admin/PermissionsPage.jsx`<br>`src/services/masters.js` | `GET /api/:resource`<br>`POST /api/:resource`<br>`PUT /api/:resource/:id` | `backend/src/routes/apiRoutes.js` | `backend/src/controllers/masterController.js` | `Role`, `BathroomCount`, `ServiceDuration`, `ServiceFrequency`, `SubscriptionType`, `TimeSlot`, `PaymentMethod`, `PaymentAccount`, `PaymentMaster`, `Pricing` |

---

## 🔄 3. Step-by-Step Data Flow Explanations

### 🌐 A. Vite Proxy Forwarding Flow
1. **Frontend Request**: A component inside `frontend/src/` calls `fetch('/api/bookings')` or uses `axios/react-query`.
2. **Vite Server**: Vite runs on `http://localhost:5173`. When it intercepts a request starting with `/api`:
   - Looks up `frontend/vite.config.js`:
     ```js
     proxy: {
       '/api': {
         target: 'http://localhost:5000',
         changeOrigin: true,
         secure: false,
       }
     }
     ```
3. **Backend Target**: Vite forwards the HTTP request to `http://localhost:5000/api/bookings`.

---

### 📝 B. New Booking Creation Flow (End-to-End Cascade)

When an admin creates a new booking in `NewBookingPage.jsx`:

```mermaid
sequenceDiagram
    autonumber
    actor Admin
    participant UI as NewBookingPage.jsx
    participant Service as services/bookings.js
    participant Server as backend/src/server.js
    participant Router as routes/apiRoutes.js
    participant Ctrl as operationsController.js
    participant Models as models/index.js
    participant DB as MongoDB

    Admin->>UI: Fills Form & Clicks "Create Booking"
    UI->>Service: createBooking(formData)
    Service->>Server: POST /api/bookings
    Server->>Router: Handled by router.post('/bookings')
    Router->>Ctrl: Executes createBooking(req, res)
    
    Ctrl->>Models: 1. Customer.findOne() / Customer.create()
    Models->>DB: Save Customer Record
    
    Ctrl->>Models: 2. Booking.create()
    Models->>DB: Save Booking Record
    
    Ctrl->>Models: 3. Subscription.create()
    Models->>DB: Save Active Subscription Record
    
    Ctrl->>Models: 4. Visit.insertMany()
    Models->>DB: Schedule 4-12 Visit Records
    
    Ctrl->>Models: 5. ServicePayment.create()
    Models->>DB: Save Payment Record
    
    Ctrl->>Models: 6. Invoice.create()
    Models->>DB: Generate Invoice Record
    
    Ctrl-->>UI: Returns 201 Created with linked objects
    UI-->>Admin: Displays Success Notification & Redirects
```

---

### 🧹 C. Visit Completion Flow & Automatic Subscription Sync

When an operator marks a visit as completed:

1. **User Action**: Clicks "Mark Complete" in `VisitListPage.jsx` or `VisitDetailPage.jsx`.
2. **Frontend Call**: Triggers `updateVisit(visitId, { isCompleted: true })`.
3. **HTTP Request**: `PUT http://localhost:5000/api/visits/:id`.
4. **Backend Router**: Forwarded to `updateVisit` function in `backend/src/controllers/operationsController.js`.
5. **Controller Business Logic**:
   - Queries `Visit` by ID to check previous state.
   - Updates `Visit.isCompleted = true`.
   - **Automated Cascade**:
     ```js
     if (!previousVisit.isCompleted && req.body.isCompleted === true) {
       const subscription = await Subscription.findById(subscriptionId);
       const completedVisits = subscription.completedVisits + 1;
       const remainingVisits = Math.max(0, subscription.totalVisits - completedVisits);
       const status = remainingVisits === 0 ? 'Completed' : 'Active';

       await Subscription.findByIdAndUpdate(subscription._id, {
         completedVisits,
         remainingVisits,
         subscriptionStatus: status
       });
     }
     ```
6. **Response**: Returns updated visit object and updated subscription count to frontend.

---

### ⚙️ D. Dynamic Master Data Flow

Master configurations (Roles, Bathroom Counts, Service Durations, Frequencies, Time Slots, Payment Accounts) use a unified dynamic REST handler:

1. **Frontend Request**: `GET /api/bathroom-counts` or `POST /api/pricing`.
2. **Route Match**: `router.get('/:resource', getMasterList)` in `backend/src/routes/apiRoutes.js`.
3. **Controller Handling**:
   - `masterController.js` inspects `req.params.resource` (e.g. `'bathroom-counts'`).
   - Maps `'bathroom-counts'` to `BathroomCount` Mongoose Model.
   - Runs `BathroomCount.find()` and returns JSON array.
   - If resource is `'pricing'`, automatically attaches `.populate('serviceDurationReference').populate('bathroomCountReference')`.

---

## ⚡ 4. Backend Initialization & Seeding Sequence

When you run `npm run dev` in `backend/`:

1. `server.js` calls `connectDB()` to connect to your MongoDB instance using `process.env.MONGODB_URI`.
2. `server.js` executes `seedDatabase()` from `backend/src/seed.js`.
3. `seedDatabase()` checks if `User` collection has any records:
   - If records exist: Skips seeding.
   - If empty: Creates default records with **exact ObjectIDs** matching `Jolly_Home_Needs_API_Database_Guide.md`:
     - Default User `6aa396282d8212455a8487df`
     - Roles (`superadmin`, `admin`, `user`)
     - Bathroom Counts (1 to 5)
     - Service Durations (30, 60, 90, 120, 150, 180 min)
     - Frequencies (Weekly, Fortnightly, Monthly)
     - Subscription Types (1, 2, 3, 6, 12 Months)
     - Time Slots (Morning, Afternoon, Evening)
     - Payment Methods & Accounts
     - Pricing entries
4. Express app begins listening on `PORT 5000`.

---

## 🛠️ Summary of Key File Locations

- **Frontend Application Root**: [frontend](file:///c:/Users/baran/Desktop/bathroom-cleaning-ops-phase1/app/frontend)
- **Frontend Vite Proxy**: [vite.config.js](file:///c:/Users/baran/Desktop/bathroom-cleaning-ops-phase1/app/frontend/vite.config.js)
- **Backend Application Root**: [backend](file:///c:/Users/baran/Desktop/bathroom-cleaning-ops-phase1/app/backend)
- **Backend Database Schemas**: [models/index.js](file:///c:/Users/baran/Desktop/bathroom-cleaning-ops-phase1/app/backend/src/models/index.js)
- **Backend Express Router**: [routes/apiRoutes.js](file:///c:/Users/baran/Desktop/bathroom-cleaning-ops-phase1/app/backend/src/routes/apiRoutes.js)
- **Backend Controllers**:
  - Auth: [authController.js](file:///c:/Users/baran/Desktop/bathroom-cleaning-ops-phase1/app/backend/src/controllers/authController.js)
  - Master Tables: [masterController.js](file:///c:/Users/baran/Desktop/bathroom-cleaning-ops-phase1/app/backend/src/controllers/masterController.js)
  - Operations: [operationsController.js](file:///c:/Users/baran/Desktop/bathroom-cleaning-ops-phase1/app/backend/src/controllers/operationsController.js)
- **Backend Auto-Seeder**: [seed.js](file:///c:/Users/baran/Desktop/bathroom-cleaning-ops-phase1/app/backend/src/seed.js)
