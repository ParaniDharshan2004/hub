import mongoose from 'mongoose';
import dns from 'dns';

// Fix for Windows ISP/router DNS blocking SRV lookup (_mongodb._tcp)
try {
  dns.setServers(['8.8.8.8', '1.1.1.1']);
} catch (err) {
  console.warn('[DNS Warning] Could not set custom DNS servers:', err.message);
}

/**
 * Connects to MongoDB database using MONGODB_URI environment variable.
 */
export const connectDB = async () => {
  try {
    const conn = await mongoose.connect(process.env.MONGODB_URI || 'mongodb://localhost:27017/jolly_home_needs');
    console.log(`[MongoDB] Connected: ${conn.connection.host}/${conn.connection.name}`);
  } catch (error) {
    console.error(`[MongoDB Error] ${error.message}`);
    process.exit(1);
  }
};

export default connectDB;

