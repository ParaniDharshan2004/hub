import jwt from 'jsonwebtoken';
import { User, Role } from '../models/index.js';

/**
 * Controller to handle user authentication (login)
 */
export const login = async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email) {
      return res.status(400).json({ message: 'Email is required' });
    }

    // Find user by email
    const user = await User.findOne({ email }).populate('roleId');

    if (!user) {
      // If user does not exist yet, allow fallback for development or return 401
      return res.status(401).json({ message: 'Invalid credentials. User not found.' });
    }

    // Generate JWT Token
    const secret = process.env.JWT_SECRET || 'jolly_home_needs_secret_key';
    const token = jwt.sign(
      { userId: user._id, email: user.email, role: user.roleId?.roleName || 'admin' },
      secret,
      { expiresIn: '7d' }
    );

    return res.json({
      message: 'Login successful',
      token,
      user: {
        id: user._id,
        name: user.name,
        email: user.email,
        role: user.roleId
      }
    });
  } catch (error) {
    console.error('Login Error:', error);
    return res.status(500).json({ message: 'Internal server error during login', error: error.message });
  }
};

/**
 * Controller to get current authenticated user profile
 */
export const getCurrentUser = async (req, res) => {
  try {
    const user = await User.findOne().populate('roleId'); // Return primary user
    return res.json(user);
  } catch (error) {
    return res.status(500).json({ message: 'Failed to fetch user', error: error.message });
  }
};
