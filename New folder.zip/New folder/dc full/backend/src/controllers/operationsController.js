import {
  Customer,
  Booking,
  Subscription,
  Visit,
  ServicePayment,
  Invoice,
  BathroomCount,
  ServiceFrequency,
  PaymentMaster,
  Pricing,
  PaymentAccount,
  PaymentMethod,
  TimeSlot
} from '../models/index.js';

function formatServiceTime(totalMinutes) {
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  const suffix = hours >= 12 ? 'PM' : 'AM';
  const displayHours = hours % 12 || 12;
  return `${String(displayHours).padStart(2, '0')}:${String(minutes).padStart(2, '0')} ${suffix}`;
}

// ==================== CUSTOMERS ====================

export const getCustomers = async (req, res) => {
  try {
    const filter = {};
    if (req.query.phoneNumber) filter.phoneNumber = req.query.phoneNumber;
    const customers = await Customer.find(filter).sort({ createdAt: -1 });
    const customerIds = customers.map((customer) => customer._id);
    const [subscriptions, bookings, visits] = await Promise.all([
      Subscription.find({ customerId: { $in: customerIds } }).select('customerId subscriptionStatus isActive').lean(),
      Booking.find({ customerId: { $in: customerIds } }).select('customerId').lean(),
      Visit.find({ customerId: { $in: customerIds }, isCompleted: false, isCancelled: false })
        .select('customerId visitNumber scheduledDate')
        .sort({ scheduledDate: 1 })
        .lean(),
    ]);

    const subscriptionCounts = new Map();
    subscriptions.forEach((subscription) => {
      if (subscription.subscriptionStatus === 'Active' && subscription.isActive !== false) {
        const key = String(subscription.customerId);
        subscriptionCounts.set(key, (subscriptionCounts.get(key) || 0) + 1);
      }
    });
    const bookingCounts = new Map();
    bookings.forEach((booking) => {
      const key = String(booking.customerId);
      bookingCounts.set(key, (bookingCounts.get(key) || 0) + 1);
    });
    const nextVisits = new Map();
    visits.forEach((visit) => {
      const key = String(visit.customerId);
      if (!nextVisits.has(key)) nextVisits.set(key, visit);
    });

    return res.json(customers.map((customer) => ({
      ...customer.toObject(),
      addressCount: customer.address ? 1 : 0,
      activeSubscriptionCount: subscriptionCounts.get(String(customer._id)) || 0,
      bookingCount: bookingCounts.get(String(customer._id)) || 0,
      nextVisit: nextVisits.get(String(customer._id)) || null,
    })));
  } catch (error) {
    return res.status(500).json({ message: 'Error fetching customers', error: error.message });
  }
};

export const createCustomer = async (req, res) => {
  try {
    const customer = new Customer({
      name: req.body.name,
      phoneNumber: req.body.phoneNumber || req.body.mobile,
      address: req.body.address || req.body.addressLine,
      doorNo: req.body.doorNo,
      block: req.body.block,
      apartmentName: req.body.apartmentName || req.body.community,
      landmark: req.body.landmark,
      city: req.body.city,
      pincode: req.body.pincode,
      area: req.body.area,
      email: req.body.email,
      whatsapp: req.body.whatsapp,
    });
    await customer.save();
    return res.status(201).json(customer);
  } catch (error) {
    return res.status(400).json({ message: 'Error creating customer', error: error.message });
  }
};

export const getCustomerById = async (req, res) => {
  try {
    const customer = await Customer.findById(req.params.id);
    if (!customer) return res.status(404).json({ message: 'Customer not found' });

    const [bookings, subscriptions, visits, payments, invoices] = await Promise.all([
      Booking.find({ customerId: customer._id }).sort({ createdAt: -1 }).lean(),
      Subscription.find({ customerId: customer._id }).sort({ createdAt: -1 }).lean(),
      Visit.find({ customerId: customer._id }).sort({ scheduledDate: 1 }).lean(),
      ServicePayment.find({ customerId: customer._id }).sort({ paymentDate: -1 }).lean(),
      Invoice.find({ customerId: customer._id }).sort({ invoiceDate: -1 }).lean(),
    ]);

    const bookingById = new Map(bookings.map((booking) => [String(booking._id), booking]));
    const address = customer.address
      ? {
          id: String(customer._id),
          addressNumber: String(customer._id),
          customerId: String(customer._id),
          label: 'Service address',
          addressLine: customer.address,
          doorNo: customer.doorNo || '',
          block: customer.block || '',
          community: customer.apartmentName || '',
          area: customer.area || '',
          city: customer.city || '',
          pincode: customer.pincode || '',
          landmark: customer.landmark || '',
          isDefault: true,
          status: customer.isActive ? 'Active' : 'Inactive',
        }
      : null;

    const normalizedBookings = bookings.map((booking) => ({
      ...booking,
      id: String(booking._id),
      bookingNumber: booking.bookingId || String(booking._id),
      addressId: booking.addressId || (address && address.id),
      type: booking.type || 'New',
      total: booking.totalAmount || 0,
      startDate: booking.scheduledDate || booking.startDateTime,
      status: booking.isCancelled ? 'Cancelled' : booking.isCompleted ? 'Confirmed' : 'Draft',
    }));
    const normalizedSubscriptions = subscriptions.map((subscription) => {
      const booking = bookingById.get(String(subscription.bookingId));
      return {
        ...subscription,
        id: String(subscription._id),
        subscriptionNumber: subscription.subscriptionId || String(subscription._id),
        addressId: booking?.addressId || (address && address.id),
        status: subscription.subscriptionStatus || (subscription.isActive ? 'Active' : 'Completed'),
        currentPeriod: {
          completedServices: subscription.completedVisits || 0,
          totalServices: subscription.totalVisits || 0,
          endDate: booking?.endDateTime || null,
          planId: booking?.planId,
        },
        renewalStatus: subscription.subscriptionStatus || 'Active',
      };
    });
    const normalizedVisits = visits.map((visit) => ({
      ...visit,
      id: String(visit._id),
      visitNumber: visit.visitNumber || String(visit._id),
      date: visit.scheduledDate,
      status: visit.isCancelled ? 'Cancelled' : visit.isCompleted ? 'Completed' : 'Scheduled',
    }));
    const normalizedPayments = payments.map((payment) => ({
      ...payment,
      id: String(payment._id),
      bookingId: payment.bookingId ? String(payment.bookingId) : null,
      amount: payment.amount || 0,
    }));
    const normalizedInvoices = invoices.map((invoice) => ({
      ...invoice,
      id: String(invoice._id),
      bookingId: invoice.bookingId ? String(invoice.bookingId) : null,
      invoiceNumber: invoice.invoiceNumber || String(invoice._id),
    }));
    const upcomingVisits = normalizedVisits.filter((visit) => visit.status === 'Scheduled');
    const lifetimeCollected = normalizedPayments
      .filter((payment) => payment.status !== 'Reversed')
      .reduce((sum, payment) => sum + payment.amount, 0);

    return res.json({
      ...customer.toObject(),
      addresses: address ? [address] : [],
      bookings: normalizedBookings,
      subscriptions: normalizedSubscriptions,
      visits: normalizedVisits,
      payments: normalizedPayments,
      invoices: normalizedInvoices,
      summary: {
        addressCount: address && address.status === 'Active' ? 1 : 0,
        totalBookings: normalizedBookings.length,
        activeSubscriptions: normalizedSubscriptions.filter((subscription) => subscription.status === 'Active').length,
        visitsCompleted: normalizedVisits.filter((visit) => visit.status === 'Completed').length,
        lifetimeCollected,
        nextVisits: upcomingVisits.slice(0, 2),
      },
    });
  } catch (error) {
    return res.status(400).json({ message: 'Error fetching customer', error: error.message });
  }
};

export const updateCustomer = async (req, res) => {
  try {
    const customer = await Customer.findByIdAndUpdate(req.params.id, req.body, { new: true });
    return res.json(customer);
  } catch (error) {
    return res.status(400).json({ message: 'Error updating customer', error: error.message });
  }
};

export const deleteCustomer = async (req, res) => {
  try {
    await Customer.findByIdAndDelete(req.params.id);
    return res.json({ message: 'Customer deleted successfully' });
  } catch (error) {
    return res.status(500).json({ message: 'Error deleting customer', error: error.message });
  }
};

// ==================== BOOKINGS ====================

export const getBookings = async (req, res) => {
  try {
    const bookings = await Booking.find()
      .populate('customerId')
      .populate('bathroomCountId')
      .populate('paymentMethodId')
      .populate('paymentAccountId')
      .sort({ createdAt: -1 });
    return res.json(bookings);
  } catch (error) {
    return res.status(500).json({ message: 'Error fetching bookings', error: error.message });
  }
};

export const getBookingById = async (req, res) => {
  try {
    const booking = await Booking.findOne({ bookingId: req.params.id })
      .populate('customerId')
      .populate('bathroomCountId')
      .populate('paymentMethodId')
      .populate('paymentAccountId');
    if (!booking) return res.status(404).json({ message: 'Booking not found' });
    return res.json(booking);
  } catch (error) {
    return res.status(500).json({ message: 'Error fetching booking', error: error.message });
  }
};

export const createBooking = async (req, res) => {
  try {
    const body = req.body;
    const customer = await Customer.findById(body.customerId);
    if (!customer) return res.status(404).json({ message: 'Customer not found' });

    const bathroomCount = await BathroomCount.findOne({ bathroomCount: body.bathroomCount });
    if (!bathroomCount) return res.status(400).json({ message: 'Bathroom count is not configured' });

    const booking = new Booking({
      bookingId: `BKG-${Date.now().toString().slice(-8)}`,
      customerId: customer._id,
      bathroomCountId: bathroomCount._id,
      scheduledDate: body.startDate,
      startDateTime: body.startDate ? new Date(body.startDate) : undefined,
      addressId: body.addressId,
      offeringId: body.offeringId,
      frequencyCode: body.frequencyId,
      planId: body.planId,
      slotId: body.slotId,
      discountAmount: body.discount || 0,
      serviceCharges: body.serviceCharges || 0,
      taxableAmount: body.taxableAmount || 0,
      totalAmount: body.totalAmount || 0,
      totalVisits: body.totalVisits || 0,
      isPending: true,
      isActive: true,
    });
    await booking.save();

    return res.status(201).json({ booking });
  } catch (error) {
    console.error('Error creating booking:', error);
    return res.status(400).json({ message: 'Error creating booking', error: error.message });
  }
};

export const confirmBooking = async (req, res) => {
  try {
    const booking = await Booking.findOne({ bookingId: req.params.id });
    if (!booking) return res.status(404).json({ message: 'Booking not found' });
    if (!booking.isPending || booking.isCompleted) {
      return res.status(400).json({ message: 'Only pending bookings can be confirmed' });
    }
    const paymentAccount = await PaymentAccount.findOne({ _id: req.body.receiverAccountId, isActive: true });
    if (!paymentAccount) return res.status(400).json({ message: 'Receiver bank type is not configured' });
    const paymentMethod = await PaymentMethod.findOne({ _id: req.body.paymentModeId, isActive: true });
    if (!paymentMethod) return res.status(400).json({ message: 'Payment mode is not configured' });

    const now = new Date();
    const totalVisits = booking.totalVisits || 0;
    const subscription = await Subscription.create({
      subscriptionId: `SUB-${booking.bookingId}`,
      bookingId: booking._id,
      customerId: booking.customerId,
      totalVisits,
      remainingVisits: totalVisits,
      subscriptionStatus: 'Active',
      isActive: true,
    });

    const visits = [];
    const startDate = booking.startDateTime || now;
    for (let index = 0; index < totalVisits; index += 1) {
      const visitDate = new Date(startDate);
      visitDate.setDate(visitDate.getDate() + index * 7);
      visits.push(await Visit.create({
        visitNumber: `${booking.bookingId}-${index + 1}`,
        subscriptionId: subscription._id,
        bookingId: booking._id,
        customerId: booking.customerId,
        scheduledDate: visitDate,
        isPending: true,
        isActive: true,
      }));
    }

    const payment = await ServicePayment.create({
      paymentNumber: `PAY-${Date.now().toString().slice(-8)}`,
      bookingId: booking._id,
      customerId: booking.customerId,
      amount: booking.totalAmount || 0,
      paymentMethodId: paymentMethod._id,
      paymentAccountId: paymentAccount._id,
      transactionId: req.body.paymentReference || '',
      status: 'Completed',
      isActive: true,
    });

    const invoice = await Invoice.create({
      invoiceNumber: `INV-${Date.now().toString().slice(-8)}`,
      bookingId: booking._id,
      subscriptionId: subscription._id,
      customerId: booking.customerId,
      amount: booking.totalAmount || 0,
      totalAmount: booking.totalAmount || 0,
      invoiceDate: now,
      status: 'Paid',
      isActive: true,
    });

    booking.isPending = false;
    booking.isCompleted = true;
    booking.paymentAccountId = paymentAccount._id;
    await booking.save();

    return res.json({ booking, payment, invoice, subscription, visits });
  } catch (error) {
    console.error('Error confirming booking:', error);
    return res.status(400).json({ message: 'Error confirming booking', error: error.message });
  }
};

export const updateBooking = async (req, res) => {
  try {
    const booking = await Booking.findByIdAndUpdate(req.params.id, req.body, { new: true });
    return res.json(booking);
  } catch (error) {
    return res.status(400).json({ message: 'Error updating booking', error: error.message });
  }
};

export const deleteBooking = async (req, res) => {
  try {
    await Booking.findByIdAndDelete(req.params.id);
    return res.json({ message: 'Booking deleted successfully' });
  } catch (error) {
    return res.status(500).json({ message: 'Error deleting booking', error: error.message });
  }
};

// ==================== SUBSCRIPTIONS ====================

export const getSubscriptions = async (req, res) => {
  try {
    const subscriptions = await Subscription.find().sort({ createdAt: -1 }).lean();
    const customerIds = subscriptions.map((subscription) => subscription.customerId).filter(Boolean);
    const bookingIds = subscriptions.map((subscription) => subscription.bookingId).filter(Boolean);
    const [customers, bookings, visits] = await Promise.all([
      Customer.find({ _id: { $in: customerIds } }).lean(),
      Booking.find({ _id: { $in: bookingIds } }).lean(),
      Visit.find({ subscriptionId: { $in: subscriptions.map((subscription) => subscription._id) }, isCompleted: false, isCancelled: false })
        .sort({ scheduledDate: 1 })
        .lean(),
    ]);
    const customerById = new Map(customers.map((customer) => [String(customer._id), customer]));
    const bookingById = new Map(bookings.map((booking) => [String(booking._id), booking]));
    const firstVisitBySubscription = new Map();
    visits.forEach((visit) => {
      const key = String(visit.subscriptionId);
      if (!firstVisitBySubscription.has(key)) firstVisitBySubscription.set(key, visit);
    });

    return res.json(subscriptions.map((subscription) => {
      const customer = customerById.get(String(subscription.customerId));
      const booking = bookingById.get(String(subscription.bookingId));
      const nextVisit = firstVisitBySubscription.get(String(subscription._id));
      const currentPeriod = {
        completedServices: subscription.completedVisits || 0,
        totalServices: subscription.totalVisits || 0,
        planId: booking?.planId || null,
        endDate: booking?.endDateTime || null,
      };
      return {
        ...subscription,
        id: String(subscription._id),
        subscriptionNumber: subscription.subscriptionId || String(subscription._id),
        status: subscription.subscriptionStatus || (subscription.isActive ? 'Active' : 'Completed'),
        customer: customer ? {
          ...customer,
          id: String(customer._id),
          customerNumber: customer.customerNumber || String(customer._id),
          mobile: customer.phoneNumber,
        } : null,
        address: customer?.address ? {
          label: 'Service address',
          addressLine: customer.address,
          area: customer.area || '',
          city: customer.city || '',
          pincode: customer.pincode || '',
        } : null,
        offeringId: booking?.offeringId || null,
        currentPeriod,
        nextVisit: nextVisit ? { ...nextVisit, date: nextVisit.scheduledDate } : null,
        renewalStatus: subscription.subscriptionStatus === 'Active' ? 'On Track' : subscription.subscriptionStatus,
      };
    }));
  } catch (error) {
    return res.status(500).json({ message: 'Error fetching subscriptions', error: error.message });
  }
};

export const getSubscriptionById = async (req, res) => {
  try {
    const subscription = await Subscription.findOne({ subscriptionId: req.params.id }).lean();
    if (!subscription) return res.status(404).json({ message: 'Subscription not found' });

    const [customer, booking, visits] = await Promise.all([
      Customer.findById(subscription.customerId).lean(),
      subscription.bookingId ? Booking.findById(subscription.bookingId).lean() : null,
      Visit.find({ subscriptionId: subscription._id }).sort({ scheduledDate: 1 }).lean(),
    ]);
    const address = customer?.address
      ? {
          id: String(customer._id),
          label: 'Service address',
          addressLine: customer.address,
          area: customer.area || '',
          city: customer.city || '',
          pincode: customer.pincode || '',
        }
      : null;
    const normalizedVisits = visits.map((visit) => ({
      ...visit,
      id: String(visit._id),
      visitNumber: visit.visitNumber || String(visit._id),
      date: visit.scheduledDate,
      status: visit.isCancelled ? 'Cancelled' : visit.isCompleted ? 'Completed' : 'Scheduled',
    }));
    const currentPeriod = {
      completedServices: subscription.completedVisits || 0,
      totalServices: subscription.totalVisits || 0,
      remainingServices: subscription.remainingVisits || 0,
      planId: booking?.planId,
      startDate: booking?.startDateTime || booking?.scheduledDate,
      endDate: booking?.endDateTime || null,
      visits: normalizedVisits,
    };

    return res.json({
      ...subscription,
      id: String(subscription._id),
      subscriptionNumber: subscription.subscriptionId || String(subscription._id),
      status: subscription.subscriptionStatus || (subscription.isActive ? 'Active' : 'Completed'),
      customer: customer
        ? {
            ...customer,
            id: String(customer._id),
            customerNumber: customer.customerNumber || String(customer._id),
            mobile: customer.phoneNumber,
          }
        : null,
      address,
      currentPeriod,
      periods: [currentPeriod],
      nextVisit: normalizedVisits.find((visit) => visit.status === 'Scheduled') || null,
    });
  } catch (error) {
    return res.status(400).json({ message: 'Error fetching subscription', error: error.message });
  }
};

export const updateSubscription = async (req, res) => {
  try {
    const subscription = await Subscription.findByIdAndUpdate(req.params.id, req.body, { new: true });
    return res.json(subscription);
  } catch (error) {
    return res.status(400).json({ message: 'Error updating subscription', error: error.message });
  }
};

// ==================== VISITS ====================

export const getVisits = async (req, res) => {
  try {
    const visits = await Visit.find()
      .populate('bookingId')
      .populate('subscriptionId')
      .populate('customerId')
      .sort({ scheduledDate: 1 });
    return res.json(visits);
  } catch (error) {
    return res.status(500).json({ message: 'Error fetching visits', error: error.message });
  }
};

export const getVisitByNumber = async (req, res) => {
  try {
    const visit = await Visit.findOne({ visitNumber: req.params.visitNumber })
      .populate('bookingId')
      .populate('subscriptionId')
      .populate('customerId');
    if (!visit) return res.status(404).json({ message: 'Visit not found' });
    return res.json(visit);
  } catch (error) {
    return res.status(500).json({ message: 'Error fetching visit', error: error.message });
  }
};

export const updateVisit = async (req, res) => {
  try {
    const { id } = req.params;
    const previousVisit = await Visit.findById(id);

    if (!previousVisit) {
      return res.status(404).json({ message: 'Visit not found' });
    }

    const updatedVisit = await Visit.findByIdAndUpdate(id, req.body, { new: true })
      .populate('bookingReference')
      .populate('subscriptionReference')
      .populate('customerReference')
      .populate('timeSlotReference');

    // Business Logic: If status changed to completed, update Subscription counts
    if (!previousVisit.isCompleted && req.body.isCompleted === true) {
      const subscription = await Subscription.findById(previousVisit.subscriptionReference);
      if (subscription) {
        const completedVisits = subscription.completedVisits + 1;
        const remainingVisits = Math.max(0, subscription.totalVisits - completedVisits);
        const status = remainingVisits === 0 ? 'Completed' : 'Active';

        await Subscription.findByIdAndUpdate(subscription._id, {
          completedVisits,
          remainingVisits,
          subscriptionStatus: status
        });
      }
    }

    return res.json(updatedVisit);
  } catch (error) {
    return res.status(400).json({ message: 'Error updating visit', error: error.message });
  }
};

// ==================== SERVICE PAYMENTS ====================

export const getServicePayments = async (req, res) => {
  try {
    const payments = await ServicePayment.find()
      .populate('bookingReference')
      .populate('customerReference')
      .populate('paymentMethodReference')
      .populate('paymentAccountReference')
      .sort({ createdAt: -1 });
    return res.json(payments);
  } catch (error) {
    return res.status(500).json({ message: 'Error fetching service payments', error: error.message });
  }
};

export const createServicePayment = async (req, res) => {
  try {
    const payment = new ServicePayment(req.body);
    await payment.save();
    return res.status(201).json(payment);
  } catch (error) {
    return res.status(400).json({ message: 'Error creating payment', error: error.message });
  }
};

// ==================== INVOICES ====================

export const getInvoices = async (req, res) => {
  try {
    const invoices = await Invoice.find()
      .populate('bookingId')
      .populate('customerId')
      .sort({ createdAt: -1 });
    return res.json(invoices);
  } catch (error) {
    return res.status(500).json({ message: 'Error fetching invoices', error: error.message });
  }
};

// ==================== DASHBOARD ====================

export const getDashboardSummary = async (req, res) => {
  try {
    const requestedDate = req.query.date ? new Date(`${req.query.date}T00:00:00`) : new Date();
    const dayStart = new Date(requestedDate);
    dayStart.setHours(0, 0, 0, 0);
    const dayEnd = new Date(dayStart);
    dayEnd.setDate(dayEnd.getDate() + 1);
    const monthStart = new Date(dayStart.getFullYear(), dayStart.getMonth(), 1);
    const renewalWindow = new Date(dayStart);
    renewalWindow.setDate(renewalWindow.getDate() + 7);

    const [visits, subscriptions, payments, bookings, timeSlots] = await Promise.all([
      Visit.find({ isActive: true })
        .populate('customerId')
        .populate('bookingId')
        .sort({ scheduledDate: 1 }),
      Subscription.find({ isActive: true }).sort({ createdAt: -1 }),
      ServicePayment.find({ isActive: true, status: { $ne: 'Reversed' } }).sort({ paymentDate: -1 }),
      Booking.find({ isActive: true }).populate('customerId').sort({ createdAt: -1 }),
      TimeSlot.find({ isActive: true }).lean(),
    ]);

    const todayVisits = visits.filter((visit) => visit.scheduledDate >= dayStart && visit.scheduledDate < dayEnd);
    const completedToday = todayVisits.filter((visit) => visit.isCompleted);
    const pendingToday = todayVisits.filter((visit) => visit.isPending && !visit.isCompleted && !visit.isCancelled);
    const activeSubscriptions = subscriptions.filter((subscription) => subscription.subscriptionStatus === 'Active');
    const lastVisitBySubscription = new Map();
    visits.forEach((visit) => {
      const key = String(visit.subscriptionId);
      const current = lastVisitBySubscription.get(key);
      if (!current || visit.scheduledDate > current) lastVisitBySubscription.set(key, visit.scheduledDate);
    });
    const renewalDates = activeSubscriptions
      .map((subscription) => lastVisitBySubscription.get(String(subscription._id)))
      .filter(Boolean);

    const todaysPayments = payments.filter((payment) => payment.paymentDate >= dayStart && payment.paymentDate < dayEnd);
    const mtdPayments = payments.filter((payment) => payment.paymentDate >= monthStart && payment.paymentDate < dayEnd);
    const areaWorkload = new Map();
    todayVisits.forEach((visit) => {
      const areaName = visit.customerId?.area || 'Unassigned';
      const area = areaWorkload.get(areaName) || { areaName, completed: 0, scheduled: 0 };
      if (visit.isCompleted) area.completed += 1;
      else if (visit.isPending && !visit.isCancelled) area.scheduled += 1;
      areaWorkload.set(areaName, area);
    });

    const recentBookings = bookings
      .filter((booking) => booking.isCompleted)
      .slice(0, 5)
      .map((booking) => ({
        id: booking._id,
        bookingNumber: booking.bookingId,
        customer: booking.customerId,
        confirmedOn: booking.updatedAt || booking.createdAt,
        total: booking.totalAmount,
      }));
    const upcomingVisits = visits
      .filter((visit) => visit.isPending && !visit.isCompleted && !visit.isCancelled && visit.scheduledDate >= dayStart)
      .slice(0, 6)
      .map((visit) => {
        const storedSlotId = String(visit.bookingId?.slotId || '');
        const slotParts = storedSlotId.match(/^(.*)-(\d+)$/);
        const timeSlot = timeSlots.find((slot) =>
          String(slot._id) === String(visit.bookingId?.timeSlotId || slotParts?.[1]),
        );
        const startMinutes = slotParts ? Number(slotParts[2]) : null;
        return {
          id: visit._id,
          visitNumber: visit.visitNumber,
          date: visit.scheduledDate,
          serviceStartTime: timeSlot
            ? startMinutes == null
              ? timeSlot.startTime
              : formatServiceTime(startMinutes)
            : null,
          serviceEndTime: timeSlot
            ? startMinutes == null
              ? timeSlot.endTime
              : formatServiceTime(startMinutes + 30)
            : null,
          status: 'Scheduled',
          customer: visit.customerId,
        };
      });
    const staleDrafts = bookings
      .filter((booking) => booking.isPending && dayStart - booking.createdAt >= 2 * 24 * 60 * 60 * 1000)
      .map((booking) => ({ id: booking._id, bookingNumber: booking.bookingId }));

    return res.json({
      date: req.query.date,
      kpis: {
        todayVisits: todayVisits.length,
        completedToday: completedToday.length,
        pendingToday: pendingToday.length,
        rescheduledToday: 0,
        activeSubscriptions: activeSubscriptions.length,
        renewalsDueSoon: renewalDates.filter((date) => date >= dayStart && date <= renewalWindow).length,
        renewalsDue: renewalDates.filter((date) => date < dayStart).length,
        todaysCollection: todaysPayments.reduce((total, payment) => total + payment.amount, 0),
        mtdCollection: mtdPayments.reduce((total, payment) => total + payment.amount, 0),
      },
      areaWorkload: [...areaWorkload.values()],
      recentBookings,
      upcomingVisits,
      exceptions: { staleDrafts },
    });
  } catch (error) {
    return res.status(500).json({ message: 'Error fetching dashboard summary', error: error.message });
  }
};

export const getInvoiceById = async (req, res) => {
  try {
    const invoice = await Invoice.findById(req.params.id)
      .populate('bookingId')
      .populate('customerId');
    if (!invoice) return res.status(404).json({ message: 'Invoice not found' });
    return res.json(invoice);
  } catch (error) {
    return res.status(500).json({ message: 'Error fetching invoice', error: error.message });
  }
};
