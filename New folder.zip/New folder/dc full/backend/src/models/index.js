import mongoose from "mongoose";

const { Schema } = mongoose;

// 1. Role Model
const roleSchema = new Schema(
  {
    roleName: { type: String, required: true, unique: true },
    canRead: { type: Boolean, default: true },
    canWrite: { type: Boolean, default: false },
    canUpdate: { type: Boolean, default: false },
    canDelete: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 2. User Model
const userSchema = new Schema(
  {
    name: { type: String, default: "System User" },
    email: { type: String, required: true, unique: true },
    password: { type: String, required: true },
    roleId: { type: Schema.Types.ObjectId, ref: "Role" },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 3. BathroomCount Model
const bathroomCountSchema = new Schema(
  {
    bathroomCount: { type: Number, required: true },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 4. ServiceDuration Model
const serviceDurationSchema = new Schema(
  {
    durationMinutes: { type: Number, required: true },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 5. ServiceFrequency Model
const serviceFrequencySchema = new Schema(
  {
    frequencyName: { type: String, required: true },
    intervalDays: { type: Number, required: true },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 6. SubscriptionType Model
const subscriptionTypeSchema = new Schema(
  {
    subscriptionName: { type: String, required: true },
    timeGap: { type: Number, required: true },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 7. TimeSlot Model
const timeSlotSchema = new Schema(
  {
    startTime: { type: String, required: true },
    endTime: { type: String, required: true },
    bufferTime: { type: Number, default: 30 },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 8. PaymentMethod Model
const paymentMethodSchema = new Schema(
  {
    paymentMethodName: { type: String, required: true },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 9. PaymentAccount Model
const paymentAccountSchema = new Schema(
  {
    accountName: { type: String, required: true },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 10. PaymentMaster Model (Tax & Discount Config)
const paymentMasterSchema = new Schema(
  {
    cgstRate: { type: Number, default: 9 },
    sgstRate: { type: Number, default: 9 },
    discountRate: { type: Number, default: 0 },
    effectiveFrom: { type: Date, default: Date.now },
    effectiveTo: { type: Date, default: null },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 11. Pricing Model
const pricingSchema = new Schema(
  {
    serviceDurationReference: {
      type: Schema.Types.ObjectId,
      ref: "ServiceDuration",
      required: true,
    },
    bathroomCountReference: {
      type: Schema.Types.ObjectId,
      ref: "BathroomCount",
      required: true,
    },
    price: { type: Number, required: true },
    effectiveFrom: { type: Date, default: Date.now },
    effectiveTo: { type: Date, default: null },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 12. Customer Model
const customerSchema = new Schema(
  {
    name: { type: String, required: true },
    phoneNumber: { type: String, required: true },
    address: { type: String },
    doorNo: { type: String },
    block: { type: String },
    apartmentName: { type: String },
    landmark: { type: String },
    city: { type: String },
    pincode: { type: String },
    area: { type: String },
    email: { type: String },
    whatsapp: { type: String },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 13. Booking Model
const bookingSchema = new Schema(
  {
    bookingId: { type: String },
    customerId: {
      type: Schema.Types.ObjectId,
      ref: "Customer",
      required: true,
    },
    bathroomCountId: {
      type: Schema.Types.ObjectId,
      ref: "BathroomCount",
      required: true,
    },
    pricingId: { type: Schema.Types.ObjectId, ref: "Pricing" },
    serviceDurationId: { type: Schema.Types.ObjectId, ref: "ServiceDuration" },
    serviceFrequencyId: {
      type: Schema.Types.ObjectId,
      ref: "ServiceFrequency",
    },
    subscriptionTypeId: {
      type: Schema.Types.ObjectId,
      ref: "SubscriptionType",
    },
    scheduledDate: { type: String },
    startDateTime: { type: Date },
    endDateTime: { type: Date },
    addressId: { type: String },
    offeringId: { type: String },
    frequencyCode: { type: String },
    planId: { type: String },
    slotId: { type: String },
    serviceCharges: { type: Number, default: 0 },
    discountAmount: { type: Number, default: 0 },
    taxableAmount: { type: Number, default: 0 },
    totalAmount: { type: Number, default: 0 },
    totalVisits: { type: Number, default: 0 },
    paymentMethodId: { type: Schema.Types.ObjectId, ref: "PaymentMethod" },
    paymentAccountId: { type: Schema.Types.ObjectId, ref: "PaymentAccount" },
    transactionId: { type: String, default: "" },
    timeSlotId: { type: Schema.Types.ObjectId, ref: "TimeSlot" },
    isPending: { type: Boolean, default: true },
    isCompleted: { type: Boolean, default: false },
    isCancelled: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 14. Subscription Model
const subscriptionSchema = new Schema(
  {
    subscriptionId: { type: String },
    bookingId: { type: Schema.Types.ObjectId, ref: "Booking" },
    customerId: { type: Schema.Types.ObjectId, ref: "Customer" },
    totalVisits: { type: Number, default: 0 },
    completedVisits: { type: Number, default: 0 },
    remainingVisits: { type: Number, default: 0 },
    subscriptionStatus: {
      type: String,
      enum: ["Active", "Completed", "Cancelled"],
      default: "Active",
    },
    isPending: { type: Boolean, default: false },
    isCompleted: { type: Boolean, default: false },
    isCancelled: { type: Boolean, default: false },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 15. Visit Model
const visitSchema = new Schema(
  {
    visitNumber: { type: String },
    subscriptionId: { type: Schema.Types.ObjectId, ref: "Subscription" },
    bookingId: { type: Schema.Types.ObjectId, ref: "Booking" },
    customerId: { type: Schema.Types.ObjectId, ref: "Customer" },
    scheduledDate: { type: Date },
    startDateTime: { type: Date },
    endDateTime: { type: Date },
    actualStartDateTime: { type: Date },
    actualEndDateTime: { type: Date },
    isPending: { type: Boolean, default: true },
    isCompleted: { type: Boolean, default: false },
    isCancelled: { type: Boolean, default: false },
    remarks: { type: String, default: "" },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 16. ServicePayment Model
const servicePaymentSchema = new Schema(
  {
    paymentNumber: { type: String },
    bookingId: { type: Schema.Types.ObjectId, ref: "Booking" },
    customerId: { type: Schema.Types.ObjectId, ref: "Customer" },
    amount: { type: Number, required: true },
    paymentMethodId: { type: Schema.Types.ObjectId, ref: "PaymentMethod" },
    paymentAccountId: { type: Schema.Types.ObjectId, ref: "PaymentAccount" },
    transactionId: { type: String, default: "" },
    paymentDate: { type: Date, default: Date.now },
    status: { type: String, default: "Completed" },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

// 17. Invoice Model
const invoiceSchema = new Schema(
  {
    invoiceNumber: { type: String, required: true },
    bookingId: { type: Schema.Types.ObjectId, ref: "Booking" },
    subscriptionId: { type: Schema.Types.ObjectId, ref: "Subscription" },
    customerId: { type: Schema.Types.ObjectId, ref: "Customer" },
    amount: { type: Number, required: true },
    cgstAmount: { type: Number, default: 0 },
    sgstAmount: { type: Number, default: 0 },
    totalAmount: { type: Number, required: true },
    invoiceDate: { type: Date, default: Date.now },
    status: { type: String, default: "Paid" },
    isActive: { type: Boolean, default: true },
  },
  { timestamps: true },
);

export const Role = mongoose.models.Role || mongoose.model("Role", roleSchema);
export const User = mongoose.models.User || mongoose.model("User", userSchema);
export const BathroomCount =
  mongoose.models.BathroomCount ||
  mongoose.model("BathroomCount", bathroomCountSchema);
export const ServiceDuration =
  mongoose.models.ServiceDuration ||
  mongoose.model("ServiceDuration", serviceDurationSchema);
export const ServiceFrequency =
  mongoose.models.ServiceFrequency ||
  mongoose.model("ServiceFrequency", serviceFrequencySchema);
export const SubscriptionType =
  mongoose.models.SubscriptionType ||
  mongoose.model("SubscriptionType", subscriptionTypeSchema);
export const TimeSlot =
  mongoose.models.TimeSlot || mongoose.model("TimeSlot", timeSlotSchema);
export const PaymentMethod =
  mongoose.models.PaymentMethod ||
  mongoose.model("PaymentMethod", paymentMethodSchema);
export const PaymentAccount =
  mongoose.models.PaymentAccount ||
  mongoose.model("PaymentAccount", paymentAccountSchema);
export const PaymentMaster =
  mongoose.models.PaymentMaster ||
  mongoose.model("PaymentMaster", paymentMasterSchema);
export const Pricing =
  mongoose.models.Pricing || mongoose.model("Pricing", pricingSchema);
export const Customer =
  mongoose.models.Customer || mongoose.model("Customer", customerSchema);
export const Booking =
  mongoose.models.Booking || mongoose.model("Booking", bookingSchema);
export const Subscription =
  mongoose.models.Subscription ||
  mongoose.model("Subscription", subscriptionSchema);
export const Visit =
  mongoose.models.Visit || mongoose.model("Visit", visitSchema);
export const ServicePayment =
  mongoose.models.ServicePayment ||
  mongoose.model("ServicePayment", servicePaymentSchema);
export const Invoice =
  mongoose.models.Invoice || mongoose.model("Invoice", invoiceSchema);
