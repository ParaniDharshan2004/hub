import mongoose from 'mongoose';
import dotenv from 'dotenv';
import {
  Role,
  User,
  BathroomCount,
  ServiceDuration,
  ServiceFrequency,
  SubscriptionType,
  TimeSlot,
  PaymentMethod,
  PaymentAccount,
  PaymentMaster,
  Pricing,
  Customer,
  Booking,
  Subscription,
  Visit,
  ServicePayment,
  Invoice
} from './models/index.js';

dotenv.config();

export const seedDatabase = async () => {
  try {
    const userCount = await User.countDocuments();
    if (userCount > 0) {
      console.log('Database already initialized. Skipping auto-seeding.');
      return;
    }

    console.log('Seeding initial master data...');

    // 1. Roles
    const superadminRole = await Role.create({
      _id: '6aa397622d8212455a8487e6',
      roleName: 'superadmin',
      canRead: true,
      canWrite: true,
      canUpdate: true,
      canDelete: true,
      isActive: true
    });

    const adminRole = await Role.create({
      _id: '6aa397982d8212455a8487ec',
      roleName: 'admin',
      canRead: true,
      canWrite: true,
      canUpdate: false,
      canDelete: false,
      isActive: true
    });

    const userRole = await Role.create({
      _id: '6aa397b52d8212455a8487f2',
      roleName: 'user',
      canRead: true,
      canWrite: false,
      canUpdate: false,
      canDelete: false,
      isActive: true
    });

    // 2. Default User
    const defaultUser = await User.create({
      _id: '6aa396282d8212455a8487df',
      name: 'Muthu Ramkumar',
      email: 'muthuramkumar17@gmail.com',
      password: 'password123', // In production, hash with bcrypt
      roleId: superadminRole._id,
      isActive: true
    });

    // 3. Bathroom Counts
    const b1 = await BathroomCount.create({ _id: '6aa397f42d8212455a8487f8', bathroomCount: 1, isActive: true });
    const b2 = await BathroomCount.create({ _id: '6aa3985b2d8212455a8487fd', bathroomCount: 2, isActive: true });
    const b3 = await BathroomCount.create({ _id: '6aa3986e2d8212455a848802', bathroomCount: 3, isActive: true });
    const b4 = await BathroomCount.create({ _id: '6aa3987c2d8212455a848807', bathroomCount: 4, isActive: true });

    // 4. Service Durations
    const d30 = await ServiceDuration.create({ _id: '6aa398e32d8212455a84880c', durationMinutes: 30, isActive: true });
    const d60 = await ServiceDuration.create({ _id: '6aa399152d8212455a848811', durationMinutes: 60, isActive: true });
    const d90 = await ServiceDuration.create({ _id: '6aa399452d8212455a848816', durationMinutes: 90, isActive: true });
    const d120 = await ServiceDuration.create({ _id: '6aa399552d8212455a84881b', durationMinutes: 120, isActive: true });

    // 5. Service Frequencies
    const fWeek = await ServiceFrequency.create({ _id: '6aa399e82d8212455a848820', frequencyName: 'Once a Week', intervalDays: 7, isActive: true });
    const f2Week = await ServiceFrequency.create({ _id: '6aa39a062d8212455a848825', frequencyName: 'Once in 2 Weeks', intervalDays: 14, isActive: true });
    const fMonth = await ServiceFrequency.create({ _id: '6aa39a1f2d8212455a84882a', frequencyName: 'Once a Month', intervalDays: 30, isActive: true });

    // 6. Subscription Types
    const sub2m = await SubscriptionType.create({ _id: '6aa39c0f2d8212455a848839', subscriptionName: '2 Months', timeGap: 60, isActive: true });
    const sub3m = await SubscriptionType.create({ _id: '6aa39cb32d8212455a84883f', subscriptionName: '3 Months', timeGap: 90, isActive: true });

    // 7. Time Slots
    const tSlot1 = await TimeSlot.create({ _id: '6aa39e3d2d8212455a848853', startTime: '08:00 AM', endTime: '10:00 AM', bufferTime: 30, isActive: true });
    const tSlot2 = await TimeSlot.create({ _id: '6aa39e6a2d8212455a848858', startTime: '10:30 AM', endTime: '12:30 PM', bufferTime: 30, isActive: true });
    const tSlot3 = await TimeSlot.create({ _id: '6aa39e942d8212455a84885d', startTime: '02:00 PM', endTime: '04:00 PM', bufferTime: 30, isActive: true });

    // 8. Payment Methods
    const pmUPI = await PaymentMethod.create({ _id: '6aa39f7a2d8212455a848867', paymentMethodName: 'UPI', isActive: true });
    const pmCash = await PaymentMethod.create({ _id: '6aa39fa62d8212455a84886c', paymentMethodName: 'Cash', isActive: true });

    // 9. Payment Account
    const payAcc = await PaymentAccount.create({ _id: '6aa3a0b52d8212455a848876', accountName: 'Main HDFC Account', isActive: true });

    // 10. Payment Master Config
    const payMaster = await PaymentMaster.create({
      _id: '6aa3a1eb2d8212455a84887b',
      cgstRate: 9,
      sgstRate: 9,
      discountRate: 0,
      isActive: true
    });

    // 11. Pricing Matrix
    const p1 = await Pricing.create({
      _id: '6aa3a2ec2d8212455a848880',
      serviceDurationReference: d60._id,
      bathroomCountReference: b1._id,
      price: 499,
      isActive: true
    });
    const p2 = await Pricing.create({
      _id: '6aa3a35b2d8212455a848886',
      serviceDurationReference: d90._id,
      bathroomCountReference: b2._id,
      price: 799,
      isActive: true
    });

    // 12. Sample Customer
    const sampleCustomer = await Customer.create({
      _id: '6aa3a5682d8212455a84889e',
      name: 'John Doe',
      phoneNumber: '9876543210',
      address: '123 Main Street',
      doorNo: '4A',
      block: 'B',
      apartmentName: 'Skyline Apartments',
      city: 'Chennai',
      pincode: '600001'
    });

    console.log('Seeding completed successfully!');
  } catch (error) {
    console.error('Seeding error:', error.message);
  }
};
