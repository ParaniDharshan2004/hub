import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import dayjs from "dayjs";
import Grid from "@mui/material/Grid";
import Paper from "@mui/material/Paper";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Divider from "@mui/material/Divider";
import Chip from "@mui/material/Chip";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import AddIcon from "@mui/icons-material/Add";
import EventNoteOutlinedIcon from "@mui/icons-material/EventNoteOutlined";
import CleaningServicesOutlinedIcon from "@mui/icons-material/CleaningServicesOutlined";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import WarningAmberIcon from "@mui/icons-material/WarningAmber";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import PendingActionsIcon from "@mui/icons-material/PendingActions";

import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip as ReTooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";

import PageHeader from "../../components/PageHeader";
import Money from "../../components/Money";
import EntityLink from "../../components/EntityLink";
import StatusChip from "../../components/StatusChip";
import { LoadingSkeleton, ErrorState } from "../../components/PageStates";
import KpiCard from "../../components/dashboard-components/KpiCards";
import { getDashboardSummary } from "../../api/dashboard";
import { serviceAreas } from "../../api/masters";
import { formatDate, formatDateTime } from "../../utils/format";

/** Vibrant color palette for charts and category metrics */
const CHART_COLORS = ["#0F5C57", "#1F7A6C", "#D98E04", "#D32F2F", "#9FCDC3"];

/**
 * DashboardPage Component
 * Operational control center giving telecallers & admins real-time insights into today's visit workload, financial collections, and pending exceptions.
 */
export default function DashboardPage() {
  const navigate = useNavigate();
  const today = dayjs().format("YYYY-MM-DD");

  /** Fetch live dashboard metrics */
  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ["dashboard", today],
    queryFn: () => getDashboardSummary({ date: today }),
  });

  if (isLoading) {
    return (
      <>
        <PageHeader
          title="Dashboard"
          subtitle={dayjs().format("dddd, DD MMMM YYYY")}
        />
        <LoadingSkeleton rows={8} />
      </>
    );
  }

  if (isError) return <ErrorState message={error.message} onRetry={refetch} />;

  const { kpis, areaWorkload, recentBookings, upcomingVisits, exceptions } =
    data;
  const todaysVisits = upcomingVisits.filter((visit) =>
    dayjs(visit.date).isSame(dayjs(), "day"),
  );

  /** Format pie chart dataset for today's completed vs pending visits */
  const visitPieData = [
    { name: "Completed", value: kpis.completedToday },
    { name: "Pending", value: kpis.pendingToday },
  ].filter((d) => d.value > 0);

  return (
    <>
      {/* Top Header & Quick Actions */}
      <PageHeader
        title="Dashboard"
        subtitle={`Operational summary for ${dayjs().format("dddd, DD MMMM YYYY")}`}
        actions={
          <>
            <Button
              variant="outlined"
              startIcon={<AddIcon />}
              onClick={() => navigate("/customers")}
            >
              Add Customer
            </Button>
            <Button
              variant="contained"
              startIcon={<EventNoteOutlinedIcon />}
              onClick={() => navigate("/bookings/new")}
            >
              Create Booking
            </Button>
          </>
        }
      />

      {/* Row 1: Visit Execution KPIs */}
      <Grid container spacing={2} sx={{ mb: 3 }}>

        <Grid item xs={6} sm={4} md={4}>
          <KpiCard
            label="Today's Visits"
            value={kpis.todayVisits}
            onClick={() => navigate("/visits/today")}
            icon={
              <CleaningServicesOutlinedIcon
                fontSize="small"
                sx={{ color: "primary.main", opacity: 0.8 }}
              />
            }
          />
        </Grid>

        <Grid item xs={6} sm={4} md={4}>
          <KpiCard
            label="Active Subscriptions"
            value={kpis.activeSubscriptions}
            onClick={() => navigate("/subscriptions")}
            icon={
              <TrendingUpIcon fontSize="small" sx={{ color: "primary.main" }} />
            }
          />
        </Grid>

        <Grid item xs={6} sm={4}>
          <KpiCard
            label="Renewals Due Soon"
            value={kpis.renewalsDueSoon}
            accent="warning.main"
            onClick={() => navigate("/subscriptions")}
          />
        </Grid>
      </Grid>

      {/* Row 3: Charts */}
      <Grid container spacing={3}>
        {/* Visit Status Donut Chart */}
        {/* <Grid item xs={12} md={4}>
          <Paper
            variant="outlined"
            sx={{ p: 2.5, borderRadius: 1, height: "100%" }}
          >
            <Typography variant="subtitle1" sx={{ mb: 1.5, fontWeight: 700 }}>
              Today's Visit Status
            </Typography>
            {visitPieData.length === 0 ? (
              <Typography
                variant="body2"
                color="text.secondary"
                sx={{ py: 6, textAlign: "center" }}
              >
                No visits scheduled today.
              </Typography>
            ) : (
              <Stack sx={{ height: 210 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={visitPieData}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={50}
                      outerRadius={80}
                      paddingAngle={3}
                    >
                      {visitPieData.map((entry, i) => (
                        <Cell
                          key={entry.name}
                          fill={CHART_COLORS[i % CHART_COLORS.length]}
                        />
                      ))}
                    </Pie>
                    <ReTooltip />
                  </PieChart>
                </ResponsiveContainer>
              </Stack>
            )}
            <Stack
              direction="row"
              spacing={2}
              justifyContent="center"
              sx={{ mt: 1 }}
            >
              {visitPieData.map((d, i) => (
                <Stack
                  key={d.name}
                  direction="row"
                  spacing={0.75}
                  alignItems="center"
                >
                  <Box
                    sx={{
                      width: 10,
                      height: 10,
                      borderRadius: 1,
                      bgcolor: CHART_COLORS[i % CHART_COLORS.length],
                    }}
                  />
                  <Typography
                    variant="caption"
                    color="text.secondary"
                    sx={{ fontWeight: 600 }}
                  >
                    {d.name} ({d.value})
                  </Typography>
                </Stack>
              ))}
            </Stack>
          </Paper>
        </Grid> */}

        {/* Area Workload Bar Chart */}
        {/* <Grid item xs={12} md={8}>
          <Paper
            variant="outlined"
            sx={{ p: 2.5, borderRadius: 1, height: "100%" }}
          >
            <Typography variant="subtitle1" sx={{ mb: 1.5, fontWeight: 700 }}>
              Area-wise Workload Today
            </Typography>
            {areaWorkload.length === 0 ? (
              <Typography
                variant="body2"
                color="text.secondary"
                sx={{ py: 6, textAlign: "center" }}
              >
                No visits scheduled today.
              </Typography>
            ) : (
              <Stack sx={{ height: 220 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart
                    data={areaWorkload}
                    margin={{ top: 10, right: 10, left: -20, bottom: 0 }}
                  >
                    <CartesianGrid
                      strokeDasharray="3 3"
                      vertical={false}
                      stroke="#E2E8E6"
                    />
                    <XAxis dataKey="areaName" fontSize={12} stroke="#70807D" />
                    <YAxis
                      allowDecimals={false}
                      fontSize={12}
                      stroke="#70807D"
                    />
                    <ReTooltip />
                    <Bar
                      dataKey="completed"
                      stackId="a"
                      fill={CHART_COLORS[0]}
                      radius={[0, 0, 4, 4]}
                      name="Completed"
                    />
                    <Bar
                      dataKey="scheduled"
                      stackId="a"
                      fill={CHART_COLORS[2]}
                      radius={[4, 4, 0, 0]}
                      name="Scheduled"
                    />
                  </BarChart>
                </ResponsiveContainer>
              </Stack>
            )}
          </Paper>
        </Grid> */}
      </Grid>
      {/* Row 4: Recent Feeds */}
      <Grid container spacing={3} sx={{ mt: 0.5 }}>
        {/* Today's Cleaning Schedule */}
        <Grid item xs={12} md={12}>
          <Paper variant="outlined" sx={{ p: 2.5, borderRadius: 1 }}>
            <Stack
              direction="row"
              justifyContent="space-between"
              alignItems="center"
              sx={{ mb: 2 }}
            >
              <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
                Today&apos;s Cleaning Schedule
              </Typography>
              <Button size="small" onClick={() => navigate("/visits")}>
                View All
              </Button>
            </Stack>
            {todaysVisits.length === 0 ? (
              <Typography variant="body2" color="text.secondary" sx={{ py: 2 }}>
                No cleaning scheduled for today.
              </Typography>
            ) : (
              <TableContainer>
                <Table size="small">
                  <TableHead>
                    <TableRow>
                      <TableCell sx={{ fontWeight: 700 }}>Customer</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Area</TableCell>
                      <TableCell sx={{ fontWeight: 700 }}>Service Time</TableCell>
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {todaysVisits.map((visit) => (
                      <TableRow
                        key={visit.id}
                        hover
                        onClick={() => navigate(`/visits/${visit.visitNumber}`)}
                        sx={{ cursor: "pointer" }}
                      >
                        <TableCell>
                          <Typography variant="body2" sx={{ fontWeight: 600 }}>
                            {visit.customer?.name || "—"}
                          </Typography>
                        </TableCell>
                        <TableCell>
                          {serviceAreas.find((area) => area.id === visit.customer?.area)?.name ||
                            visit.customer?.area ||
                            "—"}
                        </TableCell>
                        <TableCell>
                          {visit.serviceStartTime && visit.serviceEndTime
                            ? `${visit.serviceStartTime} - ${visit.serviceEndTime}`
                            : "—"}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </TableContainer>
            )}
          </Paper>
        </Grid>

        {/* Recent Confirmations Feed */}
        {/* <Grid item xs={12} md={6}>
          <Paper variant="outlined" sx={{ p: 2.5, borderRadius: 1 }}>
            <Stack
              direction="row"
              justifyContent="space-between"
              alignItems="center"
              sx={{ mb: 2 }}
            >
              <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
                Recent Booking Confirmations
              </Typography>
              <Button size="small" onClick={() => navigate("/bookings")}>
                View All
              </Button>
            </Stack>
            {recentBookings.length === 0 ? (
              <Typography variant="body2" color="text.secondary" sx={{ py: 2 }}>
                No confirmed bookings yet.
              </Typography>
            ) : (
              <Stack
                divider={<Divider sx={{ borderColor: "#E2E8E6" }} />}
                spacing={1.5}
              >
                {recentBookings.map((b) => (
                  <Stack
                    key={b.id}
                    direction="row"
                    justifyContent="space-between"
                    alignItems="center"
                  >
                    <Stack>
                      <EntityLink type="Booking" id={b.bookingNumber} />
                      <Typography variant="caption" color="text.secondary">
                        {b.customer?.name} · {formatDateTime(b.confirmedOn)}
                      </Typography>
                    </Stack>
                    <Money value={b.total} strong />
                  </Stack>
                ))}
              </Stack>
            )}
          </Paper>
        </Grid> */}
      </Grid>

      {/* Row 5: Pending Stale Draft Exceptions */}
      {exceptions.staleDrafts.length > 0 && (
        <Paper
          variant="outlined"
          sx={{
            p: 2.5,
            mt: 3,
            borderRadius: 1,
            borderColor: "warning.main",
            bgcolor: "#FCF3E3",
          }}
        >
          <Typography
            variant="subtitle1"
            sx={{ mb: 1, fontWeight: 700, color: "warning.dark" }}
          >
            Action Required: Stale Draft Bookings
          </Typography>
          <Stack direction="row" spacing={1} flexWrap="wrap">
            {exceptions.staleDrafts.map((b) => (
              <Chip
                key={b.id}
                label={`Draft ${b.bookingNumber}`}
                color="warning"
                onClick={() => navigate(`/bookings/${b.bookingNumber}`)}
                sx={{ fontWeight: 600, cursor: "pointer" }}
              />
            ))}
          </Stack>
        </Paper>
      )}
    </>
  );
}
