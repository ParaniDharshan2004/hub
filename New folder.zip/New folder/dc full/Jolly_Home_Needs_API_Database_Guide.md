# JOLLY HOME NEEDS

## API AND DATABASE TESTING GUIDE

**Base URL:** `http://localhost:5000`\
**Authorization:** Bearer token required for protected endpoints.

------------------------------------------------------------------------

## 1. Login

**Endpoint**

``` http
POST http://localhost:5000/api/login
```

**Request Body**

``` json
{
  "email": "muthuramkumar17@gmail.com",
  "password": "YOUR_PASSWORD"
}
```

**User ID**

``` text
6aa396282d8212455a8487df
```

**Authorization Header**

``` http
Authorization: Bearer YOUR_LOGIN_TOKEN
```

------------------------------------------------------------------------

## 2. Roles

### Superadmin

**Endpoint**

``` http
POST http://localhost:5000/api/roles
```

**Request Body**

``` json
{
  "roleName": "superadmin",
  "canRead": true,
  "canWrite": true,
  "canUpdate": true,
  "canDelete": true,
  "isActive": true
}
```

**ID**

``` text
6aa397622d8212455a8487e6
```

### Admin

**Endpoint**

``` http
POST http://localhost:5000/api/roles
```

**Request Body**

``` json
{
  "roleName": "admin",
  "canRead": true,
  "canWrite": true,
  "canUpdate": false,
  "canDelete": false,
  "isActive": true
}
```

**ID**

``` text
6aa397982d8212455a8487ec
```

### User

**Endpoint**

``` http
POST http://localhost:5000/api/roles
```

**Request Body**

``` json
{
  "roleName": "user",
  "canRead": true,
  "canWrite": false,
  "canUpdate": false,
  "canDelete": false,
  "isActive": true
}
```

**ID**

``` text
6aa397b52d8212455a8487f2
```

------------------------------------------------------------------------

## 3. Bathroom Count Master

### 1 Bathroom

**Endpoint**

``` http
POST http://localhost:5000/api/bathroom-counts
```

**Request Body**

``` json
{
  "bathroomCount": 1,
  "isActive": true
}
```

**ID**

``` text
6aa397f42d8212455a8487f8
```

### 2 Bathrooms

**Endpoint**

``` http
POST http://localhost:5000/api/bathroom-counts
```

**Request Body**

``` json
{
  "bathroomCount": 2,
  "isActive": true
}
```

**ID**

``` text
6aa3985b2d8212455a8487fd
```

### 3 Bathrooms

**Endpoint**

``` http
POST http://localhost:5000/api/bathroom-counts
```

**Request Body**

``` json
{
  "bathroomCount": 3,
  "isActive": true
}
```

**ID**

``` text
6aa3986e2d8212455a848802
```

### 4 Bathrooms

**Endpoint**

``` http
POST http://localhost:5000/api/bathroom-counts
```

**Request Body**

``` json
{
  "bathroomCount": 4,
  "isActive": true
}
```

**ID**

``` text
6aa3987c2d8212455a848807
```

------------------------------------------------------------------------

## 4. Service Duration Master

### 30 Minutes

**Endpoint**

``` http
POST http://localhost:5000/api/service-durations
```

**Request Body**

``` json
{
  "durationMinutes": 30,
  "isActive": true
}
```

**ID**

``` text
6aa398e32d8212455a84880c
```

### 60 Minutes

**Endpoint**

``` http
POST http://localhost:5000/api/service-durations
```

**Request Body**

``` json
{
  "durationMinutes": 60,
  "isActive": true
}
```

**ID**

``` text
6aa399152d8212455a848811
```

### 90 Minutes

**Endpoint**

``` http
POST http://localhost:5000/api/service-durations
```

**Request Body**

``` json
{
  "durationMinutes": 90,
  "isActive": true
}
```

**ID**

``` text
6aa399452d8212455a848816
```

### 120 Minutes

**Endpoint**

``` http
POST http://localhost:5000/api/service-durations
```

**Request Body**

``` json
{
  "durationMinutes": 120,
  "isActive": true
}
```

**ID**

``` text
6aa399552d8212455a84881b
```

------------------------------------------------------------------------

## 5. Service Frequency Master

### Once a Week

**Endpoint**

``` http
POST http://localhost:5000/api/service-frequencies
```

**Request Body**

``` json
{
  "frequencyName": "Once a Week",
  "intervalDays": 7,
  "isActive": true
}
```

**ID**

``` text
6aa399e82d8212455a848820
```

### Once in 2 Weeks

**Endpoint**

``` http
POST http://localhost:5000/api/service-frequencies
```

**Request Body**

``` json
{
  "frequencyName": "Once in 2 Weeks",
  "intervalDays": 14,
  "isActive": true
}
```

**ID**

``` text
6aa39a062d8212455a848825
```

### Once a Month

**Endpoint**

``` http
POST http://localhost:5000/api/service-frequencies
```

**Request Body**

``` json
{
  "frequencyName": "Once a Month",
  "intervalDays": 30,
  "isActive": true
}
```

**ID**

``` text
6aa39a1f2d8212455a84882a
```

------------------------------------------------------------------------

## 6. Subscription Type Master

### 2 Months

**Endpoint**

``` http
POST http://localhost:5000/api/subscription-types
```

**Request Body**

``` json
{
  "subscriptionName": "2 Months",
  "timeGap": 2,
  "isActive": true
}
```

**ID**

``` text
6aa39d5a7c29ba4d9e1c3f93
```

### 3 Months

**Endpoint**

``` http
POST http://localhost:5000/api/subscription-types
```

**Request Body**

``` json
{
  "subscriptionName": "3 Months",
  "timeGap": 3,
  "isActive": true
}
```

**ID**

``` text
6aa39d767c29ba4d9e1c3f99
```

### 6 Months

**Endpoint**

``` http
POST http://localhost:5000/api/subscription-types
```

**Request Body**

``` json
{
  "subscriptionName": "6 Months",
  "timeGap": 6,
  "isActive": true
}
```

**ID**

``` text
6aa39d967c29ba4d9e1c3f9f
```

### 12 Months

**Endpoint**

``` http
POST http://localhost:5000/api/subscription-types
```

**Request Body**

``` json
{
  "subscriptionName": "12 Months",
  "timeGap": 12,
  "isActive": true
}
```

**ID**

``` text
6aa39dbb7c29ba4d9e1c3fa5
```

------------------------------------------------------------------------

## 7. Time Slot Master

**Endpoint**

``` http
POST http://localhost:5000/api/time-slots
```

**Request Body**

``` json
{
  "startTime": "08:30",
  "endTime": "21:00",
  "bufferTime": 30,
  "isActive": true
}
```

**ID**

``` text
6aa39e6c7c29ba4d9e1c3fab
```

------------------------------------------------------------------------

## 8. Payment Method Master

### UPI

**Endpoint**

``` http
POST http://localhost:5000/api/payment-methods
```

**Request Body**

``` json
{
  "paymentMethodName": "UPI",
  "isActive": true
}
```

**ID**

``` text
6aa39ea97c29ba4d9e1c3fb0
```

### Cash

**Endpoint**

``` http
POST http://localhost:5000/api/payment-methods
```

**Request Body**

``` json
{
  "paymentMethodName": "Cash",
  "isActive": true
}
```

**ID**

``` text
6aa39ee87c29ba4d9e1c3fb5
```

### Card

**Endpoint**

``` http
POST http://localhost:5000/api/payment-methods
```

**Request Body**

``` json
{
  "paymentMethodName": "Card",
  "isActive": true
}
```

**ID**

``` text
6aa39f0f7c29ba4d9e1c3fba
```

------------------------------------------------------------------------

## 9. Payment Account Master

### ICICI

**Endpoint**

``` http
POST http://localhost:5000/api/payment-accounts
```

**Request Body**

``` json
{
  "accountName": "ICICI",
  "isActive": true
}
```

**ID**

``` text
6aa39f737c29ba4d9e1c3fbf
```

### HDFC

**Endpoint**

``` http
POST http://localhost:5000/api/payment-accounts
```

**Request Body**

``` json
{
  "accountName": "HDFC",
  "isActive": true
}
```

**ID**

``` text
6aa39fce7c29ba4d9e1c3fc4
```

------------------------------------------------------------------------

## 10. Payment Master

**Endpoint**

``` http
POST http://localhost:5000/api/payment-masters
```

**Request Body**

``` json
{
  "cgstRate": 9,
  "sgstRate": 9,
  "discountRate": 0,
  "effectiveFrom": "2026-09-11T00:00:00.000Z",
  "effectiveTo": null,
  "isActive": true
}
```

**ID**

``` text
6aa3a0127c29ba4d9e1c3fc9
```

------------------------------------------------------------------------

## 11. Pricing Master

### 1 Bathroom - 1200

**Endpoint**

``` http
POST http://localhost:5000/api/pricing
```

**Request Body**

``` json
{
  "serviceDurationReference": "6aa398e32d8212455a84880c",
  "bathroomCountReference": "6aa397f42d8212455a8487f8",
  "price": 1200,
  "effectiveFrom": "2026-09-11T00:00:00.000Z",
  "effectiveTo": null,
  "isActive": true
}
```

**ID**

``` text
6aa3a06d7c29ba4d9e1c3fce
```

### 2 Bathrooms - 2400

**Endpoint**

``` http
POST http://localhost:5000/api/pricing
```

**Request Body**

``` json
{
  "serviceDurationReference": "6aa398e32d8212455a84880c",
  "bathroomCountReference": "6aa3985b2d8212455a8487fd",
  "price": 2400,
  "effectiveFrom": "2026-09-11T00:00:00.000Z",
  "effectiveTo": null,
  "isActive": true
}
```

**ID**

``` text
6aa3a0917c29ba4d9e1c3fd3
```

### 3 Bathrooms - 3600

**Endpoint**

``` http
POST http://localhost:5000/api/pricing
```

**Request Body**

``` json
{
  "serviceDurationReference": "6aa398e32d8212455a84880c",
  "bathroomCountReference": "6aa3986e2d8212455a848802",
  "price": 3600,
  "effectiveFrom": "2026-09-11T00:00:00.000Z",
  "effectiveTo": null,
  "isActive": true
}
```

**ID**

``` text
6aa3a0c17c29ba4d9e1c3fd8
```

### 4 Bathrooms - 4800

**Endpoint**

``` http
POST http://localhost:5000/api/pricing
```

**Request Body**

``` json
{
  "serviceDurationReference": "6aa398e32d8212455a84880c",
  "bathroomCountReference": "6aa3987c2d8212455a848807",
  "price": 4800,
  "effectiveFrom": "2026-09-11T00:00:00.000Z",
  "effectiveTo": null,
  "isActive": true
}
```

**ID**

``` text
6aa3a1117c29ba4d9e1c3fdd
```

------------------------------------------------------------------------

## 12. Customers

### Arun Kumar

**Endpoint**

``` http
POST http://localhost:5000/api/customers
```

**Request Body**

``` json
{
  "name": "Arun Kumar",
  "phoneNumber": "9876543210",
  "address": "12 Lake View Road",
  "doorNo": "A-12",
  "block": "A",
  "apartmentName": "Green Residency",
  "landmark": "Near Central Park",
  "city": "Chennai",
  "pincode": "600001",
  "isActive": true
}
```

**ID**

``` text
6aa3a1597c29ba4d9e1c3fe2
```

### Priya Kumar

**Endpoint**

``` http
POST http://localhost:5000/api/customers
```

**Request Body**

``` json
{
  "name": "Priya Kumar",
  "phoneNumber": "9876543211",
  "address": "25 Anna Nagar Main Road",
  "doorNo": "B-204",
  "block": "B",
  "apartmentName": "Sunshine Apartments",
  "landmark": "Near Anna Nagar Tower",
  "city": "Chennai",
  "pincode": "600040",
  "isActive": true
}
```

**ID**

``` text
6aa3a1807c29ba4d9e1c3fe8
```

### Karthik Raj

**Endpoint**

``` http
POST http://localhost:5000/api/customers
```

**Request Body**

``` json
{
  "name": "Karthik Raj",
  "phoneNumber": "9876543212",
  "address": "45 Whitefield Main Road",
  "doorNo": "C-305",
  "block": "C",
  "apartmentName": "Green Valley Apartments",
  "landmark": "Near ITPL",
  "city": "Bangalore",
  "pincode": "560066",
  "isActive": true
}
```

**ID**

``` text
6aa3a19e7c29ba4d9e1c3fee
```

### Rahul Reddy

**Endpoint**

``` http
POST http://localhost:5000/api/customers
```

**Request Body**

``` json
{
  "name": "Rahul Reddy",
  "phoneNumber": "9876543213",
  "address": "18 Hitech City Main Road",
  "doorNo": "D-402",
  "block": "D",
  "apartmentName": "Lake View Residency",
  "landmark": "Near Cyber Towers",
  "city": "Hyderabad",
  "pincode": "500081",
  "isActive": true
}
```

**ID**

``` text
6aa3a1ca7c29ba4d9e1c3ff4
```

------------------------------------------------------------------------

## 13. Bookings

### Arun Kumar

**Endpoint**

``` http
POST http://localhost:5000/api/bookings
```

**Request Body**

``` json
{
  "customerId": "6aa3a1597c29ba4d9e1c3fe2",
  "bathroomCountId": "6aa397f42d8212455a8487f8",
  "pricingId": "6aa3a06d7c29ba4d9e1c3fce",
  "serviceDurationId": "6aa398e32d8212455a84880c",
  "serviceFrequencyId": "6aa399e82d8212455a848820",
  "subscriptionTypeId": "6aa39d5a7c29ba4d9e1c3f93",
  "scheduledDate": "2026-09-12",
  "startDateTime": "2026-09-12T08:30:00.000Z",
  "endDateTime": "2026-09-12T09:30:00.000Z",
  "paymentMethodId": "6aa39ea97c29ba4d9e1c3fb0",
  "paymentAccountId": "6aa39f737c29ba4d9e1c3fbf",
  "transactionId": "TXN-ARUN-001",
  "timeSlotId": "6aa39e6c7c29ba4d9e1c3fab",
  "isPending": true,
  "isCompleted": false,
  "isCancelled": false,
  "isActive": true
}
```

**Booking ID**

``` text
BKG_01
```

**Booking ObjectId**

``` text
6aa3ac985b0f5fe60b265266
```

### Priya Kumar

**Endpoint**

``` http
POST http://localhost:5000/api/bookings
```

**Request Body**

``` json
{
  "customerId": "6aa3a1807c29ba4d9e1c3fe8",
  "bathroomCountId": "6aa3985b2d8212455a8487fd",
  "pricingId": "6aa3a0917c29ba4d9e1c3fd3",
  "serviceDurationId": "6aa398e32d8212455a84880c",
  "serviceFrequencyId": "6aa39a062d8212455a848825",
  "subscriptionTypeId": "6aa39d767c29ba4d9e1c3f99",
  "scheduledDate": "2026-09-13",
  "startDateTime": "2026-09-13T08:30:00.000Z",
  "endDateTime": "2026-09-13T09:30:00.000Z",
  "paymentMethodId": "6aa39ee87c29ba4d9e1c3fb5",
  "paymentAccountId": "6aa39fce7c29ba4d9e1c3fc4",
  "transactionId": "",
  "timeSlotId": "6aa39e6c7c29ba4d9e1c3fab",
  "isPending": true,
  "isCompleted": false,
  "isCancelled": false,
  "isActive": true
}
```

**Booking ID**

``` text
BKG_02
```

**Booking ObjectId**

``` text
6aa3adb3c48a96b6eebce6cf
```

### Karthik Raj

**Endpoint**

``` http
POST http://localhost:5000/api/bookings
```

**Request Body**

``` json
{
  "customerId": "6aa3a19e7c29ba4d9e1c3fee",
  "bathroomCountId": "6aa3986e2d8212455a848802",
  "pricingId": "6aa3a0c17c29ba4d9e1c3fd8",
  "serviceDurationId": "6aa398e32d8212455a84880c",
  "serviceFrequencyId": "6aa39a1f2d8212455a84882a",
  "subscriptionTypeId": "6aa39d967c29ba4d9e1c3f9f",
  "scheduledDate": "2026-09-14",
  "startDateTime": "2026-09-14T08:30:00.000Z",
  "endDateTime": "2026-09-14T09:30:00.000Z",
  "paymentMethodId": "6aa39f0f7c29ba4d9e1c3fba",
  "paymentAccountId": "6aa39f737c29ba4d9e1c3fbf",
  "transactionId": "TXN-KARTHIK-001",
  "timeSlotId": "6aa39e6c7c29ba4d9e1c3fab",
  "isPending": true,
  "isCompleted": false,
  "isCancelled": false,
  "isActive": true
}
```

**Booking ID**

``` text
BKG_03
```

**Booking ObjectId**

``` text
6aa3add3c48a96b6eebce704
```

### Rahul Reddy

**Endpoint**

``` http
POST http://localhost:5000/api/bookings
```

**Request Body**

``` json
{
  "customerId": "6aa3a1ca7c29ba4d9e1c3ff4",
  "bathroomCountId": "6aa3987c2d8212455a848807",
  "pricingId": "6aa3a1117c29ba4d9e1c3fdd",
  "serviceDurationId": "6aa398e32d8212455a84880c",
  "serviceFrequencyId": "6aa399e82d8212455a848820",
  "subscriptionTypeId": "6aa39dbb7c29ba4d9e1c3fa5",
  "scheduledDate": "2026-09-15",
  "startDateTime": "2026-09-15T08:30:00.000Z",
  "endDateTime": "2026-09-15T09:30:00.000Z",
  "paymentMethodId": "6aa39ea97c29ba4d9e1c3fb0",
  "paymentAccountId": "6aa39f737c29ba4d9e1c3fbf",
  "transactionId": "TXN-RAHUL-001",
  "timeSlotId": "6aa39e6c7c29ba4d9e1c3fab",
  "isPending": true,
  "isCompleted": false,
  "isCancelled": false,
  "isActive": true
}
```

**Booking ID**

``` text
BKG_04
```

**Booking ObjectId**

``` text
6aa3adfec48a96b6eebce739
```

------------------------------------------------------------------------

## 14. Generated Transaction IDs

### Arun Kumar

``` json
{
  "bookingId": "BKG_01",
  "bookingObjectId": "6aa3ac985b0f5fe60b265266",
  "subscriptionId": "SUB_05",
  "subscriptionObjectId": "6aa3ac985b0f5fe60b265269",
  "totalVisits": 9,
  "servicePaymentObjectId": "6aa3ac985b0f5fe60b26527f",
  "invoiceNumber": "JHN20260912-0001",
  "invoiceObjectId": "6aa3ac985b0f5fe60b265284",
  "amount": 12744
}
```

### Priya Kumar

``` json
{
  "bookingId": "BKG_02",
  "bookingObjectId": "6aa3adb3c48a96b6eebce6cf",
  "subscriptionId": "SUB_06",
  "subscriptionObjectId": "6aa3adb4c48a96b6eebce6d2",
  "totalVisits": 7,
  "servicePaymentObjectId": "6aa3adb4c48a96b6eebce6e4",
  "invoiceNumber": "JHN20260913-0001",
  "invoiceObjectId": "6aa3adb4c48a96b6eebce6e9",
  "amount": 19824
}
```

### Karthik Raj

``` json
{
  "bookingId": "BKG_03",
  "bookingObjectId": "6aa3add3c48a96b6eebce704",
  "subscriptionId": "SUB_07",
  "subscriptionObjectId": "6aa3add3c48a96b6eebce707",
  "totalVisits": 7,
  "servicePaymentObjectId": "6aa3add3c48a96b6eebce719",
  "invoiceNumber": "JHN20260914-0001",
  "invoiceObjectId": "6aa3add4c48a96b6eebce71e",
  "amount": 29736
}
```

### Rahul Reddy

``` json
{
  "bookingId": "BKG_04",
  "bookingObjectId": "6aa3adfec48a96b6eebce739",
  "subscriptionId": "SUB_08",
  "subscriptionObjectId": "6aa3adfec48a96b6eebce73c",
  "totalVisits": 53,
  "servicePaymentObjectId": "6aa3adfec48a96b6eebce7aa",
  "invoiceNumber": "JHN20260915-0001",
  "invoiceObjectId": "6aa3adffc48a96b6eebce7af",
  "amount": 300192
}
```

------------------------------------------------------------------------

## 15. Update Booking Payment Account

**Endpoint**

``` http
PATCH http://localhost:5000/api/bookings/6aa3ac985b0f5fe60b265266
```

**Request Body**

``` json
{
  "paymentAccountId": "6aa39f737c29ba4d9e1c3fbf"
}
```

------------------------------------------------------------------------

## 16. Visit Lifecycle API

### Arun Kumar Subscription

**Subscription ID**

``` text
6aa3ac985b0f5fe60b265269
```

### Visit 1

**Visit ObjectId**

``` text
6aa3ac985b0f5fe60b26526c
```

**Endpoint**

``` http
PATCH http://localhost:5000/api/visits/6aa3ac985b0f5fe60b26526c
```

**Request Body**

``` json
{
  "actualStartDateTime": "2026-09-12T08:30:00.000Z",
  "actualEndDateTime": "2026-09-12T09:30:00.000Z",
  "isPending": false,
  "isCompleted": true,
  "isCancelled": false,
  "remarks": "Visit 1 completed successfully"
}
```

### Visit 2

**Visit ObjectId**

``` text
6aa3ac985b0f5fe60b26526d
```

**Endpoint**

``` http
PATCH http://localhost:5000/api/visits/6aa3ac985b0f5fe60b26526d
```

**Request Body**

``` json
{
  "actualStartDateTime": "2026-09-19T08:30:00.000Z",
  "actualEndDateTime": "2026-09-19T09:30:00.000Z",
  "isPending": false,
  "isCompleted": true,
  "isCancelled": false,
  "remarks": "Visit 2 completed successfully"
}
```

### Visit 3

**Visit ObjectId**

``` text
6aa3ac985b0f5fe60b26526e
```

**Endpoint**

``` http
PATCH http://localhost:5000/api/visits/6aa3ac985b0f5fe60b26526e
```

**Request Body**

``` json
{
  "actualStartDateTime": "2026-09-26T08:30:00.000Z",
  "actualEndDateTime": "2026-09-26T09:30:00.000Z",
  "isPending": false,
  "isCompleted": true,
  "isCancelled": false,
  "remarks": "Visit 3 completed successfully"
}
```

### Visit 4

**Visit ObjectId**

``` text
6aa3ac985b0f5fe60b26526f
```

**Endpoint**

``` http
PATCH http://localhost:5000/api/visits/6aa3ac985b0f5fe60b26526f
```

**Request Body**

``` json
{
  "actualStartDateTime": "2026-10-03T08:30:00.000Z",
  "actualEndDateTime": "2026-10-03T09:30:00.000Z",
  "isPending": false,
  "isCompleted": true,
  "isCancelled": false,
  "remarks": "Visit 4 completed successfully"
}
```

### Visit 5

**Visit ObjectId**

``` text
6aa3ac985b0f5fe60b265270
```

**Endpoint**

``` http
PATCH http://localhost:5000/api/visits/6aa3ac985b0f5fe60b265270
```

**Request Body**

``` json
{
  "actualStartDateTime": "2026-10-10T08:30:00.000Z",
  "actualEndDateTime": "2026-10-10T09:30:00.000Z",
  "isPending": false,
  "isCompleted": true,
  "isCancelled": false,
  "remarks": "Visit 5 completed successfully"
}
```

### Visit 6

**Visit ObjectId**

``` text
6aa3ac985b0f5fe60b265271
```

**Endpoint**

``` http
PATCH http://localhost:5000/api/visits/6aa3ac985b0f5fe60b265271
```

**Request Body**

``` json
{
  "actualStartDateTime": "2026-10-17T08:30:00.000Z",
  "actualEndDateTime": "2026-10-17T09:30:00.000Z",
  "isPending": false,
  "isCompleted": true,
  "isCancelled": false,
  "remarks": "Visit 6 completed successfully"
}
```

### Visit 7

**Visit ObjectId**

``` text
6aa3ac985b0f5fe60b265272
```

**Endpoint**

``` http
PATCH http://localhost:5000/api/visits/6aa3ac985b0f5fe60b265272
```

**Request Body**

``` json
{
  "actualStartDateTime": "2026-10-24T08:30:00.000Z",
  "actualEndDateTime": "2026-10-24T09:30:00.000Z",
  "isPending": false,
  "isCompleted": true,
  "isCancelled": false,
  "remarks": "Visit 7 completed successfully"
}
```

### Visit 8

**Visit ObjectId**

``` text
6aa3ac985b0f5fe60b265273
```

**Endpoint**

``` http
PATCH http://localhost:5000/api/visits/6aa3ac985b0f5fe60b265273
```

**Request Body**

``` json
{
  "actualStartDateTime": "2026-10-31T08:30:00.000Z",
  "actualEndDateTime": "2026-10-31T09:30:00.000Z",
  "isPending": false,
  "isCompleted": true,
  "isCancelled": false,
  "remarks": "Visit 8 completed successfully"
}
```

### Visit 9

**Visit ObjectId**

``` text
6aa3ac985b0f5fe60b265274
```

**Endpoint**

``` http
PATCH http://localhost:5000/api/visits/6aa3ac985b0f5fe60b265274
```

**Request Body**

``` json
{
  "actualStartDateTime": "2026-11-07T08:30:00.000Z",
  "actualEndDateTime": "2026-11-07T09:30:00.000Z",
  "isPending": false,
  "isCompleted": true,
  "isCancelled": false,
  "remarks": "Visit 9 completed successfully"
}
```

------------------------------------------------------------------------

## 17. Lifecycle Verification

### Subscription Verification

**Endpoint**

``` http
GET http://localhost:5000/api/subscriptions/6aa3ac985b0f5fe60b265269
```

**Response**

``` json
{
  "subscriptionId": "SUB_05",
  "totalVisits": 9,
  "completedVisits": 9,
  "remainingVisits": 0,
  "subscriptionStatus": "Completed",
  "isPending": false,
  "isCompleted": true,
  "isCancelled": false,
  "isActive": true
}
```

### Booking Verification

**Endpoint**

``` http
GET http://localhost:5000/api/bookings/6aa3ac985b0f5fe60b265266
```

**Response**

``` json
{
  "bookingId": "BKG_01",
  "isPending": false,
  "isCompleted": true,
  "isCancelled": false,
  "isActive": true
}
```

------------------------------------------------------------------------

## 18. Core GET APIs

``` http
GET http://localhost:5000/api/roles
GET http://localhost:5000/api/users
GET http://localhost:5000/api/customers
GET http://localhost:5000/api/bathroom-counts
GET http://localhost:5000/api/service-durations
GET http://localhost:5000/api/service-frequencies
GET http://localhost:5000/api/subscription-types
GET http://localhost:5000/api/time-slots
GET http://localhost:5000/api/payment-methods
GET http://localhost:5000/api/payment-accounts
GET http://localhost:5000/api/payment-masters
GET http://localhost:5000/api/pricing
GET http://localhost:5000/api/bookings
GET http://localhost:5000/api/subscriptions
GET http://localhost:5000/api/visits
GET http://localhost:5000/api/service-payments
GET http://localhost:5000/api/invoices
```

------------------------------------------------------------------------

## End of Guide
