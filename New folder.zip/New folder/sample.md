# GlyphCode Specification v1.0
### A Radial Visual Data Encoding System

---

# Overview

GlyphCode is a next-generation machine-readable visual encoding standard designed as an alternative to traditional QR codes.

Unlike QR codes, which use a square matrix of black and white modules, GlyphCode uses:

- Radial (circular) data organization
- Symbol-based encoding
- Multi-layer error recovery
- Decorative visual structures
- Human-friendly aesthetic patterns

The primary goals are:

- Hidden digital experiences
- Apparel and merchandise integration
- Brand storytelling
- Artistic machine-readable codes
- Future patentable scanning technology

---

# Design Principles

GlyphCode is built on three core principles:

1. Beautiful enough to wear
2. Robust enough to scan
3. Unique enough to become a new standard

---

# Visual Structure

## Architecture

```text
                 ◉
         ○ ○ ○ ○ ○ ○
      ○ ○ ○ ○ ○ ○ ○ ○ ○
   △ □ ○ ◇ △ □ ○ ◇ △ □ ○
◇ △ □ ○ ◇ △ □ ○ ◇ △ □ ○ ◇
   ○ ○ ○ ○ ○ ○ ○ ○ ○
      ○ ○ ○ ○ ○ ○
```

---

## Layer Structure

```text
Layer 0 : Core Marker
Layer 1 : Orientation Ring
Layer 2 : Metadata Ring
Layer 3 : Data Ring A
Layer 4 : Data Ring B
Layer 5 : Error Recovery Ring
Layer 6 : Integrity Ring
```

---

## Core Marker

Purpose:

- Locate center
- Assist alignment
- Verify code authenticity

Example:

```text
◉
```

A high-contrast circle always exists in the center.

---

## Orientation Ring

Purpose:

- Determine rotation
- Determine scale
- Determine reading direction

Structure:

```text
N = Large Dot
E = Medium Dot
S = Small Dot
W = Triangle
```

Example:

```text
        ●

   ▲    ◉    ◐

        •
```

Every scanner identifies these markers before decoding.

---

## Metadata Ring

Contains:

```text
Version Number
Encoding Mode
Language Information
Error Correction Level
Payload Size
```

Example:

```text
Version: 1
Mode: UTF-8
ECC: Level 3
```

---

# Encoding System

## Symbol Encoding

Instead of binary squares, GlyphCode uses symbols.

### Symbol Set

```text
○ = 00
△ = 01
□ = 10
◇ = 11
```

Every symbol stores 2 bits.

---

## Example

Message:

```text
A
```

ASCII:

```text
65
```

Binary:

```text
01000001
```

Grouped:

```text
01 00 00 01
```

Converted:

```text
△ ○ ○ △
```

Stored in the radial data ring.

---

## Extended Symbol Set (Future Version)

```text
○
△
□
◇
⬟
⬢
✦
✧
```

Stores:

```text
3 bits
4 bits
or more per symbol
```

Increasing storage density.

---

# Data Placement Logic

Data is stored clockwise.

```text
Start Marker
      ↓

[Ring 1]

A B C D E F

[Ring 2]

G H I J K L
```

The scanner always reads:

```text
Center Outwards
Clockwise
```

---

# New Error Correction System

## Name

Radial Redundancy Recovery (RRR)

---

## Problem With Traditional Methods

Traditional QR recovery works primarily on linear blocks.

GlyphCode operates in circular geometry.

Therefore recovery must also be radial.

---

# Three-Level Error Protection

## Level 1

### Sector Mirroring

Every sector appears twice.

Example:

```text
Sector 1
Sector 12

Contain same data
```

Damage on one side can be recovered from the opposite side.

---

## Level 2

### Ring Redundancy

Data is duplicated in neighboring rings.

Example:

```text
Ring 3

A B C D E

Ring 4

A B C D E
```

If one ring becomes unreadable:

```text
Fallback → Adjacent Ring
```

---

## Level 3

### Recovery Ring

Entire ring dedicated to repair information.

Example:

```text
Data Ring A
Data Ring B

↓

Generate

Recovery Ring
```

Used to reconstruct lost sectors.

---

# Integrity Ring

Purpose:

- Tamper detection
- Authenticity verification
- Error validation

Generated using:

```text
SHA-256 Payload Hash
```

Partial hash stored in outer ring.

Scanner verifies:

```text
Decoded Data == Stored Integrity
```

---

# Damage Recovery Example

Original

```text
Ring 3

A B C D E F G H
```

Damaged

```text
A B ? D E ? G H
```

Recovery Process

```text
Step 1
Check mirrored sectors

Step 2
Check adjacent ring copy

Step 3
Apply Recovery Ring

Step 4
Reconstruct missing symbols
```

Recovered:

```text
A B C D E F G H
```

---

# Scanning Algorithm

## Phase 1

Center Detection

Detect:

```text
◉
```

---

## Phase 2

Orientation Detection

Find:

```text
North Marker
East Marker
South Marker
West Marker
```

Determine:

```text
Rotation
Scale
Perspective
```

---

## Phase 3

Radial Mapping

Convert image into:

```text
Polar Coordinates
```

Instead of:

```text
Cartesian Grid
```

---

## Phase 4

Symbol Extraction

Read:

```text
○
△
□
◇
```

Convert into:

```text
Bits
```

---

## Phase 5

Error Recovery

Apply:

```text
Sector Mirroring
+
Ring Redundancy
+
Recovery Ring Logic
```

---

## Phase 6

Payload Reconstruction

Convert:

```text
Bits
```

to:

```text
Text
URL
JSON
Profile Data
Digital Content
```

---

# Advantages Over QR

## Visual Appeal

QR:

```text
Technical
```

GlyphCode:

```text
Decorative
```

Suitable for:

- T-shirts
- Mugs
- Posters
- Jewelry
- Artwork

---

## Multi-Layer Recovery

QR:

```text
Single ECC Strategy
```

GlyphCode:

```text
Sector Recovery
Ring Recovery
Payload Recovery
```

---

## Brand Customization

Organizations may customize:

```text
Shapes
Colors
Themes
```

Without changing decoding logic.

---

## Hidden Storytelling

A GlyphCode can:

- Store a personal message
- Link to a video
- Reveal ownership
- Unlock digital rewards
- Preserve memories

---

# Future Roadmap

## GlyphCode v2

- AI-assisted reconstruction
- Color encoding
- 3D scanning support
- Animated GlyphCodes
- AR integration

---

# Conclusion

GlyphCode is a radial, symbol-based visual data encoding system that combines:

- New Visual Structure
- New Symbol Encoding Method
- New Radial Error Recovery Model
- Artistic Machine Readability

It is designed to serve as a foundation for a future generation of wearable and decorative machine-readable codes.