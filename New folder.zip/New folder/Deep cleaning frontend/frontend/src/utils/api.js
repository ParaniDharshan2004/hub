const API_BASE = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

export async function api(path, options = {}) {
  const token = localStorage.getItem("token");
  const response = await fetch(`${API_BASE}${path}`, {
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      ...options.headers,
    },
    ...options,
  });
  if (response.status === 204) return null;
  const body = await response.json().catch(() => ({}));
  if (!response.ok || body.success === false) {
    throw new Error(body.message || "Request failed");
  }
  return body.data ?? body;
}
export const get = (path) => api(path);
export const post = (path, data) => api(path, { method: "POST", body: JSON.stringify(data) });
export const patch = (path, data) => api(path, { method: "PATCH", body: JSON.stringify(data) });
export const put = (path, data) => api(path, { method: "PUT", body: JSON.stringify(data) });
export const del = (path) => api(path, { method: "DELETE" });
