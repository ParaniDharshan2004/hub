import dayjs from 'dayjs';

export function fmtDateHuman(value) {
  return value ? dayjs(value).format('DD MMM YYYY') : '—';
}

export function fmtMoney(value) {
  return Number(value || 0).toLocaleString('en-IN', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function fmtTime12(value) {
  return value ? dayjs(value).format('hh:mm A') : '—';
}

export function formatCustomerAddress(customer) {
  return [customer?.address, customer?.area, customer?.city, customer?.pincode].filter(Boolean).join(', ') || '—';
}
