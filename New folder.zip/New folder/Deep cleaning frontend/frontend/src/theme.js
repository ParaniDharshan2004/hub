import { createTheme, alpha } from '@mui/material/styles';

/**
 * Custom color palette for Bathroom Operations Console.
 * Deep Teal (#0F5C57) provides a professional, clean identity.
 * Amber (#D98E04) highlights financial and warning items.
 */
const teal = {
  50: '#EAF3F1',
  100: '#CFE6E1',
  200: '#9FCDC3',
  300: '#6BB1A4',
  400: '#3E9585',
  500: '#1F7A6C',
  600: '#166357',
  700: '#0F5C57',
  800: '#0B4642',
  900: '#08302D',
};

const amber = {
  50: '#FCF3E3',
  100: '#F9E5C5',
  300: '#E8B85B',
  500: '#D98E04',
  700: '#A96C02',
};

const theme = createTheme({
  palette: {
    mode: 'light',
    primary: {
      main: teal[700],
      light: teal[500],
      dark: teal[900],
      contrastText: '#FFFFFF',
    },
    secondary: {
      main: amber[500],
      light: amber[300],
      dark: amber[700],
      contrastText: '#1A1A1A',
    },
    success: {
      main: '#1F8A55',
      light: '#E8F5EE',
      dark: '#145C38',
    },
    warning: {
      main: amber[500],
      light: amber[50],
      dark: amber[700],
    },
    error: {
      main: '#D32F2F',
      light: '#FDECEA',
      dark: '#9A0007',
    },
    info: {
      main: '#0288D1',
      light: '#E1F5FE',
      dark: '#01579B',
    },
    background: {
      default: '#F8FAF9',
      paper: '#FFFFFF',
    },
    text: {
      primary: '#112220',
      secondary: '#4A605C',
    },
    divider: '#E2E8E6',
    teal,
    amber,
  },
  shape: {
    borderRadius: 10,
  },
  shadows: [
    'none',
    '0px 1px 3px rgba(15, 92, 87, 0.05)',
    '0px 2px 6px rgba(15, 92, 87, 0.08)',
    '0px 4px 12px rgba(15, 92, 87, 0.10)',
    '0px 8px 24px rgba(15, 92, 87, 0.12)',
    ...Array(20).fill('0px 8px 24px rgba(15, 92, 87, 0.12)'),
  ],
  typography: {
    fontFamily: '"Inter", "Helvetica Neue", Arial, sans-serif',
    fontMonoFamily: '"IBM Plex Mono", "Roboto Mono", monospace',
    h1: { fontSize: '1.85rem', fontWeight: 700, letterSpacing: '-0.02em', color: '#112220' },
    h2: { fontSize: '1.45rem', fontWeight: 700, letterSpacing: '-0.01em', color: '#112220' },
    h3: { fontSize: '1.2rem', fontWeight: 600, color: '#112220' },
    h4: { fontSize: '1.05rem', fontWeight: 600, color: '#112220' },
    subtitle1: { fontSize: '0.95rem', fontWeight: 600 },
    subtitle2: { fontSize: '0.85rem', fontWeight: 600, color: '#4A605C' },
    body1: { fontSize: '0.925rem', lineHeight: 1.5 },
    body2: { fontSize: '0.85rem', lineHeight: 1.45 },
    button: { textTransform: 'none', fontWeight: 600, letterSpacing: '0.01em' },
  },
  components: {
    MuiButton: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          paddingInline: 18,
          paddingBlock: 8,
          boxShadow: 'none',
          transition: 'all 0.2s ease-in-out',
          '&:hover': {
            boxShadow: '0 4px 12px rgba(15, 92, 87, 0.15)',
            transform: 'translateY(-1px)',
          },
        },
        containedPrimary: {
          background: `linear-gradient(135deg, ${teal[700]} 0%, ${teal[800]} 100%)`,
        },
        outlinedPrimary: {
          borderColor: teal[300],
          '&:hover': {
            backgroundColor: teal[50],
            borderColor: teal[600],
          },
        },
      },
      defaultProps: { disableElevation: true },
    },
    MuiPaper: {
      styleOverrides: {
        root: {
          backgroundImage: 'none',
          transition: 'box-shadow 0.2s ease-in-out, border-color 0.2s ease-in-out',
        },
        outlined: {
          borderColor: '#E2E8E6',
          boxShadow: '0px 1px 4px rgba(15, 92, 87, 0.04)',
        },
      },
    },
    MuiAppBar: {
      styleOverrides: {
        root: {
          backgroundColor: 'rgba(255, 255, 255, 0.95)',
          backdropFilter: 'blur(8px)',
          color: '#112220',
          borderBottom: '1px solid #E2E8E6',
        },
      },
      defaultProps: { elevation: 0 },
    },
    MuiDrawer: {
      styleOverrides: {
        paper: {
          backgroundColor: teal[900],
          color: '#EAF3F1',
          borderRight: 'none',
        },
      },
    },
    MuiChip: {
      styleOverrides: {
        root: {
          fontWeight: 600,
          borderRadius: 6,
          fontSize: '0.75rem',
        },
      },
    },
    MuiTableCell: {
      styleOverrides: {
        root: {
          borderColor: '#E2E8E6',
          paddingTop: 12,
          paddingBottom: 12,
        },
        head: {
          fontWeight: 600,
          backgroundColor: '#F3F7F6',
          color: '#4A605C',
          fontSize: '0.8rem',
          textTransform: 'uppercase',
          letterSpacing: '0.04em',
        },
      },
    },
    MuiOutlinedInput: {
      styleOverrides: {
        root: {
          borderRadius: 8,
          backgroundColor: '#FFFFFF',
          '& fieldset': {
            borderColor: '#D4DFDC',
          },
          '&:hover fieldset': {
            borderColor: teal[400],
          },
          '&.Mui-focused fieldset': {
            borderColor: teal[600],
            borderWidth: 1.5,
          },
        },
      },
    },
    MuiCard: {
      styleOverrides: {
        root: {
          borderRadius: 12,
          border: '1px solid #E2E8E6',
          boxShadow: '0px 2px 8px rgba(15, 92, 87, 0.04)',
        },
      },
    },
    MuiDataGrid: {
      styleOverrides: {
        root: {
          border: 'none',
          '& .MuiDataGrid-cell': {
            display: 'flex',
            alignItems: 'center',
            borderColor: '#E2E8E6',
            paddingLeft: '16px',
            paddingRight: '16px',
          },
          '& .MuiDataGrid-columnHeader': {
            backgroundColor: '#F3F7F6',
            color: '#4A605C',
            fontWeight: 600,
            fontSize: '0.8rem',
            textTransform: 'uppercase',
            letterSpacing: '0.04em',
            paddingLeft: '16px',
            paddingRight: '16px',
          },
          '& .MuiDataGrid-columnHeaderTitleContainer': {
            display: 'flex',
            alignItems: 'center',
          },
          '& .MuiDataGrid-row:hover': {
            backgroundColor: '#F3F7F6',
          },
        },
      },
    },
  },
});

export default theme;

