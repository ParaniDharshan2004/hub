import { useEffect, useState } from "react";
import {
  Box,
  Stack,
  Typography,
  Chip,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
} from "@mui/material";
import { AccessTime as AccessTimeIcon } from "@mui/icons-material";
import StatusChip from "../common-components/StatusChip.jsx";
import {
  timeToMin,
  fmtDateHuman,
  fmtTime12,
  minToTime,
  formatCustomerAddress,
} from "../../utils/scheduling.js";

const ROWS_PER_PAGE_OPTIONS = [5, 10, 25];

export default function ScheduleTable({
  jobs,
  customerById,
  durationByBathrooms,
  onScheduleSelect,
}) {
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);

  useEffect(() => {
    setPage(0);
  }, [jobs]);

  const visibleJobs = jobs.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage,
  );

  return (
    <>
      <TableContainer
        sx={{
          overflowX: "hidden",
          border: 1,
          borderColor: "divider",
          borderRadius: 0.5,
          bgcolor: "background.paper",
          "&::-webkit-scrollbar": { height: 8 },
          "&::-webkit-scrollbar-thumb": {
            bgcolor: "divider",
            borderRadius: 4,
          },
        }}
      >
        <Table
          size="small"
          sx={{
            width: "100%",
            tableLayout: "fixed",
            borderCollapse: "separate",
            borderSpacing: 0,
            "& .MuiTableCell-root": {
              borderColor: "divider",
            },
          }}
        >
          <TableHead>
            <TableRow
              sx={{
                bgcolor: (theme) =>
                  theme.palette.mode === "dark" ? "action.hover" : "#F7F5F0",
                "& .MuiTableCell-root": {
                  fontSize: 12,
                  fontWeight: 700,
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                  whiteSpace: "nowrap",
                  py: 1.5,
                },
              }}
            >
              <TableCell sx={{ width: { xs: "31%", md: "17%" } }}>
                Date &amp; time
              </TableCell>
              <TableCell sx={{ width: { xs: "39%", md: "16%" } }}>
                Customer
              </TableCell>
              <TableCell sx={{ display: { xs: "none", md: "table-cell" }, width: "22%" }}>
                Address
              </TableCell>
              {/* <TableCell sx={{ display: { xs: "none", md: "table-cell" }, width: "13%" }}>
                Area
              </TableCell> */}
              <TableCell sx={{ display: { xs: "none", md: "table-cell" }, width: "14%" }}>
                Phone
              </TableCell>
              <TableCell align="right" sx={{ width: { xs: "30%", md: "18%" } }}>
                Booking
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
          {visibleJobs.map((booking) => {
            const customer = customerById[booking.customerId];
            const duration = durationByBathrooms[booking.bathroomCount] || 60;
            const address = formatCustomerAddress(customer);
            return (
              <TableRow
                key={booking.id}
                hover
                tabIndex={0}
                role="button"
                onClick={() => onScheduleSelect(booking)}
                onKeyDown={(event) => {
                  if (event.key === "Enter" || event.key === " ") {
                    event.preventDefault();
                    onScheduleSelect(booking);
                  }
                }}
                sx={{
                  cursor: "pointer",
                  transition: "background-color 160ms ease",
                  "&:nth-of-type(even)": {
                    bgcolor: "action.selected",
                  },
                  "&:hover": {
                    bgcolor: "rgba(226, 109, 79, 0.08)",
                  },
                  "&:focus-visible": {
                    outline: "2px solid",
                    outlineColor: "primary.main",
                    outlineOffset: -2,
                  },
                  "& .MuiTableCell-root": {
                    py: 1.75,
                    verticalAlign: "middle",
                  },
                }}
              >
                <TableCell sx={{ verticalAlign: "top" }}>
                  <Stack direction="row" spacing={0.75} alignItems="center">
                    
                    <Box>
                      <Typography variant="body2" fontWeight={700} sx={{ lineHeight: 1.25 }}>
                        {fmtDateHuman(booking.date)}
                      </Typography>

                      <Typography variant="caption" color="text.secondary" sx={{ lineHeight: 1.25 }}>
                        {fmtTime12(booking.startTime)} –{" "}
                        {fmtTime12(
                          minToTime(timeToMin(booking.startTime) + duration),
                        )}
                      </Typography>
                    </Box>
                  </Stack>
                </TableCell>
                
                <TableCell>
                  <Typography variant="body2" fontWeight={700} sx={{ overflowWrap: "anywhere" }}>
                    {customer?.name || "Unknown customer"}
                  </Typography>
                  <Box sx={{ display: { xs: "block", md: "none" }, mt: 0.5 }}>
                    <Typography variant="caption" color="text.secondary" sx={{ display: "block", overflowWrap: "anywhere" }}>
                      {customer?.phone || "Phone not provided"}
                    </Typography>
                    <Typography variant="caption" color="text.secondary" sx={{ display: "block", overflowWrap: "anywhere" }}>
                      {address || "Address not provided"}
                    </Typography>
                  </Box>
                </TableCell>

                <TableCell sx={{ display: { xs: "none", md: "table-cell" } }}>
                  <Typography
                    variant="body2"
                    color={address ? "text.primary" : "text.secondary"}
                    sx={{ maxWidth: 240, whiteSpace: "normal" }}
                  >
                    {address || "Address not provided"}
                  </Typography>
                </TableCell>

                {/* <TableCell sx={{ display: { xs: "none", md: "table-cell" } }}>
                  <Typography variant="body2" color="text.secondary" noWrap>
                    {customer?.area || "Area not provided"}
                  </Typography>
                </TableCell> */}

                <TableCell sx={{ display: { xs: "none", md: "table-cell" } }}>
                  <Typography variant="body2" color="text.secondary">
                    {customer?.phone || "Phone not provided"}
                  </Typography>
                </TableCell>

                <TableCell align="right" sx={{ verticalAlign: "top" }}>
                  <Stack spacing={0.5} alignItems="flex-end">
                    <Chip
                      size="small"
                      label={`${booking.bathroomCount} Service${booking.bathroomCount > 1 ? "s" : ""}`}
                      sx={{
                        maxWidth: "100%",
                        height: "auto",
                        bgcolor: "rgba(45, 122, 105, 0.1)",
                        color: "secondary.main",
                        border: 1,
                        borderColor: "rgba(45, 122, 105, 0.25)",
                        "& .MuiChip-label": {
                          whiteSpace: "normal",
                          textAlign: "right",
                          px: 0.75,
                          py: 0.25,
                        },
                      }}
                    />

                    <StatusChip status={booking.status} />
                  </Stack>
                </TableCell>
              </TableRow>
            );
          })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        component="div"
        count={jobs.length}
        page={page}
        onPageChange={(_, nextPage) => setPage(nextPage)}
        onRowsPerPageChange={(event) => {
          setRowsPerPage(Number(event.target.value));
          setPage(0);
        }}
        rowsPerPage={rowsPerPage}
        rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
        sx={{
          ".MuiTablePagination-toolbar": {
            minHeight: 52,
            px: { xs: 0, sm: 1 },
          },
          ".MuiTablePagination-selectLabel, .MuiTablePagination-displayedRows": {
            color: "text.secondary",
            fontSize: 12,
          },
        }}
      />
    </>
  );
}
