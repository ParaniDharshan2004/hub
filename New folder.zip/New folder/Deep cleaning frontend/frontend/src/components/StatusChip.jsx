import Chip from '@mui/material/Chip';
import Box from '@mui/material/Box';

/**
 * Status mapping table defining theme colors and text labels for operational entities.
 * Ensures consistent badge rendering across Customers, Bookings, Subscriptions, and Visits.
 */
const STATUS_MAP = {
  Active: { color: 'success', label: 'Active', dotColor: '#1F8A55', bg: '#E8F5EE' },
  Inactive: { color: 'default', label: 'Inactive', dotColor: '#70807D', bg: '#F0F4F3' },
  Draft: { color: 'warning', label: 'Draft', dotColor: '#D98E04', bg: '#FCF3E3' },
  Confirmed: { color: 'success', label: 'Confirmed', dotColor: '#1F8A55', bg: '#E8F5EE' },
  Cancelled: { color: 'error', label: 'Cancelled', dotColor: '#D32F2F', bg: '#FDECEA' },
  Scheduled: { color: 'info', label: 'Scheduled', dotColor: '#0288D1', bg: '#E1F5FE' },
  Completed: { color: 'success', label: 'Completed', dotColor: '#1F8A55', bg: '#E8F5EE' },
  Rescheduled: { color: 'warning', label: 'Rescheduled', dotColor: '#D98E04', bg: '#FCF3E3' },
  Expired: { color: 'default', label: 'Expired', dotColor: '#70807D', bg: '#F0F4F3' },
  Recorded: { color: 'success', label: 'Recorded', dotColor: '#1F8A55', bg: '#E8F5EE' },
  Reversed: { color: 'error', label: 'Reversed', dotColor: '#D32F2F', bg: '#FDECEA' },
  'On Track': { color: 'success', label: 'On Track', dotColor: '#1F8A55', bg: '#E8F5EE' },
  'Renewal Due Soon': { color: 'warning', label: 'Renewal Due Soon', dotColor: '#D98E04', bg: '#FCF3E3' },
  'Renewal Overdue': { color: 'error', label: 'Renewal Overdue', dotColor: '#D32F2F', bg: '#FDECEA' },
  'No Period': { color: 'default', label: 'No Period', dotColor: '#70807D', bg: '#F0F4F3' },
};

/**
 * StatusChip Component
 * Render status badges with a colorful indicator dot for quick visual identification.
 * 
 * @param {Object} props
 * @param {string} props.status - Status key name (e.g. "Active", "Scheduled", "Completed")
 * @param {string} [props.size='small'] - Chip size ("small" | "medium")
 */
export default function StatusChip({ status, size = 'small' }) {
  const meta = STATUS_MAP[status] || { color: 'default', label: status || 'Unknown', dotColor: '#70807D', bg: '#F0F4F3' };

  return (
    <Chip
      size={size}
      label={meta.label}
      icon={
        <Box
          sx={{
            width: 7,
            height: 7,
            borderRadius: '50%',
            backgroundColor: meta.dotColor,
            ml: 1,
            mr: -0.5,
          }}
        />
      }
      sx={{
        backgroundColor: meta.bg,
        color: meta.dotColor,
        fontWeight: 600,
        fontSize: '0.75rem',
        border: '1px solid',
        borderColor: `${meta.dotColor}33`,
        height: size === 'small' ? 24 : 28,
        '& .MuiChip-label': {
          px: 1,
        },
      }}
    />
  );
}

