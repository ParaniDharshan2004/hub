import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import dayjs from 'dayjs';

import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogActions from '@mui/material/DialogActions';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import Button from '@mui/material/Button';
import CircularProgress from '@mui/material/CircularProgress';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';

import { renewSubscription } from '../../api/subscriptions';
import { plans, frequencies, paymentModes } from '../../api/masters';
import { useSnackbar } from '../common-components/SnackbarProvider';
import BillSummary from '../common-components/BillSummary';
import { quotePricing } from '../../api/bookings';

const schema = z.object({
  planId: z.string().min(1, 'Select a plan'),
  frequencyId: z.string().min(1, 'Select a frequency'),
  startDate: z.any().refine((v) => !!v, 'Select a start date'),
  paymentModeId: z.string().min(1, 'Select a payment mode'),
});

export default function RenewSubscriptionDialog({ open, onClose, subscription, onRenewed }) {
  const snackbar = useSnackbar();
  const queryClient = useQueryClient();
  const suggestedStart = subscription?.currentPeriod
    ? dayjs(subscription.currentPeriod.endDate).add(1, 'day')
    : dayjs().add(1, 'day');

  const {
    control,
    handleSubmit,
    watch,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(schema),
    defaultValues: {
      planId: subscription?.currentPeriod?.planId || '',
      frequencyId: subscription?.currentPeriod?.frequencyId || '',
      startDate: suggestedStart,
      paymentModeId: '',
    },
  });

  const values = watch();
  const bathrooms = subscription?.periods?.[0]?.booking?.bathrooms || 1;
  const quote = quotePricing({ planId: values.planId, frequencyId: values.frequencyId, bathrooms, discount: 0 });

  const mutation = useMutation({
    mutationFn: (payload) =>
      renewSubscription(subscription.subscriptionNumber, {
        ...payload,
        startDate: payload.startDate.format('YYYY-MM-DD'),
      }),
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['subscription', subscription.subscriptionNumber] });
      queryClient.invalidateQueries({ queryKey: ['subscriptions'] });
      queryClient.invalidateQueries({ queryKey: ['customer360'] });
      snackbar.success(`Subscription ${subscription.subscriptionNumber} renewed successfully.`);
      snackbar.success(`Invoice ${result.invoice.invoiceNumber} is ready.`);
      onRenewed?.(result);
    },
    onError: (err) => snackbar.error(err.message),
  });

  if (!subscription) return null;

  return (
    <Dialog open={open} onClose={mutation.isPending ? undefined : onClose} maxWidth="sm" fullWidth>
      <DialogTitle>Renew Subscription</DialogTitle>
      <DialogContent>
        <DialogContentText sx={{ mb: 2 }}>
          This creates a new subscription period under {subscription.subscriptionNumber}. The previous period, its visits,
          and all historical bookings/invoices stay exactly as they are.
        </DialogContentText>
        <Stack spacing={2}>
          <Controller
            name="planId"
            control={control}
            render={({ field }) => (
              <TextField select label="Subscription Plan" required fullWidth {...field} error={!!errors.planId} helperText={errors.planId?.message}>
                {plans.map((p) => (
                  <MenuItem key={p.id} value={p.id}>
                    {p.name}
                  </MenuItem>
                ))}
              </TextField>
            )}
          />
          <Controller
            name="frequencyId"
            control={control}
            render={({ field }) => (
              <TextField select label="Cleaning Frequency" required fullWidth {...field} error={!!errors.frequencyId} helperText={errors.frequencyId?.message}>
                {frequencies.map((f) => (
                  <MenuItem key={f.id} value={f.id}>
                    {f.name}
                  </MenuItem>
                ))}
              </TextField>
            )}
          />
          <Controller
            name="startDate"
            control={control}
            render={({ field }) => (
              <DatePicker
                label="New Period Start Date"
                value={field.value}
                onChange={field.onChange}
                minDate={dayjs()}
                slotProps={{ textField: { fullWidth: true, error: !!errors.startDate, helperText: errors.startDate?.message } }}
              />
            )}
          />
          <Controller
            name="paymentModeId"
            control={control}
            render={({ field }) => (
              <TextField select label="Payment Mode Received" required fullWidth {...field} error={!!errors.paymentModeId} helperText={errors.paymentModeId?.message}>
                {paymentModes.map((m) => (
                  <MenuItem key={m.id} value={m.id}>
                    {m.name}
                  </MenuItem>
                ))}
              </TextField>
            )}
          />
          <BillSummary quote={quote} />
        </Stack>
      </DialogContent>
      <DialogActions sx={{ px: 3, pb: 2 }}>
        <Button onClick={onClose} disabled={mutation.isPending}>
          Cancel
        </Button>
        <Button
          variant="contained"
          onClick={handleSubmit((v) => mutation.mutate(v))}
          disabled={mutation.isPending}
          startIcon={mutation.isPending ? <CircularProgress size={16} color="inherit" /> : null}
        >
          Renew Subscription
        </Button>
      </DialogActions>
    </Dialog>
  );
}
