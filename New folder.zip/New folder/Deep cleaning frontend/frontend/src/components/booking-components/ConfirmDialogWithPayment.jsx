import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import ConfirmDialog from '../common-components/ConfirmDialog';
import { paymentModes } from '../../api/masters';

/**
 * Modal dialog for selecting payment mode during booking confirmation.
 */
export function ConfirmDialogWithPayment({ open, onClose, paymentModeId, setPaymentModeId, onConfirm, bookingNumber }) {
  return (
    <ConfirmDialog
      open={open}
      title="Confirm Booking"
      description="Record the payment already collected and confirm this booking. This generates the invoice, activates the subscription, and schedules all service visits."
      entityLabel={bookingNumber}
      confirmLabel="Confirm Booking"
      onClose={onClose}
      onConfirm={async () => {
        if (!paymentModeId) return;
        await onConfirm();
      }}
      confirmDisabled={!paymentModeId}
    >
      <TextField
        select
        fullWidth
        label="Payment Mode Received"
        required
        value={paymentModeId}
        onChange={(e) => setPaymentModeId(e.target.value)}
        sx={{ mt: 2 }}
      >
        {paymentModes.map((m) => (
          <MenuItem key={m.id} value={m.id}>
            {m.name}
          </MenuItem>
        ))}
      </TextField>
    </ConfirmDialog>
  );
}

export default ConfirmDialogWithPayment;
