import { useEffect, useState } from 'react';
import { Outlet, useLocation, useNavigate } from 'react-router-dom';
import Box from '@mui/material/Box';
import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import Drawer from '@mui/material/Drawer';
import List from '@mui/material/List';
import Stack from '@mui/material/Stack';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Typography from '@mui/material/Typography';
import IconButton from '@mui/material/IconButton';
import InputBase from '@mui/material/InputBase';
import Avatar from '@mui/material/Avatar';
import Tooltip from '@mui/material/Tooltip';
import Divider from '@mui/material/Divider';
import Collapse from '@mui/material/Collapse';
import Menu from '@mui/material/Menu';
import MenuItem from '@mui/material/MenuItem';
import Chip from '@mui/material/Chip';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme, alpha } from '@mui/material/styles';

import MenuIcon from '@mui/icons-material/Menu';
import SearchIcon from '@mui/icons-material/Search';
import DashboardOutlinedIcon from '@mui/icons-material/DashboardOutlined';
import PeopleAltOutlinedIcon from '@mui/icons-material/PeopleAltOutlined';
import EventNoteOutlinedIcon from '@mui/icons-material/EventNoteOutlined';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';
import AutorenewOutlinedIcon from '@mui/icons-material/AutorenewOutlined';
import CleaningServicesOutlinedIcon from '@mui/icons-material/CleaningServicesOutlined';
import PaymentsOutlinedIcon from '@mui/icons-material/PaymentsOutlined';
import ReceiptLongOutlinedIcon from '@mui/icons-material/ReceiptLongOutlined';
import BarChartOutlinedIcon from '@mui/icons-material/BarChartOutlined';
import jollyLogo from '../assets/logo/Jollydark.png';
import TuneOutlinedIcon from '@mui/icons-material/TuneOutlined';
import AdminPanelSettingsOutlinedIcon from '@mui/icons-material/AdminPanelSettingsOutlined';
import SettingsOutlinedIcon from '@mui/icons-material/SettingsOutlined';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import NotificationsOutlinedIcon from '@mui/icons-material/NotificationsOutlined';
import LogoutOutlinedIcon from '@mui/icons-material/LogoutOutlined';
import AccountCircleOutlinedIcon from '@mui/icons-material/AccountCircleOutlined';

import { initials } from '../utils/format';

/** Width of the left navigation drawer in pixels */
const DRAWER_WIDTH = 260;

/**
 * Grouped navigation structure organizing options into logical operational sections.
 */
const NAV_SECTIONS = [
  {
    title: 'MAIN',
    items: [
      { label: 'Dashboard', to: '/dashboard', icon: DashboardOutlinedIcon },
      { label: 'Customers', to: '/customers', icon: PeopleAltOutlinedIcon },
    ],
  },
  {
    title: 'OPERATIONS',
    items: [
      { label: 'Bookings', to: '/bookings', icon: EventNoteOutlinedIcon },
      { label: 'Subscriptions', to: '/subscriptions', icon: AutorenewOutlinedIcon },
      { label: 'Visits', to: '/visits', icon: CleaningServicesOutlinedIcon },
      { label: 'Visit Calendar', to: '/visits/calendar', icon: CalendarMonthOutlinedIcon },
    ],
  },
  {
    title: 'FINANCE & REPORTS',
    items: [
      { label: 'Payments', to: '/payments', icon: PaymentsOutlinedIcon },
      { label: 'Invoices', to: '/invoices', icon: ReceiptLongOutlinedIcon },
      { label: 'Reports', to: '/reports', icon: BarChartOutlinedIcon },
    ],
  },
  {
    title: 'CONFIGURATION',
    items: [
      {
        label: 'Masters',
        icon: TuneOutlinedIcon,
        children: [
          'Service Offerings',
          'Bathroom Options',
          'Frequencies',
          'Plans',
          'Plan Prices',
          'Taxes',
          'Areas',
          'Service Slots',
          'Payment Modes',
          'Receiver Accounts',
          'Status Configuration',
        ].map((label) => ({ label, to: `/masters/${label.toLowerCase().replace(/\s+/g, '-')}` })),
      },
      {
        label: 'Administration',
        icon: AdminPanelSettingsOutlinedIcon,
        children: [
          { label: 'Users', to: '/admin/users' },
          { label: 'Roles', to: '/admin/roles' },
          { label: 'Permissions', to: '/admin/permissions' },
          { label: 'Audit Logs', to: '/admin/audit-logs' },
          { label: 'Status History', to: '/admin/status-history' },
        ],
      },
      { label: 'Settings', to: '/settings', icon: SettingsOutlinedIcon },
    ],
  },
];

/**
 * NavGroup Component
 * Render collapsible accordion groups for sub-navigation items like Masters and Administration.
 */
function NavGroup({ item, currentPath, onNavigate }) {
  const [openGroup, setOpenGroup] = useState(
    item.children ? item.children.some((c) => currentPath.startsWith(c.to)) : false
  );
  const Icon = item.icon;

  return (
    <>
      <ListItemButton
        onClick={() => setOpenGroup((o) => !o)}
        sx={{
          mx: 1.2,
          mb: 0.5,
          borderRadius: 1,
          color: '#EAF3F1',
          '&:hover': { bgcolor: alpha('#EAF3F1', 0.08) },
        }}
      >
        <ListItemIcon sx={{ color: 'inherit', minWidth: 34, opacity: 0.85 }}>
          <Icon fontSize="small" />
        </ListItemIcon>
        <ListItemText primaryTypographyProps={{ fontSize: '0.875rem', fontWeight: 500 }} primary={item.label} />
        {openGroup ? <ExpandLessIcon fontSize="small" sx={{ opacity: 0.7 }} /> : <ExpandMoreIcon fontSize="small" sx={{ opacity: 0.7 }} />}
      </ListItemButton>

      <Collapse in={openGroup} timeout="auto" unmountOnExit>
        <List component="div" disablePadding>
          {item.children.map((child) => {
            const selected = currentPath === child.to;
            return (
              <ListItemButton
                key={child.to}
                selected={selected}
                onClick={() => onNavigate(child.to)}
                sx={{
                  pl: 5.5,
                  mx: 1.2,
                  mb: 0.25,
                  borderRadius: 1,
                  color: selected ? '#FFFFFF' : alpha('#EAF3F1', 0.75),
                  bgcolor: selected ? alpha('#EAF3F1', 0.15) : 'transparent',
                  '&:hover': { bgcolor: alpha('#EAF3F1', 0.1) },
                }}
              >
                <ListItemText primaryTypographyProps={{ fontSize: '0.825rem', fontWeight: selected ? 600 : 400 }} primary={child.label} />
              </ListItemButton>
            );
          })}
        </List>
      </Collapse>
    </>
  );
}

/**
 * DrawerContent Component
 * Renders logo branding banner, scrollable grouped navigation items, and bottom system version indicator.
 */
function DrawerContent({ currentPath, onNavigate }) {
  return (
    <Box sx={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
      {/* Brand Header */}
      <Toolbar sx={{ gap: 1.5, px: 2.5, minHeight: '64px !important' }}>
        <Box
          component="img"
          src={jollyLogo}
          alt="Jolly Home Needs"
          sx={{ width: 132, height: 52, objectFit: 'contain', objectPosition: 'left center' }}
        />
      </Toolbar>

      <Divider sx={{ borderColor: alpha('#EAF3F1', 0.1) }} />

      {/* Navigation List grouped by operational domain */}
      <List sx={{ flex: 1, py: 1.5, px: 0, overflowY: 'auto' }}>
        {NAV_SECTIONS.map((section) => (
          <Box key={section.title} sx={{ mb: 1.5 }}>
            <Typography
              variant="caption"
              sx={{
                px: 2.5,
                py: 0.5,
                display: 'block',
                fontSize: '0.675rem',
                fontWeight: 700,
                letterSpacing: '0.08em',
                color: alpha('#EAF3F1', 0.45),
              }}
            >
              {section.title}
            </Typography>

            {section.items.map((item) => {
              if (item.children) {
                return <NavGroup key={item.label} item={item} currentPath={currentPath} onNavigate={onNavigate} />;
              }

              const selected = currentPath === item.to || (item.to !== '/' && currentPath.startsWith(item.to + '/'));

              return (
                <ListItemButton
                  key={item.to}
                  selected={selected}
                  onClick={() => onNavigate(item.to)}
                  sx={{
                    mx: 1.2,
                    mb: 0.35,
                    borderRadius: 2,
                    color: selected ? '#FFFFFF' : alpha('#EAF3F1', 0.8),
                    position: 'relative',
                    bgcolor: selected ? alpha('#EAF3F1', 0.16) : 'transparent',
                    boxShadow: selected ? '0 2px 8px rgba(0, 0, 0, 0.15)' : 'none',
                    '&:hover': { bgcolor: alpha('#EAF3F1', 0.1) },
                    '&::before': selected
                      ? {
                          content: '""',
                          position: 'absolute',
                          left: -6,
                          top: 8,
                          bottom: 8,
                          width: 4,
                          borderRadius: 2,
                          bgcolor: '#D98E04',
                        }
                      : {},
                  }}
                >
                  <ListItemIcon sx={{ color: selected ? '#D98E04' : 'inherit', minWidth: 34, opacity: selected ? 1 : 0.85 }}>
                    <item.icon fontSize="small" />
                  </ListItemIcon>
                  <ListItemText
                    primaryTypographyProps={{ fontSize: '0.875rem', fontWeight: selected ? 600 : 400 }}
                    primary={item.label}
                  />
                </ListItemButton>
              );
            })}
          </Box>
        ))}
      </List>

      {/* Footer Version Tag */}
      <Box sx={{ p: 2, borderTop: `1px solid ${alpha('#EAF3F1', 0.1)}` }}>
        <Stack direction="row" alignItems="center" justifyContent="space-between">
          <Typography variant="caption" sx={{ color: alpha('#EAF3F1', 0.5), fontSize: '0.7rem' }}>
            Phase 1 Build v1.2
          </Typography>
          <Chip label="OPERATIONAL" size="small" sx={{ height: 18, fontSize: '0.65rem', bgcolor: alpha('#1F8A55', 0.25), color: '#82E0AA' }} />
        </Stack>
      </Box>
    </Box>
  );
}

/**
 * AppShell Component
 * Main application layout wrapper containing top AppBar and responsive side navigation Drawer.
 */
export default function AppShell() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [mobileOpen, setMobileOpen] = useState(false);
  const [anchorEl, setAnchorEl] = useState(null);
  const [currentUser, setCurrentUser] = useState({ name: 'System User', email: '', role: 'admin' });
  const navigate = useNavigate();
  const location = useLocation();

  useEffect(() => {
    let active = true;

    const loadCurrentUser = async () => {
      try {
        const response = await fetch('/api/me');
        if (!response.ok) {
          throw new Error('Failed to fetch current user');
        }

        const user = await response.json();

        if (!active) return;

        setCurrentUser({
          name: user?.name || 'System User',
          email: user?.email || '',
          role: user?.roleId?.roleName || user?.role?.roleName || 'admin',
        });
      } catch (error) {
        if (!active) return;
        setCurrentUser({ name: 'System User', email: '', role: 'admin' });
      }
    };

    loadCurrentUser();
    return () => {
      active = false;
    };
  }, []);

  /** Navigation routing handler */
  const handleNavigate = (to) => {
    navigate(to);
    if (isMobile) setMobileOpen(false);
  };

  /** Open user profile dropdown menu */
  const handleMenuOpen = (e) => setAnchorEl(e.currentTarget);
  /** Close user profile dropdown menu */
  const handleMenuClose = () => setAnchorEl(null);

  return (
    <Box sx={{ display: 'flex', minHeight: '100vh' }}>
      {/* Top Application Bar */}
      <AppBar
        position="fixed"
        sx={{
          width: { md: `calc(100% - ${DRAWER_WIDTH}px)` },
          ml: { md: `${DRAWER_WIDTH}px` },
          zIndex: theme.zIndex.drawer + 1,
        }}
      >
        <Toolbar sx={{ gap: 1.5, px: { xs: 2, sm: 3 } }}>
          <IconButton edge="start" onClick={() => setMobileOpen(true)} sx={{ display: { md: 'none' } }} aria-label="Open menu">
            <MenuIcon />
          </IconButton>

          {/* Global Search Bar */}
          <Box
            sx={{
              display: 'flex',
              alignItems: 'center',
              gap: 1,
              bgcolor: '#F3F7F6',
              borderRadius: 999,
              px: 2,
              py: 0.65,
              flex: 1,
              maxWidth: 440,
              border: '1px solid #DCE5E3',
              transition: 'all 0.2s ease',
              '&:focus-within': {
                bgcolor: '#FFFFFF',
                borderColor: 'primary.main',
                boxShadow: '0 0 0 3px rgba(15, 92, 87, 0.1)',
              },
            }}
          >
            <SearchIcon fontSize="small" sx={{ color: 'text.secondary' }} />
            <InputBase
              placeholder="Search Customer ID, Booking ID, mobile..."
              sx={{ fontSize: '0.85rem', width: '100%' }}
              inputProps={{ 'aria-label': 'Global search' }}
            />
            <Chip
              label="/"
              size="small"
              sx={{
                height: 18,
                fontSize: '0.65rem',
                fontWeight: 700,
                bgcolor: '#E0E8E6',
                color: 'text.secondary',
                px: 0.5,
              }}
            />
          </Box>

          <Box sx={{ flex: 1 }} />

          {/* Notifications Icon Button */}
          <Tooltip title="Notifications">
            <IconButton size="small" sx={{ bgcolor: '#F3F7F6', border: '1px solid #DCE5E3' }}>
              <NotificationsOutlinedIcon fontSize="small" sx={{ color: 'text.secondary' }} />
            </IconButton>
          </Tooltip>

          {/* User Profile Avatar Button */}
          <Tooltip title="Account menu">
            <IconButton onClick={handleMenuOpen} size="small" sx={{ p: 0.25 }}>
              <Avatar
                sx={{
                  width: 36,
                  height: 36,
                  fontSize: '0.85rem',
                  fontWeight: 700,
                  bgcolor: 'primary.main',
                  color: '#FFFFFF',
                  boxShadow: '0 2px 6px rgba(15, 92, 87, 0.25)',
                }}
              >
                {initials(currentUser.name)}
              </Avatar>
            </IconButton>
          </Tooltip>

          {/* User Profile Dropdown Menu */}
          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)}
            onClose={handleMenuClose}
            transformOrigin={{ horizontal: 'right', vertical: 'top' }}
            anchorOrigin={{ horizontal: 'right', vertical: 'bottom' }}
            PaperProps={{
              sx: {
                mt: 1,
                width: 200,
                borderRadius: 2,
                boxShadow: '0 4px 20px rgba(0,0,0,0.1)',
              },
            }}
          >
            <Box sx={{ px: 2, py: 1.25 }}>
              <Typography variant="subtitle2" sx={{ fontWeight: 700, color: 'text.primary' }}>
                {currentUser.name}
              </Typography>
              <Typography variant="caption" color="text.secondary">
                {currentUser.email || 'No email on file'}
              </Typography>
            </Box>
            <Divider />
            <MenuItem onClick={() => { handleMenuClose(); navigate('/settings'); }} sx={{ fontSize: '0.85rem', gap: 1.5, py: 1 }}>
              <AccountCircleOutlinedIcon fontSize="small" color="action" /> My Profile
            </MenuItem>
            <MenuItem onClick={() => { handleMenuClose(); navigate('/settings'); }} sx={{ fontSize: '0.85rem', gap: 1.5, py: 1 }}>
              <SettingsOutlinedIcon fontSize="small" color="action" /> Settings
            </MenuItem>
            <Divider />
            <MenuItem onClick={handleMenuClose} sx={{ fontSize: '0.85rem', gap: 1.5, py: 1, color: 'error.main' }}>
              <LogoutOutlinedIcon fontSize="small" color="error" /> Logout
            </MenuItem>
          </Menu>
        </Toolbar>
      </AppBar>

      {/* Side Navigation Drawer (Responsive Mobile Temporary & Desktop Permanent) */}
      <Box component="nav" sx={{ width: { md: DRAWER_WIDTH }, flexShrink: { md: 0 } }}>
        <Drawer
          variant="temporary"
          open={mobileOpen}
          onClose={() => setMobileOpen(false)}
          ModalProps={{ keepMounted: true }}
          sx={{ display: { xs: 'block', md: 'none' }, '& .MuiDrawer-paper': { width: DRAWER_WIDTH } }}
        >
          <DrawerContent currentPath={location.pathname} onNavigate={handleNavigate} />
        </Drawer>
        <Drawer
          variant="permanent"
          sx={{ display: { xs: 'none', md: 'block' }, '& .MuiDrawer-paper': { width: DRAWER_WIDTH, boxSizing: 'border-box' } }}
          open
        >
          <DrawerContent currentPath={location.pathname} onNavigate={handleNavigate} />
        </Drawer>
      </Box>

      {/* Main Content Area */}
      <Box
        component="main"
        sx={{
          flexGrow: 1,
          width: { md: `calc(100% - ${DRAWER_WIDTH}px)` },
          bgcolor: 'background.default',
          minHeight: '100vh',
        }}
      >
        <Toolbar />
        <Box sx={{ p: { xs: 2, sm: 3, md: 4 }, maxWidth: 1440, mx: 'auto' }}>
          <Outlet />
        </Box>
      </Box>
    </Box>
  );
}

