import Box from '@mui/material/Box';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Breadcrumbs from '@mui/material/Breadcrumbs';
import NavigateNextIcon from '@mui/icons-material/NavigateNext';
import { Link as RouterLink } from 'react-router-dom';

/**
 * PageHeader Component
 * Provides a standardized header section across all app screens with title, breadcrumbs, status badge, and action buttons.
 *
 * @param {Object} props
 * @param {string} props.title - Main title of the page
 * @param {string} [props.subtitle] - Subtitle or helpful contextual text below title
 * @param {Array<{label: string, to?: string}>} [props.breadcrumbs] - Breadcrumb link items
 * @param {React.ReactNode} [props.statusSlot] - Optional status badge element placed next to title
 * @param {React.ReactNode} [props.actions] - Action buttons rendered on top right
 */
export default function PageHeader({ title, subtitle, breadcrumbs, statusSlot, actions }) {
  return (
    <Box sx={{ mb: 3.5 }} className="page-fade-in">
      {/* Breadcrumb Navigation Trail */}
      {breadcrumbs && breadcrumbs.length > 0 && (
        <Breadcrumbs
          separator={<NavigateNextIcon fontSize="small" sx={{ fontSize: '0.9rem', color: 'text.secondary' }} />}
          sx={{ mb: 1, fontSize: '0.825rem' }}
        >
          {breadcrumbs.map((b, i) =>
            b.to ? (
              <Box
                key={i}
                component={RouterLink}
                to={b.to}
                sx={{
                  color: 'text.secondary',
                  textDecoration: 'none',
                  fontWeight: 500,
                  transition: 'color 0.15s ease',
                  '&:hover': { color: 'primary.main', textDecoration: 'underline' },
                }}
              >
                {b.label}
              </Box>
            ) : (
              <Typography key={i} variant="body2" sx={{ color: 'text.primary', fontWeight: 600, fontSize: '0.825rem' }}>
                {b.label}
              </Typography>
            )
          )}
        </Breadcrumbs>
      )}

      {/* Main Header Title & Right Action Buttons */}
      <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} justifyContent="space-between" alignItems={{ sm: 'center' }}>
        <Stack direction="row" spacing={1.5} alignItems="center" flexWrap="wrap">
          <Typography variant="h1" sx={{ fontSize: { xs: '1.45rem', sm: '1.75rem' }, fontWeight: 700 }}>
            {title}
          </Typography>
          {statusSlot}
        </Stack>

        {actions && (
          <Stack direction="row" spacing={1.25} flexWrap="wrap">
            {actions}
          </Stack>
        )}
      </Stack>

      {/* Subtitle Description */}
      {subtitle && (
        <Typography variant="body2" color="text.secondary" sx={{ mt: 0.75, maxWidth: 800 }}>
          {subtitle}
        </Typography>
      )}
    </Box>
  );
}
