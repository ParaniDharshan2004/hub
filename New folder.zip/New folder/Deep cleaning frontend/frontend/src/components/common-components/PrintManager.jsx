import { useEffect } from "react";
import GlobalStyles from "@mui/material/GlobalStyles";

import InvoicePrintable from "./InvoicePrintable.jsx";
import ServiceAreaPrintable from "./ServiceAreaPrintable.jsx";

export default function PrintManager({
  invoice,
  services,
  onPrintComplete,
}) {
  useEffect(() => {
    if (!invoice && !services) return undefined;

    const originalTitle = document.title;
    document.title = "";
    const printTimer = setTimeout(() => window.print(), 80);

    const handleAfterPrint = () => {
      onPrintComplete?.();
      document.title = originalTitle;
    };

    window.addEventListener("afterprint", handleAfterPrint);
    return () => {
      clearTimeout(printTimer);
      window.removeEventListener("afterprint", handleAfterPrint);
      document.title = originalTitle;
    };
  }, [invoice, services, onPrintComplete]);

  return (
    <>
      <GlobalStyles
        styles={{
          "#invoice-print-area, #service-area-print-area": { display: "none" },
          "@media print": {
            "@page": { size: "A4 landscape", margin: 0 },
            "@page invoice-page": { size: "A4 landscape", margin: 0 },
            "@page service-area-page": { size: "A4 landscape", margin: "12mm" },
            "body *": { visibility: "hidden" },
            "#invoice-print-area, #invoice-print-area *, #service-area-print-area, #service-area-print-area *": {
              visibility: "visible",
            },
            "#invoice-print-area": {
              display: "block",
              position: "absolute",
              top: 0,
              left: 0,
              width: "100vw",
              height: "100vh",
              padding: 0,
              boxSizing: "border-box",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              page: "invoice-page",
            },
            "#service-area-print-area": {
              display: "block",
              position: "absolute",
              top: 0,
              left: 0,
              width: "100vw",
              height: "100vh",
              padding: "12mm",
              boxSizing: "border-box",
              page: "service-area-page",
            },
          },
        }}
      />

      {invoice && (
        <div id="invoice-print-area">
          <InvoicePrintable {...invoice} />
        </div>
      )}
      {services && (
        <div id="service-area-print-area">
          <ServiceAreaPrintable {...services} />
        </div>
      )}
    </>
  );
}
