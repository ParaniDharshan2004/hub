import Box from "@mui/material/Box";
import CircularProgress from "@mui/material/CircularProgress";

export default function FullPageSpinner() {
  return (
    <Box
      sx={{
        minHeight: "100vh",
        display: "grid",
        placeItems: "center",
        bgcolor: "background.default",
      }}
    >
      <CircularProgress />
    </Box>
  );
}
