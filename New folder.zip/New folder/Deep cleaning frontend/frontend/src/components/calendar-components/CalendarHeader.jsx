import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Chip from "@mui/material/Chip";
import CalendarMonthOutlinedIcon from "@mui/icons-material/CalendarMonthOutlined";
import TodayIcon from "@mui/icons-material/Today";
import { fmtDateHuman } from "../../utils/scheduling.js";

export default function CalendarHeader({
  selectedDate,
  onToday,
  totalCount = 0,
  completedCount = 0,
  conflictCount = 0,
}) {
  return (
    <Stack
      direction="row"
      justifyContent="space-between"
      alignItems="center"
      spacing={1.5}
      sx={{ mb: 3 }}
    >
      <Box sx={{ minWidth: 0 }}>
        <Stack direction="row" spacing={1.25} alignItems="center">
          <CalendarMonthOutlinedIcon color="primary" />
          <Typography variant="h5" sx={{ fontWeight: 800, lineHeight: 1.1 }}>
            Service Schedule
          </Typography>
        </Stack>
        <Typography variant="body2" color="text.secondary" sx={{ mt: 0.5 }}>
          {selectedDate
            ? fmtDateHuman(selectedDate)
            : "Manage schedules and service activities."}
        </Typography>
      </Box>

      <Stack
        direction="row"
        spacing={1}
        flexWrap="wrap"
        useFlexGap
        sx={{ width: "auto", flexShrink: 0, pt: 0.5 }}
      >
        <Chip
          size="small"
          label={`${totalCount} Service${totalCount === 1 ? "" : "s"}`}
          sx={{ fontWeight: 700, bgcolor: "action.selected" }}
        />
        {/* {completedCount > 0 && (
          <Chip
            size="small"
            label={`${completedCount} completed`}
            sx={{ fontWeight: 700, bgcolor: "rgba(45, 122, 105, 0.14)", color: "#2D7A69" }}
          />
        )}
        {conflictCount > 0 && (
          <Chip
            size="small"
            label={`${conflictCount} conflict${conflictCount === 1 ? "" : "s"}`}
            sx={{ fontWeight: 700, bgcolor: "rgba(211, 47, 47, 0.12)", color: "#D32F2F" }}
          />
        )} */}

        {/* {onToday && (
          <Button
            size="small"
            variant="outlined"
            startIcon={<TodayIcon fontSize="small" />}
            onClick={onToday}
            sx={{ ml: { xs: 0, sm: 0.5 }, flexShrink: 0 }}
          >
            Today
          </Button>
        )} */}

      </Stack>
    </Stack>
  );
}