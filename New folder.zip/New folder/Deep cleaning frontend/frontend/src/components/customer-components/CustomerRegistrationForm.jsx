import { useEffect, useState } from "react";
import Button from "@mui/material/Button";
import Stack from "@mui/material/Stack";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import PersonAddAlt1Icon from "@mui/icons-material/PersonAddAlt1";

export default function CustomerRegistrationForm({
  onSubmit,
  onDirtyChange,
  initialCustomer = {},
  submitLabel = "Add customer",
  description = "Add the customer details before creating a service order.",
}) {
  const [form, setForm] = useState({
    name: initialCustomer.name || "",
    phone: initialCustomer.phone || "",
    address: initialCustomer.address || "",
    doorNumber: initialCustomer.doorNumber || "",
    blockNumber: initialCustomer.blockNumber || "",
    apartmentNumber: initialCustomer.apartmentNumber || "",
    area: initialCustomer.area || "",
    pincode: initialCustomer.pincode || "",
    city: initialCustomer.city || "",
    landmark: initialCustomer.landmark || "",
  });
  const [errors, setErrors] = useState({});

  useEffect(() => {
    onDirtyChange?.(Object.values(form).some((value) => value.trim()));
  }, [form, onDirtyChange]);

  const update = (field) => (event) => {
    const rawValue = event.target.value;
    const value =
      field === "phone"
        ? rawValue.replace(/\D/g, "").slice(0, 10)
        : field === "pincode"
          ? rawValue.replace(/\D/g, "").slice(0, 6)
          : field === "name"
            ? rawValue.replace(/[^a-zA-Z\s]/g, "")
            : rawValue;
    setForm((current) => ({ ...current, [field]: value }));
    setErrors((current) => ({ ...current, [field]: "" }));
  };

  const validate = () => {
    const nextErrors = {};
    const name = form.name.trim();
    const phone = form.phone.trim();
    const doorNumber = form.doorNumber.trim();
    const address = form.address.trim();
    const pincode = form.pincode.trim();
    const city = form.city.trim();

    if (!name) {
      nextErrors.name = "Customer name is required";
    } else if (name.length < 2) {
      nextErrors.name = "Enter at least 2 characters";
    }
    if (name.length > 80) nextErrors.name = "Name must be 80 characters or less";
    if (!/^\d{10}$/.test(phone)) {
      nextErrors.phone = "Enter a valid 10-digit mobile number";
    }
    if (!doorNumber) nextErrors.doorNumber = "Door number is required";
    if (!address) nextErrors.address = "Address is required";
    if (address.length > 200) nextErrors.address = "Address must be 200 characters or less";
    if (!/^\d{6}$/.test(pincode)) {
      nextErrors.pincode = "Enter a valid 6-digit pincode";
    }
    if (!city) nextErrors.city = "City is required";
    if (city.length > 60) nextErrors.city = "City must be 60 characters or less";
    setErrors(nextErrors);
    return Object.keys(nextErrors).length === 0;
  };

  const submit = async () => {
    if (!validate()) return;
    const normalizedForm = Object.fromEntries(
      Object.entries(form).map(([field, value]) => [field, value.trim()]),
    );
    await onSubmit(normalizedForm);
  };

  return (
    <Stack spacing={2}>
      <Typography variant="body2" color="text.secondary">
        {description}
      </Typography>
      <TextField autoFocus fullWidth size="small" required label="Customer name" value={form.name} onChange={update("name")} inputProps={{ pattern: "[A-Za-z ]*", maxLength: 80 }} error={!!errors.name} helperText={errors.name} />
      <TextField fullWidth size="small" label="Whatsapp/Mobile no" value={form.phone} onChange={update("phone")} required inputProps={{ inputMode: "numeric", maxLength: 10 }} error={!!errors.phone} helperText={errors.phone} />
      <Stack direction={{ xs: "column", sm: "row" }} spacing={1.5}>
        <TextField fullWidth size="small" label="Door no" value={form.doorNumber} onChange={update("doorNumber")} required error={!!errors.doorNumber} helperText={errors.doorNumber} />
        <TextField fullWidth size="small" label="Block/Tower no" value={form.blockNumber} onChange={update("blockNumber")} error={!!errors.blockNumber} helperText={errors.blockNumber} />
        <TextField fullWidth size="small" label="Apartment name" value={form.apartmentNumber} onChange={update("apartmentNumber")} error={!!errors.apartmentNumber} helperText={errors.apartmentNumber} />
      </Stack>
      <Stack direction={{ xs: "column", sm: "row" }} spacing={1.5}>
        <TextField fullWidth size="small" required label="Address" value={form.address} onChange={update("address")} inputProps={{ maxLength: 200 }} error={!!errors.address} helperText={errors.address} sx={{ flex: 2 }} />
        <TextField fullWidth size="small" label="Area" value={form.area} onChange={update("area")} sx={{ flex: 1 }} />
      </Stack>
      <Stack direction={{ xs: "column", sm: "row" }} spacing={1.5}>
        <TextField fullWidth size="small" label="Pincode" value={form.pincode} onChange={update("pincode")} required inputProps={{ inputMode: "numeric", maxLength: 6 }} error={!!errors.pincode} helperText={errors.pincode} />
        <TextField fullWidth size="small" label="City" value={form.city} onChange={update("city")} required inputProps={{ maxLength: 60 }} error={!!errors.city} helperText={errors.city} />
      </Stack>
      <TextField fullWidth size="small" label="Landmark" value={form.landmark} onChange={update("landmark")} />
      <Button fullWidth variant="contained" startIcon={<PersonAddAlt1Icon />} disabled={!form.name.trim()} onClick={submit}>
        {submitLabel}
      </Button>
    </Stack>
  );
}
