import ConfirmDialog from "../common-components/ConfirmDialog.jsx";
import CustomerRegistrationForm from "./CustomerRegistrationForm.jsx";
import { useState, useMemo, useEffect } from "react";
import {
  Box,
  Button,
  ButtonBase,
  Typography,
  TextField,
  InputAdornment,
  Stack,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  TablePagination,
  FormControl,
  Select,
  MenuItem,
  Dialog,
  DialogTitle,
  DialogContent,
  IconButton,
  Divider,
  Tooltip,
} from "@mui/material";
import {
  Search as SearchIcon,
  EditOutlined as EditOutlinedIcon,
  VisibilityOutlined as VisibilityOutlinedIcon,
  Close as CloseIcon,
  PersonOutlineOutlined as PersonOutlineOutlinedIcon,
  PhoneOutlined as PhoneOutlinedIcon,
  LocationOnOutlined as LocationOnOutlinedIcon,
  PersonAddAlt1Outlined as PersonAddAlt1OutlinedIcon,
  DownloadOutlined as DownloadOutlinedIcon,
} from "@mui/icons-material";
import {
  norm,
  fmtDateHuman,
  formatCustomerAddress,
} from "../../utils/scheduling.js";

const ROWS_PER_PAGE_OPTIONS = [5, 10, 25];

function isDateInPeriod(dateString, period) {
  if (!dateString || period === "all") return period === "all";
  const date = new Date(
    String(dateString).includes("T")
      ? dateString
      : `${dateString}T00:00:00`,
  );
  if (Number.isNaN(date.getTime())) return false;

  const today = new Date();
  today.setHours(0, 0, 0, 0);
  if (period === "today") return date.getTime() === today.getTime();

  const start = new Date(today);
  if (period === "previousMonth") {
    start.setDate(1);
    start.setMonth(start.getMonth() - 1);
  } else if (period === "week") {
    start.setDate(today.getDate() - ((today.getDay() + 6) % 7));
  } else {
    start.setDate(1);
  }
  const end = new Date(start);
  if (period === "previousMonth") {
    end.setMonth(start.getMonth() + 1);
  } else if (period === "week") end.setDate(start.getDate() + 7);
  else end.setMonth(start.getMonth() + 1);
  return date >= start && date < end;
}

function getCustomerRegistrationDate(customer) {
  return (
    customer.createdAt ||
    customer.createdDate ||
    customer.registeredAt ||
    customer.registrationDate
  );
}

function formatSubscriptionDetails(details) {
  if (!details) return null;
  return Object.values(details).map((subscription) => {
    const dates = [...subscription.dates].sort();
    return {
      visits: subscription.visits,
      frequency: subscription.frequency,
      frequencyName: subscription.frequencyName,
      weeks: subscription.weeks,
      subscriptionName: subscription.subscriptionName,
      startDate: fmtDateHuman(dates[0]),
      endDate: fmtDateHuman(dates[dates.length - 1]),
    };
  });
}

function formatFrequency(frequency) {
  return (
    {
      weekly: "Once a week",
      biweekly: "Once every 2 weeks",
      monthly: "Once a month",
    }[frequency] || "Not recorded"
  );
}

function formatSubscriptionLength(weeks) {
  const monthsByWeeks = { 8: 2, 12: 3, 24: 6, 48: 12 };
  const months = monthsByWeeks[weeks];
  return months ? `${months} months` : "Not recorded";
}

function getSubscriptionSummary(details) {
  const subscriptions = details ? Object.values(details) : [];
  if (!subscriptions.length) {
    return { frequency: "Not recorded", duration: "Not recorded" };
  }

  return {
    frequency: [...new Set(
      subscriptions.map(
        (item) => item.frequencyName || formatFrequency(item.frequency),
      ),
    )].join(" / "),
    duration: [...new Set(
      subscriptions.map(
        (item) =>
          item.subscriptionName || formatSubscriptionLength(item.weeks),
      ),
    )].join(" / "),
  };
}

export default function CustomerDetails({
  customers,
  bookings,
  invoices,
  onPrintInvoice,
  onUpdateCustomer,
}) {
  const [search, setSearch] = useState("");
  const [bookingPeriod, setBookingPeriod] = useState("all");
  const [nameSort, setNameSort] = useState("asc");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [editingCustomer, setEditingCustomer] = useState(null);
  const [pendingCustomerUpdate, setPendingCustomerUpdate] = useState(null);
  const [profileServicePage, setProfileServicePage] = useState(0);

  const subscriptionDetailsByCustomer = useMemo(() => {
    const details = {};
    bookings.forEach((booking) => {
      if (booking.status === "cancelled") return;
      const customerSubscriptions = details[booking.customerId] || {};
      const subscriptionKey =
        booking.subscriptionId || booking.subscriptionTypeId || booking.id;
      const current = customerSubscriptions[subscriptionKey] || {
        visits: 0,
        dates: [],
        frequency: booking.frequency,
        frequencyName: booking.serviceFrequencyName,
        weeks: booking.weeks,
        subscriptionName: booking.subscriptionTypeName,
      };
      current.visits += 1;
      current.dates.push(booking.date);
      current.frequency ||= booking.frequency;
      current.frequencyName ||= booking.serviceFrequencyName;
      current.weeks ||= booking.weeks;
      current.subscriptionName ||= booking.subscriptionTypeName;
      customerSubscriptions[subscriptionKey] = current;
      details[booking.customerId] = customerSubscriptions;
    });
    return details;
  }, [bookings]);

  const filtered = useMemo(() => {
    const query = norm(search);
    const matchingCustomers = query
      ? customers.filter((customer) => {
          const address = formatCustomerAddress(customer);
          return (
            norm(customer.name).includes(query) ||
            norm(customer.phone).includes(query) ||
            norm(address).includes(query) ||
            norm(customer.area).includes(query) ||
            norm(customer.id).includes(query)
          );
        })
      : customers;
    const periodCustomers = matchingCustomers.filter((customer) =>
      isDateInPeriod(getCustomerRegistrationDate(customer), bookingPeriod),
    );

    return [...periodCustomers].sort((firstCustomer, secondCustomer) => {
      const firstName = norm(firstCustomer.name);
      const secondName = norm(secondCustomer.name);
      const comparison = firstName.localeCompare(secondName);
      return nameSort === "asc" ? comparison : -comparison;
    });
  }, [bookingPeriod, customers, nameSort, search]);

  useEffect(() => {
    setPage(0);
  }, [bookingPeriod, filtered.length, search]);

  const visibleCustomers = filtered.slice(
    page * rowsPerPage,
    page * rowsPerPage + rowsPerPage,
  );

  const profileBookings = selectedCustomer
    ? bookings.filter(
        (booking) =>
          booking.customerId === selectedCustomer.id &&
          booking.status !== "cancelled",
      )
    : [];
  const profileInvoices = selectedCustomer
    ? (invoices || []).filter(
        (invoice) =>
          invoice.customerId === selectedCustomer.id &&
          invoice.status === "paid",
      )
    : [];
  const profileSubscriptions = formatSubscriptionDetails(
    selectedCustomer
      ? subscriptionDetailsByCustomer[selectedCustomer.id]
      : null,
  ) || [];
  const profileCompletedVisits = profileBookings.filter(
    (booking) => String(booking.status || "").toLowerCase() === "completed",
  ).length;
  const profilePaidAmount = profileInvoices.reduce(
    (total, invoice) => total + Number(invoice.amount || 0),
    0,
  );
  const profileNextBooking = [...profileBookings].sort((first, second) =>
    String(first.date || "").localeCompare(String(second.date || "")),
  )[0];
  const profileStatus =
    selectedCustomer?.activeStatusName || selectedCustomer?.status || "Nil";

  return (
    <Box>
      <Stack
        direction={{ xs: "column", sm: "row" }}
        spacing={1.5}
        sx={{ mb: 2 }}
      >
        <TextField
          size="small"
          placeholder="Search by Name, Area, or Phone Number"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
          fullWidth
          sx={{ "& .MuiOutlinedInput-root": { borderRadius: 0.5 } }}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <SearchIcon fontSize="small" />
              </InputAdornment>
            ),
          }}
        />
        <TextField
          select
          size="small"
          label="Show"
          value={bookingPeriod}
          onChange={(event) => setBookingPeriod(event.target.value)}
          sx={{ minWidth: { xs: "100%", sm: 170 } }}
        >
          <MenuItem value="all">All customers</MenuItem>
          <MenuItem value="today">Today</MenuItem>
          <MenuItem value="week">This week</MenuItem>
          <MenuItem value="month">This month</MenuItem>
          <MenuItem value="previousMonth">Previous month</MenuItem>
        </TextField>
      </Stack>
      <TableContainer
        sx={{
          overflowX: "auto",
          border: 1,
          borderColor: "divider",
          borderRadius: 0.5,
          bgcolor: "background.paper",
        }}
      >
        <Table
          size="small"
          sx={{
            width: "100%",
            minWidth: 760,
            tableLayout: "fixed",
            borderCollapse: "separate",
            borderSpacing: 0,
            "& .MuiTableCell-root": {
              borderColor: "divider",
              px: { xs: 1.25, sm: 2, lg: 2.5 },
            },
          }}
        >
          <TableHead>
            <TableRow
              sx={{
                bgcolor: (theme) =>
                  theme.palette.mode === "dark" ? "action.hover" : "#F7F5F0",
                "& .MuiTableCell-root": {
                  fontSize: 12,
                  fontWeight: 700,
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                  py: 1.5,
                },
              }}
            >
              <TableCell sx={{ width: "8%", whiteSpace: "nowrap" }}>
                S.No
              </TableCell>
              <TableCell sx={{ width: "23%" }}>
                <Stack direction="row" spacing={0.5} alignItems="center">
                  <Typography
                    component="span"
                    sx={{ fontSize: 12, fontWeight: 700 }}
                  >
                    Name
                  </Typography>
                  <FormControl size="small" sx={{ width: 24 }}>
                    <Select
                      value={nameSort}
                      variant="standard"
                      disableUnderline
                      aria-label="Sort customers by name"
                      renderValue={() => ""}
                      onChange={(event) => setNameSort(event.target.value)}
                      sx={{
                        fontSize: 12,
                        fontWeight: 700,
                        "& .MuiSelect-select": { p: 0, minHeight: "auto" },
                      }}
                    >
                      <MenuItem value="asc">A-Z</MenuItem>
                      <MenuItem value="desc">Z-A</MenuItem>
                    </Select>
                  </FormControl>
                </Stack>
              </TableCell>
              <TableCell sx={{ width: "17%" }}>Area</TableCell>
              <TableCell sx={{ width: "20%" }}>Service type</TableCell>
              <TableCell sx={{ width: "20%" }}>Subscription type</TableCell>
              <TableCell sx={{ width: "12%", textAlign: "center" }}>
                Details
              </TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {visibleCustomers.map((customer) => {
              const subscriptionSummary = getSubscriptionSummary(
                subscriptionDetailsByCustomer[customer.id],
              );
              return (
                <TableRow
                  key={customer.id}
                  hover
                  sx={{
                    "&:nth-of-type(even)": { bgcolor: "action.selected" },
                    "&:hover": { bgcolor: "rgba(226, 109, 79, 0.08)" },
                    "& .MuiTableCell-root": { py: 1.75, verticalAlign: "top" },
                  }}
                >
                  <TableCell>
                    <Typography variant="body2" fontWeight={700}>
                      {page * rowsPerPage +
                        visibleCustomers.indexOf(customer) +
                        1}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <ButtonBase
                      component="button"
                      onClick={() => {
                        setSelectedCustomer(customer);
                        setProfileServicePage(0);
                      }}
                      aria-label={`View customer details for ${customer.name || "customer"}`}
                      sx={{
                        display: "block",
                        width: "100%",
                        textAlign: "left",
                        borderRadius: 0.5,
                        color: "#000",
                        "&:hover": { textDecoration: "underline" },
                      }}
                    >
                      <Typography
                        variant="body2"
                        fontWeight={700}
                        sx={{ overflowWrap: "anywhere" }}
                      >
                        {customer.name || "Unnamed customer"}
                      </Typography>
                    </ButtonBase>
                  </TableCell>
                  <TableCell>
                    <Typography
                      variant="body2"
                      color={customer.area ? "text.primary" : "text.secondary"}
                      sx={{ whiteSpace: "normal", overflowWrap: "anywhere" }}
                    >
                      {customer.area || "Area not provided"}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography
                      variant="body2"
                      color="text.secondary"
                      sx={{ overflowWrap: "anywhere" }}
                    >
                      {subscriptionSummary.frequency}
                    </Typography>
                  </TableCell>
                  <TableCell>
                    <Typography
                      variant="body2"
                      color="text.secondary"
                      sx={{ overflowWrap: "anywhere" }}
                    >
                      {subscriptionSummary.duration}
                    </Typography>
                  </TableCell>
                  <TableCell sx={{ textAlign: "center" }}>
                    <IconButton
                      size="small"
                      color="primary"
                      aria-label={`View customer details for ${customer.name || "customer"}`}
                      onClick={() => {
                        setSelectedCustomer(customer);
                        setProfileServicePage(0);
                      }}
                    >
                      <VisibilityOutlinedIcon fontSize="small" />
                    </IconButton>
                    <IconButton
                      size="small"
                      color="primary"
                      aria-label={`Edit customer details for ${customer.name || "customer"}`}
                      onClick={() => setEditingCustomer(customer)}
                    >
                      <EditOutlinedIcon fontSize="small" />
                    </IconButton>
                  </TableCell>
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        component="div"
        count={filtered.length}
        page={page}
        onPageChange={(_, nextPage) => setPage(nextPage)}
        onRowsPerPageChange={(event) => {
          setRowsPerPage(Number(event.target.value));
          setPage(0);
        }}
        rowsPerPage={rowsPerPage}
        rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
      />
      <Dialog
        open={Boolean(selectedCustomer)}
        onClose={() => setSelectedCustomer(null)}
        fullWidth
        maxWidth="xl"
        PaperProps={{
          sx: {
            width: "min(1280px, calc(100vw - 32px))",
            maxHeight: "calc(100vh - 32px)",
            borderRadius: 2,
            overflow: "hidden",
          },
        }}
      >
        <DialogTitle
          sx={{
            position: "relative",
            p: { xs: 2, md: 3 },
            borderBottom: 1,
            borderColor: "divider",
          }}
        >
          <Stack spacing={2}>
            <IconButton
              aria-label="Close customer profile"
              onClick={() => setSelectedCustomer(null)}
              size="small"
              sx={{ position: "absolute", top: 12, right: 12 }}
            >
              <CloseIcon fontSize="small" />
            </IconButton>
            <Box
              sx={{
                display: "grid",
                gridTemplateColumns: { xs: "1fr", md: "minmax(0, 1fr) auto" },
                gap: 2,
                alignItems: "center",
                maxHeight: { xs: 260, md: 190 },
                overflowY: "auto",
                pr: { xs: 1, md: 5 },
              }}
            >
              <Stack direction="row" spacing={2} alignItems="center" sx={{ minWidth: 0 }}>
                <Box sx={{ width: 76, height: 76, flexShrink: 0, borderRadius: "50%", bgcolor: "rgba(226,109,79,0.16)", display: "grid", placeItems: "center" }}>
                  <PersonOutlineOutlinedIcon sx={{ fontSize: 46, color: "primary.main" }} />
                </Box>
                <Box sx={{ minWidth: 0 }}>
                  <Stack direction="row" spacing={1} alignItems="center" flexWrap="wrap">
                    <Typography variant="h5" fontWeight={800} sx={{ overflowWrap: "anywhere", lineHeight: 1.2 }}>{selectedCustomer?.name || "Unnamed customer"}</Typography>
                    <Typography variant="caption" sx={{ px: 1, py: 0.35, borderRadius: 1.5, bgcolor: profileStatus === "Nil" ? "action.hover" : "rgba(45,122,105,0.16)", color: profileStatus === "Nil" ? "text.secondary" : "secondary.main", fontWeight: 700 }}>{profileStatus}</Typography>
                  </Stack>
                  <Stack spacing={0.45} sx={{ mt: 0.75 }}>
                    <Typography variant="caption" color="text.secondary">Customer ID: {selectedCustomer?.id || "Not available"}</Typography>
                    <Stack direction="row" spacing={0.75} alignItems="center">
                      <PhoneOutlinedIcon sx={{ fontSize: 16, color: "text.secondary" }} />
                      <Typography variant="body2" color="text.secondary">{selectedCustomer?.phone || "Phone not provided"}</Typography>
                    </Stack>
                    <Stack direction="row" spacing={0.75} alignItems="flex-start">
                      <LocationOnOutlinedIcon sx={{ fontSize: 16, color: "text.secondary", mt: 0.2 }} />
                      <Typography variant="body2" color="text.secondary" sx={{ overflowWrap: "anywhere" }}>{selectedCustomer?.address || "Address not provided"}</Typography>
                    </Stack>
                    <Typography variant="caption" color="text.secondary" sx={{ pl: 2.75 }}>Default Area: {selectedCustomer?.area || "Not provided"}</Typography>
                  </Stack>
                </Box>
              </Stack>
              <Stack direction="row" spacing={1} justifyContent="flex-end" flexWrap="wrap" sx={{ alignSelf: "center" }}>
                <Tooltip title="Edit customer">
                  <Button variant="outlined" size="small" startIcon={<EditOutlinedIcon />}>Edit Customer</Button>
                </Tooltip>
                <Tooltip title="Add address">
                  <Button variant="outlined" size="small" startIcon={<PersonAddAlt1OutlinedIcon />}>Add Address</Button>
                </Tooltip>
                <Tooltip title="Download customer record">
                  <Button variant="outlined" size="small" startIcon={<DownloadOutlinedIcon />}>Download Record</Button>
                </Tooltip>
              </Stack>
            </Box>
          </Stack>
        </DialogTitle>
        <DialogContent dividers>
          <Stack spacing={2}>
            <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr 1fr", sm: "repeat(3, 1fr)", lg: "repeat(5, 1fr)" }, gap: 1.5 }}>
              {[
                ["Service Addresses", selectedCustomer?.address ? "1" : "0", selectedCustomer?.address ? "Active" : "None"],
                ["Total Bookings", String(profileBookings.length), "All Time"],
                ["Active Subscriptions", String(profileSubscriptions.length), "Currently Active"],
                ["Next Service", profileNextBooking?.date ? fmtDateHuman(profileNextBooking.date) : "None", profileNextBooking?.startTime || "No time set"],
                ["Total Payments", profilePaidAmount ? `₹${profilePaidAmount.toLocaleString("en-IN")}` : "Nil", "All Time"],
              ].map(([label, value, hint], index) => (
                <Box key={label} sx={{ p: 1.5, border: 1, borderColor: "divider", borderTop: 3, borderTopColor: ["primary.main", "secondary.main", "success.main", "warning.main", "info.main"][index], borderRadius: 1.5, bgcolor: "background.paper", minWidth: 0, minHeight: 104 }}>
                  <Typography variant="caption" color="text.secondary" sx={{ display: "block", minHeight: 32 }}>{label}</Typography>
                  <Typography variant="h6" fontWeight={800} sx={{ lineHeight: 1.2, overflowWrap: "anywhere" }}>{value}</Typography>
                  <Typography variant="caption" color="text.secondary">{hint}</Typography>
                </Box>
              ))}
            </Box>
            <Box sx={{ display: "grid", gridTemplateColumns: { xs: "minmax(0, 1fr)", lg: "minmax(0, 1.15fr) minmax(0, 1fr)" }, gap: 2, alignItems: "start" }}>
                <Box sx={{ minWidth: 0 }}>
                  <Typography variant="subtitle1" fontWeight={800} color="secondary.main" sx={{ mb: 1.25, letterSpacing: "0.01em" }}>Current Subscriptions</Typography>
                  <Box sx={{ display: "grid", gridTemplateColumns: { xs: "1fr", md: "repeat(auto-fit, minmax(260px, 1fr))" }, gap: 1.5 }}>
                    {profileSubscriptions.length ? profileSubscriptions.map((subscription, index) => {
                      const subscriptionBookings = profileBookings.filter(
                        (booking) =>
                          (booking.subscriptionId || booking.subscriptionTypeId || booking.id) ===
                          Object.keys(subscriptionDetailsByCustomer[selectedCustomer?.id] || {})[index],
                      );
                      const completed = subscriptionBookings.filter(
                        (booking) => String(booking.status || "").toLowerCase() === "completed",
                      ).length;
                      const subscriptionBooking = subscriptionBookings[0];
                      return (
                      <Box key={`${subscription.subscriptionName || "subscription"}-${index}`} sx={{ p: 1.75, border: 1, borderColor: "divider", borderRadius: 1.5, bgcolor: "background.paper", minWidth: 0 }}>
                        <Stack direction="row" justifyContent="space-between" alignItems="flex-start" spacing={1}><Typography fontWeight={800} sx={{ minWidth: 0, overflowWrap: "anywhere" }}>{subscription.subscriptionName || `Subscription ${index + 1}`}</Typography><Typography variant="caption" sx={{ px: 1, borderRadius: 1, whiteSpace: "nowrap", bgcolor: completed === subscription.visits ? "success.light" : "info.light" }}>{completed === subscription.visits ? "Completed" : "Active"}</Typography></Stack>
                        <Typography variant="body2" color="text.secondary" sx={{ mt: 1 }}>{selectedCustomer?.area || selectedCustomer?.address || "Address not provided"}</Typography>
                        <Typography variant="caption" color="text.secondary">{subscription.frequencyName || formatFrequency(subscription.frequency)} · {subscription.visits} Services</Typography>
                        <Box sx={{ display: "grid", gridTemplateColumns: "82px minmax(0, 1fr)", columnGap: 1, rowGap: 0.5, mt: 1 }}>
                          <Typography variant="body2" color="text.secondary">Period</Typography>
                          <Typography variant="body2" sx={{ overflowWrap: "anywhere" }}>{subscription.startDate} to {subscription.endDate}</Typography>
                          <Typography variant="body2" color="text.secondary">Completed</Typography>
                          <Typography variant="body2">{completed} of {subscription.visits} Services</Typography>
                        </Box>
                        <Box sx={{ height: 5, bgcolor: "action.hover", borderRadius: 1, my: 1 }}><Box sx={{ width: `${subscription.visits ? Math.round((completed / subscription.visits) * 100) : 0}%`, height: "100%", bgcolor: "success.main", borderRadius: 1 }} /></Box>
                        <Box sx={{ display: "grid", gridTemplateColumns: "82px minmax(0, 1fr)", columnGap: 1, mt: 1 }}>
                          <Typography variant="caption" color="text.secondary">Next service</Typography>
                          <Typography variant="caption" sx={{ overflowWrap: "anywhere" }}>{subscriptionBooking?.date ? fmtDateHuman(subscriptionBooking.date) : "No upcoming service"}</Typography>
                        </Box>
                        <Box sx={{ display: "grid", gridTemplateColumns: "auto 1fr", columnGap: 1, rowGap: 0.5, mt: 1.25, pt: 1.25, borderTop: 1, borderColor: "divider" }}>
                          <Typography variant="caption" color="text.secondary">Frequency</Typography>
                          <Typography variant="caption" fontWeight={700}>{subscription.frequencyName || formatFrequency(subscription.frequency)}</Typography>
                          <Typography variant="caption" color="text.secondary">Interval</Typography>
                          <Typography variant="caption" fontWeight={700}>{subscriptionBooking?.serviceFrequencyIntervalDays ? `${subscriptionBooking.serviceFrequencyIntervalDays} days` : "Nil"}</Typography>
                          <Typography variant="caption" color="text.secondary">Total visits</Typography>
                          <Typography variant="caption" fontWeight={700}>{subscription.visits}</Typography>
                        </Box>
                      </Box>
                      );
                    }) : <Typography variant="body2" color="text.secondary">No subscriptions found</Typography>}
                  </Box>
                </Box>
                <Box sx={{ minWidth: 0 }}>
                  <Typography variant="subtitle1" fontWeight={800} color="secondary.main" sx={{ mb: 1.25, letterSpacing: "0.01em" }}>Upcoming Services <Typography component="span" variant="body2" color="text.secondary">(Next 5)</Typography></Typography>
                  <Box sx={{ p: 1.25, border: 1, borderColor: "divider", borderRadius: 1.5, overflowX: "auto", bgcolor: "background.paper" }}>
                    <Table size="small" sx={{ width: "100%", minWidth: 540, tableLayout: "auto", "& .MuiTableCell-root": { whiteSpace: "nowrap", px: 1.25 } }}>
                      <TableHead><TableRow sx={{ bgcolor: "action.hover" }}><TableCell>Date</TableCell><TableCell>Time</TableCell><TableCell>Service Address</TableCell><TableCell>Bathrooms</TableCell><TableCell>Status</TableCell></TableRow></TableHead>
                      <TableBody>{profileBookings.slice(profileServicePage * 5, profileServicePage * 5 + 5).map((booking) => <TableRow key={booking.id}><TableCell>{fmtDateHuman(booking.date)}</TableCell><TableCell>{booking.startTime || "Not set"}</TableCell><TableCell>{selectedCustomer?.address || selectedCustomer?.area || "Not provided"}</TableCell><TableCell>{booking.bathroomCount || "-"}</TableCell><TableCell><Typography variant="caption" color="info.main" fontWeight={700}>{booking.status || "Scheduled"}</Typography></TableCell></TableRow>)}</TableBody>
                    </Table>
                    <TablePagination
                      component="div"
                      count={profileBookings.length}
                      page={profileServicePage}
                      onPageChange={(_, nextPage) => setProfileServicePage(nextPage)}
                      rowsPerPage={5}
                      rowsPerPageOptions={[5]}
                      sx={{
                        ".MuiTablePagination-toolbar": { minHeight: 42, px: 0 },
                        ".MuiTablePagination-selectLabel, .MuiTablePagination-displayedRows": { fontSize: 12 },
                      }}
                    />
                  </Box>
                </Box>
            </Box>
          </Stack>
          {/*
                    <Box>
                      <Typography
                        variant="subtitle2"
                        color="primary.main"
                        sx={{ mb: 1.5, pb: 0.75, fontWeight: 900 }}
                      >
                        CUSTOMER DETAILS
                      </Typography>
                      <Stack spacing={1}>
                        {[
                          [
                            "Phone number",
                            selectedCustomer.phone || "Phone not provided",
                          ],
                          [
                            "Door number",
                            selectedCustomer.doorNumber || "Not provided",
                          ],
                          [
                            "Block / Tower",
                            selectedCustomer.blockNumber || "Not provided",
                          ],
                          [
                            "Apartment name",
                            selectedCustomer.apartmentNumber || "Not provided",
                          ],
                          [
                            "Address",
                            selectedCustomer.address || "Not provided",
                          ],
                          ["City", selectedCustomer.city || "Not provided"],
                          ["Area", selectedCustomer.area || "Not provided"],
                        ].map(([label, value]) => (
                          <Stack key={label} direction="row" spacing={2}>
                            <Typography
                              variant="body2"
                              color="text.primary"
                              sx={{ minWidth: 110, fontWeight: 700 }}
                            >
                              {label}
                            </Typography>
                            <Typography
                              variant="body2"
                              color="text.secondary"
                              sx={{ overflowWrap: "anywhere" }}
                            >
                              {value}
                            </Typography>
                          </Stack>
                        ))}
                      </Stack>
                    </Box>
                    <Box
                      sx={{
                        borderLeft: { xs: 0, md: 1 },
                        borderTop: { xs: 1, md: 0 },
                        borderColor: "divider",
                        pl: { xs: 0, md: 4 },
                        pt: { xs: 2, md: 0 },
                      }}
                    >
                      <Typography
                        variant="subtitle2"
                        color="primary.main"
                        sx={{ mb: 1.5, pb: 0.75, fontWeight: 900 }}
                      >
                        BOOKING DETAILS
                      </Typography>
                      <Stack spacing={1}>
                        <Stack direction="row" spacing={2}>
                          <Typography
                            variant="body2"
                            color="text.primary"
                            sx={{ minWidth: 140, fontWeight: 700 }}
                          >
                            Paid amount
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            {paidAmount
                              ? `₹${paidAmount.toLocaleString("en-IN")}`
                              : "Nil"}
                          </Typography>
                        </Stack>
                        
                        <Box
                          sx={{
                            display: "grid",
                            gridTemplateColumns: "140px minmax(0, 1fr)",
                            columnGap: 2,
                            alignItems: "start",
                          }}
                        >
                          <Typography
                            variant="body2"
                            color="text.primary"
                            sx={{ fontWeight: 700 }}
                          >
                            Invoice
                          </Typography>
                          <Box sx={{ display: "grid", gap: 0.5, minWidth: 0 }}>
                            {customerInvoices.length ? (
                              customerInvoices.map((invoice) => {
                                const invoiceBookings = (invoice.bookingIds || [invoice.bookingId])
                                  .map((bookingId) => bookings.find((booking) => booking.id === bookingId))
                                  .filter(Boolean);
                                const invoicePreview = {
                                  invoice,
                                  customer: selectedCustomer,
                                  booking: invoiceBookings[0],
                                  bookings: invoiceBookings,
                                };
                                return (
                                  <Box
                                    key={invoice.id || invoice._id}
                                    sx={{
                                      display: "flex",
                                      alignItems: "center",
                                      justifyContent: "flex-start",
                                    }}
                                  >
                                    <Button
                                      size="small"
                                      variant="text"
                                      onClick={() => onPrintInvoice?.(invoicePreview)}
                                      sx={{
                                        minWidth: 0,
                                        p: 0,
                                        justifyContent: "flex-start",
                                        justifySelf: "start",
                                        
                                      }}
                                    >
                                      Download
                                    </Button>
                                  </Box>
                                );
                              })
                            ) : (
                              <Typography variant="body2" color="text.secondary">
                                Nil
                              </Typography>
                            )}
                          </Box>
                        </Box>
                        <Stack direction="row" spacing={2}>
                          <Typography
                            variant="body2"
                            color="text.primary"
                            sx={{ minWidth: 140, fontWeight: 700 }}
                          >
                            Subscription status
                          </Typography>
                          <Typography variant="body2" color="text.secondary">
                            Nil
                          </Typography>
                        </Stack>
                      </Stack>
                      <Divider sx={{ my: 2 }} />
                      <Typography
                        variant="subtitle2"
                        color="primary.main"
                        sx={{ mt: 2.5, mb: 1.5, pb: 0.75, fontWeight: 900 }}
                      >
                        SUBSCRIPTION DETAILS
                      </Typography>
                      <Stack spacing={1}>
                        {subscriptions?.length ? (
                          subscriptions.map((subscription, index) => (
                            <Stack key={index} spacing={1}>
                              <Stack direction="row" spacing={2}>
                                <Typography
                                  variant="body2"
                                  color="text.primary"
                                  sx={{ minWidth: 140, fontWeight: 700 }}
                                >
                                  Service frequency
                                </Typography>
                                <Typography
                                  variant="body2"
                                  color="text.secondary"
                                >
                                  {subscription.frequencyName ||
                                    formatFrequency(subscription.frequency)}
                                </Typography>
                              </Stack>
                              <Stack direction="row" spacing={2}>
                                <Typography
                                  variant="body2"
                                  color="text.primary"
                                  sx={{ minWidth: 140, fontWeight: 700 }}
                                >
                                  Subscription type
                                </Typography>
                                <Typography
                                  variant="body2"
                                  color="text.secondary"
                                >
                                  {subscription.subscriptionName ||
                                    formatSubscriptionLength(
                                      subscription.weeks,
                                    )}
                                </Typography>
                              </Stack>
                              <Stack direction="row" spacing={2}>
                                <Typography
                                  variant="body2"
                                  color="text.primary"
                                  sx={{ minWidth: 140, fontWeight: 700 }}
                                >
                                  Subscription period
                                </Typography>
                                <Typography
                                  variant="body2"
                                  color="text.secondary"
                                  sx={{ overflowWrap: "anywhere" }}
                                >
                                  {subscription.startDate} to{" "}
                                  {subscription.endDate}
                                </Typography>
                              </Stack>
                              
                            </Stack>
                          ))
                        ) : (
                          <Typography variant="body2" color="text.secondary">
                            One-time service
                          </Typography>
                        )}
                      </Stack>
                    </Box>
                  </Box>
                  <Divider />
                  <Typography
                    variant="subtitle2"
                    color="primary.main"
                    sx={{ mb: 1.5, pb: 0.75, fontWeight: 900 }}
                  >
                    SERVICE DETAILS
                  </Typography>
                  <Stack spacing={1}>
                    <Stack direction="row" spacing={2}>
                      <Typography
                        variant="body2"
                        color="text.primary"
                        sx={{ minWidth: 140, fontWeight: 700 }}
                      >
                        Total visits
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {customerBookings.length} visits
                      </Typography>
                    </Stack>
                    <Stack direction="row" spacing={2}>
                      <Typography
                        variant="body2"
                        color="text.primary"
                        sx={{ minWidth: 140, fontWeight: 700 }}
                      >
                        Completed visits
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {completedVisits} of {customerBookings.length} visits
                      </Typography>
                    </Stack>
                  </Stack>
                </Stack>
              );
            })()}
          */}
        </DialogContent>
      </Dialog>
      <Dialog
        open={Boolean(editingCustomer)}
        onClose={() => {}}
        disableEscapeKeyDown
        fullWidth
        maxWidth="sm"
      >
        <DialogTitle
          sx={{
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
          }}
        >
          Edit customer details
          <IconButton
            aria-label="Close edit customer details"
            onClick={() => setEditingCustomer(null)}
            edge="end"
            size="small"
          >
            <CloseIcon fontSize="small" />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers>
          {editingCustomer && (
            <CustomerRegistrationForm
              key={editingCustomer.id}
              initialCustomer={editingCustomer}
              submitLabel="Save changes"
              description="Update customer details only. Subscription details will not be changed."
              onSubmit={(data) => {
                setPendingCustomerUpdate({
                  customerId: editingCustomer.id,
                  data,
                });
              }}
            />
          )}
        </DialogContent>
      </Dialog>
      <ConfirmDialog
        open={Boolean(pendingCustomerUpdate)}
        title="Update customer details?"
        message="Are you sure you want to save these customer detail changes? Subscription details will not be changed."
        confirmLabel="Update"
        onConfirm={async () => {
          const updated = await onUpdateCustomer?.(
            pendingCustomerUpdate.customerId,
            pendingCustomerUpdate.data,
          );
          if (updated) {
            setPendingCustomerUpdate(null);
            setEditingCustomer(null);
          }
        }}
        onClose={() => setPendingCustomerUpdate(null)}
      />
    </Box>
  );
}
