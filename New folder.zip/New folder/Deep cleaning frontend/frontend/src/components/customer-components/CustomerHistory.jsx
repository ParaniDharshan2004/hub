import { useMemo, useState } from "react";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogContent from "@mui/material/DialogContent";
import DialogTitle from "@mui/material/DialogTitle";
import IconButton from "@mui/material/IconButton";
import InputAdornment from "@mui/material/InputAdornment";
import MenuItem from "@mui/material/MenuItem";
import Paper from "@mui/material/Paper";
import Select from "@mui/material/Select";
import Stack from "@mui/material/Stack";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import TextField from "@mui/material/TextField";
import Typography from "@mui/material/Typography";
import CloseIcon from "@mui/icons-material/Close";
import DownloadIcon from "@mui/icons-material/Download";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import SearchIcon from "@mui/icons-material/Search";
import { fmtDateHuman, fmtTime12, norm } from "../../utils/scheduling.js";

const rowsPerPageOptions = [5, 10, 25];

function formatFrequency(frequency) {
  return {
    weekly: "Once a week",
    biweekly: "Once every 2 weeks",
    monthly: "Once a month",
  }[frequency] || "Not recorded";
}

function formatLength(weeks) {
  const months = { 8: 2, 12: 3, 24: 6, 48: 12 }[weeks];
  return months ? `${months} months` : "Not recorded";
}

export default function CustomerHistory({ customers, bookings, invoices, onPrint }) {
  const [search, setSearch] = useState("");
  const [page, setPage] = useState(0);
  const [rowsPerPage, setRowsPerPage] = useState(10);
  const [selectedCustomer, setSelectedCustomer] = useState(null);
  const [servicePage, setServicePage] = useState(0);
  const [serviceRowsPerPage, setServiceRowsPerPage] = useState(5);

  const bookingByCustomer = useMemo(() => {
    const result = {};
    bookings.forEach((booking) => {
      if (booking.status === "cancelled") return;
      result[booking.customerId] = [...(result[booking.customerId] || []), booking];
    });
    return result;
  }, [bookings]);

  const invoiceByCustomer = useMemo(() => {
    const result = {};
    invoices
      .filter((invoice) => invoice.status === "paid")
      .forEach((invoice) => {
        result[invoice.customerId] = invoice;
      });
    return result;
  }, [invoices]);

  const history = useMemo(() => customers.map((customer) => {
    const customerBookings = bookingByCustomer[customer.id] || [];
    const subscriptions = new Map();
    customerBookings.forEach((booking) => {
      if (!booking.subscriptionId) return;
      const current = subscriptions.get(booking.subscriptionId) || {
        frequency: booking.frequency,
        weeks: booking.weeks,
        visits: 0,
        startDate: booking.date,
        endDate: booking.date,
      };
      current.frequency ||= booking.frequency;
      current.weeks ||= booking.weeks;
      current.visits += 1;
      if (booking.date < current.startDate) current.startDate = booking.date;
      if (booking.date > current.endDate) current.endDate = booking.date;
      subscriptions.set(booking.subscriptionId, current);
    });
    return {
      customer,
      bookings: customerBookings,
      subscriptions: [...subscriptions.values()],
      invoice: invoiceByCustomer[customer.id],
    };
  }), [bookingByCustomer, customers, invoiceByCustomer]);

  const filtered = useMemo(() => {
    const query = norm(search);
    if (!query) return history;
    return history.filter(({ customer }) =>
      [customer.name, customer.phone, customer.area].some((value) => norm(value).includes(query)),
    );
  }, [history, search]);

  const visibleRows = filtered.slice(page * rowsPerPage, page * rowsPerPage + rowsPerPage);

  return (
    <Box sx={{ width: "100%" }}>
      <Stack direction={{ xs: "column", sm: "row" }} spacing={1.5} sx={{ mb: 2 }}>
        <TextField
          size="small"
          fullWidth
          placeholder="Search by name, phone number, or area"
          value={search}
          onChange={(event) => { setSearch(event.target.value); setPage(0); }}
          sx={{ "& .MuiOutlinedInput-root": { borderRadius: 0.5 } }}
          InputProps={{ startAdornment: <InputAdornment position="start"><SearchIcon fontSize="small" /></InputAdornment> }}
        />
      </Stack>
      <TableContainer
        component={Paper}
        variant="outlined"
        sx={{
          overflowX: "auto",
          borderRadius: 0.5,
          bgcolor: "background.paper",
        }}
      >
        <Table
          size="small"
          sx={{
            width: "100%",
            minWidth: 920,
            tableLayout: "fixed",
            borderCollapse: "separate",
            borderSpacing: 0,
            "& .MuiTableCell-root": {
              borderColor: "divider",
              px: { xs: 1.25, sm: 2, lg: 2.5 },
            },
          }}
        >
          <TableHead>
            <TableRow
              sx={{
                bgcolor: (theme) => theme.palette.mode === "dark" ? "action.hover" : "#F7F5F0",
                "& .MuiTableCell-root": {
                  fontSize: 12,
                  fontWeight: 700,
                  letterSpacing: "0.08em",
                  textTransform: "uppercase",
                  py: 1.5,
                },
              }}
            >
              <TableCell sx={{ width: "7%" }}>S.No</TableCell>
              <TableCell sx={{ width: "18%" }}>Name</TableCell>
              <TableCell sx={{ width: "16%" }}>Phone number</TableCell>
              <TableCell sx={{ width: "14%" }}>Subscription</TableCell>
              <TableCell sx={{ width: "22%" }}>Service type</TableCell>
              <TableCell sx={{ width: "10%", textAlign: "center" }}>Invoice</TableCell>
              <TableCell sx={{ width: "10%", textAlign: "center" }}>Info</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {visibleRows.map((row, index) => {
              const subscription = row.subscriptions[0];
              return (
                <TableRow
                  key={row.customer.id}
                  hover
                  sx={{
                    "&:nth-of-type(even)": { bgcolor: "action.selected" },
                    "&:hover": { bgcolor: "rgba(226, 109, 79, 0.08)" },
                    "& .MuiTableCell-root": { py: 1.75, verticalAlign: "top" },
                  }}
                >
                  <TableCell>{page * rowsPerPage + index + 1}</TableCell>
                  <TableCell sx={{ fontWeight: 700 }}>{row.customer.name || "Unnamed customer"}</TableCell>
                  <TableCell>{row.customer.phone || "Phone not provided"}</TableCell>
                  <TableCell>{subscription ? formatLength(subscription.weeks) : "One-time service"}</TableCell>
                  <TableCell>{subscription ? formatFrequency(subscription.frequency) : "Not applicable"}</TableCell>
                  <TableCell sx={{ textAlign: "center" }}>
                    <IconButton
                      size="small"
                      color="primary"
                      disabled={!row.invoice}
                      aria-label={`Download invoice for ${row.customer.name || "customer"}`}
                      onClick={() => row.invoice && onPrint({
                        invoice: row.invoice,
                        customer: row.customer,
                        booking: row.bookings[0],
                        bookings: (row.invoice.bookingIds || [row.invoice.bookingId]).map((id) => row.bookings.find((booking) => booking.id === id)).filter(Boolean),
                      })}
                    >
                      <DownloadIcon fontSize="small" />
                    </IconButton>
                  </TableCell>
                  <TableCell sx={{ textAlign: "center" }}>
                    <IconButton size="small" color="primary" aria-label={`View service history for ${row.customer.name || "customer"}`} onClick={() => { setServicePage(0); setSelectedCustomer(row); }}>
                      <InfoOutlinedIcon fontSize="small" />
                    </IconButton>
                  </TableCell>
                </TableRow>
              );
            })}
            {!visibleRows.length && (
              <TableRow><TableCell colSpan={7} align="center">No customer history found.</TableCell></TableRow>
            )}
          </TableBody>
        </Table>
      </TableContainer>
      <TablePagination
        component="div"
        count={filtered.length}
        page={page}
        rowsPerPage={rowsPerPage}
        rowsPerPageOptions={rowsPerPageOptions}
        onPageChange={(_, nextPage) => setPage(nextPage)}
        onRowsPerPageChange={(event) => { setRowsPerPage(Number(event.target.value)); setPage(0); }}
      />

      <Dialog open={Boolean(selectedCustomer)} onClose={() => {}} disableEscapeKeyDown fullWidth maxWidth="md">
        <DialogTitle sx={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          {selectedCustomer?.customer.name || "Service history"}
          <IconButton aria-label="Close service history" onClick={() => setSelectedCustomer(null)}><CloseIcon /></IconButton>
        </DialogTitle>
        <DialogContent dividers>
          <TableContainer component={Paper} variant="outlined">
            <Table size="small">
              <TableHead><TableRow sx={{ bgcolor: "action.hover" }}><TableCell sx={{ fontWeight: 700 }}>Date</TableCell><TableCell sx={{ fontWeight: 700 }}>Time</TableCell><TableCell sx={{ fontWeight: 700 }}>Services</TableCell><TableCell sx={{ fontWeight: 700 }}>Status</TableCell></TableRow></TableHead>
              <TableBody>
                {selectedCustomer?.bookings
                  .slice(servicePage * serviceRowsPerPage, servicePage * serviceRowsPerPage + serviceRowsPerPage)
                  .map((booking) => (
                    <TableRow key={booking.id}><TableCell>{fmtDateHuman(booking.date)}</TableCell><TableCell>{booking.startTime ? fmtTime12(booking.startTime) : "Unscheduled"}</TableCell><TableCell>{booking.bathroomCount}</TableCell><TableCell>{booking.status}</TableCell></TableRow>
                  ))}
                {!selectedCustomer?.bookings.length && <TableRow><TableCell colSpan={4}>No services found.</TableCell></TableRow>}
              </TableBody>
            </Table>
            <TablePagination
              component="div"
              count={selectedCustomer?.bookings.length || 0}
              page={servicePage}
              rowsPerPage={serviceRowsPerPage}
              rowsPerPageOptions={[5, 10, 25]}
              onPageChange={(_, nextPage) => setServicePage(nextPage)}
              onRowsPerPageChange={(event) => { setServiceRowsPerPage(Number(event.target.value)); setServicePage(0); }}
            />
          </TableContainer>
        </DialogContent>
      </Dialog>
    </Box>
  );
}