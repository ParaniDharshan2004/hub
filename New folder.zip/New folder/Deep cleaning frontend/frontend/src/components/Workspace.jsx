import { useState, useEffect, useMemo } from "react";
import Box from "@mui/material/Box";
import Alert from "@mui/material/Alert";
import Snackbar from "@mui/material/Snackbar";
import CircularProgress from "@mui/material/CircularProgress";
 
import { DEFAULT_PRICING, DURATION_BY_BATHROOMS } from "../constants.js";
import {
  listCustomers,
  createCustomer as createCustomerRequest,
  updateCustomer as updateCustomerRequest,
} from "../api/customers.js";
import {
  listBookings,
  createBooking,
  updateBooking,
  cancelBooking as cancelBookingRequest,
  completeBooking as completeBookingRequest,
  subscriptionWeeks,
} from "../api/bookings.js";
import { listInvoices } from "../api/invoices.js";
import { listPricing } from "../api/pricing.js";
import {
  listServiceDurations,
} from "../api/serviceDurations.js";
import { listServiceFrequencies } from "../api/serviceFrequencies.js";
import { listSubscriptionTypes } from "../api/subscriptionTypes.js";
import { listTimeSlots } from "../api/timeSlots.js";
import { listPaymentMethods } from "../api/paymentMethods.js";
import { listPaymentAccounts } from "../api/paymentAccounts.js";
import { listPaymentMasters } from "../api/paymentMasters.js";
import { listBathroomCounts } from "../api/bathroomCounts.js";
import {
  toDateStr,
  timeToMin,
  generateOccurrenceDates,
} from "../utils/scheduling.js";
 
import Navbar from "./common-components/Navbar.jsx";
import UnsavedChangesDialog from "./common-components/UnsavedChangesDialog.jsx";
import PrintManager from "./common-components/PrintManager.jsx";
import DashboardPage from "../pages/DashboardPage.jsx";
import CalendarPage from "../pages/CalendarPage.jsx";
import NewBookingPage from "../pages/NewBookingPage.jsx";
import CustomersPage from "../pages/CustomersPage.jsx";
import InvoicesPage from "../pages/InvoicesPage.jsx";
import AnalyticsPage from "../pages/AnalyticsPage.jsx";
import SettingsPage from "../pages/SettingsPage.jsx";
 
const ROUTES = {
  dashboard: "/dashboard",
  calendar: "/service-schedule",
  "new-booking": "/new-booking",
  registration: "/customer-registration",
  details: "/customer-details",
  invoices: "/invoices",
  analytics: "/analytics",
  settings: "/settings",
};
 
const stateFromUrl = () => {
  const path = window.location.pathname.replace(/\/$/, "") || "/";
  if (path === ROUTES.registration)
    return { view: "customers", customerView: "registration" };
  if (path === ROUTES.details || path === "/customers") {
    return { view: "customers", customerView: "details" };
  }
  const view = Object.entries(ROUTES).find(([, route]) => route === path)?.[0];
  return view && view !== "registration" && view !== "details"
    ? { view, customerView: "details" }
    : { view: "dashboard", customerView: "details" };
};
 
const cleanUrlForState = (view, customerView) =>
  view === "customers" ? ROUTES[customerView] : ROUTES[view];
 
const userFriendlyError = (message) => {
  if (message?.toLowerCase().includes("booking conflicts with an existing booking or working hours")) {
    return "This time slot is unavailable. Please choose another time.";
  }
  return message || "Something went wrong. Please try again.";
};
 
const frequencyValue = (frequencyName = "") => {
  const normalized = frequencyName.toLowerCase().replace(/[^a-z0-9]/g, "");
  if (normalized === "once" || normalized.includes("onetime")) return "once";
  if (
    normalized.includes("biweekly") ||
    normalized.includes("every2weeks") ||
    normalized.includes("2weeks")
  ) return "biweekly";
  if (
    normalized.includes("weekly") ||
    normalized.includes("everyweek") ||
    normalized.includes("onceaweek") ||
    normalized.includes("perweek")
  ) return "weekly";
  if (
    normalized.includes("monthly") ||
    normalized.includes("everymonth") ||
    normalized.includes("onceamonth") ||
    normalized.includes("permonth")
  ) return "monthly";
  return frequencyName.toLowerCase();
};
 
const paymentValue = (paymentMethodName = "") => {
  const normalized = paymentMethodName.toLowerCase().replace(/[^a-z]/g, "");
  if (normalized === "upi") return "upi";
  if (normalized === "card") return "card";
  if (normalized === "cash") return "cash";
  if (normalized.includes("net") || normalized.includes("bank")) return "bank_transfer";
  return paymentMethodName.toLowerCase();
};
 
export default function Workspace({ currentUser, onLogout, mode, setMode }) {
  const role = currentUser.role;
  const initialUrlState = stateFromUrl();
  const [view, setView] = useState(initialUrlState.view);
  const [newBookingDirty, setNewBookingDirty] = useState(false);
  const [customerRegistrationDirty, setCustomerRegistrationDirty] =
    useState(false);
  const [pendingNavigation, setPendingNavigation] = useState(null);
  const [customerView, setCustomerView] = useState(
    initialUrlState.customerView,
  );
  const [selectedDate, setSelectedDate] = useState(toDateStr(new Date()));
  const [customers, setCustomers] = useState([]);
  const [bookings, setBookings] = useState([]);
  const [invoices, setInvoices] = useState([]);
  const [pricing, setPricing] = useState(DEFAULT_PRICING);
  const [pricingRecords, setPricingRecords] = useState([]);
  const [durations, setDurations] = useState(DURATION_BY_BATHROOMS);
  const [serviceDurationRecords, setServiceDurationRecords] = useState([]);
  const [serviceFrequencies, setServiceFrequencies] = useState([]);
  const [serviceSubscriptions, setServiceSubscriptions] = useState([]);
  const [timeSlots, setTimeSlots] = useState([]);
  const [paymentMethods, setPaymentMethods] = useState([]);
  const [paymentAccounts, setPaymentAccounts] = useState([]);
  const [paymentMasters, setPaymentMasters] = useState([]);
  const [bathroomCounts, setBathroomCounts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState("");
  const [successMessage, setSuccessMessage] = useState("");
  const [preferredCustomerId, setPreferredCustomerId] = useState("");
  const [printInvoice, setPrintInvoice] = useState(null);
  const [printServices, setPrintServices] = useState(null);
 
  const navigate = (nextView) => {
    if (nextView === view) return;
    if (view === "new-booking" && newBookingDirty) {
      setPendingNavigation({ view: nextView });
      return;
    }
    if (
      view === "customers" &&
      customerView === "registration" &&
      customerRegistrationDirty
    ) {
      setPendingNavigation({ view: nextView });
      return;
    }
    if (view === "new-booking" && nextView !== "new-booking") {
      setPreferredCustomerId("");
    }
    window.scrollTo({ top: 0, behavior: "auto" });
    setView(nextView);
  };
 
  const discardNewBookingChanges = () => {
    const nextNavigation = pendingNavigation;
    setNewBookingDirty(false);
    setCustomerRegistrationDirty(false);
    setPendingNavigation(null);
    if (nextNavigation) {
      window.scrollTo({ top: 0, behavior: "auto" });
      setView(nextNavigation.view);
      if (nextNavigation.customerView)
        setCustomerView(nextNavigation.customerView);
    }
  };
 
  const changeCustomerView = (nextCustomerView) => {
    if (nextCustomerView === customerView) return;
    if (
      view === "customers" &&
      customerView === "registration" &&
      customerRegistrationDirty
    ) {
      setPendingNavigation({
        view: "customers",
        customerView: nextCustomerView,
      });
      return;
    }
    window.scrollTo({ top: 0, behavior: "auto" });
    setCustomerView(nextCustomerView);
  };
 
  useEffect(() => {
    const syncViewFromUrl = () => {
      const nextState = stateFromUrl();
      setView(nextState.view);
      setCustomerView(nextState.customerView);
    };
    window.addEventListener("hashchange", syncViewFromUrl);
    window.addEventListener("popstate", syncViewFromUrl);
    return () => {
      window.removeEventListener("hashchange", syncViewFromUrl);
      window.removeEventListener("popstate", syncViewFromUrl);
    };
  }, []);
 
  useEffect(() => {
    const nextPath = cleanUrlForState(view, customerView);
    const nextUrl = `${nextPath}${window.location.search}`;
    if (window.location.pathname !== nextPath || window.location.hash) {
      window.history.replaceState({ view, customerView }, "", nextUrl);
    }
  }, [view, customerView]);
 
  const refresh = async () => {
    const results = await Promise.allSettled([
        listCustomers(),
        listBookings(),
        listInvoices(),
        listServiceDurations(),
        listServiceFrequencies(),
        listSubscriptionTypes(),
        listTimeSlots(),
        listPaymentMethods(),
        listPaymentAccounts(),
        listPricing(true),
        listBathroomCounts(),
        listPaymentMasters(),
    ]);
    const failedRequests = results.filter((result) => result.status === "rejected");
    const valueAt = (index, fallback = []) =>
      results[index]?.status === "fulfilled" && Array.isArray(results[index].value)
        ? results[index].value
        : fallback;
    const customersData = valueAt(0);
    const bookingsData = valueAt(1);
    const invoicesData = valueAt(2);
    const durationData = valueAt(3);
    const frequencyData = valueAt(4);
    const subscriptionData = valueAt(5);
    const timeSlotData = valueAt(6).filter((slot) => slot?.startTime && slot?.endTime);
    const paymentMethodData = valueAt(7);
    const paymentAccountData = valueAt(8);
    const pricingData = valueAt(9);
    const bathroomCountData = valueAt(10);
    const paymentMasterData = valueAt(11);
    if (failedRequests.length) {
      const messages = failedRequests
        .map((result) => result.reason?.message)
        .filter(Boolean);
      setError(messages.join("; ") || "Some master data could not be loaded.");
    }
    setCustomers(customersData);
    setBookings(bookingsData);
    setInvoices(invoicesData);
    const sortedDurations = [...durationData].sort(
      (first, second) => first.durationMinutes - second.durationMinutes,
    );
    setServiceDurationRecords(sortedDurations);
    setServiceFrequencies(frequencyData);
    setServiceSubscriptions(subscriptionData);
    setTimeSlots(timeSlotData);
    setPaymentMethods(paymentMethodData);
    setPaymentAccounts(paymentAccountData);
    setBathroomCounts(bathroomCountData);
    setPaymentMasters(paymentMasterData);
    const activePricing = pricingData.filter((record) => record.isActive !== false);
    setPricingRecords(activePricing);
    setPricing(
      activePricing.reduce(
        (pricingMap, record) => {
          const bathroomCount = (record.bathroomCountReference ?? record.bathroomCountId)?.bathroomCount;
          return bathroomCount === undefined
            ? pricingMap
            : { ...pricingMap, [bathroomCount]: record.price };
        },
        {},
      ),
    );
    setDurations(
      sortedDurations.reduce(
        (durationMap, record, index) => ({
          ...durationMap,
          [index + 1]: record.durationMinutes,
        }),
        {},
      ),
    );
  };
 
  useEffect(() => {
    let active = true;
    refresh()
      .catch((err) => {
        if (active) setError(userFriendlyError(err.message));
      })
      .finally(() => {
        if (active) setLoading(false);
      });
    return () => {
      active = false;
    };
  }, []);
 
  const run = async (work, { rethrow = false } = {}) => {
    setError("");
    try {
      const result = await work();
      await refresh();
      return result;
    } catch (err) {
      setError(userFriendlyError(err.message));
      if (rethrow) throw err;
      return null;
    }
  };
 
  const customerById = useMemo(
    () =>
      Object.fromEntries(customers.map((customer) => [customer.id, customer])),
    [customers],
  );
 
  const frequencyOptions = useMemo(
    () =>
      serviceFrequencies
        .filter((frequency) => frequency.isActive !== false)
        .map((frequency) => ({
        id: frequency._id,
        label: frequency.frequencyName,
        value: frequencyValue(frequency.frequencyName),
        intervalDays: frequency.intervalDays,
        intervalDays: frequency.intervalDays,
      })),
    [serviceFrequencies],
  );
 
  const subscriptionOptions = useMemo(
    () =>
      serviceSubscriptions.map((subscription) => ({
        id: subscription._id,
        label: subscription.subscriptionName,
        weeks: subscriptionWeeks(subscription.subscriptionName),
      })),
    [serviceSubscriptions],
  );
 
  const paymentOptions = useMemo(
    () =>
      paymentMethods.map((paymentMethod) => ({
        id: paymentMethod._id,
        label: paymentMethod.paymentMethodName,
        value: paymentValue(paymentMethod.paymentMethodName),
      })),
    [paymentMethods],
  );
 
  const accountOptions = useMemo(
    () =>
      paymentAccounts.map((account) => ({
        id: account._id,
        label: account.accountName,
      })),
    [paymentAccounts],
  );
 
  const createSubscriptionBooking = async ({
    customerId,
    bathroomCount,
    frequency,
    frequencyIntervalDays,
    weeks,
    startDate,
    startTime,
    paymentMode,
    paymentAmount,
    bankType,
    receiverBankId,
    transactionId,
  }) => {
    setSuccessMessage("");
    await run(
      async () => {
        const dates = generateOccurrenceDates(
          startDate,
          frequency,
          weeks,
          frequencyIntervalDays,
        );
        const subscriptionId = crypto.randomUUID();
        const bathroom = bathroomCounts.find(
          (record) => Number(record.bathroomCount) === Number(bathroomCount),
        );
        const duration = serviceDurationRecords.find(
          (record) => record.durationMinutes === durations[bathroomCount],
        );
        const pricingRecord = pricingRecords.find(
          (record) =>
            (record.bathroomCountReference?._id ?? record.bathroomCountId?._id) === bathroom?._id &&
            (record.serviceDurationReference?._id ?? record.serviceDurationId?._id) === duration?._id,
        );
        const frequencyRecord = frequencyOptions.find(
          (option) => option.value === frequency,
        );
        const subscriptionRecord = subscriptionOptions.find(
          (option) => option.weeks === Number(weeks),
        );
        const timeSlot = timeSlots.find((slot) => {
          const toMinutes = (value) => {
            const match = String(value || "")
              .trim()
              .toUpperCase()
              .match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/);
            if (!match) return null;
            let hours = Number(match[1]);
            if (match[3] === "PM" && hours !== 12) hours += 12;
            if (match[3] === "AM" && hours === 12) hours = 0;
            return hours * 60 + Number(match[2]);
          };
          const selectedMinutes = toMinutes(startTime);
          const slotStart = toMinutes(slot.startTime);
          const slotEnd = toMinutes(slot.endTime);
          return (
            selectedMinutes !== null &&
            slotStart !== null &&
            slotEnd !== null &&
            selectedMinutes >= slotStart &&
            selectedMinutes <= slotEnd
          );
        });
        const paymentMethod = paymentOptions.find(
          (option) => option.value === paymentMode,
        );
 
        if (!bathroom?._id || !duration?._id || !pricingRecord?._id) {
          throw new Error("Booking master data is incomplete for this service.");
        }
        if (!timeSlot?._id) {
          throw new Error(
            "Booking selection data is incomplete: select a valid start time.",
          );
        }
 
        const createdBooking = await createBooking({
          customerReference: customerId,
          bathroomCountReference: bathroom._id,
          pricingReference: pricingRecord._id,
          serviceDurationReference: duration._id,
          serviceFrequencyReference: frequencyRecord?.id ?? null,
          subscriptionTypeReference: subscriptionRecord?.id ?? null,
          timeSlotReference: timeSlot._id,
          bookingDate: dates[0],
          startTime,
          paymentMethodReference: paymentMethod?.id ?? null,
          paymentAccountReference: receiverBankId || null,
          transactionId,
          totalServiceVisits: dates.length,
          scheduleIntervalDays: frequencyRecord?.intervalDays || null,
        });

        if (!createdBooking?.booking) {
          throw new Error("No booking was created for this subscription.");
        }
      },
      { rethrow: true },
    );
    setPreferredCustomerId("");
    setSuccessMessage("Booking created successfully.");
  };
 
  const createCustomer = async (data) => {
    const customer = await run(() => createCustomerRequest(data), {
      rethrow: true,
    });
    if (customer) setPreferredCustomerId(customer.id);
    return customer;
  };
 
  const updateCustomer = async (customerId, data) =>
    run(() => updateCustomerRequest(customerId, data), { rethrow: true });
 
  const openServiceBooking = () => {
    setCustomerRegistrationDirty(false);
    setPendingNavigation(null);
    window.scrollTo({ top: 0, behavior: "auto" });
    setView("new-booking");
  };
 
  const cancelBooking = async (bookingId) => {
    if (role !== "superadmin") return;
    await run(() => cancelBookingRequest(bookingId), { rethrow: true });
  };
 
  const dayBookings = useMemo(
    () =>
      bookings
        .filter(
          (booking) =>
            booking.date === selectedDate &&
            booking.status !== "cancelled" &&
            booking.status !== "conflict" &&
            booking.startTime,
        )
        .sort((a, b) => timeToMin(a.startTime) - timeToMin(b.startTime)),
    [bookings, selectedDate],
  );
 
  const navbarProps = {
    view,
    setView,
    onNavigate: navigate,
    customerView,
    onCustomerViewChange: changeCustomerView,
    currentUser,
    onLogout,
    mode,
    setMode,
  };
 
  if (loading) {
    return (
      <Navbar {...navbarProps}>
        <Box sx={{ py: 8, textAlign: "center" }}>
          <CircularProgress />
        </Box>
      </Navbar>
    );
  }
 
  return (
    <Navbar {...navbarProps}>
      <Snackbar
        open={Boolean(error)}
        autoHideDuration={5000}
        onClose={() => setError("")}
        anchorOrigin={{ vertical: "bottom", horizontal: "right" }}
      >
        <Alert severity="error" variant="filled" onClose={() => setError("")}>
          {error}
        </Alert>
      </Snackbar>
      <Snackbar
        open={Boolean(successMessage)}
        autoHideDuration={3500}
        onClose={() => setSuccessMessage("")}
        message={successMessage}
      />
 
      {view === "dashboard" && (
        <DashboardPage
          key={view}
          bookings={bookings}
          customers={customers}
          invoices={invoices}
          customerById={customerById}
          durationByBathrooms={durations}
          goToCalendar={() => setView("calendar")}
          goToCustomerRegistration={() => {
            changeCustomerView("registration");
            navigate("customers");
          }}
        />
      )}
      {view === "calendar" && (
        <CalendarPage
          key={view}
          selectedDate={selectedDate}
          setSelectedDate={setSelectedDate}
          dayBookings={dayBookings}
          bookings={bookings}
          customerById={customerById}
          role={role}
          run={run}
          onCancel={cancelBooking}
          onPrintServices={(data) => setPrintServices(data)}
          durationByBathrooms={durations}
        />
      )}
      {view === "new-booking" && (
        <NewBookingPage
          key={view}
          customers={customers}
          bookings={bookings}
          pricing={pricing}
          onSubmit={createSubscriptionBooking}
          preferredCustomerId={preferredCustomerId}
          durationByBathrooms={durations}
          frequencyOptions={frequencyOptions}
          subscriptionOptions={subscriptionOptions}
          timeSlots={timeSlots}
          paymentOptions={paymentOptions}
          paymentMaster={paymentMasters[0] ?? null}
          accountOptions={accountOptions}
          onBack={() => setView("calendar")}
          onDirtyChange={setNewBookingDirty}
        />
      )}
      {view === "customers" && (
        <CustomersPage
          key={`${view}-${customerView}`}
          customers={customers}
          bookings={bookings}
          invoices={invoices}
          customerView={customerView}
          onCustomerViewChange={changeCustomerView}
          onDirtyChange={setCustomerRegistrationDirty}
          onAddCustomer={createCustomer}
          onUpdateCustomer={updateCustomer}
          onPrintInvoice={setPrintInvoice}
          onCustomerCreated={openServiceBooking}
        />
      )}
      {view === "invoices" && (
        <InvoicesPage
          key={view}
          invoices={invoices}
          customerById={customerById}
          bookings={bookings}
          onPrint={setPrintInvoice}
        />
      )}
      {view === "analytics" && (
        <AnalyticsPage key={view} invoices={invoices} bookings={bookings} />
      )}
      {view === "settings" && (
        <SettingsPage
          key={view}
          pricing={pricing}
          durations={durations}
          pricingRecords={pricingRecords}
          serviceDurationRecords={serviceDurationRecords}
          run={run}
        />
      )}
 
      <PrintManager
        invoice={printInvoice}
        services={printServices}
        onPrintComplete={() => {
          setPrintInvoice(null);
          setPrintServices(null);
        }}
      />
 
      <UnsavedChangesDialog
        open={Boolean(pendingNavigation)}
        onDiscard={discardNewBookingChanges}
        onCancel={() => setPendingNavigation(null)}
      />
    </Navbar>
  );
}
