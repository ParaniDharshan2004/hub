export const BRAND = {
  black: '#111111',
  greenDark: '#0F5C57',
};
