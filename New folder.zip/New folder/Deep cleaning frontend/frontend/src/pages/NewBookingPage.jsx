import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import Stack from "@mui/material/Stack";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutlined";
import { createBooking } from "../api/bookings.js";
import { generateOccurrenceDates } from "../utils/scheduling.js";
import NewBookingForm from "../components/booking-components/NewBookingForm.jsx";

const frequencyValue = (frequencyName = "") => {
  const normalized = frequencyName.toLowerCase().replace(/[^a-z0-9]/g, "");
  if (normalized === "once" || normalized.includes("onetime")) return "once";
  if (
    normalized.includes("biweekly") ||
    normalized.includes("every2weeks") ||
    normalized.includes("2weeks")
  )
    return "biweekly";
  if (
    normalized.includes("weekly") ||
    normalized.includes("everyweek") ||
    normalized.includes("onceaweek") ||
    normalized.includes("perweek")
  )
    return "weekly";
  if (
    normalized.includes("monthly") ||
    normalized.includes("everymonth") ||
    normalized.includes("onceamonth") ||
    normalized.includes("permonth")
  )
    return "monthly";
  return frequencyName.toLowerCase();
};

export default function NewBookingPage({
  customers,
  bookings,
  pricing,
  onSubmit,
  preferredCustomerId,
  durationByBathrooms,
  frequencyOptions,
  subscriptionOptions,
  timeSlots,
  paymentOptions,
  paymentMaster,
  accountOptions,
  bathroomCounts,
  serviceDurationRecords,
  pricingRecords,
  durations,
  run,
  setPreferredCustomerId,
  setSuccessMessage,
  onDirtyChange,
}) {
  // Creates the selected bookings and their invoice from the booking form.
  const createSubscriptionBooking = async ({
    customerId,
    bathroomCount,
    frequency,
    frequencyId,
    weeks,
    startDate,
    startTime,
    paymentMode,
    paymentAmount,
    receiverBankId,
    transactionId,
  }) => {
    setSuccessMessage("");
    await run(
      async () => {
        const dates = generateOccurrenceDates(startDate, frequency, weeks);
        const bathroom = bathroomCounts.find(
          (record) => Number(record.bathroomCount) === Number(bathroomCount),
        );
        const duration = serviceDurationRecords.find(
          (record) => record.durationMinutes === durations[bathroomCount],
        );
        const pricingRecord = pricingRecords.find(
          (record) =>
            record.bathroomCountId?._id === bathroom?._id &&
            record.serviceDurationId?._id === duration?._id,
        );
        const subscriptionRecord = subscriptionOptions.find(
          (option) => option.weeks === Number(weeks),
        );
        const timeSlot = timeSlots.find((slot) => {
          const toMinutes = (value) => {
            const match = String(value || "")
              .trim()
              .toUpperCase()
              .match(/^(\d{1,2}):(\d{2})\s*(AM|PM)?$/);
            if (!match) return null;
            let hours = Number(match[1]);
            if (match[3] === "PM" && hours !== 12) hours += 12;
            if (match[3] === "AM" && hours === 12) hours = 0;
            return hours * 60 + Number(match[2]);
          };
          const selectedMinutes = toMinutes(startTime);
          const slotStart = toMinutes(slot.startTime);
          const slotEnd = toMinutes(slot.endTime);
          return (
            selectedMinutes !== null &&
            slotStart !== null &&
            slotEnd !== null &&
            selectedMinutes >= slotStart &&
            selectedMinutes <= slotEnd
          );
        });
        const paymentMethod = paymentOptions.find(
          (option) => option.value === paymentMode,
        );

        if (!bathroom?._id || !duration?._id || !pricingRecord?._id) {
          throw new Error(
            "Booking master data is incomplete for this service.",
          );
        }
        if (!timeSlot?._id) {
          throw new Error(
            "Booking selection data is incomplete: select a valid start time.",
          );
        }

        const createdBookings = await Promise.all(
          dates.map(async (date) => {
            const createdBooking = await createBooking({
              customerId,
              bathroomCountId: bathroom._id,
              pricingId: pricingRecord._id,
              serviceDurationId: duration._id,
              serviceFrequencyId: frequencyId ?? null,
              subscriptionTypeId: subscriptionRecord?.id ?? null,
              timeSlotId: timeSlot._id,
              bookingDate: date,
              startTime,
              paymentMethodId: paymentMethod?.id ?? null,
              receiverBankId: receiverBankId || null,
              transactionId,
              amount: Number(paymentAmount),
            });
            return createdBooking.booking ?? createdBooking;
          }),
        );

        if (createdBookings.filter(Boolean).length === 0) {
          throw new Error("No bookings were created for this subscription.");
        }

        await createInvoice({
          customerId,
          bookingIds: createdBookings
            .map((booking) => booking?._id ?? booking?.id ?? booking?.bookingId)
            .filter(Boolean),
          amount: Number(paymentAmount),
        });
      },
      { rethrow: true },
    );
    setPreferredCustomerId("");
    setSuccessMessage("Booking created successfully.");
  };

  return (
    <Box sx={{ width: "100%", maxWidth: 980, mr: "auto" }}>
      
      <Stack direction="row" spacing={1.25} alignItems="center" sx={{ mb: 1 }}>
        <AddCircleOutlineIcon color="primary" />
        <Typography variant="h5" sx={{ fontWeight: 800, lineHeight: 1.1 }}>
          Service Booking
        </Typography>
      </Stack>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Manage customer service orders and recurring plans.
      </Typography>
      <Paper
        variant="outlined"
        sx={{ p: { xs: 2, sm: 3 }, }}
      >
        <NewBookingForm
          customers={customers}
          bookings={bookings}
          pricing={pricing}
          onSubmit={onSubmit}
          preferredCustomerId={preferredCustomerId}
          durationByBathrooms={durationByBathrooms}
          frequencyOptions={frequencyOptions}
          subscriptionOptions={subscriptionOptions}
          timeSlots={timeSlots}
          paymentOptions={paymentOptions}
          paymentMaster={paymentMaster}
          accountOptions={accountOptions}
          onDirtyChange={onDirtyChange}
        />
      </Paper>
    </Box>
  );
}
