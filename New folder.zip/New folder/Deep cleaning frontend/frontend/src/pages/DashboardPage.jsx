import Box from "@mui/material/Box";
import SummaryCards from "../components/dashboard-components/SummaryCards.jsx";
import BookingSchedule from "../components/dashboard-components/BookingSchedule.jsx";

export default function DashboardPage({
  bookings,
  customers,
  customerById,
  goToCalendar,
  goToCustomerRegistration,
  durationByBathrooms,
}) {
  return (
    <Box>
      
      <SummaryCards bookings={bookings} customers={customers} />
      <BookingSchedule
        bookings={bookings}
        customerById={customerById}
        goToCalendar={goToCalendar}
        goToCustomerRegistration={goToCustomerRegistration}
        durationByBathrooms={durationByBathrooms}
      />
    </Box>
  );
}
