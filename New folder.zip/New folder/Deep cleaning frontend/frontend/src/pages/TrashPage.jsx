import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Stack from "@mui/material/Stack";
import Divider from "@mui/material/Divider";
import RestoreIcon from "@mui/icons-material/Restore";
import { fmtDateHuman, fmtTime12 } from "../utils/scheduling.js";

export default function TrashPage({ bookings, customerById, role, onRestore }) {
  const cancelled = bookings.filter((b) => b.status === "cancelled");
  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Cancelled bookings
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Cancelled visits move here instead of cluttering the calendar. Only
        super admins can restore.
      </Typography>
      {cancelled.length === 0 ? (
        <Paper variant="outlined" sx={{ p: 5, textAlign: "center" }}>
          <Typography variant="body2" color="text.secondary">
            Nothing cancelled.
          </Typography>
        </Paper>
      ) : (
        <Paper variant="outlined">
          <Stack divider={<Divider />}>
            {cancelled.map((b) => (
              <Stack
                key={b.id}
                direction="row"
                justifyContent="space-between"
                alignItems="center"
                spacing={2}
                sx={{ px: 2.5, py: 1.75 }}
              >
                <Box minWidth={0}>
                  <Typography variant="body2" fontWeight={600} noWrap>
                    {customerById[b.customerId]?.name || "Unknown"}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {fmtDateHuman(b.date)}
                    {b.startTime ? ` · ${fmtTime12(b.startTime)}` : ""} ·{" "}
                    {b.bathroomCount} bath{b.bathroomCount > 1 ? "s" : ""}
                  </Typography>
                </Box>
                <Button
                  size="small"
                  variant="outlined"
                  startIcon={<RestoreIcon />}
                  disabled={role !== "superadmin"}
                  onClick={() => onRestore(b.id)}
                >
                  Restore
                </Button>
              </Stack>
            ))}
          </Stack>
        </Paper>
      )}
    </Box>
  );
}
