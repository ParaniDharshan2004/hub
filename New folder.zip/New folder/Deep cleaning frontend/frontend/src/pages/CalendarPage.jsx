import { useState } from "react";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import Box from "@mui/material/Box";
import CalendarHeader from "../components/calendar-components/CalendarHeader.jsx";
import CalendarDatePicker from "../components/calendar-components/CalendarDatePicker.jsx";
import RouteByBlock from "../components/calendar-components/RouteByBlock.jsx";
import DayTimeline from "../components/calendar-components/DayTimeline.jsx";
import BookingDetailsDialog from "../components/calendar-components/BookingDetailsDialog.jsx";
import { toDateStr, fmtDateHuman, fmtTime12 } from "../utils/scheduling.js";
import ConfirmDialog from "../components/common-components/ConfirmDialog.jsx";
import RescheduleForm from "../components/calendar-components/RescheduleForm.jsx";
import CompleteJobForm from "../components/calendar-components/CompleteJobForm.jsx";
import {
  updateBooking,
  completeBooking as completeBookingRequest,
} from "../api/bookings.js";

export default function CalendarPage({
  selectedDate,
  setSelectedDate,
  dayBookings,
  bookings,
  customerById,
  role,
  run,
  onCancel,
  onPrintServices,
  durationByBathrooms,
}) {
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [rescheduleTarget, setRescheduleTarget] = useState(null);
  const [completeTarget, setCompleteTarget] = useState(null);
  const [cancelTarget, setCancelTarget] = useState(null);
  const monthCursor = selectedDate.slice(0, 7);
  const activeBookings = dayBookings.filter((booking) => booking.status !== "cancelled");
  const completedCount = activeBookings.filter((booking) => booking.status === "completed").length;
  const conflictCount = activeBookings.filter((booking) => booking.status === "conflict").length;
  const today = toDateStr(new Date());

  const rescheduleBooking = async (bookingId, newDate, newTime) => {
    await run(
      () => updateBooking(bookingId, { bookingDate: newDate, startTime: newTime }),
      { rethrow: true },
    );
  };

  const completeBooking = async (bookingId, photoDataUrl) => {
    await run(() => completeBookingRequest(bookingId, photoDataUrl), {
      rethrow: true,
    });
  };

  return (
    <Box sx={{ pb: 3 }}>
      <CalendarHeader
        selectedDate={selectedDate}
        onToday={() => setSelectedDate(today)}
        totalCount={activeBookings.length}
        completedCount={completedCount}
        conflictCount={conflictCount}
      />

      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "minmax(0, 1fr)",
            lg: "minmax(0, 3.6fr) minmax(0, 8.4fr)",
          },
          gridTemplateAreas: {
            xs: '"picker" "timeline" "route"',
            lg: '"picker timeline" "route timeline"',
          },
          gridTemplateRows: {
            lg: "auto 1fr",
          },
          gap: { xs: 2, lg: 2.5 },
          alignItems: "start",
        }}
      >
        <Box sx={{ gridArea: "timeline", minWidth: 0 }}>
          <DayTimeline
            selectedDate={selectedDate}
            setSelectedDate={setSelectedDate}
            dayBookings={dayBookings}
            customerById={customerById}
            role={role}
            today={today}
            onReschedule={setRescheduleTarget}
            onCancel={setCancelTarget}
            onComplete={setCompleteTarget}
            durationByBathrooms={durationByBathrooms}
            onBookingClick={setSelectedBooking}
          />
        </Box>

        <Box sx={{ gridArea: "picker", minWidth: 0 }}>
          <CalendarDatePicker
            monthCursor={monthCursor}
            selectedDate={selectedDate}
            setSelectedDate={setSelectedDate}
            bookings={bookings}
          />
        </Box>

        <Box sx={{ gridArea: "route", minWidth: 0 }}>
          <RouteByBlock
            bookings={dayBookings}
            customerById={customerById}
            selectedDate={selectedDate}
            onPrintServices={onPrintServices}
          />
        </Box>
      </Box>

      <BookingDetailsDialog
        booking={selectedBooking}
        customerById={customerById}
        durationByBathrooms={durationByBathrooms}
        onClose={() => setSelectedBooking(null)}
      />

      <Dialog open={!!rescheduleTarget} onClose={() => setRescheduleTarget(null)} fullWidth maxWidth="xs">
        <DialogTitle>Reschedule booking</DialogTitle>
        <DialogContent>
          {rescheduleTarget && <RescheduleForm booking={rescheduleTarget} bookings={bookings} customerById={customerById} onSubmit={async (...args) => { await rescheduleBooking(...args); setRescheduleTarget(null); }} />}
        </DialogContent>
      </Dialog>

      <Dialog open={!!completeTarget} onClose={() => setCompleteTarget(null)} fullWidth maxWidth="xs">
        <DialogTitle>Mark job completed</DialogTitle>
        <DialogContent>
          {completeTarget && <CompleteJobForm booking={completeTarget} customerById={customerById} onSubmit={async (...args) => { await completeBooking(...args); setCompleteTarget(null); }} />}
        </DialogContent>
      </Dialog>

      <ConfirmDialog
        open={!!cancelTarget}
        title="Cancel this booking?"
        message={cancelTarget ? `This will cancel ${customerById[cancelTarget.customerId]?.name || "this customer"}'s visit on ${fmtDateHuman(cancelTarget.date)}${cancelTarget.startTime ? ` at ${fmtTime12(cancelTarget.startTime)}` : ""}. You can restore it later from Cancelled.` : ""}
        confirmLabel="Yes, cancel booking"
        onConfirm={async () => { await onCancel(cancelTarget.id); setCancelTarget(null); }}
        onClose={() => setCancelTarget(null)}
      />

    </Box>
  );
}