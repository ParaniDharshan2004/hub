import { useMemo } from "react";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Paper from "@mui/material/Paper";
import Typography from "@mui/material/Typography";
import {
  BarChart,
  Bar,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from "recharts";
import { BRAND } from "../constants.js";
import { fmtMoney } from "../utils/scheduling.js";

export default function AnalyticsPage({ invoices, bookings }) {
  const revenueByMonth = useMemo(() => {
    const m = {};
    invoices
      .filter((i) => i.status === "paid")
      .forEach((i) => {
        const ym = (i.paidDate || i.createdDate).slice(0, 7);
        m[ym] = (m[ym] || 0) + i.amount;
      });
    return Object.entries(m)
      .sort(([a], [b]) => a.localeCompare(b))
      .map(([month, revenue]) => ({ month, revenue }));
  }, [invoices]);

  const jobsByBathroomCount = useMemo(() => {
    const m = {};
    bookings
      .filter((b) => b.status !== "cancelled")
      .forEach((b) => {
        m[b.bathroomCount] = (m[b.bathroomCount] || 0) + 1;
      });
    return [1, 2, 3, 4].map((n) => ({ toilets: `${n}`, jobs: m[n] || 0 }));
  }, [bookings]);

  const totalRevenue = revenueByMonth.reduce((s, r) => s + r.revenue, 0);
  const completedJobs = bookings.filter((b) => b.status === "completed").length;

  return (
    <Box>
      <Typography variant="h5" gutterBottom>
        Analytics
      </Typography>
      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
        Revenue and job-mix trends.
      </Typography>

      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={6}>
          <Paper variant="outlined" sx={{ p: 2 }}>
            <Typography variant="h6">{fmtMoney(totalRevenue)}</Typography>
            <Typography variant="caption" color="text.secondary">
              Total collected
            </Typography>
          </Paper>
        </Grid>
        <Grid item xs={6}>
          <Paper variant="outlined" sx={{ p: 2 }}>
            <Typography variant="h6">{completedJobs}</Typography>
            <Typography variant="caption" color="text.secondary">
              Jobs completed
            </Typography>
          </Paper>
        </Grid>
      </Grid>

      <Paper variant="outlined" sx={{ p: 2.5, mb: 3, height: 280 }}>
        <Typography variant="subtitle2" sx={{ mb: 2 }}>
          Revenue by month
        </Typography>
        {revenueByMonth.length === 0 ? (
          <Typography
            variant="body2"
            color="text.secondary"
            sx={{ textAlign: "center", py: 6 }}
          >
            No paid invoices yet.
          </Typography>
        ) : (
          <ResponsiveContainer width="100%" height="85%">
            <LineChart data={revenueByMonth}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="month" tick={{ fontSize: 11 }} />
              <YAxis tick={{ fontSize: 11 }} />
              <Tooltip formatter={(v) => fmtMoney(v)} />
              <Line
                type="monotone"
                dataKey="revenue"
                stroke={BRAND.green}
                strokeWidth={2}
                dot={{ r: 3 }}
              />
            </LineChart>
          </ResponsiveContainer>
        )}
      </Paper>

      <Paper variant="outlined" sx={{ p: 2.5, height: 280 }}>
        <Typography variant="subtitle2" sx={{ mb: 2 }}>
          Jobs by bathroom count
        </Typography>
        <ResponsiveContainer width="100%" height="85%">
          <BarChart data={jobsByBathroomCount}>
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis dataKey="bathrooms" tick={{ fontSize: 11 }} />
            <YAxis tick={{ fontSize: 11 }} allowDecimals={false} />
            <Tooltip />
            <Bar dataKey="jobs" fill={BRAND.orange} radius={[4, 4, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </Paper>
    </Box>
  );
}
