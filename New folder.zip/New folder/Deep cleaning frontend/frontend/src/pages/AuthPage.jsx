import { useState } from "react";
import Box from "@mui/material/Box";
import Paper from "@mui/material/Paper";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import Alert from "@mui/material/Alert";
import Typography from "@mui/material/Typography";
import Stack from "@mui/material/Stack";
import jollyLogo from "../assets/logo/Jollydark.png";

export default function AuthPage({ onLogIn }) {
  const [error, setError] = useState("");
  const [loginEmail, setLoginEmail] = useState("admin@demo.com");
  const [loginPassword, setLoginPassword] = useState("admin123");

  const handleLogIn = async () => {
    try {
      await onLogIn(loginEmail, loginPassword);
    } catch (err) {
      setError(err.message);
    }
  };

  return (
    <Box
      sx={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        p: 2,
        bgcolor: "background.default",
      }}
    >
      <Paper
        elevation={0}
        sx={{
          p: 4,
          width: "100%",
          maxWidth: 380,
          border: 1,
          borderColor: "divider",
        }}
      >
        <Box sx={{ display: "flex", justifyContent: "center", mb: 3 }}>
          <Box
            component="img"
            src={jollyLogo}
            alt="Jolly Home Needs"
            sx={{ display: "block", width: 190, maxWidth: "100%", height: "auto" }}
          />
        </Box>

        {error && (
          <Alert severity="error" sx={{ mb: 2 }}>
            {error}
          </Alert>
        )}

        <Stack spacing={2}>
          <TextField
            label="Email"
            type="email"
            size="small"
            value={loginEmail}
            onChange={(e) => setLoginEmail(e.target.value)}
            fullWidth
          />
          <TextField
            label="Password"
            type="password"
            size="small"
            value={loginPassword}
            onChange={(e) => setLoginPassword(e.target.value)}
            fullWidth
          />
          <Button variant="contained" onClick={handleLogIn}>
            Log in
          </Button>
        </Stack>

        <Typography
          variant="caption"
          color="text.secondary"
          sx={{ display: "block", textAlign: "center", mt: 3 }}
        >
          Demo admin: admin@demo.com / admin123
        </Typography>
      </Paper>
    </Box>
  );
}
