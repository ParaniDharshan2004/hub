import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import MenuItem from '@mui/material/MenuItem';
import InputAdornment from '@mui/material/InputAdornment';
import LinearProgress from '@mui/material/LinearProgress';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import { DataGrid } from '@mui/x-data-grid';
import SearchIcon from '@mui/icons-material/Search';

import PageHeader from '../../components/PageHeader';
import EntityLink from '../../components/EntityLink';
import StatusChip from '../../components/StatusChip';
import { EmptyState, ErrorState } from '../../components/PageStates';
import { listSubscriptions } from '../../api/subscriptions';
import { serviceAreas, plans, serviceOfferings } from '../../api/masters';
import { formatDate } from '../../utils/format';

/**
 * SubscriptionListPage Component
 * Tracks active recurring cleaning subscriptions, service counts, and renewal alerts.
 */
export default function SubscriptionListPage() {
  const navigate = useNavigate();
  const [search, setSearch] = useState('');
  const [status, setStatus] = useState('All');

  /** Query subscriptions data with live search and filter parameters */
  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['subscriptions', search, status],
    queryFn: () => listSubscriptions({ search, status }),
  });

  /** Define subscription DataGrid columns */
  const columns = useMemo(
    () => [
      {
        field: 'subscriptionNumber',
        headerName: 'Subscription ID',
        width: 170,
        renderCell: (p) => <EntityLink type="Subscription" id={p.value} />,
      },
      {
        field: 'customer',
        headerName: 'Customer',
        flex: 1,
        minWidth: 160,
        renderCell: (p) => (
          <Typography variant="body2" sx={{ fontWeight: 600, color: 'text.primary' }}>
            {p.row.customer ? p.row.customer.name : '—'}
          </Typography>
        ),
      },
      {
        field: 'address',
        headerName: 'Address / Area',
        width: 170,
        valueGetter: (v, row) =>
          row.address ? `${row.address.label}, ${serviceAreas.find((a) => a.id === row.address.area)?.name || ''}` : '—',
      },
      {
        field: 'offeringId',
        headerName: 'Offering',
        width: 160,
        valueGetter: (v, row) => serviceOfferings.find((o) => o.id === row.offeringId)?.name || '—',
      },
      {
        field: 'plan',
        headerName: 'Current Plan',
        width: 150,
        valueGetter: (v, row) => (row.currentPeriod ? plans.find((p) => p.id === row.currentPeriod.planId)?.name : '—'),
      },
      {
        field: 'progress',
        headerName: 'Visits Delivered',
        width: 160,
        sortable: false,
        renderCell: (params) => {
          const period = params.row.currentPeriod;
          if (!period) return '—';
          const pct = Math.round((period.completedServices / period.totalServices) * 100);
          return (
            <Box sx={{ width: '100%', py: 1 }}>
              <Stack direction="row" justifyContent="space-between" sx={{ mb: 0.5 }}>
                <Typography variant="caption" color="text.secondary" sx={{ fontWeight: 600 }}>
                  {period.completedServices} / {period.totalServices} visits
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  {pct}%
                </Typography>
              </Stack>
              <LinearProgress
                variant="determinate"
                value={pct}
                sx={{
                  height: 6,
                  borderRadius: 3,
                  bgcolor: '#EAF3F1',
                  '& .MuiLinearProgress-bar': { bgcolor: 'primary.main', borderRadius: 3 },
                }}
              />
            </Box>
          );
        },
      },
      {
        field: 'endDate',
        headerName: 'Period End',
        width: 120,
        valueGetter: (v, row) => (row.currentPeriod ? formatDate(row.currentPeriod.endDate) : '—'),
      },
      {
        field: 'nextVisit',
        headerName: 'Next Visit',
        width: 120,
        valueGetter: (v, row) => (row.nextVisit ? formatDate(row.nextVisit.date) : '—'),
      },
      { field: 'status', headerName: 'Status', width: 110, renderCell: (p) => <StatusChip status={p.value} /> },
      {
        field: 'renewalStatus',
        headerName: 'Renewal Status',
        width: 160,
        renderCell: (p) => <StatusChip status={p.value} />,
      },
    ],
    []
  );

  return (
    <>
      <PageHeader
        title="Subscriptions"
        subtitle="Manage active customer recurring packages, service fulfillment, and renewal alerts."
      />

      {/* Filter Bar */}
      <Paper variant="outlined" sx={{ p: 2, mb: 2.5, borderRadius: 3 }}>
        <Stack direction={{ xs: 'column', sm: 'row' }} spacing={1.5}>
          <TextField
            size="small"
            placeholder="Search Subscription ID or Customer Name..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            sx={{ flex: 1, minWidth: 240 }}
            InputProps={{
              startAdornment: (
                <InputAdornment position="start">
                  <SearchIcon fontSize="small" sx={{ color: 'text.secondary' }} />
                </InputAdornment>
              ),
            }}
          />
          <TextField select size="small" label="Status" value={status} onChange={(e) => setStatus(e.target.value)} sx={{ width: 160 }}>
            <MenuItem value="All">All Statuses</MenuItem>
            <MenuItem value="Active">Active</MenuItem>
            <MenuItem value="Inactive">Inactive</MenuItem>
          </TextField>
        </Stack>
      </Paper>

      {/* Data Table */}
      <Paper variant="outlined" sx={{ height: 580, borderRadius: 3, overflow: 'hidden' }}>
        {isError ? (
          <ErrorState message={error.message} onRetry={refetch} />
        ) : !isLoading && (data?.length ?? 0) === 0 ? (
          <EmptyState
            title="No subscriptions found"
            description="Subscriptions are automatically initialized when commercial bookings are confirmed."
          />
        ) : (
          <DataGrid
            rows={data || []}
            columns={columns}
            loading={isLoading}
            disableRowSelectionOnClick
            onRowClick={(p) => navigate(`/subscriptions/${p.row.subscriptionNumber}`)}
            sx={{
              border: 'none',
              '& .MuiDataGrid-row': { cursor: 'pointer', '&:hover': { bgcolor: '#F3F7F6' } },
              '& .MuiDataGrid-columnHeaders': { bgcolor: '#F3F7F6' },
            }}
            initialState={{ pagination: { paginationModel: { pageSize: 10 } } }}
            pageSizeOptions={[10, 25, 50]}
            getRowHeight={() => 60}
          />
        )}
      </Paper>
    </>
  );
}

