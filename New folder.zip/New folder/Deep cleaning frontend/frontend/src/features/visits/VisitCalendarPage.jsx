/**
 * VisitCalendarPage.jsx
 * -----------------------------------------------------------------------
 * Monthly calendar view displaying daily visit density, completion status,
 * and quick navigation to daily visit logs.
 * -----------------------------------------------------------------------
 */

import { useMemo, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import dayjs from "dayjs";
import Paper from "@mui/material/Paper";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import Button from "@mui/material/Button";
import Chip from "@mui/material/Chip";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import TodayIcon from "@mui/icons-material/Today";

import PageHeader from "../../components/PageHeader";
import { LoadingSkeleton, ErrorState } from "../../components/PageStates";
import { listVisits } from "../../api/visits";

const WEEKDAYS = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"];

/**
 * Visits monthly calendar overview page component.
 */
export default function VisitCalendarPage() {
  const navigate = useNavigate();
  const [cursor, setCursor] = useState(dayjs().startOf("month"));

  const monthStart = cursor.startOf("month");
  const monthEnd = cursor.endOf("month");
  const gridStart = monthStart.startOf("week");
  const gridEnd = monthEnd.endOf("week");

  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ["visits", "calendar", monthStart.format("YYYY-MM")],
    queryFn: () =>
      listVisits({
        dateFrom: gridStart.format("YYYY-MM-DD"),
        dateTo: gridEnd.format("YYYY-MM-DD"),
      }),
  });

  /** Computes 7x5 or 7x6 array of dates covering full calendar grid */
  const days = useMemo(() => {
    const arr = [];
    let d = gridStart;
    while (d.isBefore(gridEnd) || d.isSame(gridEnd, "day")) {
      arr.push(d);
      d = d.add(1, "day");
    }
    return arr;
  }, [gridStart, gridEnd]);

  /** Groups visits by date key (YYYY-MM-DD) for rendering day badges */
  const visitsByDay = useMemo(() => {
    const map = {};
    (data || []).forEach((v) => {
      const key = dayjs(v.date).format("YYYY-MM-DD");
      map[key] = map[key] || { total: 0, completed: 0 };
      map[key].total += 1;
      if (v.status === "Completed") map[key].completed += 1;
    });
    return map;
  }, [data]);

  if (isError) {
    return (
      <Box sx={{ p: { xs: 2, sm: 3.5 } }}>
        <ErrorState message={error.message} onRetry={refetch} />
      </Box>
    );
  }

  return (
    <Box
      sx={{
        bgcolor: "background.default",
        minHeight: "100vh",
        p: { xs: 2, sm: 3.5 },
      }}
    >
      <PageHeader
        title="Visits Calendar"
        subtitle="Monthly schedule of service operations and field visit completion density."
        actions={
          <Stack direction="row" spacing={1} alignItems="center">
            <Button
              size="small"
              variant="outlined"
              startIcon={<TodayIcon />}
              onClick={() => setCursor(dayjs().startOf("month"))}
            >
              Today
            </Button>
            <IconButton
              size="small"
              onClick={() => setCursor((c) => c.subtract(1, "month"))}
              aria-label="Previous month"
            >
              <ChevronLeftIcon />
            </IconButton>
            <Typography
              variant="subtitle2"
              sx={{ minWidth: 130, textAlign: "center", fontWeight: 700 }}
            >
              {cursor.format("MMMM YYYY")}
            </Typography>
            <IconButton
              size="small"
              onClick={() => setCursor((c) => c.add(1, "month"))}
              aria-label="Next month"
            >
              <ChevronRightIcon />
            </IconButton>
          </Stack>
        }
      />

      {isLoading ? (
        <LoadingSkeleton rows={6} />
      ) : (
        <Paper variant="outlined" sx={{ overflow: "hidden", borderRadius: 3 }}>
          <Box
            sx={{
              display: "grid",
              gridTemplateColumns: "repeat(7, 1fr)",
              bgcolor: "#F3F7F6",
            }}
          >
            {WEEKDAYS.map((w) => (
              <Box
                key={w}
                sx={{
                  p: 1.5,
                  textAlign: "center",
                  borderBottom: "1px solid",
                  borderColor: "divider",
                }}
              >
                <Typography
                  variant="caption"
                  color="text.secondary"
                  sx={{
                    fontWeight: 700,
                    textTransform: "uppercase",
                    letterSpacing: "0.5px",
                  }}
                >
                  {w}
                </Typography>
              </Box>
            ))}
          </Box>
          <Box sx={{ display: "grid", gridTemplateColumns: "repeat(7, 1fr)" }}>
            {days.map((d) => {
              const key = d.format("YYYY-MM-DD");
              const info = visitsByDay[key];
              const inMonth = d.isSame(monthStart, "month");
              const isToday = d.isSame(dayjs(), "day");
              return (
                <Box
                  key={key}
                  onClick={() => navigate(`/visits/day/${key}`)}
                  sx={{
                    minHeight: 100,
                    p: 1.25,
                    borderRight: "1px solid",
                    borderBottom: "1px solid",
                    borderColor: "divider",
                    opacity: inMonth ? 1 : 0.35,
                    cursor: "pointer",
                    bgcolor: isToday ? "rgba(15, 92, 87, 0.05)" : "transparent",
                    transition: "background-color 0.15s ease",
                    "&:hover": { bgcolor: "rgba(15, 92, 87, 0.08)" },
                  }}
                >
                  <Typography
                    variant="caption"
                    sx={{
                      fontWeight: isToday ? 700 : 500,
                      color: isToday ? "primary.main" : "text.primary",
                    }}
                  >
                    {d.format("D")}
                  </Typography>
                  {info && (
                    <Stack spacing={0.5} sx={{ mt: 0.75 }}>
                      <Chip
                        size="small"
                        label={`${info.total} visit${info.total === 1 ? "" : "s"}`}
                        color={
                          info.completed === info.total ? "success" : "info"
                        }
                        variant="outlined"
                        sx={{
                          fontSize: "0.65rem",
                          height: 20,
                          fontWeight: 600,
                        }}
                      />
                    </Stack>
                  )}
                </Box>
              );
            })}
          </Box>
        </Paper>
      )}
    </Box>
  );
}
