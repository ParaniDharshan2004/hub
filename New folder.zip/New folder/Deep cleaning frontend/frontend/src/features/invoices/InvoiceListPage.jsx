import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import TextField from '@mui/material/TextField';
import Typography from '@mui/material/Typography';
import Button from '@mui/material/Button';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import IconButton from '@mui/material/IconButton';
import PrintOutlinedIcon from '@mui/icons-material/PrintOutlined';
import CloseIcon from '@mui/icons-material/Close';
import Invoice from './invoice';
import PageHeader from '../../components/common-components/PageHeader';
import { ErrorState, LoadingSkeleton } from '../../components/common-components/PageStates';
import { listInvoices } from '../../api/invoices';
import { formatDate } from '../../utils/format';
import { formatMoney } from '../../utils/format';

export default function InvoiceListPage() {
  const [search, setSearch] = useState('');
  const [selectedInvoice, setSelectedInvoice] = useState(null);
  const [printInvoice, setPrintInvoice] = useState(null);
  const { data: invoices = [], isLoading, isError, error, refetch } = useQuery({
    queryKey: ['invoices', search],
    queryFn: () => listInvoices({ search }),
  });

  return (
    <Box sx={{ bgcolor: 'background.default', minHeight: '100vh', p: { xs: 2, sm: 3.5 } }}>
      <PageHeader title="Invoices" subtitle="Generated invoices for confirmed bookings." />
      <Paper variant="outlined" sx={{ p: 2, mb: 3, borderRadius: 3 }}>
        <TextField
          fullWidth
          size="small"
          label="Search invoice, booking, or customer"
          value={search}
          onChange={(event) => setSearch(event.target.value)}
        />
      </Paper>
      {isLoading && <LoadingSkeleton rows={5} />}
      {isError && <ErrorState message={error.message} onRetry={refetch} />}
      {!isLoading && !isError && invoices.length === 0 && (
        <Paper variant="outlined" sx={{ p: 5, borderRadius: 3, textAlign: 'center' }}>
          <Typography color="text.secondary">No invoices found.</Typography>
        </Paper>
      )}
      {!isLoading && !isError && invoices.length > 0 && (
        <Stack spacing={3}>
          {invoices.map((invoice) => (
            <Paper
              key={invoice.id}
              variant="outlined"
              role="button"
              tabIndex={0}
              onClick={() => setSelectedInvoice(invoice)}
              onKeyDown={(event) => {
                if (event.key === 'Enter' || event.key === ' ') setSelectedInvoice(invoice);
              }}
              sx={{
                p: { xs: 2, sm: 2.5 },
                borderRadius: 2,
                cursor: 'pointer',
                transition: 'border-color 0.2s, box-shadow 0.2s',
                '&:hover, &:focus-visible': {
                  borderColor: 'primary.main',
                  boxShadow: 2,
                  outline: 'none',
                },
              }}
            >
              <Stack direction={{ xs: 'column', sm: 'row' }} spacing={2} justifyContent="space-between" alignItems={{ xs: 'stretch', sm: 'center' }}>
                <Box>
                  <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
                    {invoice.customer?.name || 'Unknown customer'}
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Created {formatDate(invoice.createdDate, 'DD MMM YYYY, hh:mm A')}
                  </Typography>
                  <Typography variant="caption" color="text.secondary">
                    {invoice.invoiceNumber}
                  </Typography>
                </Box>
                <Stack direction="row" spacing={1.5} alignItems="center" justifyContent="space-between">
                  <Typography variant="h6" sx={{ fontWeight: 700, whiteSpace: 'nowrap' }}>
                    {formatMoney(invoice.amount)}
                  </Typography>
                  <Button
                    size="small"
                    variant="outlined"
                    startIcon={<PrintOutlinedIcon />}
                    onClick={(event) => {
                      event.stopPropagation();
                      setPrintInvoice(invoice);
                      window.setTimeout(() => window.print(), 100);
                    }}
                  >
                    Print
                  </Button>
                </Stack>
              </Stack>
            </Paper>
          ))}
        </Stack>
      )}

      <Dialog open={!!selectedInvoice} onClose={() => setSelectedInvoice(null)} maxWidth="xl" fullWidth>
        <DialogTitle>
          Invoice {selectedInvoice?.invoiceNumber}
          <IconButton onClick={() => setSelectedInvoice(null)} aria-label="Close invoice" sx={{ position: 'absolute', right: 12, top: 10 }}>
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent sx={{ bgcolor: '#F3F7F6', overflowX: 'auto', py: 3 }}>
          {selectedInvoice && (
            <Box>
              <Invoice
                invoice={selectedInvoice}
                customer={selectedInvoice.customer}
                booking={selectedInvoice.booking}
              />
            </Box>
          )}
        </DialogContent>
      </Dialog>

      {printInvoice && (
        <Box id="invoice-print-area">
          <Invoice
            invoice={printInvoice}
            customer={printInvoice.customer}
            booking={printInvoice.booking}
          />
        </Box>
      )}
    </Box>
  );
}
