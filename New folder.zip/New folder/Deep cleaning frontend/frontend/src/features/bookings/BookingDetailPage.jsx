/**
 * BookingDetailPage.jsx
 * -----------------------------------------------------------------------
 * Detailed view of a single booking including customer details, service
 * specifications, linked entities (payment, invoice, visits), and bill summary.
 * -----------------------------------------------------------------------
 */

import { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import Grid from '@mui/material/Grid';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Button from '@mui/material/Button';
import List from '@mui/material/List';
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import Box from '@mui/material/Box';

import PageHeader from '../../components/common-components/PageHeader';
import StatusChip from '../../components/common-components/StatusChip';
import EntityLink from '../../components/common-components/EntityLink';
import ConfirmDialog from '../../components/common-components/ConfirmDialog';
import { LoadingSkeleton, ErrorState } from '../../components/common-components/PageStates';
import { useSnackbar } from '../../components/common-components/SnackbarProvider';
import { Row, ConfirmDialogWithPayment } from '../../components/booking-components';
import { getBooking, confirmBooking, cancelBooking } from '../../api/bookings';
import { serviceAreas, plans, frequencies, serviceSlots, serviceOfferings } from '../../api/masters';
import { formatDate, formatDateTime } from '../../utils/format';

/**
 * Booking detail view component.
 */
export default function BookingDetailPage() {
  const { bookingNumber } = useParams();
  const navigate = useNavigate();
  const snackbar = useSnackbar();
  const queryClient = useQueryClient();
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [cancelOpen, setCancelOpen] = useState(false);
  const [paymentModeId, setPaymentModeId] = useState('');

  const { data: booking, isLoading, isError, error, refetch } = useQuery({
    queryKey: ['booking', bookingNumber],
    queryFn: () => getBooking(bookingNumber),
  });

  /** Mutation for confirming a draft booking */
  const confirmMutation = useMutation({
    mutationFn: () => confirmBooking(bookingNumber, { paymentModeId }),
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ['booking', bookingNumber] });
      queryClient.invalidateQueries({ queryKey: ['bookings'] });
      queryClient.invalidateQueries({ queryKey: ['customer360'] });
      snackbar.success(`Payment ${result.payment.paymentNumber} recorded successfully.`);
      snackbar.success(`Booking confirmed. Invoice ${result.invoice.invoiceNumber} is ready.`);
      setConfirmOpen(false);
    },
    onError: (err) => snackbar.error(err.message),
  });

  /** Mutation for cancelling a draft booking */
  const cancelMutation = useMutation({
    mutationFn: (reason) => cancelBooking(bookingNumber, reason),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['booking', bookingNumber] });
      queryClient.invalidateQueries({ queryKey: ['bookings'] });
      snackbar.success(`Booking ${bookingNumber} cancelled.`);
      setCancelOpen(false);
    },
    onError: (err) => snackbar.error(err.message),
  });

  if (isLoading) {
    return (
      <Box sx={{ p: { xs: 2, sm: 3.5 } }}>
        <PageHeader title="Loading booking…" breadcrumbs={[{ label: 'Bookings', path: '/bookings' }, { label: bookingNumber }]} />
        <LoadingSkeleton rows={8} />
      </Box>
    );
  }

  if (isError) {
    return (
      <Box sx={{ p: { xs: 2, sm: 3.5 } }}>
        <ErrorState message={error.message} onRetry={refetch} />
      </Box>
    );
  }

  if (!booking) {
    return (
      <Box sx={{ p: { xs: 2, sm: 3.5 } }}>
        <ErrorState message={`Booking ${bookingNumber} was not found.`} />
      </Box>
    );
  }

  return (
    <Box sx={{ bgcolor: 'background.default', minHeight: '100vh', p: { xs: 2, sm: 3.5 } }}>
      <PageHeader
        title={booking.bookingNumber}
        isMonoTitle
        breadcrumbs={[{ label: 'Bookings', path: '/bookings' }, { label: booking.bookingNumber }]}
        statusSlot={<StatusChip status={booking.status} />}
        actions={
          booking.status === 'Draft' ? (
            <Stack direction="row" spacing={1.5}>
              <Button variant="outlined" color="error" onClick={() => setCancelOpen(true)}>
                Cancel Booking
              </Button>
              <Button variant="contained" onClick={() => setConfirmOpen(true)}>
                Confirm Booking
              </Button>
            </Stack>
          ) : null
        }
      />

      <Grid container spacing={3}>
        <Grid item xs={12} md={7}>
          <Paper variant="outlined" sx={{ p: { xs: 2.5, sm: 3 }, mb: 3, borderRadius: 3 }}>
            <Typography variant="h6" sx={{ fontWeight: 700, color: 'text.primary', mb: 1.5 }}>
              Customer & Address
            </Typography>
            <Stack spacing={0.5}>
              <Stack direction="row" spacing={1} alignItems="center">
                <EntityLink type="Customer" id={booking.customer?.customerNumber} />
                <Typography variant="body2" sx={{ fontWeight: 600 }}>
                  {booking.customer?.name}
                </Typography>
              </Stack>
              <Typography variant="body2" color="text.secondary">
                {booking.address?.label}, {serviceAreas.find((a) => a.id === booking.address?.area)?.name}
              </Typography>
            </Stack>

            <Divider sx={{ my: 2.5 }} />

            <Typography variant="h6" sx={{ fontWeight: 700, color: 'text.primary', mb: 1.5 }}>
              Service Details
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Offering
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 500 }}>
                  {serviceOfferings.find((o) => o.id === booking.offeringId)?.name}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Bathrooms
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 500 }}>
                  {booking.bathrooms}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Frequency
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 500 }}>
                  {booking.frequencyName || frequencies.find((f) => f.id === booking.frequencyId)?.name || '—'}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Plan
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 500 }}>
                  {booking.planName || plans.find((p) => p.id === booking.planId)?.name || '—'}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Start Date
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 500 }}>
                  {formatDate(booking.startDate)}
                </Typography>
              </Grid>
              <Grid item xs={6}>
                <Typography variant="caption" color="text.secondary">
                  Slot
                </Typography>
                <Typography variant="body2" sx={{ fontWeight: 500 }}>
                  {booking.slotLabel || serviceSlots.find((s) => s.id === booking.slotId)?.label || '—'}
                </Typography>
              </Grid>
            </Grid>
          </Paper>

          <Paper variant="outlined" sx={{ p: { xs: 2.5, sm: 3 }, borderRadius: 3 }}>
            <Typography variant="h6" sx={{ fontWeight: 700, color: 'text.primary', mb: 1.5 }}>
              Related Records
            </Typography>
            <List dense disablePadding>
              <ListItem disableGutters sx={{ py: 1 }}>
                <ListItemText
                  primary={
                    <Stack direction="row" spacing={1.5} alignItems="center">
                      <Typography variant="body2" sx={{ minWidth: 100, color: 'text.secondary' }}>
                        Payment
                      </Typography>
                      {booking.payment ? <EntityLink type="Payment" id={booking.payment.paymentNumber} /> : <Typography variant="body2" color="text.secondary">Not recorded yet</Typography>}
                    </Stack>
                  }
                />
              </ListItem>
              <ListItem disableGutters sx={{ py: 1 }}>
                <ListItemText
                  primary={
                    <Stack direction="row" spacing={1.5} alignItems="center">
                      <Typography variant="body2" sx={{ minWidth: 100, color: 'text.secondary' }}>
                        Invoice
                      </Typography>
                      {booking.invoice ? <EntityLink type="Invoice" id={booking.invoice.invoiceNumber} /> : <Typography variant="body2" color="text.secondary">Not generated yet</Typography>}
                    </Stack>
                  }
                />
              </ListItem>
              <ListItem disableGutters sx={{ py: 1 }}>
                <ListItemText
                  primary={
                    <Stack direction="row" spacing={1.5} alignItems="center">
                      <Typography variant="body2" sx={{ minWidth: 100, color: 'text.secondary' }}>
                        Subscription
                      </Typography>
                      {booking.subscription ? <EntityLink type="Subscription" id={booking.subscription.subscriptionNumber} /> : <Typography variant="body2" color="text.secondary">Created on confirmation</Typography>}
                    </Stack>
                  }
                />
              </ListItem>
              <ListItem disableGutters sx={{ py: 1 }}>
                <ListItemText
                  primary={
                    <Stack direction="row" spacing={1.5} alignItems="center">
                      <Typography variant="body2" sx={{ minWidth: 100, color: 'text.secondary' }}>
                        Visits
                      </Typography>
                      <Typography variant="body2" color="text.secondary">
                        {booking.visits?.length ? `${booking.visits.length} scheduled` : 'Generated on confirmation'}
                      </Typography>
                    </Stack>
                  }
                />
              </ListItem>
            </List>
          </Paper>
        </Grid>

        <Grid item xs={12} md={5}>
          <Paper variant="outlined" sx={{ p: 3, borderRadius: 3 }}>
            <Typography variant="h6" sx={{ fontWeight: 700, color: 'text.primary', mb: 2 }}>
              Bill Summary
            </Typography>
            <Stack spacing={1}>
              <Row label="Service Charges" value={booking.serviceCharges} />
              {booking.discount > 0 && <Row label="Authorized Discount" value={-booking.discount} />}
              <Row label="Taxable Amount" value={booking.taxableAmount} />
              {booking.taxes?.map((t) => (
                <Row key={t.id} label={`${t.label} (${(t.rate * 100).toFixed(0)}%)`} value={t.amount} />
              ))}
              <Divider sx={{ my: 1 }} />
              <Row label="Total Amount" value={booking.total} strong />
            </Stack>
            <Typography variant="caption" color="text.secondary" sx={{ display: 'block', mt: 2 }}>
              Created {formatDateTime(booking.createdOn)}
              {booking.confirmedOn && <> · Confirmed {formatDateTime(booking.confirmedOn)}</>}
            </Typography>
          </Paper>
        </Grid>
      </Grid>

      <ConfirmDialogWithPayment
        open={confirmOpen}
        onClose={() => setConfirmOpen(false)}
        paymentModeId={paymentModeId}
        setPaymentModeId={setPaymentModeId}
        onConfirm={() => confirmMutation.mutate()}
        submitting={confirmMutation.isPending}
        bookingNumber={booking.bookingNumber}
      />

      <ConfirmDialog
        open={cancelOpen}
        title="Cancel Booking"
        description="This cancels the draft booking. Confirmed bookings cannot be cancelled here."
        entityLabel={booking.bookingNumber}
        requireReason
        destructive
        confirmLabel="Cancel Booking"
        onConfirm={(reason) => cancelMutation.mutateAsync(reason)}
        onClose={() => setCancelOpen(false)}
      />
    </Box>
  );
}

