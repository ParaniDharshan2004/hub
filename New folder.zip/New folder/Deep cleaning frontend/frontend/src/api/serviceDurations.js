import { get, post, put, del } from "../utils/api.js";

export const listServiceDurations = (activeStatusId = "") =>
  get(
    activeStatusId
      ? `/durations?activeStatusId=${encodeURIComponent(activeStatusId)}`
      : "/durations",
  );
export const getServiceDuration = (durationId) =>
  get(`/durations/${durationId}`);
export const createServiceDuration = (data) => post("/durations", data);
export const updateServiceDuration = (durationId, data) =>
  put(`/durations/${durationId}`, data);
export const deleteServiceDuration = (durationId) =>
  del(`/durations/${durationId}`);
