import dayjs from 'dayjs';
import { getDb, saveDb, recordAudit, recordStatusChange } from './db';
import { delay, paymentModes, receiverAccounts } from './masters';

function toPaymentRow(payment) {
  const db = getDb();
  const booking = db.bookings.find((b) => b.id === payment.bookingId);
  const customer = db.customers.find((c) => c.id === payment.customerId);
  const invoice = db.invoices.find((i) => i.paymentId === payment.id);
  return { ...payment, booking, customer, invoice };
}

export async function listPayments({ search = '', status = 'All', modeId = 'All' } = {}) {
  await delay();
  const db = getDb();
  let rows = db.payments.map(toPaymentRow);

  if (status !== 'All') rows = rows.filter((p) => p.status === status);
  if (modeId !== 'All') rows = rows.filter((p) => p.modeId === modeId);
  if (search.trim()) {
    const q = search.trim().toLowerCase();
    rows = rows.filter(
      (p) =>
        p.paymentNumber.toLowerCase().includes(q) ||
        p.customer?.name.toLowerCase().includes(q) ||
        p.customer?.customerNumber.toLowerCase().includes(q) ||
        p.booking?.bookingNumber.toLowerCase().includes(q)
    );
  }
  return rows.sort((a, b) => new Date(b.paymentDate) - new Date(a.paymentDate));
}

export async function getPayment(paymentNumber) {
  await delay(250);
  const db = getDb();
  const payment = db.payments.find((p) => p.paymentNumber === paymentNumber);
  if (!payment) return null;
  return toPaymentRow(payment);
}

export async function reversePayment(paymentNumber, reason) {
  await delay(350);
  if (!reason) throw new Error('A reason is required to reverse a payment.');
  const db = getDb();
  const payment = db.payments.find((p) => p.paymentNumber === paymentNumber);
  if (!payment) throw new Error('Payment not found');
  if (payment.status === 'Reversed') throw new Error('This payment has already been reversed.');

  // The original record is never overwritten — we only flip status and
  // attach the reason, exactly as the spec requires for reversals.
  payment.status = 'Reversed';
  payment.reversalReason = reason;
  payment.reversedOn = new Date().toISOString();

  recordStatusChange({ entityType: 'Payment', entityNumber: payment.paymentNumber, fromStatus: 'Recorded', toStatus: 'Reversed', reason });
  recordAudit({ module: 'Payments', action: 'REVERSE', entityType: 'Payment', entityNumber: payment.paymentNumber, details: reason });

  saveDb();
  return toPaymentRow(payment);
}

export async function dailyCollectionSummary(date = dayjs().format('YYYY-MM-DD')) {
  await delay(300);
  const db = getDb();
  const rows = db.payments.filter((p) => dayjs(p.paymentDate).format('YYYY-MM-DD') === date && p.status !== 'Reversed');

  const byMode = paymentModes.map((m) => ({
    mode: m,
    total: rows.filter((r) => r.modeId === m.id).reduce((s, r) => s + r.amount, 0),
    count: rows.filter((r) => r.modeId === m.id).length,
  }));

  return {
    date,
    totalCollected: rows.reduce((s, r) => s + r.amount, 0),
    totalCount: rows.length,
    byMode,
    receiverAccounts,
  };
}
