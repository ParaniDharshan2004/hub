import { get, post, put, del } from "../utils/api.js";

export const listBathroomCounts = (activeStatusId = "") =>
  get(
    activeStatusId
      ? `/bathrooms?activeStatusId=${encodeURIComponent(activeStatusId)}`
      : "/bathrooms",
  );
export const getBathroomCount = (bathroomCountId) =>
  get(`/bathrooms/${bathroomCountId}`);
export const createBathroomCount = (data) => post("/bathrooms", data);
export const updateBathroomCount = (bathroomCountId, data) =>
  put(`/bathrooms/${bathroomCountId}`, data);
export const deleteBathroomCount = (bathroomCountId) =>
  del(`/bathrooms/${bathroomCountId}`);
