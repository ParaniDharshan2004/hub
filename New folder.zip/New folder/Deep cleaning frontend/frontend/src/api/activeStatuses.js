import { get, post, put, del } from "../utils/api.js";

export const listActiveStatuses = () => get("/statuses");
export const getActiveStatus = (statusId) => get(`/statuses/${statusId}`);
export const createActiveStatus = (data) => post("/statuses", data);
export const updateActiveStatus = (statusId, data) =>
  put(`/statuses/${statusId}`, data);
export const deleteActiveStatus = (statusId) =>
  del(`/statuses/${statusId}`);
