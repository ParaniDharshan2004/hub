import { get, post, put, del } from "../utils/api.js";

export const listPaymentMethods = (activeStatusId = "") =>
  get(
    activeStatusId
      ? `/payments?activeStatusId=${encodeURIComponent(activeStatusId)}`
      : "/payments",
  );
export const getPaymentMethod = (paymentMethodId) =>
  get(`/payments/${paymentMethodId}`);
export const createPaymentMethod = (data) => post("/payments", data);
export const updatePaymentMethod = (paymentMethodId, data) =>
  put(`/payments/${paymentMethodId}`, data);
export const deletePaymentMethod = (paymentMethodId) =>
  del(`/payments/${paymentMethodId}`);
