import { get, post, put, del } from "../utils/api.js";

export const listBookingDates = () => get("/dates");
export const getBookingDate = (bookingDateId) =>
  get(`/dates/${bookingDateId}`);
export const createBookingDate = (data) => post("/dates", data);
export const updateBookingDate = (bookingDateId, data) =>
  put(`/dates/${bookingDateId}`, data);
export const deleteBookingDate = (bookingDateId) =>
  del(`/dates/${bookingDateId}`);
