import { get, post, put, del } from "../utils/api.js";

export const listServiceFrequencies = (activeStatusId = "") =>
  get(
    activeStatusId
      ? `/frequencies?activeStatusId=${encodeURIComponent(activeStatusId)}`
      : "/frequencies",
  );
export const getServiceFrequency = (frequencyId) =>
  get(`/frequencies/${frequencyId}`);
export const createServiceFrequency = (data) =>
  post("/frequencies", data);
export const updateServiceFrequency = (frequencyId, data) =>
  put(`/frequencies/${frequencyId}`, data);
export const deleteServiceFrequency = (frequencyId) =>
  del(`/frequencies/${frequencyId}`);
