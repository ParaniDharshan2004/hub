// Mock persistence layer standing in for the real backend/API. Everything
// here is written the way a thin backend service would be: normalized
// tables, foreign keys by internal id, business numbers generated once and
// never reused. Swap this module for real HTTP calls (e.g. via the
// TanStack Query hooks in customers.js/bookings.js/subscriptions.js)
// without touching any screen code.
const STORAGE_KEY = 'tco_mock_db_v1';

function emptyDb() {
  return {
    customers: [],
    addresses: [],
    bookings: [],
    payments: [],
    invoices: [],
    subscriptions: [],
    periods: [],
    visits: [],
    statusHistory: [],
    auditLog: [],
  };
}

function load() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (raw) return JSON.parse(raw);
  } catch (e) {
    // ignore corrupt storage, fall through to a fresh db
  }
  return null;
}

function persist() {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
  } catch (e) {
    // storage may be unavailable (private mode / quota) — app still works
    // in-memory for the session.
  }
}

let db = load() || emptyDb();

export function resetDb() {
  db = emptyDb();
  persist();
}

export function recordAudit({ module, action, entityType, entityNumber, actor = 'Demo Admin', details }) {
  db.auditLog.push({
    id: `AUD-${db.auditLog.length + 1}`,
    module,
    action,
    entityType,
    entityNumber,
    actor,
    details: details || null,
    createdOn: new Date().toISOString(),
  });
}

export function recordStatusChange({ entityType, entityNumber, fromStatus, toStatus, reason }) {
  db.statusHistory.push({
    id: `STH-${db.statusHistory.length + 1}`,
    entityType,
    entityNumber,
    fromStatus,
    toStatus,
    reason: reason || null,
    actor: 'Demo Admin',
    createdOn: new Date().toISOString(),
  });
}

export function getDb() {
  return db;
}

export function saveDb() {
  persist();
}
