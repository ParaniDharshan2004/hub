import { get, put } from "../utils/api.js";

export const getSettings = () => get("/settings");
export const updatePricing = (pricing) => put("/settings/pricing", { pricing });
export const updateDurations = (durations) => put("/settings/durations", { durations });
