import { get, post, put, del } from "../utils/api.js";

export const listPaymentAccounts = (activeStatusId = "") =>
  get(
    activeStatusId
      ? `/accounts?activeStatusId=${encodeURIComponent(activeStatusId)}`
      : "/accounts",
  );
export const getPaymentAccount = (accountId) =>
  get(`/accounts/${accountId}`);
export const createPaymentAccount = (data) => post("/accounts", data);
export const updatePaymentAccount = (accountId, data) =>
  put(`/accounts/${accountId}`, data);
export const deletePaymentAccount = (accountId) =>
  del(`/accounts/${accountId}`);
