import { get, post } from "../utils/api.js";

const DEMO_ADMIN_EMAIL = "admin@demo.com";
const DEMO_ADMIN_PASSWORD = "admin123";

const normalizeUser = (user) => ({
	...user,
	name: user?.name ?? user?.userName,
	role: user?.role ?? user?.roleId?.roleName,
});

const getDemoAdminUser = () => ({
	id: "demo-admin",
	name: "Admin User",
	email: DEMO_ADMIN_EMAIL,
	role: "superadmin",
	userName: "Admin User",
	isAdmin: true,
});

export const getCurrentUser = async () => {
	const storedDemoUser = localStorage.getItem("demoUser");
	if (storedDemoUser) {
		return JSON.parse(storedDemoUser);
	}

	const token = localStorage.getItem("token");
	if (token === "dummy-admin-token") {
		const demoUser = getDemoAdminUser();
		localStorage.setItem("demoUser", JSON.stringify(demoUser));
		return demoUser;
	}

	const user = await get("/users/me");
	return normalizeUser(user);
};

export const login = async (email, password) => {
	const normalizedEmail = (email ?? "").trim().toLowerCase();
	const normalizedPassword = password ?? "";

	if (
		normalizedEmail === DEMO_ADMIN_EMAIL &&
		normalizedPassword === DEMO_ADMIN_PASSWORD
	) {
		const demoUser = getDemoAdminUser();
		localStorage.setItem("token", "dummy-admin-token");
		localStorage.setItem("demoUser", JSON.stringify(demoUser));
		return { token: "dummy-admin-token", user: demoUser };
	}

	try {
		const data = await post("/users/login", { email, password });
		const token = data?.token ?? data?.accessToken;
		if (token) localStorage.setItem("token", token);
		return { ...data, user: normalizeUser(data?.user ?? data) };
	} catch (error) {
		throw new Error(
			"Invalid admin credentials. Use admin@demo.com / admin123 or contact your backend admin.",
		);
	}
};

export const logout = () => {
	localStorage.removeItem("token");
	localStorage.removeItem("demoUser");
};
