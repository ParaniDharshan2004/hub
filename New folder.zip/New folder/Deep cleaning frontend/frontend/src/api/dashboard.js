import dayjs from 'dayjs';

export async function getDashboardSummary({ date = dayjs().format('YYYY-MM-DD') } = {}) {
  const response = await fetch(`/api/dashboard?date=${date}`);
  if (!response.ok) throw new Error('Could not fetch dashboard values from the database');
  return response.json();
}
