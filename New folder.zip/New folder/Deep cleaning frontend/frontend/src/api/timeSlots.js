import { get, post, put, del } from "../utils/api.js";

export const listTimeSlots = () => get("/slots");
export const getTimeSlot = (slotId) => get(`/slots/${slotId}`);
export const createTimeSlot = (data) => post("/slots", data);
export const updateTimeSlot = (slotId, data) => put(`/slots/${slotId}`, data);
export const deleteTimeSlot = (slotId) => del(`/slots/${slotId}`);

export const getAvailableSlots = (params = {}) => {
  const query = new URLSearchParams(params).toString();
  return get(`/slots/availability?${query}`);
};
