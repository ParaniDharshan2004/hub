// Master data. In production every one of these lists is loaded from a
// Master API (see spec section "Masters") — forms must never hardcode
// selectable values. This module is the single mock stand-in for that
// backend so the rest of the app can already be written against real async
// data-fetch shapes (id/label objects, not raw strings).

export const serviceAreas = [
  { id: 'AREA-01', code: 'AREA-01', name: 'Indiranagar', city: 'Bengaluru' },
  { id: 'AREA-02', code: 'AREA-02', name: 'Koramangala', city: 'Bengaluru' },
  { id: 'AREA-03', code: 'AREA-03', name: 'Whitefield', city: 'Bengaluru' },
  { id: 'AREA-04', code: 'AREA-04', name: 'HSR Layout', city: 'Bengaluru' },
  { id: 'AREA-05', code: 'AREA-05', name: 'Jayanagar', city: 'Bengaluru' },
];

export const serviceOfferings = [
  { id: 'OFF-01', name: 'Toilet Cleaning' },
  { id: 'OFF-02', name: 'Full Bathroom Deep Clean' },
];

export const frequencies = [
  { id: 'FRQ-WK', name: 'Weekly', visitsPerMonth: 4 },
  { id: 'FRQ-BW', name: 'Bi-Weekly', visitsPerMonth: 2 },
  { id: 'FRQ-MO', name: 'Monthly', visitsPerMonth: 1 },
];

// Plans define a term length (in months) and the resulting total visit
// count for a given frequency; price is per single service visit and
// varies by bathroom count.
export const plans = [
  {
    id: 'PLN-BASIC',
    name: 'Basic — 1 Month',
    termMonths: 1,
    pricePerServiceByBathroom: { 1: 149, 2: 199, 3: 249, 4: 299 },
  },
  {
    id: 'PLN-STANDARD',
    name: 'Standard — 3 Months',
    termMonths: 3,
    pricePerServiceByBathroom: { 1: 139, 2: 189, 3: 235, 4: 285 },
  },
  {
    id: 'PLN-PREMIUM',
    name: 'Premium — 6 Months',
    termMonths: 6,
    pricePerServiceByBathroom: { 1: 129, 2: 175, 3: 219, 4: 265 },
  },
];

export const paymentModes = [
  { id: 'PM-CASH', name: 'Cash' },
  { id: 'PM-UPI', name: 'UPI' },
  { id: 'PM-CARD', name: 'Card' },
  { id: 'PM-BANK', name: 'Bank Transfer' },
];

export const receiverAccounts = [
  { id: 'REC-01', name: 'Bathroom Cleaning Operations' },
];

export const serviceSlots = [
  { id: 'SLOT-1', label: '08:00 AM – 10:00 AM' },
  { id: 'SLOT-2', label: '10:00 AM – 12:00 PM' },
  { id: 'SLOT-3', label: '02:00 PM – 04:00 PM' },
  { id: 'SLOT-4', label: '04:00 PM – 06:00 PM' },
];

export const taxComponents = [
  { id: 'CGST', label: 'CGST', rate: 0.09 },
  { id: 'SGST', label: 'SGST', rate: 0.09 },
];

export function visitsForPlan(plan, frequency) {
  return plan.termMonths * frequency.visitsPerMonth;
}

// Simulated network latency, applied by the api/*.js modules so loading
// states in the UI are exercised even against mock data.
export const NETWORK_DELAY_MS = 250;
export const delay = (ms = NETWORK_DELAY_MS) => new Promise((res) => setTimeout(res, ms));
