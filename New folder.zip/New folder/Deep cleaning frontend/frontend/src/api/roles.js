import { get, post, put, del } from "../utils/api.js";

export const listRoles = () => get("/roles");
export const getRole = (roleId) => get(`/roles/${roleId}`);
export const createRole = (data) => post("/roles", data);
export const updateRole = (roleId, data) => put(`/roles/${roleId}`, data);
export const deleteRole = (roleId) => del(`/roles/${roleId}`);
