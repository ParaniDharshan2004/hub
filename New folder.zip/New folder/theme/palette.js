const palette = (mode) => ({
  mode,

  primary: {
    main: "#1D89C8",
    light: "#1D89C820",
    dark: "#1565C0",
  },

  secondary: {
    main: "#3EB8AF",
    light: "#3EB8AF20",
    dark: "#2C8F89",
  },

  background: {
    default: mode === "dark" ? "#000000" : "#ffffff",
    paper: mode === "dark" ? "#000000" : "#ffffff",
  },

  text: {
    primary: mode === "dark" ? "#FFFFFF" : "#000000",
    secondary: mode === "dark" ? "#B8C5D6" : "#4B5563",
  },

  divider: "#1D89C8",
});

export default palette;
