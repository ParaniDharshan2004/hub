import { createTheme } from '@mui/material/styles';
import palette from './palette';
import typography from './typography';
import components from './components';
import Icons from './icons';
import spacing from './spacing-tokens';
 
const buildTheme = (mode) => {
  let theme = createTheme({
    palette: palette(mode),
    shape: {
      borderRadius: 10,
    },
  });
 
  theme = createTheme(theme, {
    typography: typography(theme),
 
    components: {
      ...components,
      MuiButton: {
        ...components.MuiButton,
        styleOverrides: {
          ...components.MuiButton?.styleOverrides,
          root: {
            ...components.MuiButton?.styleOverrides?.root,
            textTransform: "none",
            fontWeight: 600,
            borderRadius: 10,
          },
        },
      },
      MuiCard: {
        ...components.MuiCard,
        styleOverrides: {
          ...components.MuiCard?.styleOverrides,
          root: {
            ...components.MuiCard?.styleOverrides?.root,
            borderRadius: 12,
          },
        },
      },
      MuiCssBaseline: {
        ...components.MuiCssBaseline,
        styleOverrides: {
          ...components.MuiCssBaseline?.styleOverrides,
          body: {
            fontFamily: "'DM Sans', 'Segoe UI', sans-serif",
          },
        },
      },
    },
  });
 
 
  theme.Icons = Icons;
  theme.spacingTokens = spacing;
 
  return theme;
};
 
export { Icons, spacing };
export default buildTheme;