import { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useMutation, useQueryClient } from "@tanstack/react-query";

import Drawer from "@mui/material/Drawer";
import Dialog from "@mui/material/Dialog";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import Checkbox from "@mui/material/Checkbox";
import FormControlLabel from "@mui/material/FormControlLabel";
import Button from "@mui/material/Button";
import Divider from "@mui/material/Divider";
import Alert from "@mui/material/Alert";
import CircularProgress from "@mui/material/CircularProgress";
import useMediaQuery from "@mui/material/useMediaQuery";
import { useTheme } from "@mui/material/styles";
import CloseIcon from "@mui/icons-material/Close";

import { createCustomerWithAddress, findByMobile } from "../../api.js";
import { useSnackbar } from "../common-components/SnackbarProvider";
import EntityLink from "../common-components/EntityLink";

const schema = z.object({
  name: z.string().min(2, "Enter at least 2 characters").max(100),
  mobile: z
    .string()
    .regex(/^[6-9]\d{9}$/, "Enter a valid 10-digit mobile number"),
  sameAsMobile: z.boolean().default(true),
  whatsapp: z.string().optional().or(z.literal("")),
  email: z.string().email("Enter a valid email").optional().or(z.literal("")),
  addressLabel: z.string().min(1, "Required"),
  doorNo: z.string().optional().or(z.literal("")),
  block: z.string().optional().or(z.literal("")),
  community: z.string().optional().or(z.literal("")),
  addressLine: z.string().min(3, "Required"),
  area: z.string().min(1, "Select a service area"),
  city: z.string().optional().or(z.literal("")),
  pincode: z
    .string()
    .regex(/^\d{6}$/, "Enter a valid 6-digit pincode")
    .optional()
    .or(z.literal("")),
  landmark: z.string().optional().or(z.literal("")),
});

const defaultValues = {
  name: "",
  mobile: "",
  sameAsMobile: true,
  whatsapp: "",
  email: "",
  addressLabel: "Home",
  doorNo: "",
  block: "",
  community: "",
  addressLine: "",
  area: "",
  city: "",
  pincode: "",
  landmark: "",
};

export default function CustomerCreateDrawer({ open, onClose, onCreated }) {
  const theme = useTheme();
  const fullScreen = useMediaQuery(theme.breakpoints.down("sm"));
  const snackbar = useSnackbar();
  const queryClient = useQueryClient();
  const [duplicates, setDuplicates] = useState([]);
  const [checkingDuplicate, setCheckingDuplicate] = useState(false);

  const {
    register,
    handleSubmit,
    control,
    watch,
    reset,
    formState: { errors, isDirty },
  } = useForm({ resolver: zodResolver(schema), defaultValues });

  const mobile = watch("mobile");

  useEffect(() => {
    if (!open) return;
    if (!/^[6-9]\d{9}$/.test(mobile || "")) {
      setDuplicates([]);
      return;
    }
    let active = true;
    setCheckingDuplicate(true);
    const t = setTimeout(async () => {
      const matches = await findByMobile(mobile);
      if (active) {
        setDuplicates(matches);
        setCheckingDuplicate(false);
      }
    }, 350);
    return () => {
      active = false;
      clearTimeout(t);
    };
  }, [mobile, open]);

  useEffect(() => {
    if (!open) reset(defaultValues);
  }, [open, reset]);

  const mutation = useMutation({
    mutationFn: createCustomerWithAddress,
    onSuccess: (result) => {
      queryClient.invalidateQueries({ queryKey: ["customers"] });
      snackbar.success("Customer created successfully.");
      const customerNumber = result?.customer?.customerNumber || result?.customer?.id;
      const addressNumber = result?.address?.addressNumber || result?.address?.id;
      if (onCreated) onCreated(customerNumber, addressNumber);
    },
    onError: (err) =>
      snackbar.error(err.message || "Could not create customer."),
  });

  const onSubmit = (values) => mutation.mutate(values);

  const handleClose = () => {
    if (mutation.isPending) return;
    if (isDirty && !window.confirm("Discard unsaved changes?")) return;
    onClose();
  };

  const body = (
    <Box
      sx={{
        width: { sm: 480 },
        height: "100%",
        bgcolor: "#FFFFFF",
        color: "#000000",
        display: "flex",
        flexDirection: "column",
      }}
    >
      <Stack
        direction="row"
        alignItems="center"
        justifyContent="space-between"
        sx={{ px: 3, py: 2 }}
      >
        <Box>
          <Typography variant="h3">Add Customer</Typography>
          <Typography variant="body2" color="text.secondary">
            Personal details and first service address
          </Typography>
        </Box>
        <IconButton onClick={handleClose} aria-label="Close">
          <CloseIcon />
        </IconButton>
      </Stack>
      <Divider />

      <Box
        component="form"
        id="customer-create-form"
        onSubmit={handleSubmit(onSubmit)}
        sx={{ flex: 1, overflowY: "auto", px: 3, py: 2.5 }}
      >
        <Stack spacing={2}>
          <Typography variant="subtitle1">Customer Details</Typography>
          <TextField
            label="Customer Name"
            required
            fullWidth
            {...register("name")}
            error={!!errors.name}
            helperText={errors.name?.message}
          />
          <TextField
            label="Mobile Number"
            required
            fullWidth
            {...register("mobile")}
            error={!!errors.mobile}
            helperText={
              errors.mobile?.message ||
              (checkingDuplicate ? "Checking for existing customers…" : " ")
            }
          />

          {duplicates.length > 0 && (
            <Alert severity="warning">
              <Typography variant="body2" sx={{ mb: 0.5 }}>
                {duplicates.length === 1
                  ? "A customer with this mobile already exists:"
                  : "Customers with this mobile already exist:"}
              </Typography>
              <Stack spacing={0.5}>
                {duplicates.map((d) => (
                  <Stack
                    key={d.id}
                    direction="row"
                    spacing={1}
                    alignItems="center"
                  >
                    <EntityLink type="Customer" id={d.customerNumber} />
                    <Typography variant="body2">{d.name}</Typography>
                  </Stack>
                ))}
              </Stack>
            </Alert>
          )}

          <Controller
            name="sameAsMobile"
            control={control}
            render={({ field }) => (
              <FormControlLabel
                control={
                  <Checkbox
                    checked={field.value}
                    onChange={(e) => field.onChange(e.target.checked)}
                  />
                }
                label="WhatsApp number same as mobile"
              />
            )}
          />
          {!watch("sameAsMobile") && (
            <TextField
              label="WhatsApp Number"
              fullWidth
              {...register("whatsapp")}
            />
          )}
          

          <Divider />
          <Typography variant="subtitle1">First Service Address</Typography>

          
          <Stack direction="row" spacing={2}>
            <TextField
              label="Door / Flat No."
              fullWidth
              {...register("doorNo")}
            />
            <TextField label="Block / Tower" fullWidth {...register("block")} />
          </Stack>
          <TextField
            label="Apartment / Community"
            fullWidth
            {...register("community")}
          />
          <TextField
            label="Address Line"
            required
            fullWidth
            multiline
            minRows={2}
            {...register("addressLine")}
            error={!!errors.addressLine}
            helperText={errors.addressLine?.message}
          />
          <TextField
            label="Service Area"
            required
            fullWidth
            {...register("area")}
            error={!!errors.area}
            helperText={errors.area?.message}
          />
          <Stack direction="row" spacing={2}>
            <TextField label="City" fullWidth {...register("city")} />
            <TextField
              label="Pincode"
              fullWidth
              {...register("pincode")}
              error={!!errors.pincode}
              helperText={errors.pincode?.message}
            />
          </Stack>
          <TextField label="Landmark" fullWidth {...register("landmark")} />
        </Stack>
      </Box>

      <Divider />
      <Stack
        direction="row"
        spacing={1.5}
        justifyContent="flex-end"
        sx={{ px: 3, py: 2 }}
      >
        <Button onClick={handleClose} disabled={mutation.isPending}>
          Cancel
        </Button>
        <Button
          variant="contained"
          type="submit"
          form="customer-create-form"
          disabled={mutation.isPending}
          startIcon={
            mutation.isPending ? (
              <CircularProgress size={16} color="inherit" />
            ) : null
          }
        >
          Save Customer
        </Button>
      </Stack>
    </Box>
  );

  if (fullScreen) {
    return (
      <Dialog fullScreen open={open} onClose={handleClose}>
        {body}
      </Dialog>
    );
  }

  return (
    <Drawer
      anchor="right"
      open={open}
      onClose={handleClose}
      PaperProps={{ sx: { bgcolor: "#FFFFFF", color: "#000000" } }}
    >
      {body}
    </Drawer>
  );
}
