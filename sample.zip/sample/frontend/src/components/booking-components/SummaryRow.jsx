import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Money from '../common-components/Money';

/**
 * Summary row helper component.
 */
export function Row({ label, value, strong }) {
  return (
    <Stack direction="row" justifyContent="space-between">
      <Typography variant="body2" color="text.secondary">
        {label}
      </Typography>
      <Money value={value} strong={strong} />
    </Stack>
  );
}

export default Row;
