import Paper from "@mui/material/Paper";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Divider from "@mui/material/Divider";
import Chip from "@mui/material/Chip";
import Money from "./Money";
import { formatDate } from "../../utils/format";

/**
 * Summary Row Helper Component
 * Render label on left and money amount on right with support for strong/muted emphasis.
 */
function Row({ label, value, muted, strong }) {
  return (
    <Stack direction="row" justifyContent="space-between" alignItems="center">
      <Typography
        variant="body2"
        color={muted ? "text.secondary" : "text.primary"}
        sx={{ fontWeight: strong ? 700 : 400 }}
      >
        {label}
      </Typography>
      <Typography
        variant="body2"
        component="div"
        sx={{
          fontWeight: strong ? 700 : 500,
          color: strong ? "primary.main" : "text.primary",
        }}
      >
        <Money value={value} strong={strong} />
      </Typography>
    </Stack>
  );
}

/**
 * BillSummary Component
 * Sticky sidebar panel calculating tax breakdown, discounts, service counts, and grand total for bookings.
 *
 * @param {Object} props
 * @param {Object} [props.quote] - Computed price quote object from api/pricing
 * @param {boolean} [props.priceChanged] - Flag indicating if master pricing has been modified
 */
export default function BillSummary({ quote, priceChanged }) {
  if (!quote) {
    return (
      <Paper variant="outlined" sx={{ p: 2.5, borderRadius: 2.5 }}>
        <Typography variant="subtitle1" sx={{ fontWeight: 700, mb: 0.5 }}>
          Bill Summary
        </Typography>
        <Typography variant="body2" color="text.secondary">
          Select a service plan, frequency, and bathroom count to compute total
          pricing.
        </Typography>
      </Paper>
    );
  }

  return (
    <Paper
      variant="outlined"
      sx={{
        p: 2.75,
        borderRadius: 3,
        bgcolor: "#FFFFFF",
        position: { md: "sticky" },
        top: { md: 88 },
        boxShadow: "0 4px 16px rgba(15, 92, 87, 0.06)",
      }}
    >
      {/* Header */}
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems="center"
        sx={{ mb: 2 }}
      >
        <Typography variant="subtitle1" sx={{ fontWeight: 700 }}>
          Bill Summary
        </Typography>
        {priceChanged && (
          <Chip
            size="small"
            color="warning"
            label="Price updated"
            sx={{ height: 20, fontSize: "0.7rem" }}
          />
        )}
      </Stack>

      {/* Itemized Calculations */}
      <Stack spacing={1}>
        <Row
          label={`Price per Service (${quote.numServices} visits)`}
          value={quote.pricePerService}
          muted
        />
        <Row label="Subtotal Service Charges" value={quote.serviceCharges} />
        {quote.authorizedDiscount > 0 && (
          <Row
            label="Authorized Discount"
            value={-quote.authorizedDiscount}
            muted
          />
        )}

        <Divider sx={{ my: 0.75, borderColor: "#E2E8E6" }} />

        <Row label="Taxable Amount" value={quote.taxableAmount} />
        {quote.taxes.map((t) => (
          <Row
            key={t.id}
            label={`${t.label} (${(t.rate * 100).toFixed(0)}%)`}
            value={t.amount}
            muted
          />
        ))}

        <Divider
          sx={{ my: 0.75, borderColor: "primary.main", borderWidth: 1 }}
        />

        <Row label="Total Amount" value={quote.total} strong />
      </Stack>

      {/* Effective Date Note */}
      <Typography
        variant="caption"
        color="text.secondary"
        sx={{ display: "block", mt: 2, textAlign: "right" }}
      >
        Pricing effective as of {formatDate(quote.effectiveDate)}
      </Typography>
    </Paper>
  );
}
