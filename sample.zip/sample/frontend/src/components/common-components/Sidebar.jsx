import { useState } from 'react';
import Box from '@mui/material/Box';
import Toolbar from '@mui/material/Toolbar';
import List from '@mui/material/List';
import ListItemButton from '@mui/material/ListItemButton';
import ListItemIcon from '@mui/material/ListItemIcon';
import ListItemText from '@mui/material/ListItemText';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Collapse from '@mui/material/Collapse';
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';
import { useTheme, alpha } from '@mui/material/styles';

import DashboardOutlinedIcon from '@mui/icons-material/DashboardOutlined';
import PeopleAltOutlinedIcon from '@mui/icons-material/PeopleAltOutlined';
import EventNoteOutlinedIcon from '@mui/icons-material/EventNoteOutlined';
import CalendarMonthOutlinedIcon from '@mui/icons-material/CalendarMonthOutlined';
import AutorenewOutlinedIcon from '@mui/icons-material/AutorenewOutlined';
import PaymentsOutlinedIcon from '@mui/icons-material/PaymentsOutlined';
import ReceiptLongOutlinedIcon from '@mui/icons-material/ReceiptLongOutlined';
import BarChartOutlinedIcon from '@mui/icons-material/BarChartOutlined';
import TuneOutlinedIcon from '@mui/icons-material/TuneOutlined';
import AdminPanelSettingsOutlinedIcon from '@mui/icons-material/AdminPanelSettingsOutlined';
import SettingsOutlinedIcon from '@mui/icons-material/SettingsOutlined';
import ExpandLessIcon from '@mui/icons-material/ExpandLess';
import ExpandMoreIcon from '@mui/icons-material/ExpandMore';
import jollyLogo from '../../assets/logo/Jollydark.png';

const NAV_SECTIONS = [
  {
    title: 'MAIN',
    items: [
      { label: 'Dashboard', to: '/dashboard', icon: DashboardOutlinedIcon },
      { label: 'Customers', to: '/customers', icon: PeopleAltOutlinedIcon },
    ],
  },
  {
    title: 'OPERATIONS',
    items: [
      { label: 'Bookings', to: '/bookings', icon: EventNoteOutlinedIcon },
      { label: 'Subscriptions', to: '/subscriptions', icon: AutorenewOutlinedIcon },
      { label: 'Visit Calendar', to: '/visits/calendar', icon: CalendarMonthOutlinedIcon },
    ],
  },
  {
    title: 'FINANCE & REPORTS',
    items: [
      { label: 'Payments', to: '/payments', icon: PaymentsOutlinedIcon },
      { label: 'Invoices', to: '/invoices', icon: ReceiptLongOutlinedIcon },
      { label: 'Reports', to: '/reports', icon: BarChartOutlinedIcon },
      { label: 'Settings', to: '/settings', icon: SettingsOutlinedIcon },
    ],
  },
//   {
//     title: 'CONFIGURATION',
//     items: [
//       {
//         label: 'Masters',
//         icon: TuneOutlinedIcon,
//         children: [
//           'Service Offerings',
//           'Bathroom Options',
//           'Frequencies',
//           'Plans',
//           'Plan Prices',
//           'Taxes',
//           'Areas',
//           'Service Slots',
//           'Payment Modes',
//           'Receiver Accounts',
//           'Status Configuration',
//         ].map((label) => ({ label, to: `/masters/${label.toLowerCase().replace(/\s+/g, '-')}` })),
//       },
//       {
//         label: 'Administration',
//         icon: AdminPanelSettingsOutlinedIcon,
//         children: [
//           { label: 'Users', to: '/admin/users' },
//           { label: 'Roles', to: '/admin/roles' },
//           { label: 'Permissions', to: '/admin/permissions' },
//           { label: 'Audit Logs', to: '/admin/audit-logs' },
//           { label: 'Status History', to: '/admin/status-history' },
//         ],
//       },
//       { label: 'Settings', to: '/settings', icon: SettingsOutlinedIcon },
//     ],
//   },
];

function NavGroup({ item, currentPath, onNavigate }) {
  const theme = useTheme();
  const [openGroup, setOpenGroup] = useState(
    item.children ? item.children.some((child) => currentPath.startsWith(child.to)) : false
  );
  const Icon = item.icon;

  return (
    <>
      <ListItemButton
        onClick={() => setOpenGroup((open) => !open)}
        sx={{
          mx: 1.2,
          mb: 0.5,
          borderRadius: 2,
          color: 'text.primary',
          '&:hover': { bgcolor: alpha(theme.palette.primary.main, 0.08) },
        }}
      >
        <ListItemIcon sx={{ color: 'text.secondary', minWidth: 34 }}>
          <Icon fontSize="small" />
        </ListItemIcon>
        <ListItemText primaryTypographyProps={{ fontSize: '0.875rem', fontWeight: 500 }} primary={item.label} />
        {openGroup ? <ExpandLessIcon fontSize="small" sx={{ opacity: 0.7 }} /> : <ExpandMoreIcon fontSize="small" sx={{ opacity: 0.7 }} />}
      </ListItemButton>

      <Collapse in={openGroup} timeout="auto" unmountOnExit>
        <List component="div" disablePadding>
          {item.children.map((child) => {
            const selected = currentPath === child.to;
            return (
              <ListItemButton
                key={child.to}
                selected={selected}
                onClick={() => onNavigate(child.to)}
                sx={{
                  pl: 5.5,
                  mx: 1.2,
                  mb: 0.25,
                  borderRadius: 1.75,
                  color: selected ? 'primary.main' : 'text.secondary',
                  bgcolor: selected ? alpha(theme.palette.primary.main, 0.12) : 'transparent',
                  '&:hover': { bgcolor: alpha(theme.palette.primary.main, 0.08) },
                }}
              >
                <ListItemText
                  primaryTypographyProps={{ fontSize: '0.825rem', fontWeight: selected ? 600 : 400 }}
                  primary={child.label}
                />
              </ListItemButton>
            );
          })}
        </List>
      </Collapse>
    </>
  );
}

function DrawerContent({ currentPath, onNavigate }) {
  const theme = useTheme();
  const primaryGreen = theme.palette.primary.main;

  return (
    <Box
      sx={{
        height: '100%',
        display: 'flex',
        flexDirection: 'column',
        background: 'linear-gradient(180deg, #EEF6F4 0%, #E8F0EE 100%)',
        borderRight: '1px solid #D5E2DE',
      }}
    >
      <Toolbar
        sx={{
          gap: 1.5,
          px: 2.5,
          minHeight: '72px !important',
          background: 'linear-gradient(180deg, #0E4A47 0%, #0C3F3D 100%)',
          boxShadow: 'inset 0 -1px 0 rgba(255,255,255,0.06)',
        }}
      >
        <Box
          component="img"
          src={jollyLogo}
          alt="Jolly Home Needs"
          sx={{ width: 132, height: 52, objectFit: 'contain', objectPosition: 'left center' }}
        />
      </Toolbar>

      <Divider sx={{ borderColor: '#D9E7E3' }} />

      <List sx={{ flex: 1, py: 1.5, px: 0, overflowY: 'auto' }}>
        {NAV_SECTIONS.map((section) => (
          <Box key={section.title} sx={{ mb: 1.5 }}>
            <Typography
              variant="caption"
              sx={{
                px: 2.5,
                py: 0.5,
                display: 'block',
                fontSize: '0.675rem',
                fontWeight: 700,
                letterSpacing: '0.08em',
                color: '#4E6B65',
              }}
            >
              {section.title}
            </Typography>

            {section.items.map((item) => {
              if (item.children) {
                return <NavGroup key={item.label} item={item} currentPath={currentPath} onNavigate={onNavigate} />;
              }

              const selected = currentPath === item.to || (item.to !== '/' && currentPath.startsWith(item.to + '/'));

              return (
                <ListItemButton
                  key={item.to}
                  selected={selected}
                  onClick={() => onNavigate(item.to)}
                  sx={{
                    mx: 1.2,
                    mb: 0.35,
                    borderRadius: 2,
                    color: selected ? 'primary.main' : '#1D2E2A',
                    position: 'relative',
                    bgcolor: selected ? '#DDEAE7' : 'transparent',
                    boxShadow: selected ? 'inset 0 0 0 1px rgba(15, 92, 87, 0.04)' : 'none',
                    '&:hover': { bgcolor: selected ? '#D5E6E2' : alpha(theme.palette.primary.main, 0.08) },
                    '&::before': selected
                      ? {
                          content: '""',
                          position: 'absolute',
                          left: -6,
                          top: 8,
                          bottom: 8,
                          width: 4,
                          borderRadius: 2,
                          bgcolor: primaryGreen,
                        }
                      : {},
                  }}
                >
                  <ListItemIcon
                    sx={{
                      color: selected ? primaryGreen : '#5E726C',
                      minWidth: 34,
                      opacity: selected ? 1 : 0.85,
                    }}
                  >
                    <item.icon fontSize="small" />
                  </ListItemIcon>
                  <ListItemText
                    primaryTypographyProps={{ fontSize: '0.875rem', fontWeight: selected ? 700 : 500 }}
                    primary={item.label}
                  />
                </ListItemButton>
              );
            })}
          </Box>
        ))}
      </List>

      <Box sx={{ p: 2, borderTop: `1px solid ${theme.palette.divider}` }}>
        <Stack direction="row" alignItems="center" justifyContent="space-between">
          <Typography variant="caption" sx={{ color: '#4E6B65', fontSize: '0.7rem' }}>
            Phase 1 Build v1.2
          </Typography>
          <Chip
            label="OPERATIONAL"
            size="small"
            sx={{
              height: 18,
              fontSize: '0.65rem',
              bgcolor: alpha(theme.palette.success.main, 0.15),
              color: theme.palette.success.main,
              fontWeight: 700,
            }}
          />
        </Stack>
      </Box>
    </Box>
  );
}

export default function Sidebar({ currentPath, onNavigate, width = 260, mobileOpen = false, onMobileClose }) {
  return (
    <Box component="nav" sx={{ width: { md: width }, flexShrink: { md: 0 } }}>
      <Box
        sx={{
          display: { xs: mobileOpen ? 'block' : 'none', md: 'none' },
          position: 'fixed',
          inset: 0,
          zIndex: 1200,
          backgroundColor: 'rgba(8, 30, 28, 0.28)',
          ...(mobileOpen ? { display: 'block' } : {}),
        }}
        onClick={onMobileClose}
      />

      <Box
        sx={{
          width: { xs: width, md: width },
          display: { xs: mobileOpen ? 'block' : 'none', md: 'block' },
          position: { xs: 'fixed', md: 'relative' },
          height: '100vh',
          zIndex: { xs: 1300, md: 1 },
          left: { xs: 0, md: 'auto' },
          top: 0,
          background: 'linear-gradient(180deg, #EDF5F3 0%, #E6EFEC 100%)',
          boxShadow: { xs: '0 0 30px rgba(0,0,0,0.12)', md: 'none' },
        }}
      >
        <DrawerContent currentPath={currentPath} onNavigate={onNavigate} />
      </Box>
    </Box>
  );
}
