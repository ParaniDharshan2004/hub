import { useState } from 'react';
import { Link as RouterLink } from 'react-router-dom';
import Box from '@mui/material/Box';
import Tooltip from '@mui/material/Tooltip';
import IconButton from '@mui/material/IconButton';
import ContentCopyIcon from '@mui/icons-material/ContentCopy';
import CheckIcon from '@mui/icons-material/Check';

/**
 * Route resolvers mapping business entity types to their respective detail pages.
 */
const ROUTES = {
  Customer: (id) => `/customers/${id}`,
  Booking: (id) => `/bookings/${id}`,
  Subscription: (id) => `/subscriptions/${id}`,
  Visit: (id) => `/visits/${id}`,
};

/**
 * EntityLink Component
 * Renders business identifier codes (e.g., CUS-000102, BKG-202609-001) using monospace font.
 * Includes one-click clipboard copy functionality and clickable route navigation.
 *
 * @param {Object} props
 * @param {string} props.type - Entity type ("Customer" | "Booking" | "Subscription" | "Visit")
 * @param {string} props.id - Business identifier ID string
 * @param {string} [props.label] - Optional custom display text override
 */
export default function EntityLink({ type, id, label }) {
  const [copied, setCopied] = useState(false);
  const routeFn = ROUTES[type];
  const display = label || id;

  /**
   * Copies business ID to system clipboard and shows quick checkmark confirmation.
   */
  const handleCopy = (e) => {
    e.preventDefault();
    e.stopPropagation();
    if (id) {
      navigator.clipboard?.writeText(id);
      setCopied(true);
      setTimeout(() => setCopied(false), 1500);
    }
  };

  const content = (
    <Box
      component="span"
      sx={{
        fontFamily: 'IBM Plex Mono, monospace',
        fontWeight: 600,
        fontSize: '0.825rem',
        lineHeight: 1.2,
        display: 'inline-flex',
        alignItems: 'center',
        color: 'primary.main',
        backgroundColor: '#EAF3F1',
        px: 0.85,
        py: 0.35,
        borderRadius: 1,
        transition: 'all 0.15s ease',
        '&:hover': routeFn
          ? {
              backgroundColor: 'primary.main',
              color: '#FFFFFF',
            }
          : {},
      }}
    >
      {display}
    </Box>
  );

  return (
    <Box sx={{ display: 'inline-flex', alignItems: 'center', gap: 0.5, verticalAlign: 'middle' }}>
      {routeFn ? (
        <Box component={RouterLink} to={routeFn(id)} sx={{ textDecoration: 'none', display: 'inline-flex', alignItems: 'center' }}>
          {content}
        </Box>
      ) : (
        content
      )}
      <Tooltip title={copied ? 'Copied!' : 'Copy ID'}>
        <IconButton size="small" onClick={handleCopy} aria-label={`Copy ${id}`} sx={{ padding: '2px' }}>
          {copied ? <CheckIcon sx={{ fontSize: 13, color: 'success.main' }} /> : <ContentCopyIcon sx={{ fontSize: 13, opacity: 0.65 }} />}
        </IconButton>
      </Tooltip>
    </Box>
  );
}
