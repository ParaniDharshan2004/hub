import React, { useEffect } from "react";
import {
  Box, Stack, Typography, Button, IconButton, TextField, Chip, Drawer, Divider, Alert, List, ListItem, ListItemText,
} from "@mui/material";
import { useForm, Controller } from "react-hook-form";
import { yupResolver } from "@hookform/resolvers/yup";
import * as yup from "yup";

import CloseIcon from "@mui/icons-material/Close";
import EditIcon from "@mui/icons-material/Edit";
import ToggleOnIcon from "@mui/icons-material/ToggleOn";
import ToggleOffIcon from "@mui/icons-material/ToggleOff";
import LockIcon from "@mui/icons-material/Lock";

import { StatusChip } from "./RoleChips";

const COLORS = {
  primary: "#0F5C57",
  heading: "#112220",
};

export const roleSchema = yup.object({
  roleCode: yup.string().trim().matches(/^[A-Z0-9_]+$/, "Use uppercase letters, numbers, and underscore only.").max(40).required("Role code is required."),
  roleName: yup.string().trim().max(80).required("Role name is required."),
  description: yup.string().max(240, "Maximum 240 characters."),
});

export function RoleFormDrawer({ open, mode, record, onClose, onSubmit, onRequestUnsavedGuard, submitting }) {
  const isEdit = mode === "edit";
  const { control, handleSubmit, reset, formState: { errors, isDirty } } = useForm({
    resolver: yupResolver(roleSchema),
    defaultValues: { roleCode: "", roleName: "", description: "" },
  });

  useEffect(() => {
    if (open) {
      reset(isEdit && record
        ? { roleCode: record.roleCode, roleName: record.roleName, description: record.description }
        : { roleCode: "", roleName: "", description: "" });
    }
  }, [open, isEdit, record, reset]);

  const attemptClose = () => (isDirty ? onRequestUnsavedGuard(onClose) : onClose());
  const submit = handleSubmit((values) => onSubmit(values));

  return (
    <Drawer anchor="right" open={open} onClose={attemptClose}>
      <Box sx={{ width: { xs: "100vw", sm: 460 }, display: "flex", flexDirection: "column", height: "100%" }}>
        <Box sx={{ p: 2, display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid #eee" }}>
          <Typography variant="h6" sx={{ color: COLORS.heading, fontWeight: 700 }}>{isEdit ? "Edit Role" : "New Role"}</Typography>
          <IconButton aria-label="Close drawer" onClick={attemptClose}><CloseIcon /></IconButton>
        </Box>
        <Box sx={{ p: 2, overflowY: "auto", flex: 1 }}>
          <Stack spacing={2}>
            <Controller name="roleCode" control={control} render={({ field }) => (
              <TextField {...field} label="Role Code" required fullWidth disabled={isEdit}
                error={!!errors.roleCode} helperText={errors.roleCode?.message || "Fixed once created, e.g. BRANCH_CASHIER."} />
            )} />
            <Controller name="roleName" control={control} render={({ field }) => (
              <TextField {...field} label="Role Name" required fullWidth error={!!errors.roleName} helperText={errors.roleName?.message} />
            )} />
            <Controller name="description" control={control} render={({ field }) => (
              <TextField {...field} label="Description" fullWidth multiline minRows={3} error={!!errors.description} helperText={errors.description?.message} />
            )} />
            <Alert severity="info">
              Permission assignment for this role is managed on the Role–Permission Matrix screen after the role is created.
            </Alert>
          </Stack>
        </Box>
        <Divider />
        <Stack direction="row" spacing={1.5} sx={{ p: 2 }}>
          <Button variant="outlined" fullWidth onClick={attemptClose} disabled={submitting}>Cancel</Button>
          <Button variant="contained" fullWidth onClick={submit} disabled={submitting} sx={{ bgcolor: COLORS.primary }}>
            {isEdit ? "Save changes" : "Create"}
          </Button>
        </Stack>
      </Box>
    </Drawer>
  );
}

export function RoleDetailDrawer({ open, record, onClose, can, onEdit, onActivate, onDeactivate, formatDateTime }) {
  if (!record) return null;
  const Row = ({ label, value }) => (
    <Stack direction="row" justifyContent="space-between" sx={{ py: 0.75 }}>
      <Typography variant="body2" color="text.secondary">{label}</Typography>
      <Typography variant="body2" fontWeight={600} sx={{ textAlign: "right" }}>{value ?? "—"}</Typography>
    </Stack>
  );
  return (
    <Drawer anchor="right" open={open} onClose={onClose}>
      <Box sx={{ width: { xs: "100vw", sm: 460 }, height: "100%", display: "flex", flexDirection: "column" }}>
        <Box sx={{ p: 2, display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid #eee" }}>
          <Stack direction="row" spacing={1.5} alignItems="center">
            <Typography variant="h6" sx={{ color: COLORS.heading, fontWeight: 700 }}>{record.roleName}</Typography>
            <StatusChip isActive={record.isActive} />
            {record.isSystemRole && <Chip size="small" icon={<LockIcon sx={{ fontSize: 14 }} />} label="System" />}
          </Stack>
          <IconButton aria-label="Close details" onClick={onClose}><CloseIcon /></IconButton>
        </Box>
        <Box sx={{ p: 2, overflowY: "auto", flex: 1 }}>
          <Row label="Role code" value={record.roleCode} />
          <Row label="Description" value={record.description} />
          <Row label="Assigned permissions" value={record.permissionCodes.length} />
          <Divider sx={{ my: 1.5 }} />
          <Typography variant="overline" color="text.secondary">Permission codes</Typography>
          <List dense sx={{ maxHeight: 260, overflowY: "auto" }}>
            {record.permissionCodes.length === 0 && (
              <Typography variant="body2" color="text.secondary" sx={{ py: 1 }}>No permissions assigned.</Typography>
            )}
            {record.permissionCodes.map((p) => (
              <ListItem key={p} disableGutters sx={{ py: 0.25 }}>
                <ListItemText primaryTypographyProps={{ variant: "body2" }} primary={p} />
              </ListItem>
            ))}
          </List>
          <Divider sx={{ my: 1.5 }} />
          <Row label="Created" value={formatDateTime(record.createdAt)} />
          <Row label="Updated" value={formatDateTime(record.updatedAt)} />
        </Box>
        <Divider />
        <Stack direction="row" spacing={1.5} sx={{ p: 2 }}>
          {!record.isSystemRole && can("ROLE.UPDATE") && (
            <Button variant="outlined" fullWidth startIcon={<EditIcon />} onClick={() => onEdit(record)}>Edit</Button>
          )}
          {!record.isSystemRole && record.isActive && can("ROLE.DEACTIVATE") && (
            <Button variant="contained" color="error" fullWidth startIcon={<ToggleOffIcon />} onClick={() => onDeactivate(record)}>Deactivate</Button>
          )}
          {!record.isSystemRole && !record.isActive && can("ROLE.ACTIVATE") && (
            <Button variant="contained" fullWidth startIcon={<ToggleOnIcon />} onClick={() => onActivate(record)} sx={{ bgcolor: COLORS.primary }}>Activate</Button>
          )}
        </Stack>
      </Box>
    </Drawer>
  );
}
