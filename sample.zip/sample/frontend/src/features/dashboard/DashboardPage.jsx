import { useState, useMemo } from "react";
import { useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import dayjs from "dayjs";
import Grid from "@mui/material/Grid";
import Paper from "@mui/material/Paper";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import Button from "@mui/material/Button";
import Divider from "@mui/material/Divider";
import Chip from "@mui/material/Chip";
import Box from "@mui/material/Box";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import TextField from "@mui/material/TextField";
import MenuItem from "@mui/material/MenuItem";
import InputAdornment from "@mui/material/InputAdornment";
import IconButton from "@mui/material/IconButton";
import { DataGrid } from "@mui/x-data-grid";
import AddIcon from "@mui/icons-material/Add";
import EventNoteOutlinedIcon from "@mui/icons-material/EventNoteOutlined";
import CleaningServicesOutlinedIcon from "@mui/icons-material/CleaningServicesOutlined";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import DialogActions from "@mui/material/DialogActions";
import CloseIcon from "@mui/icons-material/Close";
import SearchIcon from "@mui/icons-material/Search";
import ClearIcon from "@mui/icons-material/Clear";

import {
  PieChart,
  Pie,
  Cell,
  ResponsiveContainer,
  Tooltip as ReTooltip,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
} from "recharts";

import { useTheme } from "@mui/material/styles";
import PageHeader from "../../components/common-components/PageHeader";
import Money from "../../components/common-components/Money";
import EntityLink from "../../components/common-components/EntityLink";
import StatusChip from "../../components/common-components/StatusChip";
import {
  LoadingSkeleton,
  ErrorState,
} from "../../components/common-components/PageStates";
import KpiCard from "../../components/dashboard-components/KpiCards";
import { getDashboardSummary } from "../../api.js";
import { formatDate, formatDateTime } from "../../utils/format";

/**
 * DashboardPage Component
 * Operational control center giving telecallers & admins real-time insights into today's visit workload, financial collections, and pending exceptions.
 */
export default function DashboardPage() {
  const navigate = useNavigate();
  const theme = useTheme();
  const today = dayjs().format("YYYY-MM-DD");

  

  const [dateRangeFilter, setDateRangeFilter] = useState("today"); // 'today' | 'week' | 'month'
  const [areaSearch, setAreaSearch] = useState("");

  // State for KPI Cards Modal Dialogs
  const [kpiModal, setKpiModal] = useState(null); // 'visits' | 'subscriptions' | 'renewals' | null
  const [renewalMonthFilter, setRenewalMonthFilter] = useState("ALL");

  /** Fetch live dashboard metrics */
  const { data, isLoading, isError, error, refetch } = useQuery({
    queryKey: ["dashboard", today],
    queryFn: () => getDashboardSummary({ date: today }),
  });

  const upcomingVisits = data?.upcomingVisits || [];
  const monthVisits = data?.monthVisits || [];
  const todayVisitsList = data?.todayVisitsList || [];
  const activeSubscriptionsList = data?.activeSubscriptionsList || [];
  const renewalsList = data?.renewalsList || [];

  const MONTHS = [
    { value: "ALL", label: "All Months" },
    { value: "0", label: "January" },
    { value: "1", label: "February" },
    { value: "2", label: "March" },
    { value: "3", label: "April" },
    { value: "4", label: "May" },
    { value: "5", label: "June" },
    { value: "6", label: "July" },
    { value: "7", label: "August" },
    { value: "8", label: "September" },
    { value: "9", label: "October" },
    { value: "10", label: "November" },
    { value: "11", label: "December" },
  ];

  /** Filter renewals due month-wise */
  const filteredRenewals = useMemo(() => {
    if (!renewalsList.length) return [];
    if (renewalMonthFilter === "ALL") return renewalsList;

    return renewalsList.filter((item) => {
      if (!item.renewalDate) return false;
      const monthIndex = dayjs(item.renewalDate).month();
      return String(monthIndex) === String(renewalMonthFilter);
    });
  }, [renewalsList, renewalMonthFilter]);

  /** Filter scheduled visits by date period (Today, This Week, This Month) and search by Area */
  const filteredVisits = useMemo(() => {
    const sourceVisits = dateRangeFilter === "month" ? (monthVisits.length ? monthVisits : upcomingVisits) : upcomingVisits;
    if (!sourceVisits.length) return [];

    return sourceVisits.filter((visit) => {
      // 1. Date Period Filter
      const visitDate = dayjs(visit.date);
      const now = dayjs();
      let matchesDate = false;

      if (dateRangeFilter === "today") {
        matchesDate = visitDate.isSame(now, "day");
      } else if (dateRangeFilter === "week") {
        matchesDate = visitDate.isSame(now, "week");
      } else if (dateRangeFilter === "month") {
        matchesDate = visitDate.isSame(now, "month");
      } else {
        matchesDate = true;
      }

      if (!matchesDate) return false;

      // 2. Area Text Search Input
      if (areaSearch.trim()) {
        const query = areaSearch.trim().toLowerCase();
        const areaName = (visit.customer?.area || "Unassigned").toLowerCase();
        const rawArea = (visit.customer?.area || "").toLowerCase();
        const customerName = (visit.customer?.name || "").toLowerCase();
        const visitNum = (visit.visitNumber || "").toLowerCase();
        const matchesAreaText =
          areaName.includes(query) || rawArea.includes(query);
        const matchesOtherText =
          customerName.includes(query) || visitNum.includes(query);

        if (!matchesAreaText && !matchesOtherText) return false;
      }

      return true;
    });
  }, [upcomingVisits, monthVisits, dateRangeFilter, areaSearch]);

  const scheduledVisitRows = useMemo(
    () => filteredVisits.map((visit, index) => ({ ...visit, sno: index + 1 })),
    [filteredVisits],
  );

  const scheduledVisitColumns = useMemo(
    () => [
      {
        field: "sno",
        headerName: "S.No",
        width: 75,
        type: "number",
      },
      {
        field: "customerName",
        headerName: "Customer",
        minWidth: 190,
        flex: 1.4,
        valueGetter: (value, row) => row.customer?.name || "—",
        renderCell: (params) => (
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              height: "100%",
            }}
          >
            <Typography
              variant="body2"
              sx={{ fontWeight: 600, lineHeight: 1.2 }}
            >
              {params.row.customer?.name || "—"}
            </Typography>
            {params.row.customer?.phoneNumber && (
              <Typography variant="caption" color="text.secondary">
                {params.row.customer.phoneNumber}
              </Typography>
            )}
          </Box>
        ),
      },
      {
        field: "area",
        headerName: "Area",
        minWidth: 145,
        flex: 1,
        valueGetter: (value, row) => row.customer?.area || "—",
        renderCell: (params) => (
          <Chip
            label={params.value}
            size="small"
            variant="outlined"
            sx={{ fontWeight: 500, fontSize: "0.75rem" }}
          />
        ),
      },
      {
        field: "date",
        headerName: "Scheduled Date & Time",
        minWidth: 190,
        flex: 1.3,
        valueGetter: (value, row) => formatDate(row.date),
        renderCell: (params) => (
          <Box
            sx={{
              display: "flex",
              flexDirection: "column",
              justifyContent: "center",
              height: "100%",
            }}
          >
            <Typography variant="body2" sx={{ fontWeight: 500 }}>
              {formatDate(params.row.date)}
            </Typography>
            <Typography variant="caption" color="text.secondary">
              {params.row.serviceStartTime && params.row.serviceEndTime
                ? `${params.row.serviceStartTime} - ${params.row.serviceEndTime}`
                : "Time not set"}
            </Typography>
          </Box>
        ),
      },
      {
        field: "status",
        headerName: "Status",
        minWidth: 125,
        flex: 0.8,
        renderCell: (params) => (
          <StatusChip status={params.value || "Scheduled"} />
        ),
      },
    ],
    [],
  );

  if (isLoading) {
    return (
      <>
        <PageHeader
          title="Dashboard"
          subtitle={dayjs().format("dddd, DD MMMM YYYY")}
        />
        <LoadingSkeleton rows={8} />
      </>
    );
  }

  if (isError) return <ErrorState message={error.message} onRetry={refetch} />;

  const { kpis, areaWorkload, recentBookings, exceptions } = data;

  /** Format pie chart dataset for today's completed vs pending visits */
  const visitPieData = [
    { name: "Completed", value: kpis?.completedToday || 0 },
    { name: "Pending", value: kpis?.pendingToday || 0 },
  ].filter((d) => d.value > 0);

  return (
    <>
      {/* Top Header & Quick Actions */}
      <PageHeader
        title="Dashboard"
        subtitle={`Operational summary for ${dayjs().format("dddd, DD MMMM YYYY")}`}
        actions={
          <>
            <Button
              variant="outlined"
              startIcon={<AddIcon />}
              onClick={() => navigate("/customers")}
            >
              Add Customer
            </Button>
            <Button
              variant="contained"
              startIcon={<EventNoteOutlinedIcon />}
              onClick={() => navigate("/bookings/new")}
            >
              Create Booking
            </Button>
          </>
        }
      />

      {/* Row 1: Visit Execution KPIs */}
      <Grid container spacing={2} sx={{ mb: 3 }}>
        <Grid item xs={6} sm={4} md={4}>
          <KpiCard
            label="Today's Visits"
            value={kpis.todayVisits}
            onClick={() => setKpiModal("visits")}
            icon={
              <CleaningServicesOutlinedIcon
                fontSize="small"
                sx={{ color: "primary.main", opacity: 0.8 }}
              />
            }
          />
        </Grid>

        <Grid item xs={6} sm={4} md={4}>
          <KpiCard
            label="Active Subscriptions"
            value={kpis.activeSubscriptions}
            onClick={() => setKpiModal("subscriptions")}
            icon={
              <TrendingUpIcon fontSize="small" sx={{ color: "primary.main" }} />
            }
          />
        </Grid>

        <Grid item xs={6} sm={4}>
          <KpiCard
            label="Renewals Due Soon"
            value={kpis.renewalsDueSoon}
            accent="warning.main"
            onClick={() => setKpiModal("renewals")}
          />
        </Grid>
      </Grid>


      {/* Row 4: Recent Feeds */}
      <Grid container spacing={3} sx={{ mt: 0.5 }}>
        {/* Cleaning Service Schedule Table */}
        <Grid item xs={12} md={12}>
          <Paper variant="outlined" sx={{ p: 2.5, borderRadius: 1 }}>
            <Stack
              direction={{ xs: "column", sm: "row" }}
              justifyContent="space-between"
              alignItems={{ xs: "flex-start", sm: "center" }}
              spacing={2}
              sx={{ mb: 2.5 }}
            >
              <Box>
                <Stack direction="row" alignItems="center" spacing={1.5}>
                  <Typography variant="h6" sx={{ fontWeight: 700 }}>
                    Scheduled Cleaning Services
                  </Typography>
                  <Chip
                    label={`${filteredVisits.length} ${filteredVisits.length === 1 ? "Service" : "Services"}`}
                    size="small"
                    color="primary"
                    sx={{ fontWeight: 600, fontSize: "0.75rem" }}
                  />
                </Stack>
                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{ mt: 0.5 }}
                >
                  {dateRangeFilter === "today"
                    ? `Showing services scheduled for today (${dayjs().format("DD MMM YYYY")})`
                    : dateRangeFilter === "week"
                      ? `Showing services scheduled for this week (${dayjs().startOf("week").format("DD MMM")} – ${dayjs().endOf("week").format("DD MMM YYYY")})`
                      : `Showing services scheduled for ${dayjs().format("MMMM YYYY")}`}
                </Typography>
              </Box>
              <Button
                size="small"
                variant="outlined"
                onClick={() => navigate("/visits/calendar")}
              >
                View Visit Calendar
              </Button>
            </Stack>

            {/* Filter and Search Toolbar */}
            <Stack
              direction={{ xs: "column", md: "row" }}
              spacing={2}
              alignItems={{ xs: "stretch", md: "center" }}
              justifyContent="space-between"
              sx={{
                mb: 2.5,
                p: 1.5,
                bgcolor: "grey.50",
                borderRadius: 1,
                border: "1px solid",
                borderColor: "divider",
              }}
            >
              {/* Search by Area Text Field (Stretched) */}
              <TextField
                size="small"
                placeholder="Search by area..."
                value={areaSearch}
                onChange={(e) => {
                  setAreaSearch(e.target.value);
                }}
                sx={{ flex: 1, minWidth: { xs: "100%", sm: 240 } }}
                InputProps={{
                  startAdornment: (
                    <InputAdornment position="start">
                      <SearchIcon
                        fontSize="small"
                        sx={{ color: "text.secondary" }}
                      />
                    </InputAdornment>
                  ),
                  endAdornment: areaSearch ? (
                    <InputAdornment position="end">
                      <IconButton
                        size="small"
                        onClick={() => setAreaSearch("")}
                      >
                        <ClearIcon fontSize="small" />
                      </IconButton>
                    </InputAdornment>
                  ) : null,
                }}
              />

              {/* Period Date Filter Dropdown */}
              <TextField
                select
                size="small"
                label="Period"
                value={dateRangeFilter}
                onChange={(e) => {
                  setDateRangeFilter(e.target.value);
                }}
                sx={{ width: { xs: "100%", sm: 160 } }}
              >
                <MenuItem value="today">Today</MenuItem>
                <MenuItem value="week">This Week</MenuItem>
                <MenuItem value="month">This Month</MenuItem>
              </TextField>
            </Stack>

            {filteredVisits.length === 0 ? (
              <Box sx={{ py: 6, textAlign: "center" }}>
                <Typography
                  variant="subtitle1"
                  color="text.secondary"
                  sx={{ fontWeight: 600 }}
                >
                  No cleaning services found
                </Typography>
                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{ mt: 0.5 }}
                >
                  {areaSearch
                    ? "No services match your area search."
                    : `No services scheduled for ${
                        dateRangeFilter === "today"
                          ? "today"
                          : dateRangeFilter === "week"
                            ? "this week"
                            : "this month"
                      }.`}
                </Typography>
              </Box>
            ) : (
              <Box sx={{ width: "100%" }}>
                <DataGrid
                  rows={scheduledVisitRows}
                  columns={scheduledVisitColumns}
                  getRowId={(row) => row.id || row.visitNumber}
                  autoHeight
                  disableRowSelectionOnClick
                  onRowClick={(params) =>
                    navigate(`/visits/${params.row.visitNumber}`)
                  }
                  sx={{
                    border: "none",
                    "& .MuiDataGrid-row": {
                      cursor: "pointer",
                      "&:hover": { bgcolor: "#F3F7F6" },
                    },
                    "& .MuiDataGrid-columnHeaders": { bgcolor: "#F3F7F6" },
                  }}
                  initialState={{
                    pagination: { paginationModel: { pageSize: 5 } },
                  }}
                  pageSizeOptions={[5, 10, 25]}
                />
              </Box>
            )}
          </Paper>
        </Grid>
      </Grid>

      {/* Row 5: Pending Stale Draft Exceptions */}
      {exceptions.staleDrafts.length > 0 && (
        <Paper
          variant="outlined"
          sx={{
            p: 2.5,
            mt: 3,
            borderRadius: 1,
            borderColor: "warning.main",
            bgcolor: "#FCF3E3",
          }}
        >
          <Typography
            variant="subtitle1"
            sx={{ mb: 1, fontWeight: 700, color: "warning.dark" }}
          >
            Action Required: Stale Draft Bookings
          </Typography>
          <Stack direction="row" spacing={1} flexWrap="wrap">
            {exceptions.staleDrafts.map((b) => (
              <Chip
                key={b.id}
                label={`Draft ${b.bookingNumber}`}
                color="warning"
                onClick={() => navigate(`/bookings/${b.bookingNumber}`)}
                sx={{ fontWeight: 600, cursor: "pointer" }}
              />
            ))}
          </Stack>
        </Paper>
      )}

      {/* 1. Today's Visits Modal */}
      <Dialog
        open={kpiModal === "visits"}
        onClose={() => setKpiModal(null)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle
          sx={{
            m: 0,
            p: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box>
            <Typography variant="h6" sx={{ fontWeight: 700 }}>
              Today's Visits Details
            </Typography>
            <Typography variant="caption" color="text.secondary">
              List of scheduled services for today (
              {dayjs().format("DD MMMM YYYY")})
            </Typography>
          </Box>
          <IconButton size="small" onClick={() => setKpiModal(null)}>
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 2 }}>
          {todayVisitsList.length === 0 ? (
            <Typography
              variant="body2"
              color="text.secondary"
              sx={{ py: 3, textAlign: "center" }}
            >
              No visits scheduled for today.
            </Typography>
          ) : (
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow sx={{ bgcolor: "grey.50" }}>
                    <TableCell sx={{ fontWeight: 700 }}>
                      Customer Name
                    </TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>
                      Mobile Number
                    </TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Visit Date</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>
                      No. of Service
                    </TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {todayVisitsList.map((row) => (
                    <TableRow key={row.id} hover>
                      <TableCell sx={{ fontWeight: 600 }}>
                        {row.customerName}
                      </TableCell>
                      <TableCell>{row.mobileNumber}</TableCell>
                      <TableCell>{formatDate(row.visitDate)}</TableCell>
                      <TableCell>{row.noOfService}</TableCell>
                      <TableCell>
                        <StatusChip status={row.status} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 2.5, py: 1.5 }}>
          <Button onClick={() => setKpiModal(null)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* 2. Active Subscriptions Modal */}
      <Dialog
        open={kpiModal === "subscriptions"}
        onClose={() => setKpiModal(null)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle
          sx={{
            m: 0,
            p: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box>
            <Typography variant="h6" sx={{ fontWeight: 700 }}>
              Active Subscriptions
            </Typography>
            <Typography variant="caption" color="text.secondary">
              List of currently active customer subscriptions
            </Typography>
          </Box>
          <IconButton size="small" onClick={() => setKpiModal(null)}>
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 2 }}>
          {activeSubscriptionsList.length === 0 ? (
            <Typography
              variant="body2"
              color="text.secondary"
              sx={{ py: 3, textAlign: "center" }}
            >
              No active subscriptions found.
            </Typography>
          ) : (
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow sx={{ bgcolor: "grey.50" }}>
                    <TableCell sx={{ fontWeight: 700 }}>
                      Customer Name
                    </TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Phone Number</TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>
                      Type of Subscription
                    </TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>Status</TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {activeSubscriptionsList.map((row) => (
                    <TableRow key={row.id} hover>
                      <TableCell sx={{ fontWeight: 600 }}>
                        {row.customerName}
                      </TableCell>
                      <TableCell>{row.phoneNumber}</TableCell>
                      <TableCell>{row.subscriptionType}</TableCell>
                      <TableCell>
                        <StatusChip status={row.status || "Active"} />
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 2.5, py: 1.5 }}>
          <Button onClick={() => setKpiModal(null)}>Close</Button>
        </DialogActions>
      </Dialog>

      {/* 3. Renewals Due Soon Modal */}
      <Dialog
        open={kpiModal === "renewals"}
        onClose={() => setKpiModal(null)}
        maxWidth="md"
        fullWidth
      >
        <DialogTitle
          sx={{
            m: 0,
            p: 2,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box>
            <Typography variant="h6" sx={{ fontWeight: 700 }}>
              Renewals Due Details
            </Typography>
            <Typography variant="caption" color="text.secondary">
              Filter and view subscription renewals due month-wise
            </Typography>
          </Box>
          <IconButton size="small" onClick={() => setKpiModal(null)}>
            <CloseIcon />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers sx={{ p: 2 }}>
          {/* Month Filter Dropdown */}
          <Stack direction="row" alignItems="center" spacing={2} sx={{ mb: 2 }}>
            <TextField
              select
              size="small"
              label="Filter by Month"
              value={renewalMonthFilter}
              onChange={(e) => setRenewalMonthFilter(e.target.value)}
              sx={{ width: 200 }}
            >
              {MONTHS.map((m) => (
                <MenuItem key={m.value} value={m.value}>
                  {m.label}
                </MenuItem>
              ))}
            </TextField>
          </Stack>

          {filteredRenewals.length === 0 ? (
            <Typography
              variant="body2"
              color="text.secondary"
              sx={{ py: 3, textAlign: "center" }}
            >
              No renewals found for the selected month.
            </Typography>
          ) : (
            <TableContainer>
              <Table size="small">
                <TableHead>
                  <TableRow sx={{ bgcolor: "grey.50" }}>
                    <TableCell sx={{ fontWeight: 700 }}>
                      Customer Name
                    </TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>
                      Mobile Number
                    </TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>
                      Renewal Due Date
                    </TableCell>
                    <TableCell sx={{ fontWeight: 700 }}>
                      Type of Subscription
                    </TableCell>
                  </TableRow>
                </TableHead>
                <TableBody>
                  {filteredRenewals.map((row) => (
                    <TableRow key={row.id} hover>
                      <TableCell sx={{ fontWeight: 600 }}>
                        {row.customerName}
                      </TableCell>
                      <TableCell>{row.mobileNumber}</TableCell>
                      <TableCell>{formatDate(row.renewalDate)}</TableCell>
                      <TableCell>{row.subscriptionType}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </TableContainer>
          )}
        </DialogContent>
        <DialogActions sx={{ px: 2.5, py: 1.5 }}>
          <Button onClick={() => setKpiModal(null)}>Close</Button>
        </DialogActions>
      </Dialog>
    </>
  );
}
