import { useState, useEffect } from 'react';
import Box from '@mui/material/Box';
import Paper from '@mui/material/Paper';
import Stack from '@mui/material/Stack';
import Typography from '@mui/material/Typography';
import Grid from '@mui/material/Grid';
import Card from '@mui/material/Card';
import CardContent from '@mui/material/CardContent';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Alert from '@mui/material/Alert';
import CircularProgress from '@mui/material/CircularProgress';
import Divider from '@mui/material/Divider';
import Switch from '@mui/material/Switch';
import FormControlLabel from '@mui/material/FormControlLabel';
import InputAdornment from '@mui/material/InputAdornment';
import SaveIcon from '@mui/icons-material/Save';
import EditIcon from '@mui/icons-material/Edit';
import RefreshIcon from '@mui/icons-material/Refresh';
import AccessTimeOutlinedIcon from '@mui/icons-material/AccessTimeOutlined';
import BathtubOutlinedIcon from '@mui/icons-material/BathtubOutlined';
import AdminPanelSettingsOutlinedIcon from '@mui/icons-material/AdminPanelSettingsOutlined';

import PageHeader from '../../components/common-components/PageHeader';
import { apiFetch } from '../../api';
import { useSnackbar } from '../../components/common-components/SnackbarProvider';

const DEFAULT_COUNTS = [1, 2, 3, 4];
const DEFAULT_FALLBACKS = {
  1: { price: 500, duration: 30 },
  2: { price: 850, duration: 60 },
  3: { price: 1200, duration: 90 },
  4: { price: 1500, duration: 120 },
};

export default function SettingsPage() {
  const snackbar = useSnackbar();
  const [loading, setLoading] = useState(true);
  const [savingCount, setSavingCount] = useState(null);
  const [configs, setConfigs] = useState([]);
  const [errorMsg, setErrorMsg] = useState(null);

  const loadData = async () => {
    setLoading(true);
    setErrorMsg(null);
    try {
      const [counts, durations, pricings] = await Promise.all([
        apiFetch('/bathroom-counts').catch(() => []),
        apiFetch('/service-durations').catch(() => []),
        apiFetch('/pricing').catch(() => []),
      ]);

      const countsList = Array.isArray(counts) ? counts : [];
      const durationsList = Array.isArray(durations) ? durations : [];
      const pricingsList = Array.isArray(pricings) ? pricings : [];

      const merged = DEFAULT_COUNTS.map((cnt) => {
        const countObj = countsList.find((c) => Number(c.bathroomCount) === cnt);
        const countId = countObj?._id || null;

        const pricingObj = pricingsList.find((p) => {
          const matchedCount =
            p.bathroomCountReference?.bathroomCount ??
            p.bathroomCountId?.bathroomCount;
          return Number(matchedCount) === cnt && p.isActive !== false;
        }) || pricingsList.find((p) => {
          return String(p.bathroomCountReference?._id || p.bathroomCountReference) === String(countId) && p.isActive !== false;
        });

        const fallback = DEFAULT_FALLBACKS[cnt] || { price: cnt * 400, duration: cnt * 30 };
        const priceVal = pricingObj?.price ?? fallback.price;
        
        const durationObj = pricingObj?.serviceDurationReference || pricingObj?.serviceDurationId;
        const durationMins = typeof durationObj === 'object' ? durationObj?.durationMinutes : fallback.duration;

        return {
          count: cnt,
          price: priceVal,
          durationMinutes: durationMins || fallback.duration,
          isActive: pricingObj?.isActive !== false,
          pricingId: pricingObj?._id || null,
          bathroomCountId: countId,
          serviceDurationId: typeof durationObj === 'object' ? durationObj?._id : null,
          isEditing: false,
          errors: {},
        };
      });

      setConfigs(merged);
    } catch (err) {
      setErrorMsg(err.message || 'Failed to load bathroom pricing configuration.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    loadData();
  }, []);

  const handleEdit = (count) => {
    setConfigs((prev) =>
      prev.map((c) => (c.count === count ? { ...c, isEditing: true } : c))
    );
  };

  const handleCancel = (count) => {
    loadData();
  };

  const handleChange = (count, field, value) => {
    setConfigs((prev) =>
      prev.map((c) => {
        if (c.count !== count) return c;
        const updated = { ...c, [field]: value };
        const errors = { ...updated.errors };
        if (field === 'price' && value >= 0) delete errors.price;
        if (field === 'durationMinutes' && value > 0) delete errors.durationMinutes;
        return { ...updated, errors };
      })
    );
  };

  const handleSave = async (item) => {
    const errors = {};
    const priceNum = Number(item.price);
    const durationNum = Number(item.durationMinutes);

    if (isNaN(priceNum) || priceNum < 0) {
      errors.price = 'Price must be a valid non-negative number';
    }
    if (isNaN(durationNum) || durationNum <= 0) {
      errors.durationMinutes = 'Duration must be greater than 0 minutes';
    }

    if (Object.keys(errors).length > 0) {
      setConfigs((prev) =>
        prev.map((c) => (c.count === item.count ? { ...c, errors } : c))
      );
      return;
    }

    setSavingCount(item.count);
    try {
      // 1. Ensure BathroomCount record exists
      let bCountId = item.bathroomCountId;
      if (!bCountId) {
        const counts = await apiFetch('/bathroom-counts').catch(() => []);
        const existing = counts.find((c) => Number(c.bathroomCount) === item.count);
        if (existing) {
          bCountId = existing._id;
        } else {
          const newCnt = await apiFetch('/bathroom-counts', {
            method: 'POST',
            body: JSON.stringify({ bathroomCount: item.count, isActive: true }),
          });
          bCountId = newCnt._id;
        }
      }

      // 2. Ensure ServiceDuration record exists
      let sDurationId = item.serviceDurationId;
      const durations = await apiFetch('/service-durations').catch(() => []);
      const existingDur = durations.find((d) => Number(d.durationMinutes) === durationNum);
      if (existingDur) {
        sDurationId = existingDur._id;
      } else {
        const newDur = await apiFetch('/service-durations', {
          method: 'POST',
          body: JSON.stringify({ durationMinutes: durationNum, isActive: true }),
        });
        sDurationId = newDur._id;
      }

      // 3. Create/Update Pricing record
      if (item.pricingId) {
        await apiFetch(`/pricing/${item.pricingId}`, {
          method: 'PUT',
          body: JSON.stringify({
            price: priceNum,
            bathroomCountReference: bCountId,
            serviceDurationReference: sDurationId,
            isActive: item.isActive,
          }),
        });
      } else {
        await apiFetch('/pricing', {
          method: 'POST',
          body: JSON.stringify({
            price: priceNum,
            bathroomCountReference: bCountId,
            serviceDurationReference: sDurationId,
            isActive: item.isActive,
            deactivatePrevious: true,
          }),
        });
      }

      snackbar.success(`${item.count} Bathroom configuration saved successfully.`);
      await loadData();
    } catch (err) {
      snackbar.error(`Failed to save configuration: ${err.message}`);
    } finally {
      setSavingCount(null);
    }
  };

  return (
    <Stack spacing={3}>
      <PageHeader
        title="Settings & Administration"
        subtitle="Configure Super Admin system parameters, service pricing, and cleaning durations."
        icon={AdminPanelSettingsOutlinedIcon}
        action={
          <Button
            variant="outlined"
            startIcon={<RefreshIcon />}
            onClick={loadData}
            disabled={loading}
          >
            Refresh
          </Button>
        }
      />

      {errorMsg && <Alert severity="error">{errorMsg}</Alert>}

      {loading ? (
        <Box sx={{ display: 'flex', justifyContent: 'center', p: 5 }}>
          <CircularProgress />
        </Box>
      ) : (
        <Paper sx={{ p: 3, borderRadius: 2 }}>
          <Box sx={{ mb: 3 }}>
            <Typography variant="h6" fontWeight={700} gutterBottom>
              Bathroom Cleaning Configuration
            </Typography>
            <Typography variant="body2" color="text.secondary">
              Set the price and cleaning duration for each supported bathroom count. These settings dynamically govern booking availability, total service duration, and invoice pricing.
            </Typography>
          </Box>

          <Divider sx={{ mb: 3 }} />

          <Grid container spacing={3}>
            {configs.map((item) => {
              const isSaving = savingCount === item.count;
              return (
                <Grid item xs={12} sm={6} md={3} key={item.count}>
                  <Card
                    variant="outlined"
                    sx={{
                      height: '100%',
                      borderColor: item.isEditing ? 'primary.main' : 'divider',
                      boxShadow: item.isEditing ? 2 : 0,
                      transition: 'all 0.2s ease-in-out',
                    }}
                  >
                    <CardContent>
                      <Stack spacing={2}>
                        <Stack direction="row" justifyContent="space-between" alignItems="center">
                          <Stack direction="row" spacing={1} alignItems="center">
                            <BathtubOutlinedIcon color="primary" />
                            <Typography variant="h6" fontWeight={700}>
                              {item.count} {item.count === 1 ? 'Bathroom' : 'Bathrooms'}
                            </Typography>
                          </Stack>
                          <FormControlLabel
                            control={
                              <Switch
                                size="small"
                                checked={item.isActive}
                                disabled={!item.isEditing || isSaving}
                                onChange={(e) =>
                                  handleChange(item.count, 'isActive', e.target.checked)
                                }
                              />
                            }
                            label={item.isActive ? 'Active' : 'Inactive'}
                            sx={{ m: 0 }}
                          />
                        </Stack>

                        <Divider />

                        <TextField
                          label="Cleaning Price"
                          type="number"
                          size="small"
                          fullWidth
                          disabled={!item.isEditing || isSaving}
                          value={item.price}
                          onChange={(e) =>
                            handleChange(item.count, 'price', e.target.value)
                          }
                          error={Boolean(item.errors?.price)}
                          helperText={item.errors?.price}
                          InputProps={{
                            startAdornment: (
                              <InputAdornment position="start">₹</InputAdornment>
                            ),
                          }}
                        />

                        <TextField
                          label="Cleaning Duration"
                          type="number"
                          size="small"
                          fullWidth
                          disabled={!item.isEditing || isSaving}
                          value={item.durationMinutes}
                          onChange={(e) =>
                            handleChange(item.count, 'durationMinutes', e.target.value)
                          }
                          error={Boolean(item.errors?.durationMinutes)}
                          helperText={item.errors?.durationMinutes}
                          InputProps={{
                            endAdornment: (
                              <InputAdornment position="end">mins</InputAdornment>
                            ),
                            startAdornment: (
                              <InputAdornment position="start">
                                <AccessTimeOutlinedIcon fontSize="small" />
                              </InputAdornment>
                            ),
                          }}
                        />

                        <Box sx={{ pt: 1 }}>
                          {!item.isEditing ? (
                            <Button
                              variant="outlined"
                              fullWidth
                              startIcon={<EditIcon />}
                              onClick={() => handleEdit(item.count)}
                            >
                              Edit Pricing
                            </Button>
                          ) : (
                            <Stack direction="row" spacing={1}>
                              <Button
                                variant="contained"
                                fullWidth
                                color="primary"
                                startIcon={
                                  isSaving ? (
                                    <CircularProgress size={16} color="inherit" />
                                  ) : (
                                    <SaveIcon />
                                  )
                                }
                                disabled={isSaving}
                                onClick={() => handleSave(item)}
                              >
                                {isSaving ? 'Saving' : 'Save'}
                              </Button>
                              <Button
                                variant="outlined"
                                color="inherit"
                                disabled={isSaving}
                                onClick={() => handleCancel(item.count)}
                              >
                                Cancel
                              </Button>
                            </Stack>
                          )}
                        </Box>
                      </Stack>
                    </CardContent>
                  </Card>
                </Grid>
              );
            })}
          </Grid>
        </Paper>
      )}
    </Stack>
  );
}
