import { useMemo, useState } from "react";
import dayjs from "dayjs";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import Box from "@mui/material/Box";
import Dialog from "@mui/material/Dialog";
import DialogTitle from "@mui/material/DialogTitle";
import DialogContent from "@mui/material/DialogContent";
import IconButton from "@mui/material/IconButton";
import CloseIcon from "@mui/icons-material/Close";

import CalendarHeader from "../../components/calendar-components/CalendarHeader";
import CalendarDatePicker from "../../components/calendar-components/CalendarDatePicker";
import RouteByBlock from "../../components/calendar-components/RouteByBlock";
import DayTimeline from "../../components/calendar-components/DayTimeline";
import BookingDetailsDialog from "../../components/calendar-components/BookingDetailsDialog";
import CompleteJobForm from "../../components/calendar-components/CompleteJobForm";
import { printServiceAreaDocument } from "../../components/calendar-components/serviceAreaPrintHelper";
import { useSnackbar } from "../../components/common-components/SnackbarProvider";
import { LoadingSkeleton, ErrorState } from "../../components/common-components/PageStates";
import { listVisits, getBookingMasters, updateVisit } from "../../api.js";
import { toDateStr } from "../../utils/scheduling";

function timeFromSlotId(slotId) {
  const match = String(slotId || "").match(/-(\d+)$/);
  if (!match) return "";
  const minutes = Number(match[1]);
  if (minutes < 0 || minutes > 1439) return "";
  return `${String(Math.floor(minutes / 60)).padStart(2, "0")}:${String(minutes % 60).padStart(2, "0")}`;
}

function toCalendarBooking(visit) {
  const customer = visit.customer || (visit.customerId && typeof visit.customerId === "object" ? visit.customerId : {});
  const booking = visit.booking || (visit.bookingId && typeof visit.bookingId === "object" ? visit.bookingId : {});
  const calendarCustomer = {
    ...customer,
    phone: customer.phone || customer.mobile || customer.phoneNumber || "",
    blockNumber: customer.blockNumber || customer.block || "",
  };
  const scheduledDate = visit.scheduledDate || visit.date || booking.scheduledDate || booking.startDateTime;
  const bathroomCount =
    booking.bathroomCount ??
    booking.bathrooms ??
    visit.bathroomCount ??
    visit.bathrooms ??
    booking.bathroomCountId?.bathroomCount ??
    visit.bathroomCountId?.bathroomCount ??
    1;
  // Use dayjs (local timezone) to extract the date so that UTC ISO strings
  // like "2026-09-18T18:30:00Z" (= 2026-09-19 in IST) are displayed on the
  // correct calendar day instead of the previous day.
  const date = scheduledDate ? dayjs(scheduledDate).format("YYYY-MM-DD") : "";
  const slotTime = timeFromSlotId(booking.slotId || visit.slotId);
  const duration = Number(
    booking.durationMinutes || booking.serviceDurationId?.durationMinutes || 60
  );
  const startDateTime = booking.startDateTime || visit.startDateTime;
  const hasRealTime = startDateTime && dayjs(startDateTime).isValid() && !String(startDateTime).includes("T00:00");
  const hasScheduledTime =
    typeof scheduledDate === "string" &&
    scheduledDate.includes("T") &&
    !scheduledDate.includes("T00:00");
  const startTime =
    slotTime ||
    (hasScheduledTime ? dayjs(scheduledDate).format("HH:mm") : "") ||
    (hasRealTime ? dayjs(startDateTime).format("HH:mm") : "") ||
    "08:00";

  return {
    id: visit._id || visit.id,
    visitNumber: visit.visitNumber || booking.bookingId || visit._id,
    bookingNumber: booking.bookingId || visit.visitNumber || visit._id,
    customerId: customer._id || customer.id || visit.customerId,
    customer: calendarCustomer,
    booking,
    date,
    startTime,
    bathroomCount,
    duration,
    status: visit.isCancelled ? "cancelled" : visit.isCompleted ? "completed" : "scheduled",
    blockNumber: customer.block || "",
    area: customer.area || "",
  };
}



/**
 * ServiceCalendarPage Component
 * Main service operations calendar: combines date picking, daily timeline, route mapping, and execution.
 */
export default function ServiceCalendarPage() {
  const queryClient = useQueryClient();
  const snackbar = useSnackbar();
  const today = toDateStr(new Date());

  const [selectedDate, setSelectedDate] = useState(dayjs().format("YYYY-MM-DD"));
  const [selectedBooking, setSelectedBooking] = useState(null);
  const [completeTarget, setCompleteTarget] = useState(null);

  const {
    data: visits = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useQuery({
    queryKey: ["visits", "service-calendar"],
    queryFn: () => listVisits(),
  });

  const mutation = useMutation({
    mutationFn: ({ id, changes }) => updateVisit(id, changes),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["visits"] });
      queryClient.invalidateQueries({ queryKey: ["subscriptions"] });
      queryClient.invalidateQueries({ queryKey: ["dashboard"] });
      queryClient.invalidateQueries({ queryKey: ["customers"] });
      snackbar.success("Service marked as completed.");
    },
    onError: (err) => {
      snackbar.error(err.message || "Failed to update visit status.");
    },
  });

  const bookings = useMemo(() => visits.map(toCalendarBooking), [visits]);

  const { data: bookingMasters } = useQuery({
    queryKey: ["booking-masters"],
    queryFn: getBookingMasters,
  });

  const durationByBathrooms = useMemo(
    () => ({
      ...(bookingMasters?.durationByBathroom || {}),
      ...bookings.reduce((durations, booking) => {
        if (!durations[booking.bathroomCount]) {
          durations[booking.bathroomCount] = booking.duration;
        }
        return durations;
      }, {}),
    }),
    [bookings, bookingMasters]
  );

  const customerById = useMemo(() => {
    const customers = {};
    visits.forEach((visit) => {
      const customer = visit.customer || (visit.customerId && typeof visit.customerId === "object" ? visit.customerId : null);
      if (customer) {
        const customerId = customer._id || customer.id;
        customers[customerId] = {
          ...customer,
          phone: customer.phoneNumber || customer.mobile,
          blockNumber: customer.block || customer.blockNumber || "",
        };
      }
    });
    return customers;
  }, [visits]);

  const dayBookings = useMemo(
    () => bookings.filter((booking) => booking.date === selectedDate),
    [bookings, selectedDate]
  );

  const monthCursor = selectedDate.slice(0, 7);
  const activeBookings = dayBookings.filter((booking) => booking.status !== "cancelled");
  const completedCount = activeBookings.filter((booking) => booking.status === "completed").length;

  const handlePrintServices = (data) => {
    printServiceAreaDocument(data);
  };

  const handleComplete = async (id) => {
    await mutation.mutateAsync({
      id,
      changes: {
        isCompleted: true,
        isPending: false,
        actualEndDateTime: new Date().toISOString(),
      },
    });
    setCompleteTarget(null);
  };

  if (isLoading) {
    return (
      <Box sx={{ p: { xs: 2, sm: 3.5 } }}>
        <LoadingSkeleton rows={8} />
      </Box>
    );
  }

  if (isError) {
    return (
      <Box sx={{ p: { xs: 2, sm: 3.5 } }}>
        <ErrorState message={error?.message || "Could not load service calendar"} onRetry={refetch} />
      </Box>
    );
  }

  return (
    <Box sx={{ width: "100%", pb: 3 }}>
      {/* Calendar Header with Summary & Today shortcut */}
      <CalendarHeader
        selectedDate={selectedDate}
        onToday={() => setSelectedDate(today)}
        totalCount={activeBookings.length}
        completedCount={completedCount}
      />

      {/* Main Grid Layout: Timeline + Date Picker + Route/Area summary */}
      <Box
        sx={{
          display: "grid",
          gridTemplateColumns: {
            xs: "minmax(0, 1fr)",
            lg: "minmax(0, 3fr) minmax(0, 7fr)",
          },
          gridTemplateAreas: {
            xs: '"picker" "timeline" "route"',
            lg: '"picker timeline" "route timeline"',
          },
          gridTemplateRows: {
            lg: "auto 1fr",
          },
          gap: { xs: 2, lg: 2.5 },
          alignItems: "start",
        }}
      >
        <Box sx={{ gridArea: "timeline", minWidth: 0 }}>
          <DayTimeline
            selectedDate={selectedDate}
            setSelectedDate={setSelectedDate}
            dayBookings={dayBookings}
            customerById={customerById}
            onComplete={setCompleteTarget}
            durationByBathrooms={durationByBathrooms}
            onBookingClick={setSelectedBooking}
            dayStartMin={bookingMasters?.dayStartMin}
            dayEndMin={bookingMasters?.dayEndMin}
          />
        </Box>

        <Box sx={{ gridArea: "picker", minWidth: 0 }}>
          <CalendarDatePicker
            monthCursor={monthCursor}
            selectedDate={selectedDate}
            setSelectedDate={setSelectedDate}
            bookings={bookings}
          />
        </Box>

        <Box sx={{ gridArea: "route", minWidth: 0 }}>
          <RouteByBlock
            bookings={dayBookings}
            customerById={customerById}
            selectedDate={selectedDate}
            onPrintServices={handlePrintServices}
          />
        </Box>
      </Box>

      {/* Booking Details Modal */}
      <BookingDetailsDialog
        booking={selectedBooking}
        customerById={customerById}
        durationByBathrooms={durationByBathrooms}
        onClose={() => setSelectedBooking(null)}
      />

      {/* Mark Job Completed Modal */}
      <Dialog
        open={!!completeTarget}
        onClose={() => setCompleteTarget(null)}
        fullWidth
        maxWidth="xs"
      >
        <DialogTitle sx={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          Mark Job Completed
          <IconButton size="small" onClick={() => setCompleteTarget(null)}>
            <CloseIcon fontSize="small" />
          </IconButton>
        </DialogTitle>
        <DialogContent dividers>
          {completeTarget && (
            <CompleteJobForm
              booking={completeTarget}
              customerById={customerById}
              onSubmit={handleComplete}
            />
          )}
        </DialogContent>
      </Dialog>
    </Box>
  );
}
