// constants/icons.js

import ArrowBackIcon from "@mui/icons-material/ArrowBack";
import ArrowForwardIcon from "@mui/icons-material/ArrowForward";
import ArrowForwardRoundedIcon from "@mui/icons-material/ArrowForwardRounded";
import ArrowOutwardIcon from "@mui/icons-material/ArrowOutward";
import EmailIcon from "@mui/icons-material/Email";
import LinkedInIcon from "@mui/icons-material/LinkedIn";
import FormatQuoteIcon from "@mui/icons-material/FormatQuote";
import FormatQuoteRoundedIcon from "@mui/icons-material/FormatQuoteRounded";
import StarIcon from "@mui/icons-material/Star";
import StarBorderIcon from "@mui/icons-material/StarBorder";
import SchoolIcon from "@mui/icons-material/School";
import WorkIcon from "@mui/icons-material/Work";
import AccountBalanceIcon from "@mui/icons-material/AccountBalance";
import BusinessIcon from "@mui/icons-material/Business";
import GroupsIcon from "@mui/icons-material/Groups";
import PersonIcon from "@mui/icons-material/Person";
import VisibilityIcon from "@mui/icons-material/Visibility";
import TrackChangesIcon from "@mui/icons-material/TrackChanges";
import HandshakeIcon from "@mui/icons-material/Handshake";
import ShieldIcon from "@mui/icons-material/Shield";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import IntegrationInstructionsIcon from "@mui/icons-material/IntegrationInstructions";
import ComputerIcon from "@mui/icons-material/Computer";
import TranslateIcon from "@mui/icons-material/Translate";
import MenuBookIcon from "@mui/icons-material/MenuBook";
import OpenInNewIcon from "@mui/icons-material/OpenInNew";
import HelpOutlineRoundedIcon from "@mui/icons-material/HelpOutlineRounded";
import PlaceRoundedIcon from "@mui/icons-material/PlaceRounded";
import EventAvailableIcon from "@mui/icons-material/EventAvailable";
import PolicyIcon from "@mui/icons-material/Policy";
import SettingsSuggestIcon from "@mui/icons-material/SettingsSuggest";
import SendTimeExtensionIcon from "@mui/icons-material/SendTimeExtension";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import VerifiedOutlinedIcon from "@mui/icons-material/VerifiedOutlined";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import PaidOutlinedIcon from "@mui/icons-material/PaidOutlined";
import RocketLaunchOutlinedIcon from "@mui/icons-material/RocketLaunchOutlined";
import LaptopOutlinedIcon from "@mui/icons-material/LaptopOutlined";
import TrendingUpOutlinedIcon from "@mui/icons-material/TrendingUpOutlined";
import CheckIcon from "@mui/icons-material/Check";
import LanguageRoundedIcon from "@mui/icons-material/LanguageRounded";
import WorkspacePremiumRoundedIcon from "@mui/icons-material/WorkspacePremiumRounded";
import CheckCircleRoundedIcon from "@mui/icons-material/CheckCircleRounded";
import ReceiptLongRoundedIcon from "@mui/icons-material/ReceiptLongRounded";
import InsightsRoundedIcon from "@mui/icons-material/InsightsRounded";
import CodeRoundedIcon from "@mui/icons-material/CodeRounded";
import MemoryRoundedIcon from "@mui/icons-material/MemoryRounded";
import SupportAgentRoundedIcon from "@mui/icons-material/SupportAgentRounded";
import PhoneIcon from "@mui/icons-material/Phone";
import User from "@mui/icons-material/VerifiedUser";
import DataObjectIcon from "@mui/icons-material/DataObject";
import AssuredWorkloadIcon from "@mui/icons-material/AssuredWorkload";
import CenterFocusStrongIcon from "@mui/icons-material/CenterFocusStrong";
import AllInclusiveIcon from "@mui/icons-material/AllInclusive";
import PublicIcon from "@mui/icons-material/Public";
import LockPersonIcon from "@mui/icons-material/LockPerson";
import DesignServicesIcon from "@mui/icons-material/DesignServices";
import SmsIcon from "@mui/icons-material/Sms";
import PsychologyIcon from "@mui/icons-material/Psychology";
import SecurityIcon from "@mui/icons-material/Security";
import Diversity3Icon from "@mui/icons-material/Diversity3";
import StarRateIcon from "@mui/icons-material/StarRate";

export const Icons = {
  arrowback: ArrowBackIcon,
  arrowforward: ArrowForwardRoundedIcon,
  arrowforwardplain: ArrowForwardIcon,
  arrowoutward: ArrowOutwardIcon,
  assuredworkload: AssuredWorkloadIcon,
  allinclusive: AllInclusiveIcon,
  centerfocus: CenterFocusStrongIcon,
  designservice: DesignServicesIcon,
  psychologyicon: PsychologyIcon,
  communication: SmsIcon,
  email: EmailIcon,
  linkedIn: LinkedInIcon,
  visibility: VisibilityIcon,
  quote: FormatQuoteIcon,
  quoterounded: FormatQuoteRoundedIcon,
  star: StarIcon,
  starborder: StarBorderIcon,
  school: SchoolIcon,
  security: SecurityIcon,
  work: WorkIcon,
  accountbalance: AccountBalanceIcon,
  business: BusinessIcon,
  groups: GroupsIcon,
  person: PersonIcon,
  trackchanges: TrackChangesIcon,
  handshake: HandshakeIcon,
  shield: ShieldIcon,
  trendingup: TrendingUpIcon,
  integration: IntegrationInstructionsIcon,
  computer: ComputerIcon,
  translate: TranslateIcon,
  helpoutlinerounded: HelpOutlineRoundedIcon,
  eventavailable: EventAvailableIcon,
  policy: PolicyIcon,
  public: PublicIcon,
  settingssuggest: SettingsSuggestIcon,
  sendtimeextension: SendTimeExtensionIcon,
  expandmore: ExpandMoreIcon,
  verifiedoutlined: VerifiedOutlinedIcon,
  lockoutlined: LockOutlinedIcon,
  lockperson: LockPersonIcon,
  paidoutlined: PaidOutlinedIcon,
  rocketlaunchoutlined: RocketLaunchOutlinedIcon,
  laptopoutlined: LaptopOutlinedIcon,
  trendingupOutlined: TrendingUpOutlinedIcon,
  check: CheckIcon,
  menubook: MenuBookIcon,
  openinnew: OpenInNewIcon,
  place: PlaceRoundedIcon,
  language: LanguageRoundedIcon,
  workspacepremium: WorkspacePremiumRoundedIcon,
  checkcircle: CheckCircleRoundedIcon,
  receiptlong: ReceiptLongRoundedIcon,
  insights: InsightsRoundedIcon,
  code: CodeRoundedIcon,
  memory: MemoryRoundedIcon,
  supportagent: SupportAgentRoundedIcon,
  phone: PhoneIcon,
  call: PhoneIcon,
  user: User,
  diversity3: Diversity3Icon,
  dataobject: DataObjectIcon,
  staricon: StarRateIcon,
};

export default Icons;
