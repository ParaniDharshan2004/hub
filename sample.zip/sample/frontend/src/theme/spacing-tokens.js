export const sectionPX = { xs: 2, md: 4.5 };

export const sectionPY = { xs: 6, md: 6 };

export const sectionPYTall = { xs: 6, md: 9 };

export const heroPT = { xs: 8, md: 13 };
export const heroPTFlush = { xs: 8, md: 0 };

export const stackMB = {
  sm: { xs: 1.5, md: 2 },
  md: { xs: 2.5, md: 3 },
  lg: { xs: 3, md: 5 },
  xl: { xs: 4, md: 5 },
  xxl: { xs: 4, md: 6 },
  xxxl: { xs: 5, md: 6 },
  huge: { xs: 6, md: 8 },
};

export const spacingtokens = {
  sectionPX,
  sectionPY,
  sectionPYTall,

  heroPT,
  heroPTFlush,
  stackMB,
};

export default spacingtokens;
