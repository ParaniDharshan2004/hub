const breakpoints = {
  values: {
    xs: 0,     // mobile
    sm: 600,   // large mobile / small tablet
    md: 900,   // tablet
    lg: 1200,  // small desktop
    xl: 1536,  // large desktop
  },
};

export default breakpoints;