import { Suspense, lazy, useEffect, useState } from "react";
import { Routes, Route, Navigate, useNavigate, useLocation } from "react-router-dom";
import AppShell from "./components/common-components/AppShell";
import { InlineSpinner } from "./components/common-components/PageStates";
import ComingSoonPage from "./components/common-components/ComingSoonPage";
import LoginPage from "./features/auth/LoginPage";
import { getAuthToken, getCurrentUserApi, logout } from "./api.js";

const CustomerListPage = lazy(
  () => import("./features/customers/CustomerListPage"),
);
const CustomerProfilePage = lazy(
  () => import("./features/customers/CustomerProfilePage"),
);
const BookingListPage = lazy(
  () => import("./features/bookings/BookingListPage"),
);
const NewBookingPage = lazy(() => import("./features/bookings/NewBookingPage"));
const BookingDetailPage = lazy(
  () => import("./features/bookings/BookingDetailPage"),
);
const SubscriptionListPage = lazy(
  () => import("./features/subscriptions/SubscriptionListPage"),
);
const SubscriptionDetailPage = lazy(
  () => import("./features/subscriptions/SubscriptionDetailPage"),
);
const DashboardPage = lazy(() => import("./features/dashboard/DashboardPage"));
const ServiceCalendarPage = lazy(
  () => import("./features/visits/ServiceCalendarPage"),
);
const VisitDetailPage = lazy(() => import("./features/visits/VisitDetailPage"));
const PaymentListPage = lazy(
  () => import("./features/payments/PaymentListPage"),
);
const InvoiceListPage = lazy(
  () => import("./features/invoices/InvoiceListPage"),
);
const RolesPage = lazy(() => import("./features/admin/RolesPage"));
const PermissionsPage = lazy(() => import("./features/admin/PermissionsPage"));
const SettingsPage = lazy(() => import("./features/settings/SettingsPage"));

function Suspended({ children }) {
  return <Suspense fallback={<InlineSpinner />}>{children}</Suspense>;
}

function ProtectedAppShell() {
  const navigate = useNavigate();
  const location = useLocation();
  const [token, setToken] = useState(() => getAuthToken());
  const [authStatus, setAuthStatus] = useState(token ? "checking" : "guest");

  useEffect(() => {
    const redirectToLogin = () => {
      setToken(null);
      setAuthStatus("guest");
      navigate("/login", {
        replace: true,
        state: { from: location.pathname + location.search },
      });
    };

    const handleLogoutEvent = () => redirectToLogin();
    const handleStorage = (event) => {
      if (event.key === "auth_token" || event.key === "token") {
        const nextToken = getAuthToken();
        setToken(nextToken);
        if (!nextToken) redirectToLogin();
      }
    };

    window.addEventListener("auth_logout", handleLogoutEvent);
    window.addEventListener("storage", handleStorage);
    return () => {
      window.removeEventListener("auth_logout", handleLogoutEvent);
      window.removeEventListener("storage", handleStorage);
    };
  }, [navigate, location.pathname, location.search]);

  useEffect(() => {
    let cancelled = false;

    if (!token) {
      setAuthStatus("guest");
      return undefined;
    }

    setAuthStatus("checking");
    getCurrentUserApi()
      .then(() => {
        if (!cancelled) setAuthStatus("authed");
      })
      .catch(() => {
        if (cancelled) return;
        logout();
        setToken(null);
        setAuthStatus("guest");
      });

    return () => {
      cancelled = true;
    };
  }, [token]);

  if (authStatus === "guest" || !token) {
    return (
      <Navigate
        to="/login"
        replace
        state={{ from: location.pathname + location.search }}
      />
    );
  }

  if (authStatus === "checking") {
    return <InlineSpinner />;
  }

  return <AppShell />;
}

export default function AppRoutes() {
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route element={<ProtectedAppShell />}>
        <Route path="/" element={<Navigate to="/dashboard" replace />} />
        <Route
          path="/dashboard"
          element={
            <Suspended>
              <DashboardPage />
            </Suspended>
          }
        />

        <Route
          path="/customers"
          element={
            <Suspended>
              <CustomerListPage />
            </Suspended>
          }
        />
        <Route
          path="/customers/:customerNumber"
          element={
            <Suspended>
              <CustomerProfilePage />
            </Suspended>
          }
        />

        <Route
          path="/bookings"
          element={
            <Suspended>
              <BookingListPage />
            </Suspended>
          }
        />
        <Route
          path="/bookings/new"
          element={
            <Suspended>
              <NewBookingPage />
            </Suspended>
          }
        />
        <Route
          path="/bookings/:bookingNumber"
          element={
            <Suspended>
              <BookingDetailPage />
            </Suspended>
          }
        />

        <Route
          path="/subscriptions"
          element={
            <Suspended>
              <SubscriptionListPage />
            </Suspended>
          }
        />
        <Route
          path="/subscriptions/:subscriptionNumber"
          element={
            <Suspended>
              <SubscriptionDetailPage />
            </Suspended>
          }
        />
        <Route
          path="/visits"
          element={<Navigate to="/visits/calendar" replace />}
        />
        <Route
          path="/visits/calendar"
          element={
            <Suspended>
              <ServiceCalendarPage />
            </Suspended>
          }
        />
        <Route
          path="/visits/:visitNumber"
          element={
            <Suspended>
              <VisitDetailPage />
            </Suspended>
          }
        />
        <Route
          path="/payments"
          element={
            <Suspended>
              <PaymentListPage />
            </Suspended>
          }
        />
        <Route
          path="/invoices"
          element={
            <Suspended>
              <InvoiceListPage />
            </Suspended>
          }
        />
        <Route path="/reports" element={<ComingSoonPage title="Reports" />} />
        <Route
          path="/masters/:masterType"
          element={<ComingSoonPage title="Masters" />}
        />
        <Route
          path="/admin/roles"
          element={
            <Suspended>
              <RolesPage />
            </Suspended>
          }
        />
        <Route
          path="/admin/permissions"
          element={
            <Suspended>
              <PermissionsPage />
            </Suspended>
          }
        />
        <Route
          path="/admin/*"
          element={<ComingSoonPage title="Administration" />}
        />
        <Route
          path="/settings"
          element={
            <Suspended>
              <SettingsPage />
            </Suspended>
          }
        />
        <Route
          path="/download-center"
          element={<ComingSoonPage title="Download Center" />}
        />

        <Route path="*" element={<Navigate to="/dashboard" replace />} />
      </Route>
    </Routes>
  );
}
