import dayjs from "dayjs";
import api from "./api/axios.js";

// --- Centralized Authentication & API Fetch Helper ---

const AUTH_TOKEN_KEY = "auth_token";

export function getAuthToken() {
  const token =
    localStorage.getItem(AUTH_TOKEN_KEY) ||
    localStorage.getItem("token") ||
    "";
  return token.trim() || null;
}

export function setAuthToken(token) {
  if (token) {
    localStorage.setItem(AUTH_TOKEN_KEY, token);
    localStorage.setItem("token", token);
  } else {
    localStorage.removeItem(AUTH_TOKEN_KEY);
    localStorage.removeItem("token");
  }
}

export function logout() {
  setAuthToken(null);
  localStorage.removeItem("tco_logged_out");
  sessionStorage.clear();
  window.dispatchEvent(new Event("auth_logout"));
}

function isLoginRequest(config = {}) {
  const url = `${config.url || ""}`.split("?")[0].replace(/^\//, "");
  return url === "login" || url.endsWith("/login");
}

api.interceptors.request.use((config) => {
  if (config.skipAuth || isLoginRequest(config)) {
    return config;
  }

  const token = getAuthToken();
  if (token) {
    config.headers = config.headers || {};
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (
      error.response?.status === 401 &&
      !error.config?.skipLogout &&
      !isLoginRequest(error.config)
    ) {
      logout();
    }
    return Promise.reject(error);
  },
);

export class ApiError extends Error {
  constructor(message, status, data) {
    super(message);
    this.name = "ApiError";
    this.status = status;
    this.data = data;
  }
}

// Build the Authorization header using the stored token.
function authHeaders() {
  const token = getAuthToken();
  return token ? { Authorization: `Bearer ${token}` } : {};
}

// Helper: translate an Axios error into an ApiError so all callers
// receive the same error shape they relied on with fetch().
function handleAxiosError(err, { skipLogout = false } = {}) {
  if (err.response) {
    const status = err.response.status;
    const data = err.response.data;
    const message =
      data?.message || `API request failed with status ${status}`;

    if (status === 401) {
      if (!skipLogout && !isLoginRequest(err.config)) {
        logout();
      }
      throw new ApiError(
        data?.message || "Session expired or unauthorized. Please log in again.",
        401,
        data,
      );
    }

    throw new ApiError(message, status, data);
  }

  // Network / no-response error
  throw new ApiError(
    err.message || "Network error occurred. Please check your connection.",
    0,
  );
}

// apiFetch — drop-in replacement for the old fetch()-based helper.
// Internally uses Axios (api.get / api.post / api.put / api.patch / api.delete)
// so every call goes through the centralized Axios instance in api/axios.js.
export async function apiFetch(endpoint, options = {}) {
  // Strip leading /api/ so the path joins cleanly with the baseURL.
  const path = endpoint.startsWith("http")
    ? endpoint
    : endpoint.replace(/^\/api\//, "").replace(/^\//, "");

  const { skipAuth = false, skipLogout = false } = options;
  const method = (options.method || "GET").toUpperCase();
  const headers = {
    ...(skipAuth ? {} : authHeaders()),
    ...options.headers,
  };
  const params = options.params || undefined;

  // Body: support pre-stringified JSON or plain objects.
  let data;
  if (options.body instanceof FormData) {
    data = options.body;
  } else if (typeof options.body === "string") {
    headers["Content-Type"] = headers["Content-Type"] || "application/json";
    try {
      data = JSON.parse(options.body);
    } catch {
      data = options.body;
    }
  } else if (options.body && typeof options.body === "object") {
    data = options.body;
  }

  try {
    let response;

    const requestConfig = { headers, params, skipAuth, skipLogout };

    if (method === "GET") {
      response = await api.get(path, requestConfig);
    } else if (method === "POST") {
      response = await api.post(path, data, requestConfig);
    } else if (method === "PUT") {
      response = await api.put(path, data, requestConfig);
    } else if (method === "PATCH") {
      response = await api.patch(path, data, requestConfig);
    } else if (method === "DELETE") {
      response = await api.delete(path, { ...requestConfig, data });
    } else {
      response = await api.request({
        method,
        url: path,
        data,
        ...requestConfig,
      });
    }

    // Axios returns the parsed JSON in response.data.
    // 204 No Content has no body — return empty object like before.
    return response.data ?? {};
  } catch (err) {
    handleAxiosError(err, { skipLogout });
  }
}

// --- Authentication API ---

export async function loginApi({ email, password }) {
  if (!email || !password) {
    throw new ApiError("Email and password are required", 400);
  }

  const result = await apiFetch("/login", {
    method: "POST",
    body: { email: email.trim(), password },
    skipAuth: true,
    skipLogout: true,
  });

  if (!result?.token) {
    throw new ApiError("Login succeeded but no access token was returned", 500);
  }

  setAuthToken(result.token);
  return result;
}

export async function getCurrentUserApi() {
  return apiFetch("/users/me");
}

// --- MongoDB ObjectId Resolution Helper ---

const MONGO_ID_REGEX = /^[0-9a-fA-F]{24}$/;

export function isMongoId(str) {
  return typeof str === "string" && MONGO_ID_REGEX.test(str);
}

export async function resolveCustomerId(param) {
  if (!param) return null;
  if (isMongoId(param)) return param;

  const customers = await apiFetch(
    `/customers?search=${encodeURIComponent(param)}`,
  );
  const match = Array.isArray(customers)
    ? customers.find(
        (c) =>
          c.customerId === param || c._id === param || c.phoneNumber === param,
      )
    : null;

  return match ? match._id : param;
}

export async function resolveBookingId(param) {
  if (!param) return null;
  if (isMongoId(param)) return param;

  const bookings = await apiFetch("/bookings");
  const match = Array.isArray(bookings)
    ? bookings.find((b) => b.bookingId === param || b._id === param)
    : null;

  return match ? match._id : param;
}

export async function resolveSubscriptionId(param) {
  if (!param) return null;
  if (isMongoId(param)) return param;

  const subscriptions = await apiFetch("/subscriptions");
  const match = Array.isArray(subscriptions)
    ? subscriptions.find((s) => s.subscriptionId === param || s._id === param)
    : null;

  return match ? match._id : param;
}

export async function resolveVisitId(param) {
  if (!param) return null;
  if (isMongoId(param)) return param;

  const visits = await apiFetch("/visits");
  const match = Array.isArray(visits)
    ? visits.find((v) => v.visitId === param || v._id === param)
    : null;

  return match ? match._id : param;
}

// --- Master Data API ---

function toMinutes(time) {
  if (!time) return null;
  const match = String(time)
    .trim()
    .match(/^(\d{1,2}):(\d{2})\s*(AM|PM)$/i);
  if (!match) return null;
  let hours = Number(match[1]) % 12;
  if (match[3].toUpperCase() === "PM") hours += 12;
  return hours * 60 + Number(match[2]);
}

function formatTime(totalMinutes) {
  const hours = Math.floor(totalMinutes / 60);
  const minutes = totalMinutes % 60;
  const suffix = hours >= 12 ? "PM" : "AM";
  const displayHours = hours % 12 || 12;
  return `${String(displayHours).padStart(2, "0")}:${String(minutes).padStart(2, "0")} ${suffix}`;
}

function buildTimeSlots(timeSlots, durationMinutes) {
  const duration = Number(durationMinutes);

  if (!Number.isFinite(duration) || duration <= 0) {
    return [];
  }

  return (timeSlots || [])
    .filter((timeSlot) => timeSlot.isActive !== false)
    .flatMap((timeSlot) => {
      const startMinutes = toMinutes(timeSlot.startTime);
      const endMinutes = toMinutes(timeSlot.endTime);

      if (
        startMinutes == null ||
        endMinutes == null ||
        endMinutes <= startMinutes
      ) {
        return [];
      }

      const bufferMinutes = Number(
        timeSlot.bufferTime || timeSlot.bufferMinutes || 0,
      );

      const slots = [];

      for (
        let current = startMinutes;
        current + duration + bufferMinutes <= endMinutes;
        current += duration + bufferMinutes
      ) {
        slots.push({
          id: `${timeSlot._id}-${current}`,
          mongoId: timeSlot._id,
          startTime: timeSlot.startTime,
          label: `${formatTime(current)} – ${formatTime(current + duration)}`,
          bufferMinutes,
        });
      }

      return slots;
    });
}

export async function getBookingMasters() {
  const [
    bathroomCounts,
    frequencies,
    subscriptionTypes,
    pricing,
    timeSlots,
    paymentAccounts,
    paymentMethods,
  ] = await Promise.all([
    apiFetch("/bathroom-counts"),
    apiFetch("/service-frequencies"),
    apiFetch("/subscription-types"),
    apiFetch("/pricing"),
    apiFetch("/time-slots"),
    apiFetch("/payment-accounts"),
    apiFetch("/payment-methods"),
  ]);

  const activeSlots = (timeSlots || []).filter(
    (ts) => ts.isActive !== false,
  );

  const startMins = activeSlots
    .map((ts) => toMinutes(ts.startTime))
    .filter((m) => m != null);

  const endMins = activeSlots
    .map((ts) => toMinutes(ts.endTime))
    .filter((m) => m != null);

  const dayStartMin = startMins.length ? Math.min(...startMins) : 8 * 60;
  const dayEndMin = endMins.length ? Math.max(...endMins) : 19 * 60 + 30;

  const priceByBathroom = (pricing || []).reduce((prices, item) => {
    const bathroomCount = item.bathroomCountReference?.bathroomCount;

    if (
      item.isActive !== false &&
      bathroomCount &&
      item.price != null
    ) {
      prices[bathroomCount] = item.price;
    }

    return prices;
  }, {});

  /*
   * IMPORTANT:
   * Duration must come from the Super Admin configuration.
   *
   * There is intentionally NO fallback such as:
   *   bathroomCount * 30
   *   30
   *   60
   *   90
   *   120
   *
   * If a bathroom count does not have a configured duration,
   * it will remain absent from durationByBathroom.
   */

  const durationByBathroom = (pricing || []).reduce(
    (durations, item) => {
      const bathroomCount =
        item.bathroomCountReference?.bathroomCount ??
        item.bathroomCountId?.bathroomCount;

      const durationMinutes =
        item.serviceDurationReference?.durationMinutes ??
        item.serviceDurationId?.durationMinutes;

      if (
        item.isActive !== false &&
        bathroomCount != null &&
        durationMinutes != null &&
        Number(durationMinutes) > 0
      ) {
        durations[Number(bathroomCount)] = Number(durationMinutes);
      }

      return durations;
    },
    {},
  );

  const resolvedDurationByBathroom = {
    ...durationByBathroom,
  };

  return {
    dayStartMin,
    dayEndMin,

    rawPricing: pricing || [],
    rawBathroomCounts: bathroomCounts || [],
    rawFrequencies: frequencies || [],
    rawSubscriptionTypes: subscriptionTypes || [],
    rawTimeSlots: timeSlots || [],
    rawPaymentAccounts: paymentAccounts || [],
    rawPaymentMethods: paymentMethods || [],

    bathrooms: (bathroomCounts || [])
      .filter((item) => item.isActive !== false)
      .sort((a, b) => a.bathroomCount - b.bathroomCount)
      .map((item) => ({
        id: item._id,
        value: item.bathroomCount,
        label: String(item.bathroomCount),
      })),

    frequencies: (frequencies || [])
      .filter((item) => item.isActive !== false)
      .map((item) => ({
        id: item._id,
        name: item.frequencyName,
        intervalDays: item.intervalDays,
        visitsPerMonth: Math.max(
          1,
          Math.round(30 / (item.intervalDays || 30)),
        ),
      })),

    plans: (subscriptionTypes || [])
      .filter((item) => item.isActive !== false)
      .map((item) => ({
        id: item._id,
        name: item.subscriptionName,
        timeGap: item.timeGap,
        termMonths: Math.max(1, Math.round(item.timeGap || 1)),
        pricePerServiceByBathroom: priceByBathroom,
      })),

    durationByBathroom: resolvedDurationByBathroom,

    slots: [],

    slotsByBathroom: Object.fromEntries(
      Object.entries(resolvedDurationByBathroom).map(
        ([bathroomCount, durationMinutes]) => [
          bathroomCount,
          buildTimeSlots(timeSlots, durationMinutes),
        ],
      ),
    ),

    paymentAccounts: (paymentAccounts || [])
      .filter((item) => item.isActive !== false)
      .map((item) => ({
        id: item._id,
        name: item.accountName,
      })),

    paymentMethods: (paymentMethods || [])
      .filter((item) => item.isActive !== false)
      .map((item) => ({
        id: item._id,
        name: item.paymentMethodName,
      })),
  };
}

// --- Dynamic Availability API (Backend is the Single Source of Truth) ---

export async function getBookingAvailability({
  date,
  bathrooms,
  bathroomCountId,
  pricingId,
  serviceDurationId,
}) {
  if (!date) return { slots: [] };
  const params = new URLSearchParams();
  params.append("date", date);
  if (bathrooms) params.append("bathrooms", String(bathrooms));
  if (bathroomCountId) params.append("bathroomCountId", String(bathroomCountId));
  if (pricingId) params.append("pricingId", String(pricingId));
  if (serviceDurationId) params.append("serviceDurationId", String(serviceDurationId));

  try {
    const res = await apiFetch(`/bookings/availability?${params.toString()}`);
    return res || { slots: [] };
  } catch (err) {
    console.error("Failed to fetch booking availability:", err);
    return { slots: [] };
  }
}

// --- Pricing Quote Helper (For UI estimates; backend is source of truth for final invoice) ---

function round2(n) {
  return Math.round((n + Number.EPSILON) * 100) / 100;
}

export function quotePricing({
  planId,
  frequencyId,
  bathrooms,
  discount = 0,
  planOptions = [],
  frequencyOptions = [],
}) {
  const plan = (planOptions || []).find((p) => p.id === planId);

  const frequency = (frequencyOptions || []).find(
    (f) => f.id === frequencyId,
  );

  if (!plan || !frequency || !bathrooms) return null;

  const bathroomCount = Number(bathrooms);

  if (!Number.isFinite(bathroomCount) || bathroomCount <= 0) {
    throw new Error("Invalid bathroom count selected for pricing.");
  }

  const configuredPrice =
    plan.pricePerServiceByBathroom?.[bathroomCount];

  if (
    configuredPrice == null ||
    configuredPrice === "" ||
    !Number.isFinite(Number(configuredPrice)) ||
    Number(configuredPrice) < 0
  ) {
    throw new Error(
      `No active pricing configuration found for ${bathroomCount} bathroom(s). Please configure the pricing in Settings.`,
    );
  }

  const pricePerService = Number(configuredPrice);

  const numServices = Math.max(
    1,
    (plan.termMonths || 1) * (frequency.visitsPerMonth || 1),
  );

  const serviceCharges = round2(
    pricePerService * numServices,
  );

  const authorizedDiscount = round2(
    Math.min(discount || 0, serviceCharges),
  );

  const taxableAmount = round2(
    serviceCharges - authorizedDiscount,
  );

  const taxes = [
    {
      id: "CGST",
      label: "CGST",
      rate: 0.09,
      amount: round2(taxableAmount * 0.09),
    },
    {
      id: "SGST",
      label: "SGST",
      rate: 0.09,
      amount: round2(taxableAmount * 0.09),
    },
  ];

  const taxTotal = round2(
    taxes.reduce((s, t) => s + t.amount, 0),
  );

  const total = round2(
    taxableAmount + taxTotal,
  );

  return {
    plan,
    frequency,
    bathroomCount,
    pricePerService,
    numServices,
    serviceCharges,
    authorizedDiscount,
    taxableAmount,
    taxes,
    taxTotal,
    total,
    effectiveDate: dayjs().format("YYYY-MM-DD"),
  };
}

// --- Customer API ---

export async function listCustomers({
  search = "",
  status = "All",
} = {}) {
  const queryParam = search.trim()
    ? `?search=${encodeURIComponent(search.trim())}`
    : "";

  const customers = await apiFetch(`/customers${queryParam}`);

  if (!Array.isArray(customers)) return [];

  let rows = customers.map((customer) => ({
    id: customer._id,
    customerNumber:
      customer.customerId ||
      customer.customerNumber ||
      customer._id,
    name: customer.name,
    mobile: customer.phoneNumber,
    email: customer.email || "",
    status: customer.isActive ? "Active" : "Inactive",
    address: customer.address,
    doorNo: customer.doorNo || "",
    block: customer.block || "",
    apartmentName: customer.apartmentName || "",
    landmark: customer.landmark || "",
    area: customer.area || "",
    city: customer.city || "",
    pincode: customer.pincode || "",
    defaultAddress: customer.address
      ? {
          addressLine: customer.address,
          area: customer.area || null,
        }
      : null,
    defaultArea: customer.area || "",
    serviceFrequencyName: "—",
    subscriptionTypeName: "—",
    addressCount: customer.address ? 1 : 0,
    activeSubscriptionCount: 0,
    createdOn: customer.createdAt,
  }));

  if (status !== "All") {
    rows = rows.filter((c) => c.status === status);
  }

  return rows.sort(
    (a, b) =>
      new Date(b.createdOn || 0) -
      new Date(a.createdOn || 0),
  );
}

export async function getCustomerByNumber(param) {
  const id = await resolveCustomerId(param);

  const customer = await apiFetch(`/customers/${id}`);

  return {
    ...customer,
    id: customer._id,
    customerNumber:
      customer.customerId || customer._id,
    mobile: customer.phoneNumber,
    status: customer.isActive ? "Active" : "Inactive",
  };
}

export async function listAddressesForCustomer(param) {
  const id = await resolveCustomerId(param);
  const customer = await apiFetch(`/customers/${id}`);

  if (!customer || !customer.address) return [];

  return [
    {
      id: customer._id,
      addressNumber: customer._id,
      customerId: customer._id,
      label: "Primary Address",
      addressLine: customer.address,
      doorNo: customer.doorNo || "",
      block: customer.block || "",
      community: customer.apartmentName || "",
      area: customer.area || "",
      city: customer.city || "",
      pincode: customer.pincode || "",
      landmark: customer.landmark || "",
      isDefault: true,
      status: customer.isActive ? "Active" : "Inactive",
    },
  ];
}

export async function findByMobile(mobile) {
  if (!mobile) return [];

  const customers = await apiFetch(
    `/customers?search=${encodeURIComponent(mobile)}`,
  );

  if (!Array.isArray(customers)) return [];

  return customers.map((customer) => ({
    id: customer._id,
    customerNumber:
      customer.customerId || customer._id,
    name: customer.name,
    mobile: customer.phoneNumber,
  }));
}

export async function createCustomerWithAddress(payload) {
  const customer = await apiFetch("/customers", {
    method: "POST",
    body: {
      name: payload.name,
      phoneNumber: payload.mobile,
      address:
        payload.addressLine ||
        payload.address ||
        "",
      doorNo: payload.doorNo || "",
      block: payload.block || "",
      apartmentName:
        payload.community ||
        payload.apartmentName ||
        "",
      landmark: payload.landmark || "",
      city: payload.city || "",
      pincode: payload.pincode || "",
      area: payload.area || "",
    },
  });

  return {
    customer: {
      ...customer,
      id: customer._id,
      customerNumber:
        customer.customerId ||
        customer._id,
      mobile: customer.phoneNumber,
    },

    address: {
      id: customer._id,
      addressNumber: customer._id,
      addressLine: customer.address,
    },
  };
}

export async function addAddress(param, payload) {
  const id = await resolveCustomerId(param);

  const customer = await apiFetch(`/customers/${id}`, {
    method: "PUT",
    body: {
      address:
        payload.addressLine ||
        payload.address ||
        "",
      doorNo: payload.doorNo || "",
      block: payload.block || "",
      apartmentName:
        payload.community ||
        payload.apartmentName ||
        "",
      area: payload.area || "",
      city: payload.city || "",
      pincode: payload.pincode || "",
      landmark: payload.landmark || "",
    },
  });

  return {
    id: customer._id,
    addressNumber: customer._id,
    customerId: customer._id,
    label:
      payload.addressLabel ||
      "Primary address",
    addressLine: customer.address,
    doorNo: customer.doorNo,
    block: customer.block,
    community: customer.apartmentName,
    area: customer.area,
    city: customer.city,
    pincode: customer.pincode,
    landmark: customer.landmark,
    isDefault: true,
    status: customer.isActive
      ? "Active"
      : "Inactive",
  };
}

export async function getCustomer360(param) {
  const id = await resolveCustomerId(param);

  let customer;

  try {
    customer = await apiFetch(`/customers/${id}`);
  } catch (err) {
    if (err.status === 404) return null;
    throw err;
  }

  const [
    subscriptionsRes,
    bookingsRes,
    visitsRes,
    invoicesRes,
    paymentsRes,
  ] = await Promise.allSettled([
    apiFetch(`/subscriptions?customerReference=${id}`),
    apiFetch(`/bookings?customerId=${id}`),
    apiFetch(`/visits?customerReference=${id}`),
    apiFetch(`/invoices?customerReference=${id}`),
    apiFetch(`/service-payments?customerReference=${id}`),
  ]);

  const subscriptions =
    subscriptionsRes.status === "fulfilled" &&
    Array.isArray(subscriptionsRes.value)
      ? subscriptionsRes.value
      : [];

  const bookings =
    bookingsRes.status === "fulfilled" &&
    Array.isArray(bookingsRes.value)
      ? bookingsRes.value
      : [];

  const visits =
    visitsRes.status === "fulfilled" &&
    Array.isArray(visitsRes.value)
      ? visitsRes.value
      : [];

  const invoices =
    invoicesRes.status === "fulfilled" &&
    Array.isArray(invoicesRes.value)
      ? invoicesRes.value
      : [];

  const payments =
    paymentsRes.status === "fulfilled" &&
    Array.isArray(paymentsRes.value)
      ? paymentsRes.value
      : [];

  const formattedCustomer = {
    ...customer,
    id: customer._id,
    customerNumber:
      customer.customerId ||
      customer._id,
    mobile: customer.phoneNumber,
    status: customer.isActive
      ? "Active"
      : "Inactive",
  };

  const addresses = customer.address
    ? [
        {
          id: customer._id,
          addressNumber: customer._id,
          customerId: customer._id,
          label: "Primary address",
          addressLine: customer.address,
          doorNo: customer.doorNo || "",
          block: customer.block || "",
          area: customer.area || "",
          city: customer.city || "",
          pincode: customer.pincode || "",
          isDefault: true,
          status: customer.isActive
            ? "Active"
            : "Inactive",
        },
      ]
    : [];

  const formattedBookings = bookings.map((b) => ({
    ...b,
    id: b._id,
    bookingNumber:
      b.bookingId || b._id,
    status: b.isCancelled
      ? "Cancelled"
      : b.isCompleted
        ? "Completed"
        : "Confirmed",
    total: b.amount,
  }));

  const formattedSubscriptions =
    subscriptions.map((s) => ({
      ...s,
      id: s._id,
      subscriptionNumber:
        s.subscriptionId || s._id,
      status:
        s.subscriptionStatus ||
        "Active",
    }));

  const formattedVisits = visits.map((v) => ({
    ...v,
    id: v._id,
    visitNumber: v.visitId || v._id,
    date:
      v.scheduledStartDateTime ||
      v.scheduledDate,
    status: v.isCompleted
      ? "Completed"
      : v.isCancelled
        ? "Cancelled"
        : "Scheduled",
  }));

  return {
    customer: formattedCustomer,
    addresses,
    bookings: formattedBookings,
    subscriptions: formattedSubscriptions,

    payments: payments.map((p) => ({
      ...p,
      id: p._id,
      paymentNumber: p._id,
      amount: p.totalAmount,
    })),

    invoices: invoices.map((i) => ({
      ...i,
      id: i._id,
      invoiceNumber:
        i.invoiceNumber || i._id,
    })),

    visits: formattedVisits,
    auditEvents: [],

    summary: {
      addressCount: addresses.length,
      totalBookings: bookings.length,
      activeSubscriptions:
        subscriptions.filter(
          (s) =>
            s.subscriptionStatus ===
              "Active" || s.isActive,
        ).length,
      visitsCompleted:
        visits.filter(
          (v) => v.isCompleted,
        ).length,
      lifetimeCollected:
        payments.reduce(
          (sum, p) =>
            sum + (p.totalAmount || 0),
          0,
        ),
      nextVisits:
        formattedVisits.filter(
          (v) =>
            !v.isCompleted &&
            !v.isCancelled,
        ),
    },
  };
}

export async function deactivateCustomer(param) {
  const id = await resolveCustomerId(param);

  const customer = await apiFetch(
    `/customers/${id}`,
    {
      method: "PUT",
      body: { isActive: false },
    },
  );

  return {
    ...customer,
    id: customer._id,
    customerNumber:
      customer.customerId ||
      customer._id,
    status: "Inactive",
  };
}

// --- Bookings API ---

function normalizeBookingRecord(booking) {
  const customerRef =
    booking.customerReference;

  const customerObj =
    typeof customerRef === "object" &&
    customerRef
      ? customerRef
      : null;

  return {
    ...booking,
    id: booking._id,
    bookingNumber:
      booking.bookingId ||
      booking._id,

    customer: customerObj
      ? {
          ...customerObj,
          id: customerObj._id,
          customerNumber:
            customerObj.customerId ||
            customerObj._id,
          mobile:
            customerObj.phoneNumber,
        }
      : null,

    address: customerObj
      ? {
          addressLine:
            customerObj.address,
          area:
            customerObj.area || "",
          label: "Service address",
        }
      : null,

    bathrooms:
      booking.bathroomCountReference
        ?.bathroomCount || 1,

    frequencyId:
      booking.serviceFrequencyReference?._id ||
      booking.serviceFrequencyReference,

    frequencyName:
      booking.serviceFrequencyReference
        ?.frequencyName || "—",

    planName:
      booking.subscriptionTypeReference
        ?.subscriptionName || "—",

    startDate:
      booking.scheduledDate ||
      booking.startDateTime,

    slotLabel:
      booking.timeSlotReference?.startTime
        ? `${booking.timeSlotReference.startTime} – ${booking.timeSlotReference.endTime}`
        : "Scheduled Slot",

    total: booking.amount || 0,
    serviceCharges: booking.amount || 0,
    taxableAmount: booking.amount || 0,

    status: booking.isCancelled
      ? "Cancelled"
      : booking.isCompleted
        ? "Completed"
        : "Confirmed",

    createdOn: booking.createdAt,
  };
}

export async function listBookings({
  search = "",
  status = "All",
} = {}) {
  const bookings =
    await apiFetch("/bookings");

  if (!Array.isArray(bookings))
    return [];

  let rows = bookings.map(
    normalizeBookingRecord,
  );

  if (status !== "All") {
    rows = rows.filter(
      (b) => b.status === status,
    );
  }

  if (search.trim()) {
    const q = search
      .trim()
      .toLowerCase();

    rows = rows.filter(
      (b) =>
        b.bookingNumber
          .toLowerCase()
          .includes(q) ||
        (b.customer?.name || "")
          .toLowerCase()
          .includes(q) ||
        (
          b.customer
            ?.customerNumber || ""
        )
          .toLowerCase()
          .includes(q),
    );
  }

  return rows.sort(
    (a, b) =>
      new Date(
        b.createdOn || 0,
      ) -
      new Date(
        a.createdOn || 0,
      ),
  );
}

export async function getBooking(param) {
  const id =
    await resolveBookingId(param);

  let res;

  try {
    res = await apiFetch(
      `/bookings/${id}`,
    );
  } catch (err) {
    if (err.status === 404)
      return null;
    throw err;
  }

  const rawBooking =
    res.booking || res;

  const directInvoice =
    res.invoice || null;

  const normalized =
    normalizeBookingRecord(
      rawBooking,
    );

  const bookingMongoId = String(
    rawBooking._id || "",
  );

  const bookingNumber = String(
    rawBooking.bookingId || "",
  );

  // Safely fetch linked records
  const [
    payments,
    subscriptions,
    visits,
    invoices,
  ] = await Promise.all([
    apiFetch("/service-payments")
      .catch(() => []),

    apiFetch("/subscriptions")
      .catch(() => []),

    apiFetch("/visits")
      .catch(() => []),

    apiFetch("/invoices")
      .catch(() => []),
  ]);

  const idMatch = (v) => {
    if (!v) return false;

    const str = String(
      typeof v === "object"
        ? v._id ||
            v.id ||
            v.bookingId ||
            ""
        : v,
    );

    return (
      str === bookingMongoId ||
      str === bookingNumber ||
      str === param
    );
  };

  const matchedPayment = (
    Array.isArray(payments)
      ? payments
      : []
  ).find(
    (p) =>
      idMatch(p.booking) ||
      idMatch(p.bookingId) ||
      idMatch(p.customer) ||
      idMatch(p.customerId),
  );

  const matchedSub = (
    Array.isArray(subscriptions)
      ? subscriptions
      : []
  ).find(
    (s) =>
      idMatch(s.booking) ||
      idMatch(s.bookingId) ||
      (s.periods &&
        s.periods.some(
          (p) =>
            idMatch(
              p.booking?.bookingId,
            ) ||
            idMatch(
              p.booking?._id,
            ),
        )),
  );

  const matchedVisits = (
    Array.isArray(visits)
      ? visits
      : []
  ).filter(
    (v) =>
      idMatch(v.booking) ||
      idMatch(v.bookingId),
  );

  const matchedInvoice =
    directInvoice ||
    (
      Array.isArray(invoices)
        ? invoices
        : []
    ).find(
      (i) =>
        idMatch(i.booking) ||
        idMatch(i.bookingId),
    );

  return {
    ...normalized,

    invoice: matchedInvoice
      ? {
          ...matchedInvoice,
          id: matchedInvoice._id,
          invoiceNumber:
            matchedInvoice.invoiceNumber ||
            matchedInvoice._id,
        }
      : null,

    payment: matchedPayment
      ? {
          ...matchedPayment,
          id: matchedPayment._id,
          paymentNumber:
            matchedPayment.paymentNumber ||
            matchedPayment.receiptNumber ||
            matchedPayment._id,
        }
      : null,

    subscription: matchedSub
      ? {
          ...matchedSub,
          id: matchedSub._id,
          subscriptionNumber:
            matchedSub.subscriptionNumber ||
            matchedSub.subscriptionId ||
            matchedSub._id,
        }
      : null,

    visits: matchedVisits.map(
      (v) => ({
        ...v,
        id: v._id,
        visitNumber:
          v.visitNumber ||
          v._id,
      }),
    ),
  };
}

export async function createBooking(
  payload,
) {
  const masters =
    await getBookingMasters();

  const customerId =
    await resolveCustomerId(
      payload.customerId,
    );

  let timeSlotId =
    payload.timeSlotId ||
    payload.slotId;

  if (
  typeof timeSlotId === "string" &&
  timeSlotId.includes("-")
) {
  const selectedBathroom =
    masters.rawBathroomCounts?.find(
      (item) =>
        String(item._id) ===
        String(payload.bathroomCountId),
    );

  const selectedBathroomCount =
    selectedBathroom?.bathroomCount;

  const bathroomSlots =
    masters.slotsByBathroom?.[
      String(selectedBathroomCount)
    ] || [];

  const slotObj = bathroomSlots.find(
    (slot) => slot.id === timeSlotId,
  );

  if (slotObj?.mongoId) {
    timeSlotId = slotObj.mongoId;
  } else {
    timeSlotId = timeSlotId.split("-")[0];
  }
}

  const matchedPricing =
  masters.rawPricing.find((p) => {
    const pricingBathroomId =
      p.bathroomCountReference?._id ||
      p.bathroomCountReference ||
      p.bathroomCountId?._id ||
      p.bathroomCountId;

    return (
      String(pricingBathroomId) ===
        String(payload.bathroomCountId) &&
      p.isActive !== false
    );
  });

if (!matchedPricing) {
  throw new ApiError(
    "No active pricing configuration found for the selected bathroom count. Please configure the pricing in Settings.",
    400,
  );
}

const pricingId = matchedPricing._id;

/*
 * Service duration must come from the selected pricing configuration.
 * Do not trust a separately supplied serviceDurationId from the frontend.
 */
const serviceDurationId =
  matchedPricing.serviceDurationReference?._id ||
  matchedPricing.serviceDurationReference ||
  matchedPricing.serviceDurationId?._id ||
  matchedPricing.serviceDurationId;

if (!serviceDurationId) {
  throw new ApiError(
    "No service duration configuration found for the selected pricing. Please configure the service duration in Settings.",
    400,
  );
}

  let resolvedStartTime = payload.startTime;
  if (!resolvedStartTime && typeof (payload.timeSlotId || payload.slotId) === "string") {
    const rawSlot = payload.timeSlotId || payload.slotId;
    if (rawSlot.includes("-")) {
      const mins = Number(rawSlot.split("-")[1]);
      if (Number.isFinite(mins)) {
        resolvedStartTime = formatTime(mins);
      }
    }
  }

  const backendBody = {
    customerId,

    bathroomCountId:
      payload.bathroomCountId ||
      undefined,

    pricingId,

   serviceDurationId,

    serviceFrequencyId:
      payload.frequencyId ||
      payload.serviceFrequencyId ||
      undefined,

    subscriptionTypeId:
      payload.planId ||
      payload.subscriptionTypeId ||
      undefined,

    timeSlotId,

    scheduledDate:
      payload.startDate ||
      payload.scheduledDate,

    startTime:
      resolvedStartTime ||
      undefined,

    paymentMethodId:
      payload.paymentModeId ||
      payload.paymentMethodId ||
      undefined,

    paymentAccountId:
      payload.receiverAccountId ||
      payload.paymentAccountId ||
      undefined,

    transactionId:
      payload.paymentReference ||
      payload.transactionId ||
      "",
  };

  const result =
    await apiFetch("/bookings", {
      method: "POST",
      body: backendBody,
    });

  const createdBooking =
    result.booking || result;

  return {
    ...result,

    booking: {
      ...createdBooking,
      id: createdBooking._id,
      bookingNumber:
        createdBooking.bookingId ||
        createdBooking._id,
      status: "Confirmed",
    },
  };
}

export async function cancelBooking(
  param,
  reason,
) {
  const id =
    await resolveBookingId(param);

  const booking =
    await apiFetch(
      `/bookings/${id}/cancel`,
      {
        method: "PATCH",
        body: { reason },
      },
    );

  return normalizeBookingRecord(
    booking,
  );
}

// --- Visits API ---

export function areaWorkloadToday(
  visits,
) {
  const areaNames =
    Array.from(
      new Set(
        (visits || [])
          .map(
            (v) =>
              v.areaId ||
              v.address?.area ||
              "Unknown",
          )
          .filter(Boolean),
      ),
    );

  return areaNames
    .map((areaName) => {
      const areaVisits =
        visits.filter(
          (v) =>
            (v.areaId ||
              v.address?.area) ===
            areaName,
        );

      return {
        area: {
          id: areaName,
          name: areaName,
        },
        total:
          areaVisits.length,
        completed:
          areaVisits.filter(
            (v) =>
              v.status ===
              "Completed",
          ).length,
      };
    })
    .filter(
      (row) => row.total > 0,
    );
}

export async function listVisits({
  search = "",
  status = "All",
  area = "All",
  date,
  dateFrom,
  dateTo,
} = {}) {
  const visits =
    await apiFetch("/visits");

  if (!Array.isArray(visits))
    return [];

  let rows = visits.map(
    (visit) => {
      const customerObj =
        typeof visit.customerReference ===
        "object"
          ? visit.customerReference
          : null;

      const bookingObj =
        typeof visit.bookingReference ===
        "object"
          ? visit.bookingReference
          : null;

      const slotObj =
        typeof visit.timeSlotReference ===
        "object"
          ? visit.timeSlotReference
          : null;

      const scheduledDate =
        visit.scheduledStartDateTime
          ? dayjs(
              visit.scheduledStartDateTime,
            ).format(
              "YYYY-MM-DD",
            )
          : "";

      return {
        ...visit,
        id: visit._id,
        visitNumber:
          visit.visitId ||
          visit._id,

        date: scheduledDate,
        scheduledDate,

        status:
          visit.isCancelled
            ? "Cancelled"
            : visit.isCompleted
              ? "Completed"
              : "Scheduled",

        customer: customerObj
          ? {
              ...customerObj,
              id: customerObj._id,
              customerNumber:
                customerObj.customerId ||
                customerObj._id,
              mobile:
                customerObj.phoneNumber,
              area:
                customerObj.area ||
                "",
            }
          : null,

        booking: bookingObj
          ? {
              ...bookingObj,
              id: bookingObj._id,
              bookingNumber:
                bookingObj.bookingId ||
                bookingObj._id,
            }
          : null,

        slotId:
          slotObj?._id || "",

        slotLabel:
          slotObj?.startTime
            ? `${slotObj.startTime} – ${slotObj.endTime}`
            : "",

        bathroomCount: 1,

        areaId:
          customerObj?.area || "",

        address: customerObj
          ? {
              addressLine:
                customerObj.address,
              doorNo:
                customerObj.doorNo,
              block:
                customerObj.block,
              area:
                customerObj.area,
            }
          : null,
      };
    },
  );

  if (status !== "All") {
    rows = rows.filter(
      (v) => v.status === status,
    );
  }

  if (area !== "All") {
    rows = rows.filter(
      (v) => v.areaId === area,
    );
  }

  if (date) {
    rows = rows.filter(
      (v) => v.date === date,
    );
  }

  if (dateFrom) {
    rows = rows.filter(
      (v) => v.date >= dateFrom,
    );
  }

  if (dateTo) {
    rows = rows.filter(
      (v) => v.date <= dateTo,
    );
  }

  if (search.trim()) {
    const q = search
      .trim()
      .toLowerCase();

    rows = rows.filter(
      (v) =>
        v.visitNumber
          .toLowerCase()
          .includes(q) ||
        (v.customer?.name || "")
          .toLowerCase()
          .includes(q) ||
        (
          v.customer
            ?.customerNumber || ""
        )
          .toLowerCase()
          .includes(q),
    );
  }

  return rows.sort(
    (a, b) =>
      new Date(
        a.date || 0,
      ) -
      new Date(
        b.date || 0,
      ),
  );
}

export async function getVisit(param) {
  const id =
    await resolveVisitId(param);

  const visit =
    await apiFetch(
      `/visits/${id}`,
    );

  const customerObj =
    typeof visit.customerReference ===
    "object"
      ? visit.customerReference
      : null;

  const bookingObj =
    typeof visit.bookingReference ===
    "object"
      ? visit.bookingReference
      : null;

  const slotObj =
    typeof visit.timeSlotReference ===
    "object"
      ? visit.timeSlotReference
      : null;

  const scheduledDate =
    visit.scheduledStartDateTime
      ? dayjs(
          visit.scheduledStartDateTime,
        ).format(
          "YYYY-MM-DD",
        )
      : "";

  return {
    ...visit,
    id: visit._id,
    visitNumber:
      visit.visitId ||
      visit._id,

    date: scheduledDate,
    scheduledDate,

    status:
      visit.isCancelled
        ? "Cancelled"
        : visit.isCompleted
          ? "Completed"
          : "Scheduled",

    customer: customerObj
      ? {
          ...customerObj,
          id: customerObj._id,
          customerNumber:
            customerObj.customerId ||
            customerObj._id,
          mobile:
            customerObj.phoneNumber,
        }
      : null,

    booking: bookingObj
      ? {
          ...bookingObj,
          id: bookingObj._id,
          bookingNumber:
            bookingObj.bookingId ||
            bookingObj._id,
        }
      : null,

    slotId:
      slotObj?._id || "",

    slotLabel:
      slotObj?.startTime
        ? `${slotObj.startTime} – ${slotObj.endTime}`
        : "",
  };
}

export async function updateVisit(
  id,
  changes,
) {
  const mongoId =
    await resolveVisitId(id);

  const payload = {};

  if (
    changes.actualStartDateTime !==
    undefined
  ) {
    payload.actualStartDateTime =
      changes.actualStartDateTime;
  }

  if (
    changes.actualEndDateTime !==
    undefined
  ) {
    payload.actualEndDateTime =
      changes.actualEndDateTime;
  }

  if (
    changes.remarks !== undefined ||
    changes.completionRemarks !==
      undefined
  ) {
    payload.remarks =
      changes.remarks ??
      changes.completionRemarks ??
      "";
  }

  if (
    changes.isCompleted !==
    undefined
  ) {
    payload.isCompleted =
      changes.isCompleted;
  }

  if (
    changes.isPending !== undefined
  ) {
    payload.isPending =
      changes.isPending;
  }

  if (
    changes.isCancelled !==
    undefined
  ) {
    payload.isCancelled =
      changes.isCancelled;
  }

  if (
    changes.isActive !== undefined
  ) {
    payload.isActive =
      changes.isActive;
  }

  if (
    changes.isCompleted &&
    !payload.actualStartDateTime
  ) {
    payload.actualStartDateTime =
      new Date().toISOString();
  }

  if (
    changes.isCompleted &&
    !payload.actualEndDateTime
  ) {
    payload.actualEndDateTime =
      new Date().toISOString();
  }

  const result =
    await apiFetch(
      `/visits/${mongoId}`,
      {
        method: "PATCH",
        body: payload,
      },
    );

  return result.visit || result;
}

export async function completeVisit(
  param,
  {
    completedOn,
    remarks = "",
  } = {},
) {
  const mongoId =
    await resolveVisitId(param);

  const now =
    new Date().toISOString();

  const endDate =
    completedOn || now;

  return updateVisit(
    mongoId,
    {
      actualStartDateTime: now,
      actualEndDateTime: endDate,
      remarks,
      isPending: false,
      isCompleted: true,
      isCancelled: false,
      isActive: true,
    },
  );
}

export async function batchCompleteVisits(
  visitNumbers = [],
  options = {},
) {
  const results = [];

  for (
    const num of visitNumbers
  ) {
    results.push(
      await completeVisit(
        num,
        options,
      ),
    );
  }

  return results;
}

export async function rescheduleVisit(
  param,
  {
    newDate,
    newSlotId,
    reason,
    remarks = "",
  } = {},
) {
  throw new ApiError(
    "Visit rescheduling is not currently supported by the backend server.",
    400,
  );
}

// --- Invoices API ---

function normalizeInvoiceRecord(
  invoice,
) {
  const customerObj =
    typeof invoice.customerReference ===
    "object"
      ? invoice.customerReference
      : null;

  const bookingObj =
    typeof invoice.bookingReference ===
    "object"
      ? invoice.bookingReference
      : null;

  return {
    ...invoice,
    id: invoice._id,
    invoiceNumber:
      invoice.invoiceNumber ||
      invoice._id,
    amount:
      invoice.amount || 0,
    createdDate:
      invoice.createdAt,

    customer: customerObj
      ? {
          ...customerObj,
          id: customerObj._id,
          customerNumber:
            customerObj.customerId ||
            customerObj._id,
          name: customerObj.name,
          phone:
            customerObj.phoneNumber,
        }
      : null,

    booking: bookingObj
      ? {
          ...bookingObj,
          id: bookingObj._id,
          bookingNumber:
            bookingObj.bookingId ||
            bookingObj._id,
        }
      : null,
  };
}

export async function listInvoices({
  search = "",
} = {}) {
  const invoices =
    await apiFetch("/invoices");

  if (!Array.isArray(invoices))
    return [];

  let rows = invoices.map(
    normalizeInvoiceRecord,
  );

  if (search.trim()) {
    const q = search
      .trim()
      .toLowerCase();

    rows = rows.filter(
      (i) =>
        i.invoiceNumber
          .toLowerCase()
          .includes(q) ||
        (i.customer?.name || "")
          .toLowerCase()
          .includes(q) ||
        (
          i.booking
            ?.bookingNumber || ""
        )
          .toLowerCase()
          .includes(q),
    );
  }

  return rows.sort(
    (a, b) =>
      new Date(
        b.createdDate || 0,
      ) -
      new Date(
        a.createdDate || 0,
      ),
  );
}

export async function getInvoice(
  param,
) {
  if (isMongoId(param)) {
    try {
      const invoice =
        await apiFetch(
          `/invoices/${param}`,
        );

      return normalizeInvoiceRecord(
        invoice,
      );
    } catch (err) {}
  }

  const invoices =
    await listInvoices();

  const match = invoices.find(
    (i) =>
      i.invoiceNumber === param ||
      i.id === param,
  );

  if (match) return match;

  try {
    const invoiceByBooking =
      await apiFetch(
        `/invoices/booking/${param}`,
      );

    return normalizeInvoiceRecord(
      invoiceByBooking,
    );
  } catch (err) {}

  return null;
}

export async function recordInvoiceDownload(
  invoiceNumber,
) {
  return true;
}

// --- Payments API ---

export async function listPayments({
  search = "",
  status = "All",
  modeId = "All",
} = {}) {
  const payments =
    await apiFetch(
      "/service-payments",
    );

  if (!Array.isArray(payments))
    return [];

  let rows = payments.map(
    (payment) => {
      const customerObj =
        typeof payment.customerReference ===
        "object"
          ? payment.customerReference
          : null;

      const bookingObj =
        typeof payment.bookingReference ===
        "object"
          ? payment.bookingReference
          : null;

      const methodObj =
        typeof payment.paymentMethodReference ===
        "object"
          ? payment.paymentMethodReference
          : null;

      let payStatus =
        "Completed";

      if (
        payment.isCancelled
      ) {
        payStatus =
          "Reversed";
      } else if (
        payment.isPending
      ) {
        payStatus =
          "Pending";
      } else if (
        payment.isCompleted
      ) {
        payStatus =
          "Completed";
      }

      return {
        ...payment,
        id: payment._id,
        paymentNumber:
          payment.transactionId ||
          payment._id,
        amount:
          payment.totalAmount || 0,
        paymentDate:
          payment.createdAt,

        customer: customerObj
          ? {
              ...customerObj,
              id: customerObj._id,
              customerNumber:
                customerObj.customerId ||
                customerObj._id,
              mobile:
                customerObj.phoneNumber,
            }
          : null,

        booking: bookingObj
          ? {
              ...bookingObj,
              id: bookingObj._id,
              bookingNumber:
                bookingObj.bookingId ||
                bookingObj._id,
            }
          : null,

        invoice: null,

        mode:
          methodObj?.paymentMethodName ||
          "Online",

        modeId:
          methodObj?._id || "",

        status: payStatus,
      };
    },
  );

  if (status !== "All") {
    rows = rows.filter(
      (p) => p.status === status,
    );
  }

  if (modeId !== "All") {
    rows = rows.filter(
      (p) => p.modeId === modeId,
    );
  }

  if (search.trim()) {
    const q = search
      .trim()
      .toLowerCase();

    rows = rows.filter(
      (p) =>
        p.paymentNumber
          .toLowerCase()
          .includes(q) ||
        (p.customer?.name || "")
          .toLowerCase()
          .includes(q) ||
        (
          p.booking
            ?.bookingNumber || ""
        )
          .toLowerCase()
          .includes(q),
    );
  }

  return rows.sort(
    (a, b) =>
      new Date(
        b.paymentDate || 0,
      ) -
      new Date(
        a.paymentDate || 0,
      ),
  );
}

export async function getPayment(
  param,
) {
  if (isMongoId(param)) {
    try {
      const payment =
        await apiFetch(
          `/service-payments/${param}`,
        );

      const customerObj =
        typeof payment.customerReference ===
        "object"
          ? payment.customerReference
          : null;

      const bookingObj =
        typeof payment.bookingReference ===
        "object"
          ? payment.bookingReference
          : null;

      const methodObj =
        typeof payment.paymentMethodReference ===
        "object"
          ? payment.paymentMethodReference
          : null;

      let payStatus =
        "Completed";

      if (
        payment.isCancelled
      ) {
        payStatus =
          "Reversed";
      } else if (
        payment.isPending
      ) {
        payStatus =
          "Pending";
      }

      return {
        ...payment,
        id: payment._id,
        paymentNumber:
          payment.transactionId ||
          payment._id,
        amount:
          payment.totalAmount || 0,
        paymentDate:
          payment.createdAt,

        customer: customerObj
          ? {
              ...customerObj,
              name: customerObj.name,
              mobile:
                customerObj.phoneNumber,
            }
          : null,

        booking: bookingObj
          ? {
              ...bookingObj,
              bookingNumber:
                bookingObj.bookingId ||
                bookingObj._id,
            }
          : null,

        mode:
          methodObj?.paymentMethodName ||
          "Online",

        status: payStatus,
      };
    } catch (e) {}
  }

  const payments =
    await listPayments();

  return (
    payments.find(
      (p) =>
        p.paymentNumber === param ||
        p.id === param,
    ) || null
  );
}

export async function reversePayment(
  param,
  reason,
) {
  if (!reason)
    throw new ApiError(
      "A reason is required to reverse a payment.",
      400,
    );

  const payments =
    await listPayments();

  const match = payments.find(
    (p) =>
      p.paymentNumber === param ||
      p.id === param,
  );

  const id = match
    ? match.id
    : param;

  const result =
    await apiFetch(
      `/service-payments/${id}`,
      {
        method: "PUT",
        body: {
          isPending: false,
          isCompleted: false,
          isCancelled: true,
          isActive: false,
        },
      },
    );

  return {
    ...result,
    status: "Reversed",
  };
}

export async function dailyCollectionSummary(
  date = dayjs().format(
    "YYYY-MM-DD",
  ),
) {
  const [
    payments,
    methods,
    accounts,
  ] = await Promise.all([
    listPayments({}),
    apiFetch("/payment-methods"),
    apiFetch("/payment-accounts"),
  ]);

  const rows = payments.filter(
    (p) =>
      dayjs(
        p.paymentDate ||
          p.createdAt,
      ).format(
        "YYYY-MM-DD",
      ) === date &&
      p.status !== "Reversed",
  );

  const byMode =
    (methods || []).map(
      (m) => {
        const modePayments =
          rows.filter(
            (r) =>
              r.modeId ===
                m._id ||
              r.mode ===
                m.paymentMethodName,
          );

        return {
          mode: {
            id: m._id,
            name:
              m.paymentMethodName,
          },

          total:
            modePayments.reduce(
              (s, r) =>
                s +
                (r.amount || 0),
              0,
            ),

          count:
            modePayments.length,
        };
      },
    );

  return {
    date,

    totalCollected:
      rows.reduce(
        (s, r) =>
          s +
          (r.amount || 0),
        0,
      ),

    totalCount:
      rows.length,

    byMode,

    receiverAccounts:
      (accounts || []).map(
        (a) => ({
          id: a._id,
          name:
            a.accountName,
        }),
      ),
  };
}

// --- Subscriptions API ---

function normalizeSubscriptionRecord(
  subscription,
) {
  const customerObj =
    typeof subscription.customerReference ===
    "object"
      ? subscription.customerReference
      : null;

  const bookingObj =
    typeof subscription.bookingReference ===
    "object"
      ? subscription.bookingReference
      : null;

  const frequencyObj =
    typeof subscription.serviceFrequencyReference ===
    "object"
      ? subscription.serviceFrequencyReference
      : null;

  const planObj =
    typeof subscription.subscriptionTypeReference ===
    "object"
      ? subscription.subscriptionTypeReference
      : null;

  const totalVisits =
    subscription.totalVisits || 0;

  const completedVisits =
    subscription.completedVisits ||
    0;

  return {
    ...subscription,

    id: subscription._id,

    subscriptionNumber:
      subscription.subscriptionId ||
      subscription._id,

    customer: customerObj
      ? {
          ...customerObj,
          id: customerObj._id,
          customerNumber:
            customerObj.customerId ||
            customerObj._id,
          mobile:
            customerObj.phoneNumber,
        }
      : null,

    address: customerObj
      ? {
          addressLine:
            customerObj.address,
          area:
            customerObj.area,
          label:
            "Service address",
        }
      : null,

    booking: bookingObj
      ? {
          ...bookingObj,
          id: bookingObj._id,
          bookingNumber:
            bookingObj.bookingId ||
            bookingObj._id,
        }
      : null,

    status:
      subscription.subscriptionStatus ||
      "Active",

    currentPeriod: {
      totalServices:
        totalVisits,

      completedServices:
        completedVisits,

      endDate:
        subscription.endDate,

      planName:
        planObj?.subscriptionName ||
        "—",

      frequencyName:
        frequencyObj?.frequencyName ||
        "—",
    },

    nextVisit: null,

    renewalStatus:
      "On Track",

    createdOn:
      subscription.createdAt,
  };
}

export async function listSubscriptions({
  search = "",
  status = "All",
} = {}) {
  const subscriptions =
    await apiFetch(
      "/subscriptions",
    );

  if (
    !Array.isArray(
      subscriptions,
    )
  ) {
    return [];
  }

  let rows =
    subscriptions.map(
      normalizeSubscriptionRecord,
    );

  if (status !== "All") {
    rows = rows.filter(
      (s) =>
        s.status === status,
    );
  }

  if (search.trim()) {
    const q = search
      .trim()
      .toLowerCase();

    rows = rows.filter(
      (s) =>
        s.subscriptionNumber
          .toLowerCase()
          .includes(q) ||
        (s.customer?.name || "")
          .toLowerCase()
          .includes(q) ||
        (
          s.customer
            ?.customerNumber || ""
        )
          .toLowerCase()
          .includes(q),
    );
  }

  return rows.sort(
    (a, b) =>
      new Date(
        b.createdOn || 0,
      ) -
      new Date(
        a.createdOn || 0,
      ),
  );
}

export async function getSubscription(
  param,
) {
  const id =
    await resolveSubscriptionId(
      param,
    );

  let res;

  try {
    res =
      await apiFetch(
        `/subscriptions/${id}`,
      );
  } catch (err) {
    if (err.status === 404)
      return null;

    throw err;
  }

  const subObj =
    res.subscription || res;

  const visits =
    res.visits || [];

  const normalized =
    normalizeSubscriptionRecord(
      subObj,
    );

  const formattedVisits =
    visits.map((v) => ({
      ...v,
      id: v._id,
      date:
        v.scheduledStartDateTime,

      status: v.isCompleted
        ? "Completed"
        : v.isCancelled
          ? "Cancelled"
          : "Scheduled",
    }));

  const period = {
    id: `${subObj._id}-period`,

    periodNumber:
      `PER-${
        subObj.subscriptionId ||
        subObj._id
      }`,

    kind: "Current",

    status:
      subObj.subscriptionStatus ||
      "Active",

    startDate:
      subObj.startDate,

    endDate:
      subObj.endDate,

    totalServices:
      subObj.totalVisits ||
      formattedVisits.length,

    completedServices:
      subObj.completedVisits ||
      formattedVisits.filter(
        (v) =>
          v.isCompleted,
      ).length,

    visits:
      formattedVisits,
  };

  return {
    ...normalized,

    currentPeriod:
      period,

    periods: [period],

    nextVisit:
      formattedVisits.find(
        (v) =>
          !v.isCompleted &&
          !v.isCancelled,
      ) || null,
  };
}

// --- Dashboard API ---

export async function getDashboardSummary({
  date = dayjs().format(
    "YYYY-MM-DD",
  ),
} = {}) {
  const [
    customers,
    bookings,
    subscriptions,
    visits,
    payments,
  ] = await Promise.all([
    listCustomers(),
    listBookings(),
    listSubscriptions(),
    listVisits(),
    listPayments(),
  ]);

  const todayVisitsList =
    visits.filter(
      (v) => v.date === date,
    );

  const activeSubscriptionsList =
    subscriptions.filter(
      (s) =>
        s.status === "Active" ||
        s.isActive,
    );

  const renewalsList =
    subscriptions
      .filter(
        (s) => s.endDate,
      )
      .map((s) => ({
        id: s.id,
        customerName:
          s.customer?.name ||
          "Customer",
        mobileNumber:
          s.customer?.mobile ||
          "—",
        renewalDate:
          s.endDate,
        subscriptionType:
          s.currentPeriod
            ?.planName ||
          "Subscription",
      }));

  const completedToday =
    todayVisitsList.filter(
      (v) =>
        v.status ===
        "Completed",
    ).length;

  const pendingToday =
    todayVisitsList.filter(
      (v) =>
        v.status ===
        "Scheduled",
    ).length;

  return {
    kpis: {
      todayVisits:
        todayVisitsList.length,

      activeSubscriptions:
        activeSubscriptionsList.length,

      renewalsDueSoon:
        renewalsList.length,

      completedToday,

      pendingToday,

      totalCollected:
        payments.reduce(
          (sum, p) =>
            sum +
            (p.amount || 0),
          0,
        ),
    },

    todayVisitsList:
      todayVisitsList.map(
        (v) => ({
          id: v.id,
          customerName:
            v.customer?.name ||
            "—",
          mobileNumber:
            v.customer?.mobile ||
            "—",
          visitDate: v.date,
          noOfService: 1,
          status: v.status,
        }),
      ),

    activeSubscriptionsList:
      activeSubscriptionsList.map(
        (s) => ({
          id: s.id,
          customerName:
            s.customer?.name ||
            "—",
          phoneNumber:
            s.customer?.mobile ||
            "—",
          subscriptionType:
            s.currentPeriod
              ?.planName ||
            "Subscription",
          status: s.status,
        }),
      ),

    renewalsList,

    upcomingVisits: visits,

    monthVisits: visits,

    exceptions: {
      staleDrafts: [],
    },
  };
}