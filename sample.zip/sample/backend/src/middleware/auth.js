const jwt = require('jsonwebtoken');
const User = require('../models/user');

const auth = (req, res, next) => {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ message: 'Access denied. No token provided.' });
    }

    const token = authHeader.split(' ')[1];
    const decoded = jwt.verify(token, process.env.JWT_SECRET || 'supersecretjwtkey_jolly_home_needs_2026');

    // Normalize user identifier across all controllers
    const userId = decoded.userId || decoded._id || decoded.id;
    req.user = {
      ...decoded,
      userId,
      _id: userId,
      id: userId,
    };

    next();
  } catch (error) {
    return res.status(401).json({ message: 'Invalid or expired token.' });
  }
};

const authorize = (capability) => async (req, res, next) => {
  try {
    const userId = req.user?.userId || req.user?._id;
    const user = await User.findById(userId).populate('roleReference');
    if (!user || !user.isActive || !user.roleReference || !user.roleReference.isActive || !user.roleReference[capability]) {
      return res.status(403).json({ message: 'Insufficient permissions' });
    }
    req.authenticatedUser = user;
    return next();
  } catch (error) {
    return res.status(403).json({ message: 'Unable to verify permissions' });
  }
};

module.exports = auth;
module.exports.authorize = authorize;
