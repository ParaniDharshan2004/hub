const mongoose = require('mongoose');
const sequentialIdPlugin = require('../../config/sequentialId');

const bookingLogSchema = new mongoose.Schema(
  {
    auditLogId: { type: String, required: true, unique: true },
    operation: { type: String, enum: ['CREATE', 'UPDATE', 'DELETE'], required: true },
    bookingId: { type: mongoose.Schema.Types.ObjectId, ref: 'Booking', required: true },
    details: { type: mongoose.Schema.Types.Mixed, default: null },
    previousValue: { type: mongoose.Schema.Types.Mixed, default: null },
    newValue: { type: mongoose.Schema.Types.Mixed, default: null },
    createdAt: { type: Date },
    actionBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);

sequentialIdPlugin(bookingLogSchema, { field: 'auditLogId', prefix: 'AUD' });

module.exports = mongoose.models.BookingLog || mongoose.model('BookingLog', bookingLogSchema);
