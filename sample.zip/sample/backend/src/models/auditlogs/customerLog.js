const mongoose = require('mongoose');
const sequentialIdPlugin = require('../../config/sequentialId');

const customerLogSchema = new mongoose.Schema(
  {
    auditLogId: { type: String, required: true, unique: true },
    operation: { type: String, enum: ['CREATE', 'UPDATE', 'DELETE'], required: true },
    customerId: { type: mongoose.Schema.Types.ObjectId, ref: 'Customer', required: true },
    details: { type: mongoose.Schema.Types.Mixed, default: null },
    previousValue: { type: mongoose.Schema.Types.Mixed, default: null },
    newValue: { type: mongoose.Schema.Types.Mixed, default: null },
    createdAt: { type: Date },
    actionBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);

sequentialIdPlugin(customerLogSchema, { field: 'auditLogId', prefix: 'AUD' });

module.exports = mongoose.models.CustomerLog || mongoose.model('CustomerLog', customerLogSchema);
