const mongoose = require('mongoose');
const sequentialIdPlugin = require('../../config/sequentialId');

const roleLogSchema = new mongoose.Schema(
  {
    auditLogId: { type: String, required: true, unique: true },
    operation: { type: String, enum: ['CREATE', 'UPDATE', 'DELETE'], required: true },
    roleId: { type: mongoose.Schema.Types.ObjectId, ref: 'Role', required: false },
    details: { type: mongoose.Schema.Types.Mixed, default: null },
    previousValue: { type: mongoose.Schema.Types.Mixed, default: null },
    newValue: { type: mongoose.Schema.Types.Mixed, default: null },
    createdAt: { type: Date },
    actionBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);

sequentialIdPlugin(roleLogSchema, { field: 'auditLogId', prefix: 'AUD' });

module.exports = mongoose.models.RoleLog || mongoose.model('RoleLog', roleLogSchema);
