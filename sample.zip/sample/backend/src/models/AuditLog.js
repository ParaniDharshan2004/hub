const mongoose = require('mongoose');

const auditLogSchema = new mongoose.Schema(
  {
    userId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    operation: { type: String, enum: ['create', 'update', 'delete', 'CREATE', 'UPDATE', 'DELETE'], required: true },
    collectionName: { type: String, required: true, trim: true },
    recordId: { type: mongoose.Schema.Types.ObjectId, default: null },
    details: { type: mongoose.Schema.Types.Mixed, default: null },
    previousValue: { type: mongoose.Schema.Types.Mixed, default: null },
    newValue: { type: mongoose.Schema.Types.Mixed, default: null },
    createdAt: { type: Date },
    actionBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  },
  { timestamps: { createdAt: true, updatedAt: false } }
);

auditLogSchema.pre('save', function (next) {
  if (this.actionBy && !this.userId) {
    this.userId = this.actionBy;
  } else if (this.userId && !this.actionBy) {
    this.actionBy = this.userId;
  }
  if (this.actionBy && this.updatedBy == null) {
    this.updatedBy = this.actionBy;
  }
  next();
});

module.exports = mongoose.models.AuditLog || mongoose.model('AuditLog', auditLogSchema);
