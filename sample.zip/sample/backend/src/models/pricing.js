const mongoose = require('mongoose');
const sequentialIdPlugin = require('../config/sequentialId');

const pricingSchema = new mongoose.Schema(
  {
    pricingId: { type: String, required: true, unique: true },
    serviceDurationReference: { type: mongoose.Schema.Types.ObjectId, ref: 'ServiceDuration', required: true },
    // Retained for documents created before the reference-field migration.
    serviceDurationId: { type: mongoose.Schema.Types.ObjectId, ref: 'ServiceDuration', select: false },
    bathroomCountReference: { type: mongoose.Schema.Types.ObjectId, ref: 'BathroomCount', required: true },
    // Retained for documents created before the reference-field migration.
    bathroomCountId: { type: mongoose.Schema.Types.ObjectId, ref: 'BathroomCount', select: false },
    price: { type: Number, required: true },
    isActive: { type: Boolean, default: true },
    effectiveFrom: { type: Date, default: Date.now },
    createdAt: { type: Date },
    createdBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
    updatedAt: { type: Date },
    updatedBy: { type: mongoose.Schema.Types.ObjectId, ref: 'User', default: null },
  },
  { timestamps: true }
);

sequentialIdPlugin(pricingSchema, { field: 'pricingId', prefix: 'PRC' });

module.exports = mongoose.models.Pricing || mongoose.model('Pricing', pricingSchema);
