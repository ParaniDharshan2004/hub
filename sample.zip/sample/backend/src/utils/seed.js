const bcrypt = require("bcryptjs");
const Role = require("../models/Role");
const User = require("../models/User");
const BathroomCount = require("../models/bathroomCount");
const ServiceDuration = require("../models/serviceDuration");
const ServiceFrequency = require("../models/ServiceFrequency");
const SubscriptionType = require("../models/subscriptionType");
const TimeSlot = require("../models/TimeSlot");
const PaymentMethod = require("../models/PaymentMethod");
const PaymentAccount = require("../models/paymentAccount");
const PaymentMaster = require("../models/paymentMaster");
const Pricing = require("../models/pricing");
const Customer = require("../models/Customer");
const Booking = require("../models/Booking");
const BookingDate = require("../models/bookingDate");
const Subscription = require("../models/subscription");
const Visit = require("../models/visit");
const Invoice = require("../models/Invoice");
const ServicePayment = require("../models/servicePayment");
const Counter = require("../models/counter");
const AuditLog = require("../models/AuditLog");
const {
  UserLog,
  RoleLog,
  CustomerLog,
  BookingLog,
  SubscriptionLog,
  ServicePaymentLog,
} = require("../models/auditlogs");

const {
  role: roles,
  defaultUser,
  bathroomCounts,
  serviceDurations,
  serviceFrequencies,
  subscriptionTypes,
  timeSlots,
  paymentMethods,
  paymentAccounts,
  paymentMaster,
  pricing,
} = require("./masters");

const schemaFieldOrder = (schema) =>
  Object.keys(schema.paths).filter((path) => path !== "__v" && !path.includes("."));

const rewriteDocumentFieldOrder = async (Model) => {
  const order = schemaFieldOrder(Model.schema);
  const docs = await Model.collection.find({}).toArray();

  for (const doc of docs) {
    const ordered = {};

    for (const key of order) {
      if (doc[key] !== undefined) ordered[key] = doc[key];
    }

    for (const key of Object.keys(doc)) {
      if (key === "__v" || ordered[key] !== undefined) continue;
      ordered[key] = doc[key];
    }

    if (doc.__v !== undefined) ordered.__v = doc.__v;

    await Model.collection.replaceOne({ _id: doc._id }, ordered);
  }
};

const ALL_MODELS = [
  Role,
  User,
  BathroomCount,
  ServiceDuration,
  ServiceFrequency,
  SubscriptionType,
  TimeSlot,
  PaymentMethod,
  PaymentAccount,
  PaymentMaster,
  Pricing,
  Customer,
  Booking,
  BookingDate,
  Subscription,
  Visit,
  Invoice,
  ServicePayment,
  Counter,
  AuditLog,
  UserLog,
  RoleLog,
  CustomerLog,
  BookingLog,
  SubscriptionLog,
  ServicePaymentLog,
];

const syncMaster = async (Model, filter, data) => {
  const existing = await Model.findOne(filter);

  if (existing) {
    Object.assign(existing, data);
    return existing.save();
  }

  return Model.create(data);
};

const seedDatabase = async () => {
  try {
    console.log("Synchronizing master data...");

    // Roles
    for (const role of roles) {
      await syncMaster(Role, { roleName: role.roleName }, role);
    }

    // Default user
    const userRole = await Role.findOne({
      roleName: defaultUser.roleName,
    });

    const existingUser = await User.findOne({
      email: defaultUser.email,
    });

    if (!existingUser) {
      const hashedPassword = await bcrypt.hash(defaultUser.password, 10);
      await User.create({
        userName: defaultUser.name,
        email: defaultUser.email,
        passwordHash: hashedPassword,
        roleReference: userRole._id,
        isActive: defaultUser.isActive,
      });
    }

    // Bathroom counts
    for (const item of bathroomCounts) {
      await syncMaster(BathroomCount, { bathroomCount: item.bathroomCount }, item);
    }

    // Service durations
    for (const item of serviceDurations) {
      await syncMaster(ServiceDuration, { durationMinutes: item.durationMinutes }, item);
    }

    // Service frequencies
    for (const item of serviceFrequencies) {
      await syncMaster(ServiceFrequency, { frequencyName: item.frequencyName }, item);
    }

    // Subscription types
    for (const item of subscriptionTypes) {
      await syncMaster(SubscriptionType, { subscriptionName: item.subscriptionName }, item);
    }

    // Time slots
    for (const item of timeSlots) {
      await syncMaster(
        TimeSlot,
        { startTime: item.startTime, endTime: item.endTime },
        item,
      );
    }

    // Payment methods
    for (const item of paymentMethods) {
      await syncMaster(PaymentMethod, { paymentMethodName: item.paymentMethodName }, item);
    }

    // Payment accounts
    for (const item of paymentAccounts) {
      await syncMaster(PaymentAccount, { accountName: item.accountName }, item);
    }

    // Payment master
    await syncMaster(PaymentMaster, { isActive: true }, paymentMaster);

    // Pricing
    for (const item of pricing) {
      const bathroom = await BathroomCount.findOne({
        bathroomCount: item.bathroomCount,
      });

      const duration = await ServiceDuration.findOne({
        durationMinutes: item.durationMinutes,
      });

      await syncMaster(
        Pricing,
        {
          bathroomCountReference: bathroom._id,
          serviceDurationReference: duration._id,
        },
        {
          bathroomCountReference: bathroom._id,
          serviceDurationReference: duration._id,
          price: item.price,
          isActive: item.isActive,
        },
      );
    }

    console.log("Rewriting document field order...");
    for (const Model of ALL_MODELS) {
      await rewriteDocumentFieldOrder(Model);
    }

    console.log("Master data synchronized successfully.");
  } catch (error) {
    console.error("Master data synchronization failed:", error.message);
    throw error;
  }
};

module.exports = { seedDatabase };
