const mongoose = require('mongoose');
const Booking = require('../models/Booking');
const Invoice = require('../models/invoice');
const Counter = require('../models/counter');
const TimeSlot = require('../models/timeSlot');
const ServiceDuration = require('../models/serviceDuration');
const ServiceFrequency = require('../models/serviceFrequency');
const Pricing = require('../models/pricing');
const PaymentAccount = require('../models/paymentAccount');
const PaymentMaster = require('../models/paymentMaster');
const ServicePayment = require('../models/servicePayment');
const SubscriptionType = require('../models/subscriptionType');
const Subscription = require('../models/subscription');
const Visit = require('../models/visit');
const BookingLog = require('../models/auditlogs/bookingLog');
const ServicePaymentLog = require('../models/auditlogs/servicePaymentLog');
const availabilityService = require('../services/availabilityService');

// Helper to format date as YYYYMMDD
const getDateKey = (date = new Date()) => {
  const yyyy = date.getUTCFullYear();
  const mm = String(date.getUTCMonth() + 1).padStart(2, '0');
  const dd = String(date.getUTCDate()).padStart(2, '0');
  return `${yyyy}${mm}${dd}`;
};

// Add calendar months safely without month overflow
const addCalendarMonths = (date, months) => {
  const result = new Date(date);
  const originalDay = result.getUTCDate();
  result.setUTCDate(1);
  result.setUTCMonth(result.getUTCMonth() + months);
  const lastDayOfTargetMonth = new Date(
    Date.UTC(result.getUTCFullYear(), result.getUTCMonth() + 1, 0)
  ).getUTCDate();
  result.setUTCDate(Math.min(originalDay, lastDayOfTargetMonth));
  return result;
};

// Helper to get authenticated user ID
const getUserObjectId = (req) => {
  if (!req.user) return null;
  const userId = req.user._id || req.user.id || req.user.userId || null;
  if (!userId || !mongoose.Types.ObjectId.isValid(userId)) return null;
  return userId;
};

// Helper to populate standard booking references
const populateBookingReferences = (query) => {
  return query
    .populate('customerReference')
    .populate('bathroomCountReference')
    .populate('pricingReference')
    .populate('serviceDurationReference')
    .populate('serviceFrequencyReference')
    .populate('subscriptionTypeReference')
    .populate('timeSlotReference')
    .populate('paymentMethodReference')
    .populate('paymentAccountReference');
};

const roundCurrency = (value) => Math.round((value + Number.EPSILON) * 100) / 100;

// GET all bookings with filters (customerId, bookingDate, status, date ranges)
exports.getAllBookings = async (req, res) => {
  try {
    const {
      customerId,
      customerReference,
      bookingDate,
      date,
      status,
      isPending,
      isCompleted,
      isCancelled,
      startDate,
      endDate,
    } = req.query;

    const filter = {};

    const targetCustomer = customerId || customerReference;
    if (targetCustomer) {
      filter.customerReference = targetCustomer;
    }

    if (isPending !== undefined) {
      filter.isPending = isPending === true || isPending === 'true';
    }

    if (isCompleted !== undefined) {
      filter.isCompleted = isCompleted === true || isCompleted === 'true';
    }

    if (isCancelled !== undefined) {
      filter.isCancelled = isCancelled === true || isCancelled === 'true';
    }

    if (status) {
      const lowerStatus = String(status).trim().toLowerCase();
      if (lowerStatus === 'active' || lowerStatus === 'confirmed') {
        filter.isCancelled = false;
      } else if (lowerStatus === 'completed') {
        filter.isCompleted = true;
        filter.isCancelled = false;
      } else if (lowerStatus === 'cancelled') {
        filter.isCancelled = true;
      } else if (lowerStatus === 'pending') {
        filter.isPending = true;
        filter.isCancelled = false;
      }
    }

    const exactDate = bookingDate || date;
    if (exactDate) {
      const dateStr = String(exactDate).trim().slice(0, 10);
      filter.startDateTime = {
        $gte: new Date(`${dateStr}T00:00:00.000Z`),
        $lte: new Date(`${dateStr}T23:59:59.999Z`),
      };
    } else if (startDate || endDate) {
      filter.startDateTime = {};
      if (startDate) {
        filter.startDateTime.$gte = new Date(`${String(startDate).slice(0, 10)}T00:00:00.000Z`);
      }
      if (endDate) {
        filter.startDateTime.$lte = new Date(`${String(endDate).slice(0, 10)}T23:59:59.999Z`);
      }
    }

    const bookings = await populateBookingReferences(
      Booking.find(filter)
    ).sort({ startDateTime: -1 });

    const recurringBookings = bookings.filter((b) => b.subscriptionTypeReference);
    const visitFilter = recurringBookings.length
      ? { bookingReference: { $in: recurringBookings.map((b) => b._id) } }
      : { bookingReference: { $in: [] } };

    const visits = await Visit.find(visitFilter).sort({ scheduledStartDateTime: -1 }).lean();
    const bookingById = new Map(
      recurringBookings.map((b) => [String(b._id), b.toObject()])
    );

    const visitBookings = visits.map((visit) => {
      const parentBooking = bookingById.get(String(visit.bookingReference));
      return {
        ...parentBooking,
        _id: visit._id,
        bookingId: visit.bookingReference,
        visitId: visit.visitId,
        subscriptionReference: visit.subscriptionReference,
        bookingReference: visit.bookingReference,
        scheduledDate: visit.scheduledStartDateTime,
        startDateTime: visit.scheduledStartDateTime,
        endDateTime: visit.scheduledEndDateTime,
        status: visit.isCancelled
          ? 'Cancelled'
          : visit.isCompleted
            ? 'Completed'
            : 'Scheduled',
        isVisit: true,
      };
    });

    const oneTimeBookings = bookings.filter((b) => !b.subscriptionTypeReference);

    res.status(200).json([...oneTimeBookings, ...visitBookings]);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// GET single booking by MongoDB ObjectId
exports.getBookingById = async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: 'Invalid booking ID' });
    }

    const booking = await populateBookingReferences(
      Booking.findById(req.params.id)
    );

    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }

    const invoice = await Invoice.findOne({ bookingReference: booking._id });

    res.status(200).json({ booking, invoice });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// CREATE a booking with atomic database transaction and backend final overlap protection
exports.createBooking = async (req, res) => {
  try {
    let {
      customerId,
      bathroomCountId,
      pricingId,
      serviceDurationId,
      serviceFrequencyId,
      subscriptionTypeId,
      timeSlotId,
      scheduledDate,
      startTime,
      paymentMethodId,
      paymentAccountId,
      transactionId,
    } = req.body;

    if (!customerId) return res.status(400).json({ message: 'customerId is required' });
    if (!scheduledDate) return res.status(400).json({ message: 'scheduledDate is required' });
    if (!timeSlotId) return res.status(400).json({ message: 'timeSlotId is required' });
    if (!pricingId) return res.status(400).json({ message: 'pricingId is required' });

    if (!mongoose.Types.ObjectId.isValid(customerId)) {
      return res.status(400).json({ message: 'Invalid customerId' });
    }
    if (!mongoose.Types.ObjectId.isValid(pricingId)) {
      return res.status(400).json({ message: 'Invalid pricingId' });
    }

    const normalizedDateStr = String(scheduledDate).trim().slice(0, 10);
    if (!/^\d{4}-\d{2}-\d{2}$/.test(normalizedDateStr)) {
      return res.status(400).json({ message: 'scheduledDate must use YYYY-MM-DD format' });
    }

    // Extract slot start time and mongo ID from timeSlotId format (e.g. `<mongoId>-<minutes>`)
    let slotStartMinutes = null;
    let actualTimeSlotMongoId = timeSlotId;

    if (typeof timeSlotId === 'string' && timeSlotId.includes('-')) {
      const parts = timeSlotId.split('-');
      actualTimeSlotMongoId = parts[0];
      const parsedOffset = parseInt(parts[1], 10);
      if (!isNaN(parsedOffset)) {
        slotStartMinutes = parsedOffset;
      }
    }

    if (!mongoose.Types.ObjectId.isValid(actualTimeSlotMongoId)) {
      return res.status(400).json({ message: 'Invalid timeSlotId' });
    }

    const selectedTimeSlot = await TimeSlot.findById(actualTimeSlotMongoId);
    if (!selectedTimeSlot) {
      return res.status(404).json({ message: 'Selected time slot not found' });
    }

    // Parse startTime if provided in body or fallback to slot offset or time slot start
    if (startTime) {
      const parsed = availabilityService.parseTimeToMinutes(startTime);
      if (parsed !== null) slotStartMinutes = parsed;
    }

    if (slotStartMinutes === null) {
      slotStartMinutes = availabilityService.parseTimeToMinutes(selectedTimeSlot.startTime);
    }

    if (slotStartMinutes === null) {
      return res.status(400).json({ message: 'Unable to determine slot start time' });
    }

    // Resolve service duration and pricing
    const selectedPricing = await Pricing.findOne({ _id: pricingId, isActive: true })
      .populate('serviceDurationReference');

    if (!selectedPricing) {
      return res.status(404).json({ message: 'Active pricing record not found' });
    }

    const resolvedServiceDuration = await availabilityService.resolveServiceDuration({
      pricingId,
      serviceDurationId,
      bathroomCountId,
    });

    const resolvedBufferTime = Number(selectedTimeSlot.bufferTime) || 30;
    const totalDuration = resolvedServiceDuration + resolvedBufferTime;

    const calculatedStartDateTime = availabilityService.combineDateAndTime(normalizedDateStr, slotStartMinutes);
    const calculatedEndDateTime = availabilityService.combineDateAndTime(normalizedDateStr, slotStartMinutes + totalDuration);

    if (!calculatedStartDateTime || !calculatedEndDateTime) {
      return res.status(400).json({ message: 'Unable to calculate booking startDateTime and endDateTime' });
    }

    // Subscription & multi-visit scheduling
    const shouldCreateSubscription = subscriptionTypeId !== undefined && subscriptionTypeId !== null;
    let normalizedTotalVisits = 1;
    let subscriptionType = null;
    let scheduleIntervalDays = null;
    let serviceFrequency = null;
    let subscriptionEndDate = null;
    let visitScheduleDates = [];

    if (shouldCreateSubscription) {
      if (!serviceFrequencyId) {
        return res.status(400).json({
          message: 'serviceFrequencyId is required for a subscription booking',
        });
      }

      subscriptionType = await SubscriptionType.findOne({ _id: subscriptionTypeId, isActive: true });
      if (!subscriptionType) {
        return res.status(404).json({ message: 'Subscription type not found' });
      }

      serviceFrequency = await ServiceFrequency.findOne({ _id: serviceFrequencyId, isActive: true });
      if (!serviceFrequency) {
        return res.status(404).json({ message: 'Service frequency not found' });
      }

      scheduleIntervalDays = Number(serviceFrequency.intervalDays) || 7;
      const subscriptionDurationMonths = Number(subscriptionType.timeGap) || 1;

      subscriptionEndDate = addCalendarMonths(calculatedStartDateTime, subscriptionDurationMonths);
      const visitDuration = calculatedEndDateTime.getTime() - calculatedStartDateTime.getTime();

      // Monthly frequencies (intervalDays >= 28) advance by calendar months to avoid
      // generating 30× too many visits. Weekly/daily use the day-based offset.
      const isMonthlyFrequency = scheduleIntervalDays >= 28;

      let currentVisitStart = new Date(calculatedStartDateTime);
      let visitMonthOffset = 0;

      while (currentVisitStart < subscriptionEndDate) {
        visitScheduleDates.push({
          scheduledStartDateTime: new Date(currentVisitStart),
          scheduledEndDateTime: new Date(currentVisitStart.getTime() + visitDuration),
        });

        if (isMonthlyFrequency) {
          // Advance by one calendar month per visit interval
          visitMonthOffset += Math.round(scheduleIntervalDays / 30) || 1;
          currentVisitStart = addCalendarMonths(calculatedStartDateTime, visitMonthOffset);
        } else {
          const nextVisitStart = new Date(currentVisitStart);
          nextVisitStart.setUTCDate(nextVisitStart.getUTCDate() + scheduleIntervalDays);
          currentVisitStart = nextVisitStart;
        }
      }

      normalizedTotalVisits = visitScheduleDates.length || 1;
    }

    // RULE 2: Backend Final Overlap Protection Check before writing to database
    const overlapResult = await availabilityService.checkBookingOverlap({
      scheduledDate: normalizedDateStr,
      startDateTime: calculatedStartDateTime,
      endDateTime: calculatedEndDateTime,
      visitScheduleDates: shouldCreateSubscription ? visitScheduleDates : [],
    });

    if (overlapResult.hasConflict) {
      return res.status(409).json({
        message: 'The selected date and time slot is already booked. Please choose another slot.',
        reason: overlapResult.reason,
      });
    }

    const userId = getUserObjectId(req);
    let savedBooking = null;
    let savedPayment = null;
    let savedInvoice = null;
    let savedSubscription = null;
    let savedVisits = [];

    const session = await mongoose.startSession();

    try {
      await session.withTransaction(async () => {
        const paymentMaster = await PaymentMaster.findOne({
          isActive: true,
          effectiveFrom: { $lte: new Date() },
          $or: [{ effectiveTo: null }, { effectiveTo: { $gte: new Date() } }],
        }).sort({ effectiveFrom: -1 }).session(session);

        if (!paymentMaster) {
          const error = new Error('No active payment master configuration found');
          error.status = 400;
          throw error;
        }

        const booking = new Booking({
          customerReference: customerId,
          bathroomCountReference: bathroomCountId || null,
          pricingReference: pricingId || null,
          serviceDurationReference: serviceDurationId || selectedPricing.serviceDurationReference?._id || null,
          serviceFrequencyReference: serviceFrequencyId || null,
          subscriptionTypeReference: subscriptionTypeId || null,
          timeSlotReference: actualTimeSlotMongoId,
          scheduledDate: new Date(`${normalizedDateStr}T00:00:00.000Z`),
          startDateTime: calculatedStartDateTime,
          endDateTime: calculatedEndDateTime,
          paymentMethodReference: paymentMethodId || null,
          paymentAccountReference: paymentAccountId || null,
          transactionId: transactionId || '',
          amount: 0,
          createdBy: userId,
        });

        booking.$session(session);
        savedBooking = await booking.save();

        if (shouldCreateSubscription) {
          const subscription = new Subscription({
            bookingReference: savedBooking._id,
            customerReference: customerId,
            pricingReference: pricingId,
            serviceFrequencyReference: serviceFrequencyId,
            subscriptionTypeReference: subscriptionType._id,
            createdBy: userId,
            startDate: calculatedStartDateTime,
            endDate: subscriptionEndDate,
            totalVisits: normalizedTotalVisits,
            completedVisits: 0,
            remainingVisits: normalizedTotalVisits,
            scheduleIntervalDays,
            subscriptionStatus: 'Upcoming',
          });

          subscription.$session(session);
          savedSubscription = await subscription.save();

          const visits = visitScheduleDates.map((schedule, index) => ({
            subscriptionReference: savedSubscription._id,
            bookingReference: savedBooking._id,
            customerReference: customerId,
            timeSlotReference: actualTimeSlotMongoId,
            createdBy: userId,
            updatedBy: userId,
            visitNumber: index + 1,
            scheduledStartDateTime: schedule.scheduledStartDateTime,
            scheduledEndDateTime: schedule.scheduledEndDateTime,
          }));

          savedVisits = await Visit.insertMany(visits, { session, ordered: true });
        }

        const pricePerVisit = Number(selectedPricing.price);
        const baseAmount = roundCurrency(pricePerVisit * normalizedTotalVisits);
        const discountAmount = roundCurrency(baseAmount * Number(paymentMaster.discountRate) / 100);
        const taxableAmount = roundCurrency(baseAmount - discountAmount);
        const cgstAmount = roundCurrency(taxableAmount * Number(paymentMaster.cgstRate) / 100);
        const sgstAmount = roundCurrency(taxableAmount * Number(paymentMaster.sgstRate) / 100);
        const totalAmount = roundCurrency(taxableAmount + cgstAmount + sgstAmount);

        const servicePayment = new ServicePayment({
          bookingReference: savedBooking._id,
          subscriptionReference: savedSubscription?._id || null,
          customerReference: customerId,
          pricingReference: selectedPricing._id,
          paymentMasterReference: paymentMaster._id,
          paymentMethodReference: paymentMethodId || null,
          paymentAccountReference: paymentAccountId || null,
          createdBy: userId,
          pricePerVisit,
          totalServiceVisits: normalizedTotalVisits,
          baseAmount,
          cgstRate: paymentMaster.cgstRate,
          cgstAmount,
          sgstRate: paymentMaster.sgstRate,
          sgstAmount,
          discountRate: paymentMaster.discountRate,
          discountAmount,
          totalAmount,
          transactionId: transactionId || '',
        });

        servicePayment.$session(session);
        savedPayment = await servicePayment.save();

        savedBooking.amount = totalAmount;
        await savedBooking.save({ session });

        const dateKey = getDateKey(calculatedStartDateTime);
        const counter = await Counter.findByIdAndUpdate(
          `invoice-${dateKey}`,
          { $inc: { seq: 1 } },
          { new: true, upsert: true, setDefaultsOnInsert: true, session }
        );

        const invoice = new Invoice({
          invoiceNumber: `JHN${dateKey}-${String(counter.seq).padStart(4, '0')}`,
          customerReference: customerId,
          bookingReference: savedBooking._id,
          servicePaymentReference: savedPayment._id,
          amount: savedPayment.totalAmount,
          createdBy: userId,
        });

        invoice.$session(session);
        savedInvoice = await invoice.save();

        await ServicePaymentLog.create([{
          operation: 'CREATE',
          actionBy: userId,
          servicePaymentId: savedPayment._id,
          details: { action: 'Service payment calculated during booking creation' },
          previousValue: null,
          newValue: savedPayment.toObject(),
        }], { session });

        await BookingLog.insertMany([{
          operation: 'CREATE',
          actionBy: userId,
          bookingId: savedBooking._id,
          details: {
            action: shouldCreateSubscription
              ? 'Booking created, subscription, visits, service payment and invoice generated'
              : 'Booking created, service payment and invoice generated',
            invoiceNumber: savedInvoice?.invoiceNumber,
            amount: savedBooking.amount,
            servicePaymentId: savedPayment._id,
            subscriptionId: savedSubscription?.subscriptionId,
            totalVisits: savedVisits.length || undefined,
          },
          previousValue: null,
          newValue: savedBooking.toObject(),
        }], { session, ordered: true });
      });
    } finally {
      await session.endSession();
    }

    const populatedBooking = await populateBookingReferences(
      Booking.findById(savedBooking._id)
    );

    const response = {
      message: 'Booking created and invoice generated successfully',
      booking: populatedBooking,
    };

    if (savedInvoice) response.invoice = savedInvoice;
    if (savedSubscription) {
      response.subscription = savedSubscription;
      response.visits = savedVisits;
    }

    res.status(201).json(response);
  } catch (error) {
    console.error('createBooking error:', error);
    if (error.code === 11000) {
      return res.status(409).json({ message: 'A related booking record already exists' });
    }
    res.status(error.status || 500).json({ message: error.message });
  }
};

// UPDATE the payment account on a booking
exports.updateBookingPaymentAccount = async (req, res) => {
  const { id } = req.params;
  const { paymentAccountId } = req.body;

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).json({ message: 'Invalid booking ID' });
  }
  if (!paymentAccountId || !mongoose.Types.ObjectId.isValid(paymentAccountId)) {
    return res.status(400).json({ message: 'Valid paymentAccountId is required' });
  }

  const userId = getUserObjectId(req);
  const session = await mongoose.startSession();
  let updatedBooking = null;

  try {
    await session.withTransaction(async () => {
      const booking = await Booking.findById(id).session(session);
      if (!booking) {
        const error = new Error('Booking not found');
        error.status = 404;
        throw error;
      }

      const paymentAccount = await PaymentAccount.findOne({
        _id: paymentAccountId,
        isActive: true,
      }).session(session);

      if (!paymentAccount) {
        const error = new Error('Active payment account not found');
        error.status = 404;
        throw error;
      }

      const servicePayment = await ServicePayment.findOne({
        bookingReference: booking._id,
      }).session(session);

      if (!servicePayment) {
        const error = new Error('Service payment not found for this booking');
        error.status = 404;
        throw error;
      }

      const previousBooking = booking.toObject();
      const previousServicePayment = servicePayment.toObject();

      booking.paymentAccountReference = paymentAccount._id;
      servicePayment.paymentAccountReference = paymentAccount._id;

      updatedBooking = await booking.save({ session });
      const updatedServicePayment = await servicePayment.save({ session });

      await BookingLog.create([{
        operation: 'UPDATE',
        actionBy: userId,
        bookingId: updatedBooking._id,
        details: { action: 'Booking payment account updated' },
        previousValue: previousBooking,
        newValue: updatedBooking.toObject(),
      }], { session });

      await ServicePaymentLog.create([{
        operation: 'UPDATE',
        actionBy: userId,
        servicePaymentId: updatedServicePayment._id,
        details: { action: 'Service payment account updated' },
        previousValue: previousServicePayment,
        newValue: updatedServicePayment.toObject(),
      }], { session });
    });
  } catch (error) {
    return res.status(error.status || 500).json({ message: error.message });
  } finally {
    await session.endSession();
  }

  const populatedBooking = await populateBookingReferences(
    Booking.findById(updatedBooking._id)
  );
  return res.status(200).json(populatedBooking);
};

// UPDATE a booking
exports.updateBooking = async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: 'Invalid booking ID' });
    }

    const previousBooking = await Booking.findById(req.params.id);
    if (!previousBooking) {
      return res.status(404).json({ message: 'Booking not found' });
    }

    const {
      customerId,
      bathroomCountId,
      pricingId,
      serviceDurationId,
      serviceFrequencyId,
      subscriptionTypeId,
      timeSlotId,
      scheduledDate,
      startTime,
      paymentMethodId,
      receiverBankId,
      transactionId,
      amount,
    } = req.body;

    const updateData = {};
    if (customerId !== undefined) updateData.customerReference = customerId;
    if (bathroomCountId !== undefined) updateData.bathroomCountReference = bathroomCountId || null;
    if (pricingId !== undefined) updateData.pricingReference = pricingId || null;
    if (serviceDurationId !== undefined) updateData.serviceDurationReference = serviceDurationId || null;
    if (serviceFrequencyId !== undefined) updateData.serviceFrequencyReference = serviceFrequencyId || null;
    if (subscriptionTypeId !== undefined) updateData.subscriptionTypeReference = subscriptionTypeId || null;
    if (timeSlotId !== undefined) updateData.timeSlotReference = timeSlotId;
    if (paymentMethodId !== undefined) updateData.paymentMethodReference = paymentMethodId || null;
    if (receiverBankId !== undefined) updateData.paymentAccountReference = receiverBankId || null;
    if (transactionId !== undefined) updateData.transactionId = transactionId;
    if (amount !== undefined) updateData.amount = Number(amount);

    const shouldRecalculateTime = scheduledDate !== undefined || startTime !== undefined || timeSlotId !== undefined;
    if (shouldRecalculateTime) {
      const resolvedDate = scheduledDate ? String(scheduledDate).slice(0, 10) : previousBooking.scheduledDate.toISOString().slice(0, 10);
      const resolvedSlotId = timeSlotId || previousBooking.timeSlotReference;
      const selectedSlot = await TimeSlot.findById(resolvedSlotId);

      const slotStartMinutes = startTime
        ? availabilityService.parseTimeToMinutes(startTime)
        : availabilityService.parseTimeToMinutes(selectedSlot?.startTime || '08:30 AM');

      const duration = await availabilityService.resolveServiceDuration({
        pricingId: pricingId || previousBooking.pricingReference,
        serviceDurationId: serviceDurationId || previousBooking.serviceDurationReference,
        bathroomCountId: bathroomCountId || previousBooking.bathroomCountReference,
      });

      const buffer = Number(selectedSlot?.bufferTime || 30);
      const startDateTime = availabilityService.combineDateAndTime(resolvedDate, slotStartMinutes);
      const endDateTime = availabilityService.combineDateAndTime(resolvedDate, slotStartMinutes + duration + buffer);

      const overlap = await availabilityService.checkBookingOverlap({
        startDateTime,
        endDateTime,
        excludeBookingId: previousBooking._id,
      });

      if (overlap.hasConflict) {
        return res.status(409).json({ message: 'The selected date and time slot is already booked.' });
      }

      updateData.scheduledDate = new Date(`${resolvedDate}T00:00:00.000Z`);
      updateData.startDateTime = startDateTime;
      updateData.endDateTime = endDateTime;
    }

    const updatedBooking = await Booking.findByIdAndUpdate(req.params.id, updateData, {
      new: true,
      runValidators: true,
    });

    const userId = getUserObjectId(req);
    await BookingLog.create({
      operation: 'UPDATE',
      actionBy: userId,
      bookingId: updatedBooking._id,
      details: { updatedFields: Object.keys(updateData) },
      previousValue: previousBooking.toObject(),
      newValue: updatedBooking.toObject(),
    });

    const populated = await populateBookingReferences(Booking.findById(updatedBooking._id));
    res.status(200).json(populated);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

// DELETE a booking and associated invoice
exports.deleteBooking = async (req, res) => {
  try {
    if (!mongoose.Types.ObjectId.isValid(req.params.id)) {
      return res.status(400).json({ message: 'Invalid booking ID' });
    }

    const booking = await Booking.findByIdAndDelete(req.params.id);
    if (!booking) {
      return res.status(404).json({ message: 'Booking not found' });
    }

    await Invoice.findOneAndDelete({ bookingReference: booking._id });

    const userId = getUserObjectId(req);
    await BookingLog.create({
      operation: 'DELETE',
      actionBy: userId,
      bookingId: booking._id,
      details: { action: 'Booking and associated invoice deleted' },
      previousValue: booking.toObject(),
      newValue: null,
    });

    res.status(200).json({ message: 'Booking and associated invoice deleted successfully' });
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

const updateBookingStatus = async (req, res, statusName, extraFields = {}) => {
  try {
    const normalizedStatus = statusName.toLowerCase();
    const lifecycleFields = normalizedStatus === 'cancelled'
      ? { isPending: false, isCompleted: false, isCancelled: true, isActive: false }
      : normalizedStatus === 'completed'
        ? { isPending: false, isCompleted: true, isCancelled: false, isActive: true }
        : { isPending: true, isCompleted: false, isCancelled: false, isActive: true };

    const booking = await Booking.findByIdAndUpdate(
      req.params.id,
      { ...lifecycleFields, ...extraFields },
      { new: true, runValidators: true }
    );

    if (!booking) {
      if (normalizedStatus === 'completed') {
        const visit = await Visit.findByIdAndUpdate(
          req.params.id,
          { isPending: false, isCompleted: true, isCancelled: false, actualEndDateTime: new Date() },
          { new: true, runValidators: true }
        );
        if (visit) return res.status(200).json(visit);
      }
      return res.status(404).json({ message: 'Booking not found' });
    }

    await Subscription.findOneAndUpdate(
      { bookingReference: booking._id },
      { ...lifecycleFields, subscriptionStatus: statusName === 'Scheduled' ? 'Upcoming' : statusName },
      { runValidators: true }
    );

    const userId = getUserObjectId(req);
    await BookingLog.create({
      operation: 'UPDATE',
      actionBy: userId,
      bookingId: booking._id,
      details: { action: `Booking marked ${statusName}` },
      previousValue: null,
      newValue: booking.toObject(),
    });

    const populatedBooking = await populateBookingReferences(Booking.findById(booking._id));
    res.status(200).json(populatedBooking);
  } catch (error) {
    res.status(500).json({ message: error.message });
  }
};

exports.cancelBooking = (req, res) => updateBookingStatus(req, res, 'Cancelled');
exports.restoreBooking = (req, res) => updateBookingStatus(req, res, 'Scheduled');
exports.completeBooking = (req, res) =>
  updateBookingStatus(req, res, 'Completed', {
    completionPhoto: req.body.completionPhoto || null,
  });
