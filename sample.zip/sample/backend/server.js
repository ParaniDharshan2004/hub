require('dotenv').config();

const express = require('express');
const cors = require('cors');

const connectDB = require('./src/config/db');
const { seedDatabase } = require('./src/utils/seed');

// Import controllers for direct endpoints
const userController = require('./src/controllers/userController');

// Import routes
const userRoutes = require('./src/routes/userRoutes');
const roleRoutes = require('./src/routes/roleRoutes');
const customerRoutes = require('./src/routes/customerRoutes');
const bookingRoutes = require('./src/routes/bookingRoutes');
const serviceDurationRoutes = require('./src/routes/serviceDurationRoutes');
const serviceFrequencyRoutes = require('./src/routes/serviceFrequencyRoutes');
const subscriptionTypeRoutes = require('./src/routes/subscriptionTypeRoutes');
const subscriptionRoutes = require('./src/routes/subscriptionRoutes');
const timeSlotRoutes = require('./src/routes/timeSlotRoutes');
const paymentMethodRoutes = require('./src/routes/paymentMethodRoutes');
const paymentAccountRoutes = require('./src/routes/paymentAccountRoutes');
const invoiceRoutes = require('./src/routes/invoiceRoutes');
const pricingRoutes = require('./src/routes/pricingRoutes');
const bathroomCountRoutes = require('./src/routes/bathroomCountRoutes');
const paymentMasterRoutes = require('./src/routes/paymentMasterRoutes');
const servicePaymentRoutes = require('./src/routes/servicePaymentRoutes');
const visitRoutes = require('./src/routes/visitRoutes');
const bookingDateRoutes = require('./src/routes/bookingDateRoutes');

const app = express();

// Middlewares
app.use(
  cors({
    origin: 'http://localhost:5173',
    credentials: true,
  })
);

app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Request logging in development
if (process.env.NODE_ENV !== 'test') {
  app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.originalUrl}`);
    next();
  });
}

// Health check endpoint
app.get('/api/health', (req, res) => {
  res.status(200).json({
    status: 'OK',
    message: 'Jolly Home Needs API is running',
    timestamp: new Date().toISOString(),
  });
});

// Authentication endpoint
app.post('/api/login', userController.login);

// Resource API Routes
app.use(['/api/users', '/api/user'], userRoutes);
app.use(['/api/roles', '/api/role'], roleRoutes);
app.use(['/api/customers', '/api/customer'], customerRoutes);
app.use(['/api/bookings', '/api/booking'], bookingRoutes);
app.use(['/api/service-durations', '/api/service-duration', '/api/servicedurations', '/api/durations'], serviceDurationRoutes);
app.use(['/api/service-frequencies', '/api/service-frequency', '/api/servicefrequencies', '/api/frequencies'], serviceFrequencyRoutes);
app.use('/api/subscription-types', subscriptionTypeRoutes);
app.use('/api/subscriptions', subscriptionRoutes);
app.use(['/api/time-slots', '/api/time-slot', '/api/timeslots', '/api/slots'], timeSlotRoutes);
app.use(['/api/payments', '/api/payment-methods', '/api/payment-method', '/api/methods'], paymentMethodRoutes);
app.use(['/api/accounts', '/api/payment-accounts', '/api/payment-account'], paymentAccountRoutes);
app.use(['/api/invoices', '/api/invoice'], invoiceRoutes);
app.use('/api/pricing', pricingRoutes);
app.use(['/api/bathroom-counts', '/api/bathroom-count', '/api/bathroomcounts', '/api/bathrooms'], bathroomCountRoutes);
app.use('/api/payment-masters', paymentMasterRoutes);
app.use('/api/service-payments', servicePaymentRoutes);
app.use('/api/visits', visitRoutes);
app.use('/api/booking-dates', bookingDateRoutes);

// 404 Handler
app.use((req, res) => {
  res.status(404).json({ message: `Route ${req.method} ${req.originalUrl} not found` });
});

// Global Error Handler
app.use((err, req, res, next) => {
  console.error('Unhandled error:', err);
  res.status(err.status || 500).json({
    message: err.message || 'Internal Server Error',
  });
});

// Start Server
const PORT = process.env.PORT || 5000;

const startServer = async () => {
  try {
    await connectDB();
    await seedDatabase();

    const server = app.listen(PORT, () => {
      console.log(`=================================================`);
      console.log(`🚀 Jolly Home Needs API Server running on port ${PORT}`);
      console.log(`🌐 Base URL: http://localhost:${PORT}`);
      console.log(`=================================================`);
    });

    return server;
  } catch (error) {
    console.error('Failed to start server:', error);
    process.exit(1);
  }
};

if (process.env.NODE_ENV !== 'test') {
  startServer();
}

module.exports = app;
