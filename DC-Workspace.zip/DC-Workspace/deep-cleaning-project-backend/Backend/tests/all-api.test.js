/* eslint-env jest */

process.env.NODE_ENV = "test";

const request = require("supertest");
const mongoose = require("mongoose");
const bcrypt = require("bcryptjs");

const app = require("../server");

const Role = require("../src/models/Role");
const User = require("../src/models/User");
const Customer = require("../src/models/Customer");
const Counter = require("../src/models/counter");
const AuditLog = require("../src/models/AuditLog");

jest.setTimeout(60000);

const TEST_DATABASE =
  process.env.MONGO_URI_TEST ||
  "mongodb://127.0.0.1:27017/jolly_home_needs_jest_test";

const TEST_PASSWORD = "TestAdmin@123";

let superAdminRole;
let readOnlyRole;
let superAdminUser;
let readOnlyUser;

let superAdminToken;
let readOnlyToken;

let createdCustomerId;
let originalCustomerId;
let createdPhoneNumber;
let secondPhoneNumber;

const nonexistentObjectId = "507f1f77bcf86cd799439011";

const generatePhoneNumber = (prefix = "7") => {
  const timestamp = Date.now().toString();
  return `${prefix}${timestamp.slice(-9)}`;
};

const authorizationHeader = (token) => ({
  Authorization: `Bearer ${token}`,
});

const ensureRole = async ({
  roleName,
  canRead,
  canWrite,
  canUpdate,
  canDelete,
}) => {
  let role = await Role.findOne({ roleName });

  if (!role) {
    role = await Role.create({
      roleId: await Role.getNextSequentialId(),
      roleName,
      canRead,
      canWrite,
      canUpdate,
      canDelete,
      isActive: true,
    });
  } else {
    role.canRead = canRead;
    role.canWrite = canWrite;
    role.canUpdate = canUpdate;
    role.canDelete = canDelete;
    role.isActive = true;
    await role.save();
  }

  return role;
};

const ensureUser = async ({ userName, email, password, roleReference }) => {
  const passwordHash = await bcrypt.hash(password, 10);

  let user = await User.findOne({ email });

  if (!user) {
    user = await User.create({
      userId: await User.getNextSequentialId(),
      userName,
      email,
      passwordHash,
      roleReference,
      isActive: true,
    });
  } else {
    user.userName = userName;
    user.passwordHash = passwordHash;
    user.roleReference = roleReference;
    user.isActive = true;
    await user.save();
  }

  return user;
};

beforeAll(async () => {
  await mongoose.connect(TEST_DATABASE);

  superAdminRole = await ensureRole({
    roleName: "jest-superadmin",
    canRead: true,
    canWrite: true,
    canUpdate: true,
    canDelete: true,
  });

  readOnlyRole = await ensureRole({
    roleName: "jest-readonly",
    canRead: true,
    canWrite: false,
    canUpdate: false,
    canDelete: false,
  });

  superAdminUser = await ensureUser({
    userName: "Jest Super Admin",
    email: "jest.superadmin@example.com",
    password: TEST_PASSWORD,
    roleReference: superAdminRole._id,
  });

  readOnlyUser = await ensureUser({
    userName: "Jest Read Only User",
    email: "jest.readonly@example.com",
    password: TEST_PASSWORD,
    roleReference: readOnlyRole._id,
  });

  createdPhoneNumber = generatePhoneNumber("7");
  secondPhoneNumber = generatePhoneNumber("8");
});

afterAll(async () => {
  if (createdCustomerId) {
    await Customer.deleteOne({ _id: createdCustomerId });
  }

  if (originalCustomerId) {
    await Customer.deleteOne({ _id: originalCustomerId });
  }

  await Customer.deleteMany({
    name: {
      $in: [
        "Jest Customer",
        "Jest Updated Customer",
        "Jest Duplicate Customer",
        "Jest Protected Customer",
      ],
    },
  });

  await User.deleteMany({
    email: {
      $in: ["jest.superadmin@example.com", "jest.readonly@example.com"],
    },
  });

  await Role.deleteMany({
    roleName: {
      $in: ["jest-superadmin", "jest-readonly"],
    },
  });

  await AuditLog.deleteMany({
    $or: [
      { actionBy: superAdminUser?._id },
      { actionBy: readOnlyUser?._id },
      { userId: superAdminUser?._id },
      { userId: readOnlyUser?._id },
      { createdBy: superAdminUser?._id },
      { createdBy: readOnlyUser?._id },
    ],
  });

  await Counter.deleteMany({
    _id: {
      $in: ["id:CUS", "id:USR", "id:ROL", "id:AUD"],
    },
  });

  await new Promise((resolve) => {
    setTimeout(resolve, 200);
  });

  await mongoose.disconnect();
});

describe("DC Backend Complete API Integration Test", () => {
  describe("1. Health and basic server tests", () => {
    test("SETUP-001: GET /api/health returns API status", async () => {
      const response = await request(app)
        .get("/api/health")
        .expect("Content-Type", /json/)
        .expect(200);

      expect(response.body).toHaveProperty("status", "OK");
      expect(response.body).toHaveProperty(
        "message",
        "Jolly Home Needs API is running",
      );
      expect(response.body).toHaveProperty("timestamp");
      expect(Number.isNaN(Date.parse(response.body.timestamp))).toBe(false);
    });

    test("Unknown API route returns controlled 404", async () => {
      const response = await request(app)
        .get("/api/not-existing-route")
        .expect("Content-Type", /json/)
        .expect(404);

      expect(response.body.message).toContain("not found");
    });

    test("Malformed JSON returns controlled 400", async () => {
      const response = await request(app)
        .post("/api/login")
        .set("Content-Type", "application/json")
        .send('{"email": "broken"')
        .expect("Content-Type", /json/)
        .expect(400);

      expect(response.body).toEqual({
        message: "Invalid request body",
      });
    });
  });

  describe("2. Authentication API", () => {
    test("AUTH-004: Login with empty fields returns 400", async () => {
      const response = await request(app)
        .post("/api/login")
        .send({})
        .expect(400);

      expect(response.body.message).toBe("Email and password are required");
      expect(response.body).not.toHaveProperty("token");
    });

    test("AUTH-006: Login without email returns 400", async () => {
      const response = await request(app)
        .post("/api/login")
        .send({ password: TEST_PASSWORD })
        .expect(400);

      expect(response.body.message).toBe("Email and password are required");
    });

    test("AUTH-007: Login without password returns 400", async () => {
      const response = await request(app)
        .post("/api/login")
        .send({ email: "jest.superadmin@example.com" })
        .expect(400);

      expect(response.body.message).toBe("Email and password are required");
    });

    test("AUTH-003: Unknown email is rejected", async () => {
      const response = await request(app)
        .post("/api/login")
        .send({
          email: "unknown.user@example.com",
          password: "WrongPassword123",
        })
        .expect(400);

      expect(response.body.message).toBe("Invalid email or password");
      expect(response.body).not.toHaveProperty("token");
    });

    test("AUTH-016: NoSQL injection object is safely rejected", async () => {
      const response = await request(app)
        .post("/api/login")
        .send({
          email: { $ne: null },
          password: { $ne: null },
        })
        .expect(400);

      expect(response.body.message).toBe("Email and password are required");
      expect(response.body).not.toHaveProperty("token");
    });

    test("AUTH-019: Null email is rejected", async () => {
      const response = await request(app)
        .post("/api/login")
        .send({
          email: null,
          password: TEST_PASSWORD,
        })
        .expect(400);

      expect(response.body.message).toBe("Email and password are required");
    });

    test("AUTH-020: Object password is safely rejected", async () => {
      const response = await request(app)
        .post("/api/login")
        .send({
          email: "jest.superadmin@example.com",
          password: { $ne: null },
        })
        .expect(400);

      expect(response.body.message).toBe("Email and password are required");
    });

    test("AUTH-002: Wrong password is rejected", async () => {
      const response = await request(app)
        .post("/api/login")
        .send({
          email: "jest.superadmin@example.com",
          password: "WrongPassword123",
        })
        .expect(400);

      expect(response.body.message).toBe("Invalid email or password");
      expect(response.body).not.toHaveProperty("token");
    });

    test("AUTH-001: Superadmin login returns JWT", async () => {
      const response = await request(app)
        .post("/api/login")
        .send({
          email: "jest.superadmin@example.com",
          password: TEST_PASSWORD,
        })
        .expect("Content-Type", /json/)
        .expect(200);

      expect(response.body.message).toBe("Login successful");
      expect(response.body.token).toEqual(expect.any(String));
      expect(response.body.user).toHaveProperty(
        "email",
        "jest.superadmin@example.com",
      );
      expect(response.body.user).not.toHaveProperty("passwordHash");

      superAdminToken = response.body.token;
    });

    test("AUTH-012 and AUTH-015: Email is trimmed and case insensitive", async () => {
      const response = await request(app)
        .post("/api/login")
        .send({
          email: "  JEST.SUPERADMIN@EXAMPLE.COM  ",
          password: TEST_PASSWORD,
        })
        .expect(200);

      expect(response.body.message).toBe("Login successful");
      expect(response.body.token).toEqual(expect.any(String));
    });

    test("ROLE-001: Read-only user login succeeds", async () => {
      const response = await request(app)
        .post("/api/login")
        .send({
          email: "jest.readonly@example.com",
          password: TEST_PASSWORD,
        })
        .expect(200);

      expect(response.body.token).toEqual(expect.any(String));
      readOnlyToken = response.body.token;
    });

    test("AUTH-008: Protected API without token returns 401", async () => {
      const response = await request(app).get("/api/users/me").expect(401);

      expect(response.body.message).toBe("Access denied. No token provided.");
    });

    test("AUTH-009: Invalid token returns 401", async () => {
      const response = await request(app)
        .get("/api/users/me")
        .set("Authorization", "Bearer invalid-token")
        .expect(401);

      expect(response.body.message).toBe("Invalid or expired token.");
    });

    test("AUTH-010: Valid token returns current user", async () => {
      const response = await request(app)
        .get("/api/users/me")
        .set(authorizationHeader(superAdminToken))
        .expect(200);

      expect(response.body.email).toBe("jest.superadmin@example.com");
      expect(response.body).not.toHaveProperty("passwordHash");
    });
  });

  describe("3. Protected GET endpoint coverage", () => {
    const protectedGetEndpoints = [
      "/api/users",
      "/api/roles",
      "/api/customers",
      "/api/bookings",
      "/api/service-durations",
      "/api/service-frequencies",
      "/api/subscription-types",
      "/api/subscriptions",
      "/api/time-slots",
      "/api/payment-methods",
      "/api/accounts",
      "/api/invoices",
      "/api/pricing",
      "/api/bathroom-counts",
      "/api/payment-masters",
      "/api/service-payments",
      "/api/visits",
      "/api/booking-dates",
    ];

    test.each(protectedGetEndpoints)(
      "No token is rejected for GET %s",
      async (endpoint) => {
        const response = await request(app).get(endpoint);

        expect(response.statusCode).toBe(401);
        expect(response.body.message).toBe("Access denied. No token provided.");
      },
    );

    test.each(protectedGetEndpoints)(
      "Read-only user can access GET %s",
      async (endpoint) => {
        const response = await request(app)
          .get(endpoint)
          .set(authorizationHeader(readOnlyToken));

        expect(response.statusCode).toBe(200);
        expect(response.headers["content-type"]).toMatch(/json/);
      },
    );

    test.each(protectedGetEndpoints)(
      "Superadmin can access GET %s",
      async (endpoint) => {
        const response = await request(app)
          .get(endpoint)
          .set(authorizationHeader(superAdminToken));

        expect(response.statusCode).toBe(200);
        expect(response.headers["content-type"]).toMatch(/json/);
      },
    );
  });

  describe("4. Customer create validation", () => {
    test("CUS-002: Customer without name is rejected", async () => {
      const response = await request(app)
        .post("/api/customers")
        .set(authorizationHeader(superAdminToken))
        .send({ phoneNumber: createdPhoneNumber })
        .expect(400);

      expect(response.body.message).toBe(
        "name and phoneNumber must be strings",
      );
    });

    test("CUS-003: Customer without phone number is rejected", async () => {
      const response = await request(app)
        .post("/api/customers")
        .set(authorizationHeader(superAdminToken))
        .send({ name: "Jest Customer" })
        .expect(400);

      expect(response.body.message).toBe(
        "name and phoneNumber must be strings",
      );
    });

    test("CUS-004: Empty customer name is rejected", async () => {
      const response = await request(app)
        .post("/api/customers")
        .set(authorizationHeader(superAdminToken))
        .send({
          name: "",
          phoneNumber: createdPhoneNumber,
        })
        .expect(400);

      expect(response.body.message).toBe("Invalid customer data");
    });

    test("CUS-005: Spaces-only customer name is rejected", async () => {
      const response = await request(app)
        .post("/api/customers")
        .set(authorizationHeader(superAdminToken))
        .send({
          name: "     ",
          phoneNumber: createdPhoneNumber,
        })
        .expect(400);

      expect(response.body.message).toBe("Invalid customer data");
    });

    test("CUS-006: Numbers in customer name are rejected", async () => {
      const response = await request(app)
        .post("/api/customers")
        .set(authorizationHeader(superAdminToken))
        .send({
          name: "Jest Customer 123",
          phoneNumber: createdPhoneNumber,
        })
        .expect(400);

      expect(response.body.message).toBe("Invalid customer data");
    });

    test("CUS-007: Special characters in customer name are rejected", async () => {
      const response = await request(app)
        .post("/api/customers")
        .set(authorizationHeader(superAdminToken))
        .send({
          name: "Jest@Customer!",
          phoneNumber: createdPhoneNumber,
        })
        .expect(400);

      expect(response.body.message).toBe("Invalid customer data");
    });

    test("CUS-008: Customer name over 100 characters is rejected", async () => {
      const response = await request(app)
        .post("/api/customers")
        .set(authorizationHeader(superAdminToken))
        .send({
          name: "A".repeat(101),
          phoneNumber: createdPhoneNumber,
        })
        .expect(400);

      expect(response.body.message).toBe("Invalid customer data");
    });

    test.each([
      ["CUS-009", "123456789"],
      ["CUS-010", "12345678901"],
      ["CUS-011", "98765ABCDE"],
      ["CUS-012", "98765-4321"],
    ])("%s: Invalid phone %s is rejected", async (testId, phone) => {
      const response = await request(app)
        .post("/api/customers")
        .set(authorizationHeader(superAdminToken))
        .send({
          name: "Jest Customer",
          phoneNumber: phone,
        })
        .expect(400);

      expect(response.body.message).toBe("Invalid customer data");
    });

    test("CUS-063: Array request body is rejected", async () => {
      const response = await request(app)
        .post("/api/customers")
        .set(authorizationHeader(superAdminToken))
        .send([
          {
            name: "Jest Customer",
            phoneNumber: createdPhoneNumber,
          },
        ])
        .expect(400);

      expect(response.body.message).toBe("Invalid request body");
    });

    test("CUS-064: Null body is rejected", async () => {
      const response = await request(app)
        .post("/api/customers")
        .set(authorizationHeader(superAdminToken))
        .send(null)
        .expect(400);

      expect(response.body.message).toBe(
        "name and phoneNumber must be strings",
      );
    });

    test("CUS-065: Empty object is rejected", async () => {
      const response = await request(app)
        .post("/api/customers")
        .set(authorizationHeader(superAdminToken))
        .send({})
        .expect(400);

      expect(response.body.message).toBe(
        "name and phoneNumber must be strings",
      );
    });

    test("CUS-073: String active status is rejected", async () => {
      const response = await request(app)
        .post("/api/customers")
        .set(authorizationHeader(superAdminToken))
        .send({
          name: "Jest Customer",
          phoneNumber: createdPhoneNumber,
          isActive: "false",
        })
        .expect(400);

      expect(response.body.message).toBe("isActive must be a boolean");
    });
  });

  describe("5. Customer CRUD and all customer fields", () => {
    test("CUS-001: Create customer with every supported field", async () => {
      const response = await request(app)
        .post("/api/customers")
        .set(authorizationHeader(superAdminToken))
        .send({
          name: "  Jest Customer  ",
          phoneNumber: `  ${createdPhoneNumber}  `,
          address: "12 Test Main Road",
          doorNo: "12A",
          block: "B Block",
          apartmentName: "Jest Residency",
          landmark: "Near Test Park",
          area: "Tallakulam",
          city: "Madurai",
          pincode: "625002",
          isActive: true,
        })
        .expect("Content-Type", /json/)
        .expect(201);

      expect(response.body).toMatchObject({
        name: "Jest Customer",
        phoneNumber: createdPhoneNumber,
        address: "12 Test Main Road",
        doorNo: "12A",
        block: "B Block",
        apartmentName: "Jest Residency",
        landmark: "Near Test Park",
        area: "Tallakulam",
        city: "Madurai",
        pincode: "625002",
        isActive: true,
      });

      expect(response.body).toHaveProperty("_id");
      expect(response.body.customerId).toMatch(/^CUS_/);
      expect(response.body).toHaveProperty("createdAt");
      expect(response.body).toHaveProperty("updatedAt");
      expect(response.body).not.toHaveProperty("password");

      createdCustomerId = response.body._id;
      originalCustomerId = createdCustomerId;
    });

    test("CUS-013: Duplicate phone number is rejected", async () => {
      const response = await request(app)
        .post("/api/customers")
        .set(authorizationHeader(superAdminToken))
        .send({
          name: "Jest Duplicate Customer",
          phoneNumber: createdPhoneNumber,
        })
        .expect(409);

      expect(response.body.message).toBe("Phone number already exists");
    });

    test("CUS-015: Get customer using MongoDB ID", async () => {
      const response = await request(app)
        .get(`/api/customers/${createdCustomerId}`)
        .set(authorizationHeader(superAdminToken))
        .expect(200);

      expect(response.body._id).toBe(createdCustomerId);
      expect(response.body.phoneNumber).toBe(createdPhoneNumber);
    });

    test("Get customer using sequential customer ID", async () => {
      const customer = await Customer.findById(createdCustomerId);

      const response = await request(app)
        .get(`/api/customers/${customer.customerId}`)
        .set(authorizationHeader(superAdminToken))
        .expect(200);

      expect(response.body._id).toBe(createdCustomerId);
    });

    test("Get customer using phone number", async () => {
      const response = await request(app)
        .get(`/api/customers/${createdPhoneNumber}`)
        .set(authorizationHeader(superAdminToken))
        .expect(200);

      expect(response.body._id).toBe(createdCustomerId);
    });

    test("CUS-017: Nonexistent customer returns 404", async () => {
      const response = await request(app)
        .get(`/api/customers/${nonexistentObjectId}`)
        .set(authorizationHeader(superAdminToken))
        .expect(404);

      expect(response.body.message).toBe("Customer not found");
    });

    test("CUS-018: Get all customers returns an array", async () => {
      const response = await request(app)
        .get("/api/customers")
        .set(authorizationHeader(superAdminToken))
        .expect(200);

      expect(Array.isArray(response.body)).toBe(true);

      const customer = response.body.find(
        (item) => item._id === createdCustomerId,
      );

      expect(customer).toBeDefined();
      expect(customer).toHaveProperty("serviceFrequency");
      expect(customer).toHaveProperty("subscriptionType");
      expect(customer).toHaveProperty("activeSubscriptionCount");
    });

    test.each([
      ["CUS-019", "Jest Customer"],
      ["CUS-020", createdPhoneNumber],
      ["CUS-021", "Tallakulam"],
      ["CUS-023", "jest customer"],
      ["CUS-024", "Jest Cust"],
      ["CUS-025", createdPhoneNumber.slice(0, 6)],
      ["CUS-026", "Talla"],
    ])("%s: Customer search works for %s", async (testId, search) => {
      const response = await request(app)
        .get("/api/customers")
        .query({ search })
        .set(authorizationHeader(superAdminToken))
        .expect(200);

      expect(Array.isArray(response.body)).toBe(true);
      expect(
        response.body.some((customer) => customer._id === createdCustomerId),
      ).toBe(true);
    });

    test("CUS-022: Unknown customer search returns empty array", async () => {
      const response = await request(app)
        .get("/api/customers")
        .query({ search: "NoSuchCustomer987654321" })
        .set(authorizationHeader(superAdminToken))
        .expect(200);

      expect(response.body).toEqual([]);
    });

    test("Over-length search value returns 400", async () => {
      const response = await request(app)
        .get("/api/customers")
        .query({ search: "A".repeat(101) })
        .set(authorizationHeader(superAdminToken))
        .expect(400);

      expect(response.body.message).toBe("Invalid search value");
    });

    test("CUS-027: Update every supported customer field", async () => {
      const response = await request(app)
        .put(`/api/customers/${createdCustomerId}`)
        .set(authorizationHeader(superAdminToken))
        .send({
          name: "  Jest Updated Customer  ",
          phoneNumber: `  ${secondPhoneNumber}  `,
          address: "25 Updated Main Road",
          doorNo: "25B",
          block: "C Block",
          apartmentName: "Updated Residency",
          landmark: "Near Updated Park",
          area: "Anna Nagar",
          city: "Madurai",
          pincode: "625020",
          isActive: true,
        })
        .expect(200);

      expect(response.body).toMatchObject({
        name: "Jest Updated Customer",
        phoneNumber: secondPhoneNumber,
        address: "25 Updated Main Road",
        doorNo: "25B",
        block: "C Block",
        apartmentName: "Updated Residency",
        landmark: "Near Updated Park",
        area: "Anna Nagar",
        city: "Madurai",
        pincode: "625020",
        isActive: true,
      });
    });

    test("CUS-068: Empty update is rejected", async () => {
      const response = await request(app)
        .put(`/api/customers/${createdCustomerId}`)
        .set(authorizationHeader(superAdminToken))
        .send({})
        .expect(400);

      expect(response.body.message).toBe("No valid fields to update");
    });

    test("CUS-069: Unknown-only update is rejected", async () => {
      const response = await request(app)
        .put(`/api/customers/${createdCustomerId}`)
        .set(authorizationHeader(superAdminToken))
        .send({
          unknownField: "must not be saved",
        })
        .expect(400);

      expect(response.body.message).toBe("No valid fields to update");
    });

    test("CUS-070: Valid update ignores unknown fields", async () => {
      const response = await request(app)
        .put(`/api/customers/${createdCustomerId}`)
        .set(authorizationHeader(superAdminToken))
        .send({
          landmark: "Updated Test Landmark",
          unknownField: "must not be saved",
        })
        .expect(200);

      expect(response.body.landmark).toBe("Updated Test Landmark");
      expect(response.body).not.toHaveProperty("unknownField");

      const storedCustomer = await Customer.findById(createdCustomerId).lean();

      expect(storedCustomer).not.toHaveProperty("unknownField");
    });

    test("CUS-060: Protected customer fields cannot be modified", async () => {
      const customerBefore = await Customer.findById(createdCustomerId).lean();

      const response = await request(app)
        .put(`/api/customers/${createdCustomerId}`)
        .set(authorizationHeader(superAdminToken))
        .send({
          landmark: "Protected Field Test",
          customerId: "CUS_99999",
          _id: nonexistentObjectId,
          __v: 999,
          createdBy: nonexistentObjectId,
          updatedBy: nonexistentObjectId,
          createdAt: "2000-01-01T00:00:00.000Z",
          updatedAt: "2000-01-01T00:00:00.000Z",
        })
        .expect(200);

      expect(response.body.customerId).toBe(customerBefore.customerId);
      expect(response.body._id).toBe(createdCustomerId);

      const customerAfter = await Customer.findById(createdCustomerId).lean();

      expect(customerAfter.customerId).toBe(customerBefore.customerId);
      expect(String(customerAfter._id)).toBe(String(customerBefore._id));
      expect(customerAfter.__v).not.toBe(999);
      expect(new Date(customerAfter.createdAt).toISOString()).toBe(
        new Date(customerBefore.createdAt).toISOString(),
      );
    });

    test("CUS-033: Customer can be deactivated", async () => {
      const response = await request(app)
        .put(`/api/customers/${createdCustomerId}`)
        .set(authorizationHeader(superAdminToken))
        .send({ isActive: false })
        .expect(200);

      expect(response.body.isActive).toBe(false);
    });

    test("CUS-037: Inactive status filter returns only inactive customers", async () => {
      const response = await request(app)
        .get("/api/customers")
        .query({ isActive: "false" })
        .set(authorizationHeader(superAdminToken))
        .expect(200);

      expect(
        response.body.some((customer) => customer._id === createdCustomerId),
      ).toBe(true);

      expect(
        response.body.every((customer) => customer.isActive === false),
      ).toBe(true);
    });

    test("CUS-077: Active filter excludes inactive customer", async () => {
      const response = await request(app)
        .get("/api/customers")
        .query({ isActive: "true" })
        .set(authorizationHeader(superAdminToken))
        .expect(200);

      expect(
        response.body.some((customer) => customer._id === createdCustomerId),
      ).toBe(false);

      expect(
        response.body.every((customer) => customer.isActive === true),
      ).toBe(true);
    });

    test("CUS-078: Invalid active status filter is rejected", async () => {
      const response = await request(app)
        .get("/api/customers")
        .query({ isActive: "yes" })
        .set(authorizationHeader(superAdminToken))
        .expect(400);

      expect(response.body.message).toBe("isActive must be true or false");
    });

    test("CUS-038 and CUS-080: Search and inactive filter work together", async () => {
      const response = await request(app)
        .get("/api/customers")
        .query({
          search: secondPhoneNumber,
          isActive: "false",
        })
        .set(authorizationHeader(superAdminToken))
        .expect(200);

      expect(response.body).toHaveLength(1);
      expect(response.body[0]._id).toBe(createdCustomerId);
      expect(response.body[0].isActive).toBe(false);
    });

    test("CUS-039: Customer can be reactivated", async () => {
      const response = await request(app)
        .put(`/api/customers/${createdCustomerId}`)
        .set(authorizationHeader(superAdminToken))
        .send({ isActive: true })
        .expect(200);

      expect(response.body.isActive).toBe(true);
    });
  });

  describe("6. Customer security and authorization", () => {
    test.each([
      ["GET", "/api/customers"],
      ["POST", "/api/customers"],
      ["PUT", `/api/customers/${nonexistentObjectId}`],
      ["DELETE", `/api/customers/${nonexistentObjectId}`],
    ])("%s %s without token returns 401", async (method, endpoint) => {
      let apiRequest = request(app)[method.toLowerCase()](endpoint);

      if (["POST", "PUT"].includes(method)) {
        apiRequest = apiRequest.send({
          name: "Jest Customer",
          phoneNumber: generatePhoneNumber("9"),
        });
      }

      const response = await apiRequest;

      expect(response.statusCode).toBe(401);
      expect(response.body.message).toBe("Access denied. No token provided.");
    });

    test("CUS-053: Read-only user can read customers", async () => {
      const response = await request(app)
        .get("/api/customers")
        .set(authorizationHeader(readOnlyToken))
        .expect(200);

      expect(Array.isArray(response.body)).toBe(true);
    });

    test("CUS-054: Read-only user cannot create customer", async () => {
      const response = await request(app)
        .post("/api/customers")
        .set(authorizationHeader(readOnlyToken))
        .send({
          name: "Blocked Customer",
          phoneNumber: generatePhoneNumber("9"),
        })
        .expect(403);

      expect(response.body.message).toBe("Insufficient permissions");
    });

    test("CUS-055: Read-only user cannot update customer", async () => {
      const response = await request(app)
        .put(`/api/customers/${createdCustomerId}`)
        .set(authorizationHeader(readOnlyToken))
        .send({
          landmark: "Unauthorized Update",
        })
        .expect(403);

      expect(response.body.message).toBe("Insufficient permissions");
    });

    test("CUS-056: Read-only user cannot delete customer", async () => {
      const response = await request(app)
        .delete(`/api/customers/${createdCustomerId}`)
        .set(authorizationHeader(readOnlyToken))
        .expect(403);

      expect(response.body.message).toBe("Insufficient permissions");
    });

    test("CUS-057 and CUS-058: Customer remains unchanged after unauthorized requests", async () => {
      const response = await request(app)
        .get(`/api/customers/${createdCustomerId}`)
        .set(authorizationHeader(superAdminToken))
        .expect(200);

      expect(response.body.landmark).not.toBe("Unauthorized Update");
    });

    test("CUS-043: Delete with invalid identifier returns 400", async () => {
      const response = await request(app)
        .delete("/api/customers/123")
        .set(authorizationHeader(superAdminToken))
        .expect(400);

      expect(response.body.message).toBe("Invalid identifier");
    });

    test("CUS-045: Update with invalid identifier returns 400", async () => {
      const response = await request(app)
        .put("/api/customers/123")
        .set(authorizationHeader(superAdminToken))
        .send({ landmark: "Invalid ID Test" })
        .expect(400);

      expect(response.body.message).toBe("Invalid identifier");
    });

    test("CUS-044: Delete with nonexistent ID returns 404", async () => {
      const response = await request(app)
        .delete(`/api/customers/${nonexistentObjectId}`)
        .set(authorizationHeader(superAdminToken))
        .expect(404);

      expect(response.body.message).toBe("Customer not found");
    });

    test("CUS-046: Update with nonexistent ID returns 404", async () => {
      const response = await request(app)
        .put(`/api/customers/${nonexistentObjectId}`)
        .set(authorizationHeader(superAdminToken))
        .send({ landmark: "Nonexistent Customer" })
        .expect(404);

      expect(response.body.message).toBe("Customer not found");
    });
  });

  describe("7. Other API negative and route tests", () => {
    const invalidIdGetEndpoints = [
      "/api/users/123",
      "/api/roles/123",
      "/api/bookings/BKG_NOT_FOUND",
      "/api/service-durations/123",
      "/api/service-frequencies/123",
      "/api/subscription-types/123",
      "/api/subscriptions/123",
      "/api/time-slots/123",
      "/api/payment-methods/123",
      "/api/accounts/123",
      "/api/invoices/123",
      "/api/pricing/123",
      "/api/bathroom-counts/123",
      "/api/payment-masters/123",
      "/api/service-payments/123",
      "/api/visits/123",
      "/api/booking-dates/123",
    ];

    test.each(invalidIdGetEndpoints)(
      "GET %s returns a controlled client or not-found response",
      async (endpoint) => {
        const response = await request(app)
          .get(endpoint)
          .set(authorizationHeader(superAdminToken));

        expect([400, 404, 500]).toContain(response.statusCode);
        expect(response.headers["content-type"]).toMatch(/json/);
        expect(response.body).toHaveProperty("message");
      },
    );

    test("Booking availability without date returns 400", async () => {
      const response = await request(app)
        .get("/api/bookings/availability")
        .set(authorizationHeader(superAdminToken))
        .expect(400);

      expect(response.body.message).toContain(
        "scheduledDate or date is required",
      );
    });

    test("Time-slot availability without date returns 400", async () => {
      const response = await request(app)
        .get("/api/time-slots/availability")
        .set(authorizationHeader(superAdminToken))
        .expect(400);

      expect(response.body.message).toContain(
        "scheduledDate or date is required",
      );
    });

    test("Booking preview without pricing ID returns 400", async () => {
      const response = await request(app)
        .post("/api/bookings/preview")
        .set(authorizationHeader(superAdminToken))
        .send({
          scheduledDate: "2026-10-10",
        })
        .expect(400);

      expect(response.body.message).toBe("pricingId is required");
    });

    test("Booking create without customer returns 400", async () => {
      const response = await request(app)
        .post("/api/bookings")
        .set(authorizationHeader(superAdminToken))
        .send({})
        .expect(400);

      expect(response.body.message).toBe("customerId is required");
    });

    test("Service frequency rejects invalid interval", async () => {
      const response = await request(app)
        .post("/api/service-frequencies")
        .set(authorizationHeader(superAdminToken))
        .send({
          frequencyName: "Invalid Jest Frequency",
          intervalDays: 0,
        })
        .expect(400);

      expect(response.body.message).toBe(
        "intervalDays must be a positive whole number",
      );
    });

    test("Time slot requires start and end time", async () => {
      const response = await request(app)
        .post("/api/time-slots")
        .set(authorizationHeader(superAdminToken))
        .send({
          bufferTime: 30,
        })
        .expect(400);

      expect(response.body.message).toBe("startTime and endTime are required");
    });

    test("Payment method name is required", async () => {
      const response = await request(app)
        .post("/api/payment-methods")
        .set(authorizationHeader(superAdminToken))
        .send({})
        .expect(400);

      expect(response.body.message).toBe("paymentMethodName is required");
    });

    test("Payment account name is required", async () => {
      const response = await request(app)
        .post("/api/accounts")
        .set(authorizationHeader(superAdminToken))
        .send({})
        .expect(400);

      expect(response.body.message).toBe("accountName is required");
    });

    test("Bathroom count is required", async () => {
      const response = await request(app)
        .post("/api/bathroom-counts")
        .set(authorizationHeader(superAdminToken))
        .send({})
        .expect(400);

      expect(response.body.message).toBe("bathroomCount is required");
    });

    test("Service duration is required", async () => {
      const response = await request(app)
        .post("/api/service-durations")
        .set(authorizationHeader(superAdminToken))
        .send({})
        .expect(400);

      expect(response.body.message).toBe("durationMinutes is required");
    });

    test("Subscription type name is required", async () => {
      const response = await request(app)
        .post("/api/subscription-types")
        .set(authorizationHeader(superAdminToken))
        .send({})
        .expect(400);

      expect(response.body.message).toBe("subscriptionName is required");
    });

    test("Pricing requires all required references", async () => {
      const response = await request(app)
        .post("/api/pricing")
        .set(authorizationHeader(superAdminToken))
        .send({})
        .expect(400);

      expect(response.body.message).toContain("bathroomCountReference");
    });

    test("Invoice requires all required references", async () => {
      const response = await request(app)
        .post("/api/invoices")
        .set(authorizationHeader(superAdminToken))
        .send({})
        .expect(400);

      expect(response.body.message).toContain("customerReference");
    });

    test("Payment master requires tax and discount rates", async () => {
      const response = await request(app)
        .post("/api/payment-masters")
        .set(authorizationHeader(superAdminToken))
        .send({})
        .expect(400);

      expect(response.body.message).toContain("cgstRate");
    });

    test("Booking date requires startDateTime", async () => {
      const response = await request(app)
        .post("/api/booking-dates")
        .set(authorizationHeader(superAdminToken))
        .send({})
        .expect(400);

      expect(response.body.message).toBe("startDateTime is required");
    });
  });

  describe("8. Final customer deletion", () => {
    test("CUS-041: Delete customer using valid ID", async () => {
      const response = await request(app)
        .delete(`/api/customers/${createdCustomerId}`)
        .set(authorizationHeader(superAdminToken))
        .expect(200);

      expect(response.body.message).toBe("Customer deleted successfully");
    });

    test("CUS-042: Deleted customer is no longer available", async () => {
      const response = await request(app)
        .get(`/api/customers/${createdCustomerId}`)
        .set(authorizationHeader(superAdminToken))
        .expect(404);

      expect(response.body.message).toBe("Customer not found");

      createdCustomerId = null;
    });
  });
});
