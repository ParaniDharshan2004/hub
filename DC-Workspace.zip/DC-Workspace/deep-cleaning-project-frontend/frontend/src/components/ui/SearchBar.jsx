import TextField from "@mui/material/TextField";
import InputAdornment from "@mui/material/InputAdornment";
import IconButton from "@mui/material/IconButton";
import { SearchIcon, CloseIcon } from "@/theme/icons";

/**
 * SearchBar — reusable search input with a leading search icon and optional
 * clear button that appears when the field has a value.
 *
 * Props:
 *   value        {string}   – controlled value
 *   onChange     {fn}       – called with the new string value
 *   placeholder  {string}   – input placeholder text
 *   sx           {object}   – additional sx overrides for the TextField
 */
export default function SearchBar({
  value,
  onChange,
  placeholder = "Search...",
  fullWidth = true,
  sx,
}) {
  return (
    <TextField
      fullWidth={fullWidth}
      size="small"
      placeholder={placeholder}
      value={value}
      onChange={(e) => onChange(e.target.value)}
      sx={{ flex: 1, width: "100%", minWidth: { xs: "100%", sm: 260 }, ...sx }}
      InputProps={{
        startAdornment: (
          <InputAdornment position="start">
            <SearchIcon fontSize="small" sx={{ color: "text.secondary" }} />
          </InputAdornment>
        ),
        ...(value && {
          endAdornment: (
            <InputAdornment position="end">
              <IconButton size="small" onClick={() => onChange("")} aria-label="Clear search">
                <CloseIcon fontSize="small" />
              </IconButton>
            </InputAdornment>
          ),
        }),
      }}
    />
  );
}
