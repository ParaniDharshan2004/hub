import { useMemo } from "react";
import Paper from "@mui/material/Paper";
import { DataGrid } from "@mui/x-data-grid";
import { EmptyState, ErrorState } from "@/components/feedback/PageStates";

/** Shared DataGrid row / header styles applied to every table instance */
const TABLE_SX = {
  border: "none",
  "& .MuiDataGrid-row": {
    cursor: "pointer",
    "&:hover": { bgcolor: "#F3F7F6" },
  },
  "& .MuiDataGrid-columnHeaders": { bgcolor: "#F3F7F6" },
};

export default function DataTable({
  rows = [],
  columns = [],
  loading = false,
  isError = false,
  error,
  onRetry,
  emptyTitle = "No records found",
  emptyDescription = "",
  emptyActionLabel,
  onEmptyAction,
  onRowClick,
  getRowId,
  columnVisibility,
  onColumnVisibilityChange,
  pageSizeOptions = [10, 25, 50],
  initialPageSize = 10,
  sx,
  gridSx,
  ...rest
}) {
  const initialStateModel = useMemo(
    () => ({ pagination: { paginationModel: { pageSize: initialPageSize } } }),
    [initialPageSize],
  );

  const mergedGridSx = useMemo(
    () => ({ ...TABLE_SX, ...gridSx }),
    [gridSx],
  );

  return (
    <Paper
      variant="outlined"
      sx={{ borderRadius: 1, overflow: "hidden", ...sx }}
    >
      {isError ? (
        <ErrorState message={error?.message} onRetry={onRetry} />
      ) : !loading && rows.length === 0 ? (
        <EmptyState
          title={emptyTitle}
          description={emptyDescription}
          actionLabel={emptyActionLabel}
          onAction={onEmptyAction}
        />
      ) : (
        <DataGrid
          rows={rows}
          columns={columns}
          loading={loading}
          autoHeight
          disableRowSelectionOnClick
          disableColumnResize
          onRowClick={onRowClick}
          getRowId={getRowId}
          columnVisibilityModel={columnVisibility}
          onColumnVisibilityModelChange={onColumnVisibilityChange}
          initialState={initialStateModel}
          pageSizeOptions={pageSizeOptions}
          sx={mergedGridSx}
          {...rest}
        />
      )}
    </Paper>
  );
}
