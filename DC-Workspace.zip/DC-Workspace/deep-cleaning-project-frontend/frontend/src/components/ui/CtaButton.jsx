import Button from "@mui/material/Button";
import CircularProgress from "@mui/material/CircularProgress";

/**
 * CtaButton — Shared primary Call-To-Action button component.
 *
 * Props:
 *   children     {node}     – Button label / text content
 *   icon         {node}     – Leading icon (shorthand for startIcon)
 *   startIcon    {node}     – Standard startIcon
 *   endIcon      {node}     – Standard endIcon
 *   variant      {string}   – Defaults to "contained"
 *   color        {string}   – Defaults to "primary"
 *   loading      {boolean}  – Displays a loading spinner & disables button
 *   disabled     {boolean}
 *   size         {string}   – "small" | "medium" | "large"
 *   sx           {object}   – Custom sx style overrides
 *   [rest]                  – Forwarded to MUI Button (onClick, type, etc.)
 */
export default function CtaButton({
  children,
  icon,
  startIcon,
  endIcon,
  variant = "contained",
  color = "primary",
  loading = false,
  disabled = false,
  size = "medium",
  sx,
  ...props
}) {
  const leadingIcon = loading ? (
    <CircularProgress size={16} color="inherit" />
  ) : (
    icon || startIcon
  );

  return (
    <Button
      variant={variant}
      color={color}
      size={size}
      disabled={disabled || loading}
      startIcon={leadingIcon}
      endIcon={loading ? undefined : endIcon}
      sx={{
        fontWeight: 600,
        textTransform: "none",
        borderRadius: 1,
        px: size === "small" ? 1.75 : size === "large" ? 3 : 2.5,
        py: size === "small" ? 0.6 : size === "large" ? 1.2 : 0.85,
        boxShadow: variant === "contained" && color === "primary"
          ? "0 2px 6px rgba(15, 92, 87, 0.2)"
          : "none",
        "&:hover": {
          boxShadow: variant === "contained" && color === "primary"
            ? "0 4px 12px rgba(15, 92, 87, 0.3)"
            : "none",
        },
        ...sx,
      }}
      {...props}
    >
      {children}
    </Button>
  );
}
