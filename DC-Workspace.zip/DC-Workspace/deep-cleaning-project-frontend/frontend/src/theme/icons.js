/**
 * theme/icons.js
 * ─────────────────────────────────────────────────────────────────────────────
 * SINGLE SOURCE OF TRUTH for active MUI icon imports in the application.
 *
 * Provides named exports for all UI features while pruning unused template icons.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import MenuIcon from "@mui/icons-material/Menu";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import ExpandMoreIcon from "@mui/icons-material/ExpandMore";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import NavigateNextIcon from "@mui/icons-material/NavigateNext";
import HomeOutlinedIcon from "@mui/icons-material/HomeOutlined";

import AddIcon from "@mui/icons-material/Add";
import EditIcon from "@mui/icons-material/Edit";
import EditOutlinedIcon from "@mui/icons-material/EditOutlined";
import SaveIcon from "@mui/icons-material/Save";
import DeleteIcon from "@mui/icons-material/Delete";
import CloseIcon from "@mui/icons-material/Close";
import RefreshIcon from "@mui/icons-material/Refresh";

import SearchIcon from "@mui/icons-material/Search";
import ClearIcon from "@mui/icons-material/Clear";
import FilterAltOffIcon from "@mui/icons-material/FilterAltOff";
import TuneOutlinedIcon from "@mui/icons-material/TuneOutlined";

import CheckIcon from "@mui/icons-material/Check";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CheckCircleOutlineIcon from "@mui/icons-material/CheckCircleOutline";
import CheckCircleRoundedIcon from "@mui/icons-material/CheckCircleRounded";
import ErrorOutlineIcon from "@mui/icons-material/ErrorOutline";
import ReplayIcon from "@mui/icons-material/Replay";
import InboxOutlinedIcon from "@mui/icons-material/InboxOutlined";
import ConstructionOutlinedIcon from "@mui/icons-material/ConstructionOutlined";

import VisibilityIcon from "@mui/icons-material/Visibility";
import LockIcon from "@mui/icons-material/Lock";
import LockOutlinedIcon from "@mui/icons-material/LockOutlined";
import AdminPanelSettingsOutlinedIcon from "@mui/icons-material/AdminPanelSettingsOutlined";
import RuleIcon from "@mui/icons-material/Rule";

import ToggleOnIcon from "@mui/icons-material/ToggleOn";
import ToggleOffIcon from "@mui/icons-material/ToggleOff";

import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import KeyboardArrowUpIcon from "@mui/icons-material/KeyboardArrowUp";

import PersonIcon from "@mui/icons-material/Person";
import PersonOutlineIcon from "@mui/icons-material/PersonOutline";
import PeopleAltOutlinedIcon from "@mui/icons-material/PeopleAltOutlined";
import MoreVertIcon from "@mui/icons-material/MoreVert";
import AccountCircleOutlinedIcon from "@mui/icons-material/AccountCircleOutlined";

import EventIcon from "@mui/icons-material/Event";
import EventNoteOutlinedIcon from "@mui/icons-material/EventNoteOutlined";
import EventRepeatIcon from "@mui/icons-material/EventRepeat";
import CalendarMonthOutlinedIcon from "@mui/icons-material/CalendarMonthOutlined";
import TodayIcon from "@mui/icons-material/Today";
import AccessTimeIcon from "@mui/icons-material/AccessTime";
import AccessTimeOutlinedIcon from "@mui/icons-material/AccessTimeOutlined";

import BathtubIcon from "@mui/icons-material/Bathtub";
import BathtubOutlinedIcon from "@mui/icons-material/BathtubOutlined";
import CleaningServicesOutlinedIcon from "@mui/icons-material/CleaningServicesOutlined";
import PlaceIcon from "@mui/icons-material/Place";
import PlaceOutlinedIcon from "@mui/icons-material/PlaceOutlined";
import AddLocationAltOutlinedIcon from "@mui/icons-material/AddLocationAltOutlined";

import PaymentsOutlinedIcon from "@mui/icons-material/PaymentsOutlined";
import ReceiptLongOutlinedIcon from "@mui/icons-material/ReceiptLongOutlined";
import ReceiptLongRoundedIcon from "@mui/icons-material/ReceiptLongRounded";

import PrintIcon from "@mui/icons-material/Print";
import PrintOutlinedIcon from "@mui/icons-material/PrintOutlined";

import AutorenewOutlinedIcon from "@mui/icons-material/AutorenewOutlined";

import BarChartOutlinedIcon from "@mui/icons-material/BarChartOutlined";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";
import InsightsRoundedIcon from "@mui/icons-material/InsightsRounded";

import DashboardOutlinedIcon from "@mui/icons-material/DashboardOutlined";
import SettingsOutlinedIcon from "@mui/icons-material/SettingsOutlined";
import NotificationsOutlinedIcon from "@mui/icons-material/NotificationsOutlined";
import LogoutOutlinedIcon from "@mui/icons-material/LogoutOutlined";

export {
  MenuIcon,
  ExpandLessIcon,
  ExpandMoreIcon,
  ChevronLeftIcon,
  ChevronRightIcon,
  NavigateNextIcon,
  HomeOutlinedIcon,
  AddIcon,
  EditIcon,
  EditOutlinedIcon,
  SaveIcon,
  DeleteIcon,
  CloseIcon,
  RefreshIcon,
  SearchIcon,
  ClearIcon,
  FilterAltOffIcon,
  TuneOutlinedIcon,
  CheckIcon,
  CheckCircleIcon,
  CheckCircleOutlineIcon,
  CheckCircleRoundedIcon,
  ErrorOutlineIcon,
  ReplayIcon,
  InboxOutlinedIcon,
  ConstructionOutlinedIcon,
  VisibilityIcon,
  LockIcon,
  LockOutlinedIcon,
  AdminPanelSettingsOutlinedIcon,
  RuleIcon,
  ToggleOnIcon,
  ToggleOffIcon,
  KeyboardArrowDownIcon,
  KeyboardArrowUpIcon,
  PersonIcon,
  PersonOutlineIcon,
  PeopleAltOutlinedIcon,
  MoreVertIcon,
  AccountCircleOutlinedIcon,
  EventIcon,
  EventNoteOutlinedIcon,
  EventRepeatIcon,
  CalendarMonthOutlinedIcon,
  TodayIcon,
  AccessTimeIcon,
  AccessTimeOutlinedIcon,
  BathtubIcon,
  BathtubOutlinedIcon,
  CleaningServicesOutlinedIcon,
  PlaceIcon,
  PlaceOutlinedIcon,
  AddLocationAltOutlinedIcon,
  PaymentsOutlinedIcon,
  ReceiptLongOutlinedIcon,
  ReceiptLongRoundedIcon,
  PrintIcon,
  PrintOutlinedIcon,
  AutorenewOutlinedIcon,
  BarChartOutlinedIcon,
  TrendingUpIcon,
  InsightsRoundedIcon,
  DashboardOutlinedIcon,
  SettingsOutlinedIcon,
  NotificationsOutlinedIcon,
  LogoutOutlinedIcon,
};

export const Icons = {
  menu: MenuIcon,
  expandless: ExpandLessIcon,
  expandmore: ExpandMoreIcon,
  chevronleft: ChevronLeftIcon,
  chevronright: ChevronRightIcon,
  visibility: VisibilityIcon,
  check: CheckIcon,
  checkcircle: CheckCircleRoundedIcon,
  receiptlong: ReceiptLongRoundedIcon,
  insights: InsightsRoundedIcon,
  person: PersonIcon,
  place: PlaceIcon,
  trendingup: TrendingUpIcon,
};

export default Icons;
