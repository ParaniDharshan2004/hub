// theme/components.js

const components = {
  MuiTypography: {
    defaultProps: {
      variantMapping: {
        body3: "p",
        points: "p",
        mono: "code",
      },
    },
  },

  MuiCssBaseline: {
    styleOverrides: `
      @import url('@fontsource/dm-sans/400.css');
      @import url('@fontsource/dm-sans/500.css');
      @import url('@fontsource/dm-sans/600.css');
      @import url('@fontsource/dm-sans/700.css');

      * {
        box-sizing: border-box;
      }

      body {
        margin: 0;
        font-family: 'DM Sans', sans-serif;
      }
    `,
  },

  MuiButton: {
    styleOverrides: {
      root: {
        borderRadius: 8,
      },
    },
  },

  MuiDrawer: {
    styleOverrides: {
      modal: {
        zIndex: 1300,
      },
    },
  },
};

export default components;